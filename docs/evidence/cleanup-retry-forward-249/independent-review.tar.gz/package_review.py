"""Bind original closed audit and seal exact capture-249 retry review; no replay."""
from pathlib import Path,PurePosixPath
import hashlib
import json
import shutil
import subprocess
import tarfile

ROOT=Path('/Users/arjunhans/Documents/ctc2026')
OUT=Path(__file__).parent
PARENT=ROOT/'out/cleanup-retry-forward-20261024'
ORIGIN=PARENT/'capture-249'
RUN=ORIGIN/'attempt-02'
SOURCE=ROOT/'.worktrees/cleanup-retry-forward'
REV='2c441aee5b5f828bc4c4e26461159a958c102067'
sha=lambda b:hashlib.sha256(b).hexdigest()
digest=lambda p:sha(Path(p).read_bytes())
load=lambda p:json.loads(Path(p).read_bytes())
vh=lambda x:sha(json.dumps(x,sort_keys=True,allow_nan=False).encode())

def verify_archive(path,count,h,manifest_name):
    assert digest(path)==h
    with tarfile.open(path) as tf:
        ms=tf.getmembers();assert len(ms)==len({m.name for m in ms})
        for m in ms:
            assert m.isfile() or m.isdir();p=PurePosixPath(m.name);assert not p.is_absolute() and '..' not in p.parts
        files={m.name:tf.extractfile(m).read() for m in ms if m.isfile()}
    assert len(files)==count
    manifest=json.loads(files[manifest_name]);entries=manifest.get('files',manifest)
    assert set(entries)==set(files)-{manifest_name}
    for n,v in entries.items():
        assert sha(files[n])==(v['sha256'] if isinstance(v,dict) else v)
        if isinstance(v,dict) and 'bytes' in v:assert len(files[n])==v['bytes']
    return files

pre=load(OUT/'prerequisites.json');audit=load(OUT/'candidate-audit.json')
reruns=load(OUT/'authorized-reruns/independent-reruns.json');traces=load(OUT/'analysis-trace-check.json')
assert audit['source_revision']==REV and audit['failed_rules']==audit['affected_attention_settings']==audit['forbidden_attempts']==[]
assert audit['unchanged_runtime_pairs']==16 and audit['identical_standard_journals']==112
assert reruns['authorized_settings']==reruns['successful_reproductions']==2 and reruns['successful_cases_reused_from_previous_invocation']==0
assert reruns['forbidden_attempts']==[] and all(c['fatal_errors']==[] for c in reruns['cases'])
assert traces['all_18_rerun_file_hashes_valid'] and traces['all_32_analyzer_pair_descriptions_exact']
for p,h in pre['source_input_sha256'].items():assert digest(p)==h
for p,h in audit['produced_file_hashes'].items():assert digest(p)==h
for n,h in pre['copied_baseline_file_hashes'].items():assert digest(ORIGIN/'baseline'/n)==digest(RUN/'baseline'/n)==h
assert subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip()==REV
assert not subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'])

original_dir=ROOT/'out/capture-249-independent-review-20261024'
original_archive=ROOT/'out/capture-249-independent-review-20261024.tar.gz'
original_files=verify_archive(original_archive,222,'4ec47a0b7d8ecce8b6c38008a8b4bfd2258c2fed1ddce04221caece7c4670729','artifact-hashes.json')
for n,b in original_files.items():assert (original_dir/n).read_bytes()==b
assert digest(original_dir/'audit.json')=='295b9f787dc47644e3998b78ad8ce29540283a4e2dd661f1dbfc71b1faf9205f'
assert digest(original_dir/'verification.json')=='1ff6ad67c1a300ee0917601a305c48f1509b905922aaf130a22a8921135b9d76'
original=load(original_dir/'audit.json');verification=load(original_dir/'verification.json')
assert [r['exact_library_rows_zero_based'] for r in original['overlap']]==[[744],[745],[746]]
assert all(r['observations']==241 and r['closest_rmse']==0 and r['repeated_identical']==0 for r in original['overlap'])
assert original['npz_sha256']==digest(SOURCE/'ctc/analog_library.npz')
original_cache=load(original_dir/'249.json');cache=load(PARENT/'249.json')
assert original_cache['frames']==cache['frames'] and original_cache['receipt']==cache['receipt']
assert vh(cache['frames'])==pre['frames_sha256'] and vh(cache['receipt'])==pre['receipt_sha256']
assert verification['unique_news_sequences']==862 and verification['final_report_round_and_seq']==[[1,283],[2,569],[3,861]]
assert verification['performance_rerun_count']==6 and verification['candidate_runs']==0 and verification['replay_failures']==[]
preflight=verify_archive(PARENT/'preflight-final-approved.tar.gz',359,'e9ab0c1026422fb42155f5957476f6296a0fffc4658a6b6a1c8119e380c6c142','artifact-manifest.json')
rejected=verify_archive(PARENT/'preflight-initial-rejected.tar.gz',134,'fa281c52dab08a04d6f7a90f4f1a5a996180e3612ee91dcfbc702a86c26c4948','artifact-manifest.json')
assert preflight['initial-blocked-review.tar.gz']==(PARENT/'preflight-initial-rejected.tar.gz').read_bytes()
assert json.loads(preflight['verdict.json'])['head']==REV
binding={'original_archive_sha256':digest(original_archive),'original_archive_files':222,'original_member_sha256':{n:sha(b) for n,b in original_files.items()},
 'original_audit_sha256':digest(original_dir/'audit.json'),'original_verification_sha256':digest(original_dir/'verification.json'),
 'frames_sha256':vh(cache['frames']),'receipt_sha256':vh(cache['receipt']),'weather_overlap':original['overlap'],
 'original_performance_reruns_reused':6,'new_original_performance_runs':0,'news_sequences':862,'final_reports':verification['final_report_round_and_seq'],
 'largest_later_valid_quote_gap':verification['largest_later_valid_quote_gap'],'initial_quote_gaps':verification['initial_round1_snapshot_to_first_valid_quote_gaps'],
 'preflight_archive_sha256':digest(PARENT/'preflight-final-approved.tar.gz'),'preflight_files_verified':359,'rejected_preflight_files_verified':134}
(OUT/'original-audit-binding.json').write_text(json.dumps(binding,indent=2,sort_keys=True)+'\n')

def cp(src,relative):
    dst=OUT/relative;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);assert dst.read_bytes()==Path(src).read_bytes()
for phase in ['baseline','candidate']:
    for p in (RUN/phase).rglob('*'):
        if p.is_file():cp(p,Path('producer/attempt-02')/phase/p.relative_to(RUN/phase))
for n in ['candidate.stderr.log','candidate.stdout.log','analysis.json','analysis.stderr.log']:
    cp(RUN/n,Path('producer/attempt-02')/n)
for n in ['spec.json','baseline.stderr.log','baseline.stdout.log','candidate.stderr.log','candidate.stdout.log']:
    cp(ORIGIN/n,Path('producer/original-attempt')/n)
for n in ['metadata.json','results.jsonl','summary.json']:
    cp(ORIGIN/'baseline'/n,Path('producer/original-attempt/baseline')/n)
for n in ['analyze.py','seal-input.py','249-seal.stdout.json','249-seal.stderr.log','preflight-final-approved.tar.gz','preflight-initial-rejected.tar.gz']:
    cp(PARENT/n,Path('producer')/n)
cp(original_archive,'original-capture-audit.tar.gz')
for n in ['README.md','audit.json','verification.json','artifact-hashes.json']:
    cp(original_dir/n,Path('original-audit-summary')/n)
for n in ['bot/practice.py','scripts/compare_cleanup_retry_forward.py','docs/cleanup-retry-window-plan.md','docs/cleanup-retry-forward-plan.md']:
    cp(SOURCE/n,Path('reviewed-source')/n)
(OUT/'capture-249-attempts.jsonl').write_text(''.join(json.dumps(e,sort_keys=True)+'\n' for e in audit['attempt_events']))
(OUT/'baseline-copy-receipt.json').write_text(json.dumps({'source':str(ORIGIN/'baseline'),'copy':str(RUN/'baseline'),
 'files':pre['copied_baseline_file_hashes'],'file_count':147,'byte_identical':True,'baseline_reruns':0,
 'original_metadata_and_results_retained_separately':True,'all_original_baseline_bytes_retained_once_in_attempt_02':True},indent=2,sort_keys=True)+'\n')
verdict={'verdict':'PASS_PREDECLARED_CAPTURE_249_NO_OP_CONFIRMATION_NO_LIVE_ACTIVATION','source_revision':REV,
 'runtime_revision':'27ab7c4b4784c9aabc92e791b0878d387cd4cc49','blockers':[],
 'settings_per_phase':16,'rows_verified':32,'original_rows_exact':16,'original_journals_byte_exact':112,
 'produced_files_verified':288,'source_input_artifacts_verified':244,'bound_baseline_artifacts':147,'copied_baseline_files_byte_exact':147,
 'paired_runtime_results_identical':16,'paired_standard_journals_byte_identical':112,'paired_mutation_profiles_byte_identical':16,
 'cleanup_profiles_equal_except_source_lines':16,'all_analyzer_fields_independently_recomputed':True,'metrics':audit['metrics'],
 'actual_mutations_per_phase':audit['actual_mutations'],'maximum_rolling_mutations':27,'cleanup_mutations':0,'extra_mutations':0,
 'positive':16,'negative':0,'completed':16,'settled':16,'attention':0,'affected_attention_settings':[],
 'primary_terminal_pnl':audit['primary_terminal_pnl'],'primary_final_mark':audit['primary_final_mark'],
 'primary_nonzero_settled_holdings':audit['primary_settled_positions'],'primary_flat':audit['primary_flat'],
 'authorized_unique_candidate_reproductions':2,'candidate_replay_executions_by_reviewer':2,'duplicate_candidate_replay_executions':0,
 'representative_exact_files':18,'representative_cases':traces['full_trace_cases'],'guard_counters':reruns['counters_for_this_resume'],
 'forbidden_attempts':[],'reviewer_harness_or_replay_failures':[],'source_unchanged':True,
 'producer_initial_candidate_failure':pre['initial_candidate_invocation_failure'],'baseline_was_copied_not_rerun':True,
 'timing':audit['timing'],'weather_overlap':original['overlap'],'original_audit_archive_sha256':digest(original_archive),'original_audit_files':222,
 'original_audit_performance_reruns_reused':6,'new_original_engine_performance_runs':0,
 'evidence_sha256':{n:digest(OUT/n) for n in ['prerequisites.json','candidate-audit.json','analysis-trace-check.json','original-audit-binding.json','authorized-reruns/independent-reruns.json']},
 'declined_to_judge':['Live ownership, activation, account P&L, fill reliability or consistent profitability.',
 'Extra-pass effectiveness on this capture; every setting settled without cleanup mutations.',
 'Unseen-weather generalization: all three tracks match fitted rows 744-746.',
 'True quote completeness, disconnect onset, live priority, latency and market impact.',
 'Active capture 250 or later outcomes, additional settings, model changes or parameter variants.']}
(OUT/'verdict.json').write_text(json.dumps(verdict,indent=2,sort_keys=True)+'\n')
(OUT/'README.md').write_text('''# Independent capture-249 bounded-retry audit

## Judgment

**Pass the predeclared capture-249 no-op confirmation. No new blocker to the previously approved integration. No live activation approval.** The retry driver remains `2c441aee5b5f828bc4c4e26461159a958c102067`; all 28 runtime files match frozen retry source `27ab7c4`.

## Complete results and scope

The baseline and corrected candidate attempt each contain all 16 prescribed settings: RTT 0/0.05/0.25/1 seconds, full/half displayed depth, baskets off/on, 10% limits, 90 strategy actions/minute, zero prior P&L and the $250 sampled loss trigger. Both modes have 16 positive, completed, settled outcomes; no loss-trigger stop or attention outcome occurs. Mean terminal P&L is $1,485.758125, worst $1,014.34 and best $1,795.95.

All 16 runtime result rows are unchanged, including pre-cleanup request/fill hashes, stopping fields, first-five request hashes, fills, positions and full trace hashes. All 112 standard paired journals and 16 mutation profiles are byte-identical. Cleanup profiles differ only in source stack line numbers. Every field of the 32 analyzer descriptions and all complete aggregate/gate fields were independently recomputed and match the fixed analysis. No affected-attention case exists, so only the two predeclared representative reruns were needed.

Each complete phase contains 1,569 actual POST/DELETE starts, with maximum inclusive trailing-60-second count 27. There are zero cleanup or extra-pass mutations. This is compatibility evidence, not an additional test of retry effectiveness.

Primary terminal P&L is **$1,760.14**, distinct from its final contemporaneous mark of **$1,755.61**. Nine nonzero holdings remain settled. Settled is not flat, and these replay values are not account returns.

## Exactly two authorized candidate reruns

| Setting | Terminal P&L | Requests | Fills | Actual mutations | Maximum rolling mutations |
| --- | ---: | ---: | ---: | ---: | ---: |
| 0.25 s / full / baskets on | $1,760.14 | 4,523 | 59 | 88 | 8 |
| 1 s / half / baskets off | $1,348.52 | 2,159 | 57 | 59 | 7 |

Both reproduced every result field and all nine files, for 18 byte-exact files. Full request traces including GET responses and full fill traces are retained. Independent fill cash, basket transfers and settled holdings reconcile terminal P&L. Both passed on their first execution, with zero sticky guard violations and no duplicate executions or other settings.

Guards cover network/credentials/history access, terminal-price availability, complete observed history, competition identity, unchanged quote-callback history, true execution-time cleanup reduction, mutation budgets and extra-pass admission. These runs recorded 72 guarded settlement value reads and 111 history-ready strategy POST checks. Neither exercised a cleanup POST or extra-budget check. No additional original-engine performance run occurred; the original audit's six authorized reproductions are bound through its verified 222-file archive.

## Prerequisites and source binding

The independently reconstructed source/input manifest has 244 entries, all unchanged before/after. The 121 current source blobs match their frozen Git commits; all 28 candidate runtime files match `27ab7c4`. The official ready receipt, exact 22,930 cached frames, and complete-line sealed observation/feed prefixes verify. Parsing those sealed inputs reconstructs the same canonical frame and receipt hashes. All original reference -> baseline -> full-supervisor phase gates completed before the retry baseline.

The baseline reproduces all original result fields and 112 standard journals. All 288 produced files/profiles and all 147 baseline artifacts bound by candidate metadata verify. The 862 news messages are contiguous, with final reports at sequences 283, 569 and 861.

## Initial invocation failure and copied baseline

The first candidate CLI supplied `--baseline baseline/results.jsonl` instead of the baseline directory. It exited with `NotADirectoryError` at the baseline metadata read, before output-directory creation and before any replay call. Its stdout is empty and no first-attempt candidate output directory exists. The failed invocation's logs, exit-1 ledger event and error hash remain retained.

The second attempt uses `capture-249/attempt-02`. Its baseline is an exact **147-file byte-identical copy** of the completed original baseline; it was not rerun. The copy preserves the original metadata/start/end timestamps. The candidate binds all copied files and the same immutable specification and frozen source. `baseline-copy-receipt.json` records both original and copied paths and every hash. Original baseline metadata/results/summary are retained separately; the full original baseline bytes are retained once under the identical attempt-02 baseline.

There were no reviewer harness failures or replay failures in this capture-249 review. The earlier rejected forward-driver preflight and corrected preflight are retained unchanged, including their counterexamples.

## Chronology and limitations

- Retry runtime froze at 10:09:20 UTC (epoch 1792836560).
- Follow-up was declared at 10:28:13 UTC (1792837693).
- Corrected driver froze at 10:33:37 UTC (1792838017).
- First selected frame was at 10:36:43.060 UTC (1792838203.06011).
- Last selected frame was at 11:23:44.083 UTC (1792841024.083031).
- Official receipt was at 11:23:46.284 UTC (1792841026.283543), within the declared cutoff.
- Baseline ran at epochs 1792841258.740354–1792841285.998842.
- Corrected candidate ran at epochs 1792841392.933404–1792841420.488076.

The entire selected interval starts after the retry runtime, declaration and corrected-driver freezes. This chronological ordering does not establish unseen-weather validation: all three 241-observation tracks exactly match fitted library rows 744, 745 and 746. That original independent result is bound to these identical canonical inputs without another weather scan or performance run.

The recorded path still has approximately 120.325-second initial snapshot-to-quote gaps and a largest later valid-quote gap of 58.935127 seconds for REIN in round one. Quote completeness and disconnect count remain unknown. Sixteen settings share one weather/quote path and are not independent seasons. Fixed latency/fill assumptions, omitted market impact and queue priority limit live conclusions.

## Declined to judge

- Live ownership, activation, actual account P&L or consistent profitability.
- Extra-pass effectiveness here, because all settings settled without cleanup mutations.
- Unseen-weather generalization despite chronological freeze ordering.
- True quote completeness, disconnect onset, live priority, latency or market impact.
- Capture 250 or later outcomes, additional settings, model or parameter variants.

## Evidence

`verdict.json` is final. `prerequisites.json` records the completed sealed-input/baseline audit before the candidate gate. `candidate-audit.json` contains every paired check, complete arithmetic, budgets and chronology. `analysis-trace-check.json` verifies analyzer details and retained full traces. `authorized-reruns/` contains exactly two reruns. `producer/attempt-02/` contains all phase files, with the initial failed invocation and original baseline receipts under `producer/original-attempt/`. `original-capture-audit.tar.gz` binds the 222-file original-engine/weather audit. `original-audit-binding.json`, `artifact-manifest.json` and `archive-receipt.json` preserve hashes and packaging integrity.
''')
for p,h in pre['source_input_sha256'].items():assert digest(p)==h
assert subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip()==REV
assert not subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'])
exclude={'artifact-manifest.json','independent-review.tar.gz','archive-receipt.json'}
files={str(p.relative_to(OUT)):{'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(OUT.rglob('*')) if p.is_file() and str(p.relative_to(OUT)) not in exclude}
(OUT/'artifact-manifest.json').write_text(json.dumps({'source_revision':REV,'files':files,'payload_files':len(files),'reviewer_candidate_runs':2,'reviewer_other_runs':0},indent=2,sort_keys=True)+'\n')
archive=OUT/'independent-review.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
    for n in sorted(set(files)|{'artifact-manifest.json'}):tf.add(OUT/n,arcname=n,recursive=False)
with tarfile.open(archive) as tf:packed={m.name:tf.extractfile(m).read() for m in tf.getmembers() if m.isfile()}
assert set(packed)==set(files)|{'artifact-manifest.json'}
for n,h in files.items():assert sha(packed[n])==h['sha256'] and len(packed[n])==h['bytes']
receipt={'path':str(archive),'bytes':archive.stat().st_size,'sha256':digest(archive),'regular_files':len(packed),'source_revision':REV,'verdict_sha256':digest(OUT/'verdict.json')}
(OUT/'archive-receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps(receipt,sort_keys=True))
