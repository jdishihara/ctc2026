"""Independent complete capture-249 comparison audit, after explicit completion gate."""
from pathlib import Path
from collections import Counter,deque
import hashlib
import itertools
import json
import math
import statistics
import subprocess
import sys

ROOT=Path('/Users/arjunhans/Documents/ctc2026')
SOURCE=ROOT/'.worktrees/cleanup-retry-forward'
PARENT=ROOT/'out/cleanup-retry-forward-20261024'
ORIGIN=PARENT/'capture-249'
RUN=ORIGIN/'attempt-02'
OUT=Path(__file__).parent
REV='2c441aee5b5f828bc4c4e26461159a958c102067'
GRID=set(itertools.product([249],[0.,.05,.25,1.],[1.,.5],[False,True]))
JOURNALS=['observations.json','actions.jsonl','status.json','final-receipt.json','startup-feed.jsonl','result.json','run.lock']
FILES=JOURNALS+['cleanup-profile.json','mutation-profile.json']
forbidden=[]
def guard(event,args):
    if event.startswith('socket.'):
        forbidden.append('network');raise RuntimeError('network forbidden')
    if event=='open' and isinstance(args[0],(str,bytes)):
        p=str(args[0]).lower()
        if any(s in p for s in ['.botkey','/.env','credentials','/data/history/','/secrets/','/250.json','/capture-250']):
            forbidden.append('restricted file');raise RuntimeError('credentials, downloaded history, later capture forbidden')
sys.addaudithook(guard)
sha=lambda b:hashlib.sha256(b).hexdigest()
digest=lambda p:sha(Path(p).read_bytes())
load=lambda p:json.loads(Path(p).read_bytes())
vh=lambda x:sha(json.dumps(x,sort_keys=True,allow_nan=False).encode())
key=lambda r:tuple(r[n] for n in ['capture','rtt_seconds','displayed_depth_fraction','basket_enabled'])
name=lambda k:f'capture-{k[0]}-{k[1]}-{k[2]}-{int(k[3])}'
def rows(p):
    b=Path(p).read_bytes();assert b.endswith(b'\n');return [json.loads(s) for s in b.splitlines()]
def finite(x):
    if isinstance(x,float):assert math.isfinite(x)
    elif isinstance(x,dict):
        for v in x.values():finite(v)
    elif isinstance(x,list):
        for v in x:finite(v)

def describe(row,profile):
    books={};ages=[];fills={};endpoints=Counter();first=None
    for item in profile:
        r=item['request'];path=r['path'].split('?')[0]
        endpoints[r['method']+' '+('/orderbook/*' if path.startswith('/orderbook/') else path)]+=1
        if path.startswith('/orderbook/'):books[path.split('/')[-1]]=r['executed_at']
        if r['method']=='POST':
            first=r['executed_at'] if first is None else first
            ages.append(r['executed_at']-books[r['body']['symbol']])
        if r['method']=='GET' and path=='/trades':
            for fill in r['response']['trades']:
                if float(fill['executed_at'])>=row['cleanup_started_at']:fills[fill['trade_id']]=fill
    return dict(pnl=row['terminal_settlement_pnl'],cleanup=row['cleanup']['state'],trial=row['trial_state'],stop=row['stop_reason'],
        duration=row['cleanup_completed_at']-row['cleanup_started_at'],requests=len(profile),
        request_seconds=sum(p['request']['completed_at']-p['request']['started_at'] for p in profile),request_counts=dict(endpoints),
        closing_orders=len(ages),min_book_age=min(ages) if ages else None,max_book_age=max(ages) if ages else None,
        first_closing_order_after=first-row['cleanup_started_at'] if first is not None else None,
        observed_cleanup_fills=len(fills),last_observed_cleanup_fill_after=max(float(f['executed_at']) for f in fills.values())-row['cleanup_started_at'] if fills else None,
        positions_after_receipt={s:q for s,q in row['server_positions_after_final_receipt'].items() if q},orders_after_receipt=row['server_orders_after_final_receipt'])

def main():
    assert __debug__
    prerequisite=load(OUT/'prerequisites.json')
    assert prerequisite['source_revision']==REV and prerequisite['forbidden_attempts']==[]
    assert subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip()==REV
    assert not subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'])
    source_map=prerequisite['source_input_sha256'];assert source_map=={p:digest(p) for p in source_map}
    assert digest(ORIGIN/'spec.json')==prerequisite['spec_sha256']
    assert digest(PARENT/'analyze.py')=='6db56e6d7a72b0c770858c33723a1d58713dd1b17ad79bb222b6caca8f56ec75'
    assert digest(RUN/'analysis.json')=='24abffad40d8bac6c6c0d4949531eddd024540ed8df381ac0ebe8c7c1abcce44'
    for n,h in prerequisite['copied_baseline_file_hashes'].items():
        assert digest(RUN/'baseline'/n)==digest(ORIGIN/'baseline'/n)==h
    meta={p:load(RUN/p/'metadata.json') for p in ['baseline','candidate']}
    summary={p:load(RUN/p/'summary.json') for p in ['baseline','candidate']}
    assert summary['baseline']==prerequisite['baseline_summary']
    assert summary['baseline']['finished_at']<meta['candidate']['started_at']<=summary['candidate']['finished_at']
    assert summary['candidate']['results_sha256']==digest(RUN/'candidate/results.jsonl')=='e373c3f18bc539110876a1cb7823d42022ef5410dba333018ffb177609cd9033'
    expected_baseline={str(RUN/'baseline'/n):h for n,h in prerequisite['copied_baseline_file_hashes'].items()}
    assert meta['candidate']['baseline_artifact_sha256']==expected_baseline and len(expected_baseline)==147
    assert meta['candidate']['baseline_results_sha256']==summary['baseline']['results_sha256']
    phases={};metrics={};descriptors={};file_hashes={};checks=[];totals={};profiles={}
    for phase in ['baseline','candidate']:
        rs=rows(RUN/phase/'results.jsonl');index={key(r):r for r in rs};phases[phase]=index
        assert len(rs)==len(index)==16 and set(index)==GRID
        m=meta[phase];s=summary[phase]
        assert m['phase']==phase and m['candidate_revision']==REV and m['source_sha256']==source_map
        assert m['spec']==load(ORIGIN/'spec.json') and m['runtime_changes']==['bot/practice.py']
        assert len(m['grid'])==16 and set(map(tuple,m['grid']))==GRID
        assert s['runs']==16 and s['errors']==0 and s['changed_sources']==s['forbidden_attempts']==[] and s['results_sha256']==digest(RUN/phase/'results.jsonl')
        pnl=[r['terminal_settlement_pnl'] for r in rs];loss=[r for r in rs if 'loss' in r['stop_reason']]
        metrics[phase]=dict(positive=sum(p>0 for p in pnl),negative=sum(p<0 for p in pnl),mean=statistics.mean(pnl),minimum=min(pnl),maximum=max(pnl),
            cleanup=dict(Counter(r['cleanup']['state'] for r in rs)),trial=dict(Counter(r['trial_state'] for r in rs)),
            loss_stops=len(loss),loss_cleanup_mean=statistics.mean(r['cleanup_completed_at']-r['cleanup_started_at'] for r in loss) if loss else None,
            results_sha256=s['results_sha256'],finished_at=s['finished_at'],lowest_marked_pnl=min(r['lowest_marked_pnl'] for r in rs),
            maximum_marked_drawdown=max(r['maximum_marked_drawdown'] for r in rs),maximum_rolling_mutations=max(r['maximum_rolling_mutations'] for r in rs),
            extra_pass_mutations=sum(r['extra_pass_mutations'] for r in rs))
        totals[phase]={'mutations':0,'cleanup_mutations':0,'extra_mutations':0};descriptors[phase]={};profiles[phase]={}
        for k,r in index.items():
            finite(r);assert r['status']=='ok' and r['errors']==[]
            assert r['comparison_status']==('exact_archive' if phase=='baseline' else 'identical_before_cleanup')
            assert r['request_count']==sum(r['request_counts'].values())
            d=RUN/phase/name(k);assert {p.name for p in d.iterdir() if p.is_file()}==set(FILES)
            assert set(r['journal_sha256'])==set(FILES)
            for n,h in r['journal_sha256'].items():assert digest(d/n)==h;file_hashes[str(d/n)]=h
            status=load(d/'status.json');assert status['fraction']==.1 and status['loss_trigger']==250 and status['target_seasons']==1
            profile=load(d/'cleanup-profile.json');profiles[phase][k]=profile
            first5=[p['request'] for p in profile if p['cleanup_attempt'] is not None and p['cleanup_attempt']<5]
            assert vh(first5)==r['first_five_requests_sha256']
            for p in profile:
                a=p['cleanup_attempt'];req=p['request'];finite(req)
                assert a is None or type(a) is int and 0<=a<62
                assert r['cleanup_started_at']<=req['started_at']<=req['executed_at']<=req['completed_at']<=r['final_client_time']
            mutations=load(d/'mutation-profile.json')
            assert len(mutations)==sum(n for endpoint,n in r['request_counts'].items() if endpoint.startswith(('POST ','DELETE ')))
            window=deque();maximum=0;previous_index=-1;previous_time=-math.inf;extra=0
            for event in mutations:
                finite(event);assert event['method'] in ['POST','DELETE'] and previous_index<event['request_index']<r['request_count']
                assert event['started_at']>=previous_time;previous_index,previous_time=event['request_index'],event['started_at']
                while window and window[0]<previous_time-60:window.popleft()
                window.append(previous_time);assert len(window)==event['rolling_60s']<=180;maximum=max(maximum,len(window))
                if event['cleanup_attempt'] is not None and event['cleanup_attempt']>=5:assert len(window)<=90;extra+=1
            assert maximum==r['maximum_rolling_mutations'] and extra==r['extra_pass_mutations']
            totals[phase]['mutations']+=len(mutations);totals[phase]['extra_mutations']+=extra
            totals[phase]['cleanup_mutations']+=sum(p['request']['method'] in ['POST','DELETE'] for p in profile)
            descriptors[phase][k]=describe(r,profile)
            checks.append({'phase':phase,'setting':k,'pnl':r['terminal_settlement_pnl'],'cleanup':r['cleanup']['state'],'trial':r['trial_state'],
                           'mutations':len(mutations),'maximum_rolling_mutations':maximum,'extra_mutations':extra})
    assert len(file_hashes)==288
    pair_descriptions=[];unchanged_runtime=0;standard_equal=0;mutation_profiles_equal=0;profiles_equal_ignoring_line=0
    affected_attention=[];changes=[];failures=[];residual_increases=[];residual_reductions=[]
    for k,b in phases['baseline'].items():
        c=phases['candidate'][k]
        for f in ['pre_cleanup_trace','first_five_requests_sha256','stop_reason','stop_at','stop_phase','stop_market_open']:
            assert b[f]==c[f],(k,f)
        differences=[f for f,v in b.items() if f not in ['comparison_status','journal_sha256'] and c[f]!=v]
        if not differences:unchanged_runtime+=1
        else:changes.append({'setting':k,'fields':differences})
        for n in JOURNALS:
            if (RUN/'baseline'/name(k)/n).read_bytes()==(RUN/'candidate'/name(k)/n).read_bytes():standard_equal+=1
        if (RUN/'baseline'/name(k)/'mutation-profile.json').read_bytes()==(RUN/'candidate'/name(k)/'mutation-profile.json').read_bytes():mutation_profiles_equal+=1
        norm=lambda ps:[{**p,'stack':[{n:v for n,v in s.items() if n!='line'} for s in p['stack']]} for p in ps]
        if norm(profiles['baseline'][k])==norm(profiles['candidate'][k]):profiles_equal_ignoring_line+=1
        before,after=descriptors['baseline'][k],descriptors['candidate'][k]
        pair_descriptions.append(dict(setting=list(k),baseline=before,candidate=after,pnl_delta=after['pnl']-before['pnl'],duration_delta=after['duration']-before['duration']))
        if before!=after and ('attention' in [before['cleanup'],after['cleanup']]):affected_attention.append(k)
        for s in set(before['positions_after_receipt'])|set(after['positions_after_receipt']):
            a,z=before['positions_after_receipt'].get(s,0),after['positions_after_receipt'].get(s,0)
            if abs(z)>abs(a):residual_increases.append(dict(setting=list(k),symbol=s,before=a,after=z))
            if before['cleanup']=='attention' and abs(z)<abs(a):residual_reductions.append(dict(setting=list(k),symbol=s,before=a,after=z))
    b,c=metrics['baseline'],metrics['candidate']
    if c['minimum']<b['minimum']-1e-7:failures.append('worse worst terminal P&L')
    if c['negative']>b['negative']:failures.append('more negative settings')
    if any(p['baseline']['pnl']>=0>p['candidate']['pnl'] for p in pair_descriptions):failures.append('new negative setting')
    if any(p['candidate']['cleanup']=='attention' and p['baseline']['cleanup']!='attention' for p in pair_descriptions):failures.append('new attention setting')
    if residual_increases:failures.append('increased absolute residual exposure')
    report=dict(summaries=metrics,pre_cleanup_pairs_equal=16,first_five_passes_equal=16,
      improved_pnl=sum(p['pnl_delta']>1e-7 for p in pair_descriptions),worsened_pnl=sum(p['pnl_delta']<-1e-7 for p in pair_descriptions),
      unchanged_pnl=sum(abs(p['pnl_delta'])<=1e-7 for p in pair_descriptions),decision='reject' if failures else 'passes_declared_gates_pending_independent_review',
      failed_rules=failures,residual_increases=residual_increases,residual_reductions=residual_reductions,
      primary=[p for p in pair_descriptions if tuple(p['setting'][1:])==(.25,1.,True)],pairs=pair_descriptions)
    assert report==load(RUN/'analysis.json')
    events=[]
    for line in (PARENT/'attempts.jsonl').open():
        if '249' not in line:continue
        e=json.loads(line)
        if e.get('capture')==249:events.append(e)
    completed=[e for e in events if e.get('attempt')==2 and e['kind']=='phase_completed' and e.get('phase')=='candidate']
    assert len(completed)==1 and completed[0]['exit_status']==0 and completed[0]['summary']==summary['candidate']
    for n,h in completed[0]['artifact_sha256'].items():assert digest(RUN/'candidate'/n)==h
    times={rev:int(subprocess.check_output(['git','-C',str(SOURCE),'show','-s','--format=%ct',rev],text=True)) for rev in ['fd35a1e','27ab7c4',REV]}
    timing={'runtime_freeze_at':times['27ab7c4'],'declaration_at':times['fd35a1e'],'driver_freeze_at':times[REV],
            'first_frame_at':prerequisite['first_frame_at'],'last_frame_at':prerequisite['last_frame_at'],'receipt_at':prerequisite['receipt_at'],
            'interval_after_all_retry_freezes':prerequisite['first_frame_at']>max(times.values()),
            'baseline_started_at':meta['baseline']['started_at'],'baseline_finished_at':summary['baseline']['finished_at'],
            'candidate_started_at':meta['candidate']['started_at'],'candidate_finished_at':summary['candidate']['finished_at']}
    assert source_map=={p:digest(p) for p in source_map} and forbidden==[]
    assert not subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'])
    primary=phases['candidate'][(249,.25,1.,True)]
    result={'verdict':'COMPLETE_CAPTURE_249_PAIRED_GATES_CHECKED_PENDING_REPRODUCTION_PACKAGE','source_revision':REV,
      'analysis_sha256':digest(RUN/'analysis.json'),'candidate_results_sha256':summary['candidate']['results_sha256'],
      'metrics':metrics,'pairs_checked':16,'rows_checked':32,'all_analysis_fields_independently_recomputed':True,
      'produced_file_hashes':file_hashes,'produced_files_checked':288,'source_manifest_entries':244,'bound_baseline_artifacts':147,
      'unchanged_runtime_pairs':unchanged_runtime,'identical_standard_journals':standard_equal,'identical_mutation_profiles':mutation_profiles_equal,
      'cleanup_profiles_equal_except_line_numbers':profiles_equal_ignoring_line,'actual_mutations':totals,'row_checks':checks,
      'changed_runtime_fields':changes,'affected_attention_settings':affected_attention,'failed_rules':failures,
      'residual_increases':residual_increases,'residual_reductions':residual_reductions,'timing':timing,
      'primary_terminal_pnl':primary['terminal_settlement_pnl'],'primary_final_mark':primary['final_receipt']['pnl'],
      'primary_settled_positions':{s:q for s,q in primary['server_positions_after_final_receipt'].items() if q},
      'primary_flat':primary['final_receipt']['flat'],'attempt_events':events,'forbidden_attempts':forbidden,'sources_unchanged':True,
      'candidate_performance_runs_by_this_audit':0}
    (OUT/'candidate-audit.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:result[k] for k in ['verdict','rows_checked','produced_files_checked','unchanged_runtime_pairs','actual_mutations','failed_rules','affected_attention_settings','primary_terminal_pnl','primary_final_mark']},sort_keys=True))

if __name__=='__main__':main()
