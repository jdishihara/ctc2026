"""Check retained analyzer details and two full traces; executes no replay."""
from pathlib import Path
from collections import Counter, deque
import gzip
import hashlib
import json
import math

ROOT=Path('/Users/arjunhans/Documents/ctc2026')
RUN=ROOT/'out/cleanup-retry-forward-20261024/capture-249/attempt-02'
OUT=Path(__file__).parent
load=lambda p:json.loads(Path(p).read_bytes())
vh=lambda x:hashlib.sha256(json.dumps(x,sort_keys=True,allow_nan=False).encode()).hexdigest()
key=lambda r:tuple(r[k] for k in ('capture','rtt_seconds','displayed_depth_fraction','basket_enabled'))

def main():
    report=load(RUN/'analysis.json');pairs={tuple(p['setting']):p for p in report['pairs']}
    assert len(pairs)==len(report['pairs'])==16
    for phase in ['baseline','candidate']:
        rows=[json.loads(s) for s in (RUN/phase/'results.jsonl').read_text().splitlines()]
        for row in rows:
            k=key(row);d=RUN/phase/f'capture-{k[0]}-{k[1]}-{k[2]}-{int(k[3])}'
            profile=load(d/'cleanup-profile.json')
            endpoints=Counter();fills={}
            for event in profile:
                req=event['request'];path=req['path'].split('?')[0]
                assert req['method']=='GET'
                endpoints[req['method']+' '+path]+=1
                if path=='/trades':
                    for fill in req['response']['trades']:
                        if float(fill['executed_at'])>=row['cleanup_started_at']:fills[fill['trade_id']]=fill
            expected=dict(pnl=row['terminal_settlement_pnl'],cleanup=row['cleanup']['state'],trial=row['trial_state'],stop=row['stop_reason'],
                duration=row['cleanup_completed_at']-row['cleanup_started_at'],requests=len(profile),
                request_seconds=sum(p['request']['completed_at']-p['request']['started_at'] for p in profile),request_counts=dict(endpoints),
                closing_orders=0,min_book_age=None,max_book_age=None,first_closing_order_after=None,
                observed_cleanup_fills=len(fills),last_observed_cleanup_fill_after=max(float(f['executed_at']) for f in fills.values())-row['cleanup_started_at'] if fills else None,
                positions_after_receipt={s:q for s,q in row['server_positions_after_final_receipt'].items() if q},orders_after_receipt=row['server_orders_after_final_receipt'])
            assert expected==pairs[k][phase],(k,phase)
            assert pairs[k]['pnl_delta']==pairs[k]['duration_delta']==0
    assert report['primary']==[pairs[(249,.25,1.,True)]]
    assert report['decision']=='passes_declared_gates_pending_independent_review'
    summary=load(OUT/'authorized-reruns/independent-reruns.json');checks=[]
    assert summary['successful_reproductions']==summary['authorized_settings']==2
    assert summary['successful_cases_reused_from_previous_invocation']==0 and summary['prior_duplicate_executions']==0
    assert summary['forbidden_attempts']==[] and summary['sources_unchanged'] is True
    for case in summary['cases']:
        k=tuple(case['setting']);assert k in [(249,.25,1.,True),(249,1.,.5,False)]
        d=OUT/'authorized-reruns'/f'capture-{k[0]}-{k[1]}-{k[2]}-{int(k[3])}'
        with gzip.open(d/'request-trace.json.gz','rt') as f:requests=json.load(f)
        with gzip.open(d/'fill-trace.json.gz','rt') as f:fills=json.load(f)
        assert vh(requests)==case['full_response_trace_sha256'] and vh(fills)==case['fill_trace_sha256']
        normalized=[{name:value for name,value in r.items() if name!='response' or r['method']!='GET'} for r in requests]
        assert vh(normalized)==case['request_trace_sha256']
        mutations=[r for r in requests if r['method'] in ['POST','DELETE']]
        window=deque();maximum=0
        for r in mutations:
            while window and window[0]<r['started_at']-60:window.popleft()
            window.append(r['started_at']);maximum=max(maximum,len(window))
        row=load(d/'result.json')
        assert len(requests)==row['request_count'] and len(fills)==row['fills']
        assert len(mutations)==sum(n for k,n in row['request_counts'].items() if k.startswith(('POST ','DELETE ')))
        assert maximum<=180 and case['fatal_errors']==[] and case['budget_checks']==[]
        assert all(case['exact_journal_profile_files'][n]==hashlib.sha256((d/n).read_bytes()).hexdigest() for n in case['exact_journal_profile_files'])
        assert not [r for r in mutations if r['started_at']>=row['cleanup_started_at']]
        assert all(r['trial_state']=='completed' for r in [row])
        checks.append(dict(setting=k,request_count=len(requests),fills=len(fills),mutations=len(mutations),maximum_rolling_mutations=maximum,
                           exact_files=len(case['exact_journal_profile_files']),full_request_hash=vh(requests),fill_hash=vh(fills),
                           cleanup_mutations=0,extra_budget_checks=0,pnl=case['pnl'],cash=case['cash'],positions=case['positions'],conversions=case['conversions']))
    result=dict(all_32_analyzer_pair_descriptions_exact=True,primary_selection_exact=True,
                full_trace_cases=checks,all_18_rerun_file_hashes_valid=True,additional_performance_runs=0)
    (OUT/'analysis-trace-check.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'analyzer_descriptions_checked':32,'full_trace_cases':checks},sort_keys=True))

if __name__=='__main__':main()
