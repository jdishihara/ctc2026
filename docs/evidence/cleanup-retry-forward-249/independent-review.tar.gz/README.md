# Independent capture-249 bounded-retry audit

## Judgment

**Pass the predeclared capture-249 no-op confirmation. No new blocker to the previously approved integration. No live activation approval.** The retry driver remains `2c441aee5b5f828bc4c4e26461159a958c102067`; all 28 runtime files match frozen retry source `27ab7c4`.

## Complete results and scope

The baseline and corrected candidate attempt each contain all 16 prescribed settings: RTT 0/0.05/0.25/1 seconds, full/half displayed depth, baskets off/on, 10% limits, 90 strategy actions/minute, zero prior P&L and the $250 sampled loss trigger. Both modes have 16 positive, completed, settled outcomes; no loss-trigger stop or attention outcome occurs. Mean terminal P&L is $1,485.758125, worst $1,014.34 and best $1,795.95.

All 16 runtime result rows are unchanged, including pre-cleanup request/fill hashes, stopping fields, first-five request hashes, fills, positions and full trace hashes. All 112 standard paired journals and 16 mutation profiles are byte-identical. Cleanup profiles differ only in source stack line numbers. Every field of the 32 analyzer descriptions and all complete aggregate/gate fields were independently recomputed and match the fixed analysis. No affected-attention case exists, so only the two predeclared representative reruns were needed.

Each complete phase contains 1,569 actual POST/DELETE starts, with maximum inclusive trailing-60-second count 27. There are zero cleanup or extra-pass mutations. This is compatibility evidence, not an additional test of retry effectiveness.

Primary terminal P&L is **$1,760.14**, distinct from its final contemporaneous mark of **$1,755.61**. Nine nonzero holdings remain settled. Settled is not flat, and these replay values are not account returns.

## Exactly two authorized candidate reruns

| Setting | Terminal P&L | Requests | Fills | Actual mutations | Maximum rolling mutations |
| --- | ---: | ---: | ---: | ---: | ---: |
| 0.25 s / full / baskets on | $1,760.14 | 4,523 | 59 | 88 | 8 |
| 1 s / half / baskets off | $1,348.52 | 2,159 | 57 | 59 | 7 |

Both reproduced every result field and all nine files, for 18 byte-exact files. Full request traces including GET responses and full fill traces are retained. Independent fill cash, basket transfers and settled holdings reconcile terminal P&L. Both passed on their first execution, with zero sticky guard violations and no duplicate executions or other settings.

Guards cover network/credentials/history access, terminal-price availability, complete observed history, competition identity, unchanged quote-callback history, true execution-time cleanup reduction, mutation budgets and extra-pass admission. These runs recorded 72 guarded settlement value reads and 111 history-ready strategy POST checks. Neither exercised a cleanup POST or extra-budget check. No additional original-engine performance run occurred; the original audit's six authorized reproductions are bound through its verified 222-file archive.

## Prerequisites and source binding

The independently reconstructed source/input manifest has 244 entries, all unchanged before/after. The 121 current source blobs match their frozen Git commits; all 28 candidate runtime files match `27ab7c4`. The official ready receipt, exact 22,930 cached frames, and complete-line sealed observation/feed prefixes verify. Parsing those sealed inputs reconstructs the same canonical frame and receipt hashes. All original reference -> baseline -> full-supervisor phase gates completed before the retry baseline.

The baseline reproduces all original result fields and 112 standard journals. All 288 produced files/profiles and all 147 baseline artifacts bound by candidate metadata verify. The 862 news messages are contiguous, with final reports at sequences 283, 569 and 861.

## Initial invocation failure and copied baseline

The first candidate CLI supplied `--baseline baseline/results.jsonl` instead of the baseline directory. It exited with `NotADirectoryError` at the baseline metadata read, before output-directory creation and before any replay call. Its stdout is empty and no first-attempt candidate output directory exists. The failed invocation's logs, exit-1 ledger event and error hash remain retained.

The second attempt uses `capture-249/attempt-02`. Its baseline is an exact **147-file byte-identical copy** of the completed original baseline; it was not rerun. The copy preserves the original metadata/start/end timestamps. The candidate binds all copied files and the same immutable specification and frozen source. `baseline-copy-receipt.json` records both original and copied paths and every hash. Original baseline metadata/results/summary are retained separately; the full original baseline bytes are retained once under the identical attempt-02 baseline.

There were no reviewer harness failures or replay failures in this capture-249 review. The earlier rejected forward-driver preflight and corrected preflight are retained unchanged, including their counterexamples.

## Chronology and limitations

- Retry runtime froze at 10:09:20 UTC (epoch 1792836560).
- Follow-up was declared at 10:28:13 UTC (1792837693).
- Corrected driver froze at 10:33:37 UTC (1792838017).
- First selected frame was at 10:36:43.060 UTC (1792838203.06011).
- Last selected frame was at 11:23:44.083 UTC (1792841024.083031).
- Official receipt was at 11:23:46.284 UTC (1792841026.283543), within the declared cutoff.
- Baseline ran at epochs 1792841258.740354–1792841285.998842.
- Corrected candidate ran at epochs 1792841392.933404–1792841420.488076.

The entire selected interval starts after the retry runtime, declaration and corrected-driver freezes. This chronological ordering does not establish unseen-weather validation: all three 241-observation tracks exactly match fitted library rows 744, 745 and 746. That original independent result is bound to these identical canonical inputs without another weather scan or performance run.

The recorded path still has approximately 120.325-second initial snapshot-to-quote gaps and a largest later valid-quote gap of 58.935127 seconds for REIN in round one. Quote completeness and disconnect count remain unknown. Sixteen settings share one weather/quote path and are not independent seasons. Fixed latency/fill assumptions, omitted market impact and queue priority limit live conclusions.

## Declined to judge

- Live ownership, activation, actual account P&L or consistent profitability.
- Extra-pass effectiveness here, because all settings settled without cleanup mutations.
- Unseen-weather generalization despite chronological freeze ordering.
- True quote completeness, disconnect onset, live priority, latency or market impact.
- Capture 250 or later outcomes, additional settings, model or parameter variants.

## Evidence

`verdict.json` is final. `prerequisites.json` records the completed sealed-input/baseline audit before the candidate gate. `candidate-audit.json` contains every paired check, complete arithmetic, budgets and chronology. `analysis-trace-check.json` verifies analyzer details and retained full traces. `authorized-reruns/` contains exactly two reruns. `producer/attempt-02/` contains all phase files, with the initial failed invocation and original baseline receipts under `producer/original-attempt/`. `original-capture-audit.tar.gz` binds the 222-file original-engine/weather audit. `original-audit-binding.json`, `artifact-manifest.json` and `archive-receipt.json` preserve hashes and packaging integrity.
