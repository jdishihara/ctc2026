"""Closed capture-249 baseline/prerequisite review; candidate data and replay are forbidden."""
from pathlib import Path
from collections import Counter, deque
import hashlib
import itertools
import json
import math
import shutil
import statistics
import subprocess
import sys

ROOT=Path('/Users/arjunhans/Documents/ctc2026')
SOURCE=ROOT/'.worktrees/cleanup-retry-forward'
BASE=ROOT/'.worktrees/practice-history'
PARENT=ROOT/'out/cleanup-retry-forward-20261024'
RUN=PARENT/'capture-249'
OUT=Path(__file__).parent
REV='2c441aee5b5f828bc4c4e26461159a958c102067'
RUNTIME='27ab7c4b4784c9aabc92e791b0878d387cd4cc49'
BASE_REV='cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026'
CID='7d19a254-8c3b-4c4a-b4f3-32c84a138b79'
GRID=set(itertools.product([249],[0.,.05,.25,1.],[1.,.5],[False,True]))
JOURNALS=['observations.json','actions.jsonl','status.json','final-receipt.json','startup-feed.jsonl','result.json','run.lock']
FILES=JOURNALS+['cleanup-profile.json','mutation-profile.json']
FORBIDDEN=[]
sys.dont_write_bytecode=True

def guard(event,args):
    if event.startswith('socket.'):
        FORBIDDEN.append('network');raise RuntimeError('network forbidden')
    if event=='open' and isinstance(args[0],(str,bytes)):
        p=str(args[0]).lower()
        if any(s in p for s in ('.botkey','/.env','credentials','/data/history/','/secrets/','/250.json','/capture-250','/capture-249/attempt-02/candidate/')):
            FORBIDDEN.append('restricted file');raise RuntimeError('active/later outcome, credentials or candidate access forbidden')
sys.addaudithook(guard)
sha=lambda b:hashlib.sha256(b).hexdigest()
digest=lambda p:sha(Path(p).read_bytes())
load=lambda p:json.loads(Path(p).read_bytes())
vh=lambda v:sha(json.dumps(v,sort_keys=True,allow_nan=False).encode())
key=lambda r:tuple(r[n] for n in ['capture','rtt_seconds','displayed_depth_fraction','basket_enabled'])
name=lambda k:f'capture-{k[0]}-{k[1]}-{k[2]}-{int(k[3])}'
git=lambda root,*args:subprocess.check_output(['git','-C',str(root),*args])

def rows(p):
    data=Path(p).read_bytes();assert data.endswith(b'\n');return [json.loads(s) for s in data.splitlines()]

def main():
    assert __debug__
    assert git(SOURCE,'rev-parse','HEAD').decode().strip()==REV and not git(SOURCE,'status','--porcelain')
    assert git(BASE,'rev-parse','HEAD').decode().strip()==BASE_REV and not git(BASE,'status','--porcelain','--untracked-files=no')
    assert digest(RUN/'spec.json')=='30cbabf63edbc24fe5107fa86c36cb918fb7b4205d05578f26dcf5df9ffdbb12'
    spec=load(RUN/'spec.json');assert [e['capture'] for e in spec['captures']]==[249]
    entry=spec['captures'][0];assert digest(entry['input'])==entry['input_sha256']=='dd90a0d5f2c8068478755c42195a230a83811a519a4ef4b28402fb6ec797ab4c'
    cache=load(entry['input']);frames=cache['frames'];receipt=cache['receipt']
    assert len(frames)==22930 and vh(frames)=='46c86a377736e0657c30f68cd1249ae85d0788981acacf7aa0794dc6639b1c2e'
    assert vh(receipt)=='b067d33043f12a2f8f11552f14b589a50f5130932a70eca59026a3a6b4d0bdcc'
    assert receipt['competition_id']==CID and receipt['at']==1792841026.283543 and receipt['year']=='1778'
    assert receipt['kind']=='settlement' and receipt['source']=='read_only_market_observer'
    assert 1792837693<=receipt['at']<1792843200
    for clock in ('clock','end_clock'):
        assert receipt[clock]['state']=='ready' and receipt[clock]['competition_id']==CID and receipt[clock]['fictional_time'].startswith('1778-')
    coverage=receipt['coverage'];assert coverage['contiguous'] is True and coverage['conflicting_sequences'] is False and coverage['final_rounds']==[1,2,3]
    assert coverage['seq_count']==coverage['last_seq']+1==coverage['advertised_last_seq']+1
    case=load(SOURCE/'data/case.json');assert set(receipt['prices'])==set(case['limits'])
    assert all(type(v) in (int,float) and math.isfinite(v) and v>0 for v in receipt['prices'].values())
    assert all(frames[i]['received_at']<=frames[i+1]['received_at'] for i in range(len(frames)-1))
    assert frames[-1]['received_at']<=receipt['at']
    original=Path(entry['archive']);upstream_spec=load(entry['forward_spec']);item=upstream_spec['captures'][0]
    assert len(upstream_spec['captures'])==1 and item['capture']==249 and item['competition_id']==CID
    sealed={}
    for field in ('observations','feed'):
        raw=Path(item[field]).read_bytes();assert raw.endswith(b'\n') and len(raw)==item[field+'_bytes'] and sha(raw)==item[field+'_sha256']
        sealed[field]={'path':item[field],'bytes':len(raw),'sha256':sha(raw)}
    meta=load(RUN/'baseline/metadata.json');summary=load(RUN/'baseline/summary.json');rs=rows(RUN/'baseline/results.jsonl');index={key(r):r for r in rs}
    assert len(rs)==len(index)==16 and set(index)==GRID and len(meta['grid'])==16 and set(map(tuple,meta['grid']))==GRID
    assert meta['phase']=='baseline' and meta['spec']==spec and meta['candidate_revision']==REV and meta['baseline_revision']==BASE_REV
    assert meta['runtime_changes']==['bot/practice.py']
    assert summary['runs']==16 and summary['errors']==0 and summary['changed_sources']==summary['forbidden_attempts']==[]
    assert summary['results_sha256']==digest(RUN/'baseline/results.jsonl')=='c0a2293534d4b16ac68b9d9ab5aa8a35e44682ce74bc2bd4202ad5e255533711'
    source_map=meta['source_sha256'];assert len(source_map)==244
    before={p:digest(p) for p in source_map};assert before==source_map
    revisions={SOURCE:REV,BASE:BASE_REV,ROOT/'.worktrees/supervised-forward':'c5c35a30e0c5f521f12324eec854f405b681b8c0',ROOT/'.worktrees/serialized-forward':'505a5ad2d5a6f81e7c711cb550871ce7aa7f3734'}
    blobs={}
    for root,revision in revisions.items():
        assert git(root,'rev-parse','HEAD').decode().strip()==revision
        for p,h in source_map.items():
            path=Path(p)
            if path.is_relative_to(root):
                rel=str(path.relative_to(root));b=git(root,'show',revision+':'+rel);assert sha(b)==h
                blobs[revision+':'+rel]=h
    assert len(blobs)==121
    runtime_names=['data/case.json','bot/live.py','bot/http_transport.py','bot/control.py','bot/practice.py','scripts/replay_practice_supervisor.py',
        'scripts/replay_serialized_client.py','scripts/replay_captured_market.py','scripts/evaluate_observed_season.py','scripts/observe_market_seasons.py','scripts/experiment_execution_costs.py']
    runtime_names += [str(p.relative_to(BASE)) for ext in ['*.py','*.json','*.npz'] for p in (BASE/'ctc').glob(ext)]
    assert len(runtime_names)==28
    for n in runtime_names:assert (SOURCE/n).read_bytes()==git(SOURCE,'show',RUNTIME+':'+n)
    for n,h in entry['archive_sha256'].items():assert digest(original/n)==h
    original_meta=load(original/'metadata.json');original_summary=load(original/'summary.json');original_rows={key(r):r for r in rows(original/'results.jsonl')}
    assert set(original_rows)==GRID and original_meta['spec']==upstream_spec
    assert original_meta['runtime_revision']==BASE_REV and original_meta['fraction']==.1 and original_meta['loss_trigger']==250 and original_meta['prior_pnl']==0
    assert original_meta['captures'][0]['frames_sha256']==vh(frames) and original_meta['captures'][0]['receipt_sha256']==vh(receipt)
    phases={};previous=receipt['at']
    for phase in ['reference','baseline','supervised']:
        d=original.parent/phase;m=load(d/'metadata.json');s=load(d/'summary.json')
        assert s['runs']==16 and s['errors']==s['mismatches']==0 and s['changed_sources']==[]
        assert s['results_sha256']==digest(d/'results.jsonl') and len(rows(d/'results.jsonl'))==16
        assert previous<=m['started_at']<=s['finished_at']<meta['started_at'];previous=s['finished_at']
        phases[phase]={'started_at':m['started_at'],**s}
    assert load(original.parent/'baseline/metadata.json')['reference_results_sha256']==phases['reference']['results_sha256']
    assert original_meta['baseline_results_sha256']==phases['baseline']['results_sha256']
    # Reconstruct the declared dependency set independently of its serialized manifest.
    core_names=set(runtime_names)-{'bot/practice.py','scripts/replay_practice_supervisor.py'}|{'docs/serialized-replay-plan.md','docs/serialized-forward-plan.md'}
    forward_names=core_names|{'bot/practice.py','scripts/replay_practice_supervisor.py','scripts/compare_practice_supervisor.py','docs/supervised-replay-plan.md','docs/practice-round-transition-plan.md','docs/supervised-forward-plan.md'}
    expected={str(SOURCE/n) for n in runtime_names}|{str(BASE/n) for n in runtime_names}
    expected|={str(SOURCE/n) for n in ['scripts/compare_cleanup_retry_forward.py','docs/cleanup-retry-window-plan.md','docs/cleanup-retry-forward-plan.md']}
    expected|={str(ROOT/'.worktrees/serialized-forward'/n) for n in core_names}|{str(ROOT/'.worktrees/supervised-forward'/n) for n in forward_names}
    expected|={str(RUN/'spec.json'),entry['input'],entry['forward_spec'],item['observations'],item['feed']}
    expected|={str(original/n) for n in ['metadata.json','results.jsonl','summary.json']}
    core=Path(item['archive_results']).parent;expected|={str(core/n) for n in ['metadata.json','results.jsonl','summary.json']}
    expected|={str(original/name(k)/n) for k in GRID for n in JOURNALS}
    assert expected==set(source_map)
    sys.path.insert(0,str(SOURCE))
    from scripts.evaluate_observed_season import observed_capture
    reconstructed_receipt,reconstructed_frames,reconstructed_coverage=observed_capture(item['observations'],item['feed'],CID,case['limits'])
    assert reconstructed_receipt==receipt and reconstructed_frames==frames and reconstructed_coverage==original_meta['captures'][0]['coverage']
    produced={};original_journals=0;mutation_count=0;maximum=0
    for k,r in index.items():
        assert r['status']=='ok' and r['errors']==[] and r['comparison_status']=='exact_archive'
        for f,v in original_rows[k].items():
            if f!='comparison_status':assert r[f]==v,(k,f)
        d=RUN/'baseline'/name(k);assert set(r['journal_sha256'])==set(FILES)
        for n,h in r['journal_sha256'].items():
            assert digest(d/n)==h;produced[str(d/n)]=h
            if n in JOURNALS:
                assert (d/n).read_bytes()==(original/name(k)/n).read_bytes();original_journals+=1
        profile=load(d/'cleanup-profile.json');assert vh([p['request'] for p in profile if p['cleanup_attempt'] is not None and p['cleanup_attempt']<5])==r['first_five_requests_sha256']
        events=load(d/'mutation-profile.json');assert len(events)==sum(v for n,v in r['request_counts'].items() if n.startswith(('POST ','DELETE ')))
        window=deque();localmax=0
        for e in events:
            while window and window[0]<e['started_at']-60:window.popleft()
            window.append(e['started_at']);assert len(window)==e['rolling_60s']<=180
            localmax=max(localmax,len(window))
        assert localmax==r['maximum_rolling_mutations'];maximum=max(maximum,localmax);mutation_count+=len(events)
    assert len(produced)==144 and original_journals==112
    first={str(p.relative_to(RUN/'baseline')):digest(p) for p in (RUN/'baseline').rglob('*') if p.is_file()}
    second={str(p.relative_to(RUN/'attempt-02/baseline')):digest(p) for p in (RUN/'attempt-02/baseline').rglob('*') if p.is_file()}
    assert len(first)==len(second)==147 and first==second
    for n in first:assert (RUN/'baseline'/n).read_bytes()==(RUN/'attempt-02/baseline'/n).read_bytes()
    failure=(RUN/'candidate.stderr.log').read_text();assert 'NotADirectoryError' in failure and 'results.jsonl/metadata.json' in failure
    assert digest(RUN/'candidate.stderr.log')=='e2530e9c9d2d9c0d17d4117b273b7f068db1b56ed1911cb9dca45a81af6b3451'
    assert (RUN/'candidate.stdout.log').read_bytes()==b'' and not (RUN/'candidate').exists()
    code=(SOURCE/'scripts/compare_cleanup_retry_forward.py').read_text()
    assert code.index("prior = json.loads((args.baseline / 'metadata.json')")<code.index('args.out.mkdir')<code.index('result = replay.replay_supervised')
    ledger=[]
    for line in (PARENT/'attempts.jsonl').open():
        if '249' not in line:continue
        row=json.loads(line)
        if row.get('capture')==249 and not(row.get('attempt')==2 and row.get('kind')=='phase_completed'):ledger.append(row)
    failed=[e for e in ledger if e['kind']=='phase_failed'];assert len(failed)==1 and failed[0]['performance_runs']==0
    copied=[e for e in ledger if e.get('baseline_copied_from')];assert len(copied)==1 and copied[0]['copied_baseline_files_verified']==147
    assert copied[0]['baseline_results_sha256']==summary['results_sha256']
    assert before=={p:digest(p) for p in source_map} and FORBIDDEN==[]
    assert not git(SOURCE,'status','--porcelain')
    pnls=[r['terminal_settlement_pnl'] for r in rs]
    result={'verdict':'SEALED_PREREQUISITES_AND_COPIED_BASELINE_VERIFIED_WAITING_FOR_CANDIDATE_GATE',
      'capture':249,'source_revision':REV,'spec_sha256':digest(RUN/'spec.json'),'input_sha256':digest(entry['input']),
      'receipt_at':receipt['at'],'receipt_sha256':vh(receipt),'frame_count':len(frames),'frames_sha256':vh(frames),
      'first_frame_at':frames[0]['received_at'],'last_frame_at':frames[-1]['received_at'],'sealed_inputs':sealed,
      'source_input_sha256':before,'source_manifest_entries':244,'source_manifest_complete':True,'source_git_blob_hashes':blobs,
      'runtime_files_exact_27ab7c4':28,'original_phase_gates':phases,'baseline_summary':summary,'baseline_started_at':meta['started_at'],
      'original_result_rows_exact':16,'original_journals_byte_exact':112,'produced_files_sha256':produced,
      'copied_baseline_file_hashes':first,'copied_baseline_files_byte_exact':147,'baseline_was_not_rerun':True,
      'baseline_metrics':{'positive':sum(p>0 for p in pnls),'negative':sum(p<0 for p in pnls),'mean':statistics.mean(pnls),'worst':min(pnls),'best':max(pnls),
          'trials':dict(Counter(r['trial_state'] for r in rs)),'cleanup':dict(Counter(r['cleanup']['state'] for r in rs)),
          'actual_mutations':mutation_count,'maximum_inclusive_rolling_mutations':maximum},
      'initial_candidate_invocation_failure':{'stderr_sha256':digest(RUN/'candidate.stderr.log'),'stdout_sha256':digest(RUN/'candidate.stdout.log'),
          'candidate_output_absent':True,'rejection_before_output_creation_and_replay':True,'performance_runs':0},
      'attempt_entries':ledger,'source_changes':[],'forbidden_attempts':FORBIDDEN,'candidate_rows_or_outcomes_read':False,'candidate_reproductions_run':0}
    (OUT/'prerequisites.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    evidence=OUT/'prerequisite-evidence';evidence.mkdir(exist_ok=True)
    for n in ['spec.json','candidate.stderr.log','candidate.stdout.log','baseline/metadata.json','baseline/results.jsonl','baseline/summary.json']:
        p=evidence/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(RUN/n,p)
    print(json.dumps({k:result[k] for k in ['verdict','source_manifest_entries','original_result_rows_exact','original_journals_byte_exact','copied_baseline_files_byte_exact','candidate_reproductions_run','candidate_rows_or_outcomes_read']},sort_keys=True))

if __name__=='__main__':main()
