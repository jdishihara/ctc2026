"""Independent closed-249 provenance, coverage, journal and fitted-track audit."""
import collections
import hashlib
import itertools
import json
import math
from pathlib import Path
import subprocess
import sys
import time

BASE = Path('/Users/arjunhans/Documents/ctc2026')
RECORDINGS = BASE / 'recordings/consistency-20261024'
CID = '7d19a254-8c3b-4c4a-b4f3-32c84a138b79'
ROOT = BASE / '.worktrees/supervised-forward'
REFERENCE = BASE / '.worktrees/serialized-forward'
ATTEMPT = RECORDINGS / 'supervised-forward' / CID / 'attempt-01'
OUT = Path(__file__).resolve().parent
GRID = set(itertools.product([0., .05, .25, 1.], [1., .5], [False, True]))
FORBIDDEN = []

def guard(event, args):
    if event in ('socket.connect', 'socket.getaddrinfo', 'socket.bind'):
        FORBIDDEN.append(event)
        raise RuntimeError('No network in the independent audit')
    if event == 'open' and isinstance(args[0], (str, bytes)):
        name = str(args[0]).lower()
        if any(part in name for part in ('/data/history/', '.botkey', '/.env', 'credentials', 'manifest')):
            FORBIDDEN.append(name)
            raise RuntimeError('No downloaded history, manifests or credentials in this audit')
        if '/recordings/' in name and not any(part in name for part in (
                CID, '/supervised-forward/scans/scan-005.observations.jsonl',
                '/supervised-forward/attempts.jsonl', '/market-observations.jsonl')):
            FORBIDDEN.append(name)
            raise RuntimeError('Only sealed capture-249 inputs and bounded ledger prefixes allowed')
sys.addaudithook(guard)

def load(p): return json.loads(Path(p).read_text())
def lines(p): return [json.loads(x) for x in Path(p).read_text().splitlines()]
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def vh(x): return hashlib.sha256(json.dumps(x, sort_keys=True, allow_nan=False).encode()).hexdigest()
def key(r): return (r['rtt_seconds'], r['displayed_depth_fraction'], r['basket_enabled'])
def close(a,b): assert math.isclose(a,b,rel_tol=0,abs_tol=1e-7), (a,b)
def dump(name, value): (OUT/name).write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')

assert sha(ATTEMPT/'spec.json')=='095faaf54718ac8cadb77d888eccf4a27ef29b06e072a9f27b8da7873b888bda'
spec = load(ATTEMPT/'spec.json'); item = spec['captures'][0]
assert item['capture']==249 and item['competition_id']==CID
for field in ('observations','feed'):
    data=Path(item[field]).read_bytes()
    assert len(data)==item[field+'_bytes'] and data.endswith(b'\n')
    assert hashlib.sha256(data).hexdigest()==item[field+'_sha256']
receipts=[r for r in lines(item['observations']) if r.get('kind')=='settlement' and r.get('competition_id')==CID]
assert len(receipts)==1
receipt=receipts[0]
assert receipt['at']==1792841026.283543 and receipt['year']=='1778'
assert receipt['clock']==receipt['end_clock'] and receipt['clock']['state']=='ready'
assert receipt['clock']['competition_id']==CID
assert 1792828815 <= receipt['at'] < 1792843200

# Closure established before importing the approved selector or loading fitted tracks.
sys.path.insert(0,str(ROOT))
from scripts.evaluate_observed_season import observed_capture
case=load(ROOT/'data/case.json')
selected_receipt,frames,coverage=observed_capture(item['observations'],item['feed'],CID,case['limits'])
assert selected_receipt==receipt
metadata={phase:load(ATTEMPT/phase/'metadata.json') for phase in ('reference','baseline','supervised')}
cap=metadata['supervised']['captures'][0]
assert vh(receipt)==cap['receipt_sha256'] and vh(frames)==cap['frames_sha256']
assert len(frames)==cap['frame_count']==22930
assert coverage==cap['coverage']
assert frames[0]['received_at']>1792828815 and frames[-1]['received_at']<=receipt['at']
cache=OUT/'249.json'
cache_bytes=(json.dumps({'frames':frames,'receipt':receipt},allow_nan=False)+'\n').encode()
if cache.exists():
    assert cache.read_bytes()==cache_bytes
else:
    cache.write_bytes(cache_bytes)
cache_info={'path':str(cache),'file_sha256':sha(cache),'frames_value_sha256':vh(frames),
    'receipt_value_sha256':vh(receipt),'frame_count':len(frames),'first_at':frames[0]['received_at'],
    'last_at':frames[-1]['received_at'],'receipt_at':receipt['at'],'coverage':coverage}
dump('cache-info.json',cache_info)
print(json.dumps({'cache':str(cache),'sha256':sha(cache),'frames':len(frames)}),flush=True)

sources={}
for phase,m in metadata.items():
    assert m['phase']==phase
    assert m['source_revision']==(spec['reference_revision'] if phase=='reference' else 'c5c35a30e0c5f521f12324eec854f405b681b8c0')
    assert m['driver_sha256']==sha(ROOT/'scripts/compare_practice_supervisor.py')
    assert m['forward_plan_sha256']==sha(ROOT/'docs/supervised-forward-plan.md')
    assert m['forward'] and m['fraction']==.1 and m['loss_trigger']==250 and m['prior_pnl']==0
    assert set(map(tuple,m['grid']))==GRID and len(m['grid'])==16
    assert m['spec']==spec and m['captures']==metadata['supervised']['captures']
    assert m['driver_revision']=='c5c35a30e0c5f521f12324eec854f405b681b8c0'
    assert m['runtime_revision']=='cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026'
    assert m['started_at']>receipt['at']
    for name,h in m['source_sha256'].items():
        assert sha(name)==h, name
        sources[name]=h
    for name,h in m['runtime_sha256'].items():
        rel=Path(name).relative_to(ROOT).as_posix()
        blob=subprocess.check_output(['git','show',f"{m['runtime_revision']}:{rel}"],cwd=ROOT)
        assert hashlib.sha256(blob).hexdigest()==h
serial=RECORDINGS/'serialized-forward'/CID
serial_meta=load(serial/'metadata.json'); serial_rows=lines(serial/'results.jsonl')
assert serial_meta['official_receipt']==receipt and serial_meta['coverage']==coverage
assert serial_meta['receipt_sha256']==vh(receipt) and serial_meta['frames_sha256']==vh(frames)
assert serial_meta['source_revision']==spec['reference_revision']
for rel,h in serial_meta['source_sha256'].items():
    assert sha(REFERENCE/rel)==h
    sources[str(REFERENCE/rel)]=h
for name in ('results','metadata','summary'):
    suffix='jsonl' if name=='results' else 'json'
    assert sha(serial/f'{name}.{suffix}')==item[f'archive_{name}_sha256']
assert len(serial_rows)==16 and {key(r) for r in serial_rows}==GRID
assert all(r['status']=='ok' for r in serial_rows)
assert load(serial/'summary.json')['runs']==16 and load(serial/'summary.json')['errors']==0

expected_phase_hashes={'reference':'9a986147e724fdd4a5e87553a0434d685a01d9785dda25eea38aab9d3c3756b5','baseline':'4ba1e0171a0c39650b146f23ca3bc17ceb4f88d867a8993bee0fa220459ff09c','supervised':'913a725d47c1c869c8e803c02e96f9289bd0f5af786905e27efe59c018402fb2'}
assert all(sha(ATTEMPT/phase/'results.jsonl')==h for phase,h in expected_phase_hashes.items())
rows={phase:lines(ATTEMPT/phase/'results.jsonl') for phase in metadata}
indexed_serial={key(r):r for r in serial_rows}
for phase,rs in rows.items():
    summary=load(ATTEMPT/phase/'summary.json')
    assert summary['runs']==16 and summary['errors']==summary['mismatches']==0
    assert summary['changed_sources']==[] and summary['results_sha256']==sha(ATTEMPT/phase/'results.jsonl')
    assert len(rs)==16 and {key(r) for r in rs}==GRID and all(r['status']=='ok' for r in rs)
    for r in rs:
        assert r['capture']==249
        if phase!='supervised':
            assert r['different_fields']==[]
            assert all(r[k]==v for k,v in indexed_serial[key(r)].items())
for a,b in zip(rows['reference'],rows['baseline']):
    assert key(a)==key(b)
    assert all(a[k]==v for k,v in b.items() if k!='comparison_status')
assert metadata['baseline']['reference_results_sha256']==sha(ATTEMPT/'reference/results.jsonl')
assert metadata['supervised']['baseline_results_sha256']==sha(ATTEMPT/'baseline/results.jsonl')
assert metadata['baseline']['source_sha256']==metadata['supervised']['source_sha256']

worker_path=RECORDINGS/'fixed-observed-evaluation'/f'{CID}.json'
worker=load(worker_path)
assert worker['official_receipt']==receipt and worker['coverage']==coverage and worker['fraction']==.1
assert worker['worker']['receipt_sha256']==vh(receipt)
for name,h in worker['worker']['sources'].items():
    assert sha(name)==h,name
    sources[name]=h
worker_rows=worker['results']
worker_grid=set(itertools.product([.25,1.,3.],[1.,.5],[False,True],[True,False]))
assert len(worker_rows)==24 and {(r['latency_seconds'],r['displayed_depth_fraction'],r['basket_enabled'],r['reset_warmup_each_snapshot']) for r in worker_rows}==worker_grid
assert all(math.isfinite(r['simulated_settlement_pnl']) for r in worker_rows)

journals=[];attention=[]
standard=['observations.json','actions.jsonl','status.json','final-receipt.json','startup-feed.jsonl','result.json','run.lock']
for r in rows['supervised']:
    d=ATTEMPT/'supervised'/f"capture-249-{r['rtt_seconds']}-{r['displayed_depth_fraction']}-{int(r['basket_enabled'])}"
    assert {p.name for p in d.iterdir()}==set(standard)
    jr=load(d/'result.json'); st=load(d/'status.json'); final=load(d/'final-receipt.json')
    obs=load(d/'observations.json'); acts=lines(d/'actions.jsonl'); startup=lines(d/'startup-feed.jsonl')
    assert all(r[k]==v for k,v in jr.items())
    assert final==r['observed_final_receipt'] and st['latest']['cleanup']==r['cleanup']
    assert st['latest']['final_receipt']==r['final_receipt'] and st['trials'][CID]==r['trial']
    assert st['stop_reason']==r['stop_reason'] and not st['ownership_blocks']
    assert float((d/'run.lock').read_text())==frames[0]['received_at']
    assert startup and all(f in frames for f in startup)
    assert all(a['at']<=b['at'] for a,b in zip(acts,acts[1:]))
    assert all(a['observed_at']<=b['observed_at'] for a,b in zip(obs,obs[1:]))
    assert r['errors']==[] and r['history_block_reason'] is None and r['terminal_closed']
    assert r['final_receipt']['verified'] and r['final_receipt']['history_ownership_clear']
    assert r['final_receipt']['flat']==(not any(p['quantity'] for p in final['positions']['positions']) and not final['orders']['orders'])
    close(sum(p['realized_pnl']+p['unrealized_pnl'] for p in final['positions']['positions']),r['final_receipt']['pnl'])
    for s,q in r['maximum_absolute_positions'].items():assert q<=max(1,math.floor(.1*case['limits'][s]))
    if r['cleanup']['state']=='flat':
        assert r['final_receipt']['flat'] and not any(r['final_positions'].values())
        close(r['terminal_settlement_pnl'],r['final_receipt']['pnl'])
    elif r['cleanup']['state']=='settled':assert r['trial_state']=='completed'
    elif r['cleanup']['state']=='attention':
        assert not r['final_receipt']['flat'] and r['trial_state']=='incomplete_trial'
        attention.append({k:r[k] for k in ['rtt_seconds','displayed_depth_fraction','basket_enabled','cleanup','final_receipt','terminal_settlement_pnl','final_positions','fills_after_final_receipt_requests']})
    else:raise AssertionError(r['cleanup'])
    journals.append({'setting':list(key(r)),'file_sha256':{name:sha(d/name) for name in standard},'observations':len(obs),'actions':len(acts)})
assert sum(len(j['file_sha256']) for j in journals)==112
input_audit=load(OUT/'input-audit.json')
assert input_audit['spec_sha256']==sha(ATTEMPT/'spec.json') and input_audit['cache']==cache_info
assert input_audit['worker_artifact_sha256']==sha(worker_path)
assert len(input_audit['worker_events'])==1
assert input_audit['worker_events'][0]['artifact_sha256']==sha(worker_path)
assert input_audit['worker_events'][0]['receipt_sha256']==vh(receipt)

events=[]
for line in (RECORDINGS/'supervised-forward/attempts.jsonl').open():
    e=json.loads(line)
    if e.get('competition_id')==CID or e.get('snapshot')==item['observations'] or e.get('kind')=='forward_frozen':events.append(e)
    if e.get('competition_id')==CID and e.get('kind')=='phase_completed' and e.get('phase')=='supervised':break
freeze=next(e for e in events if e['kind']=='forward_frozen')
assert frames[0]['received_at']>max(freeze['driver_freeze_at'],freeze['runtime_freeze_at'])
assert freeze['driver_sha256']==sha(ROOT/'scripts/compare_practice_supervisor.py')
assert freeze['plan_sha256']==sha(ROOT/'docs/supervised-forward-plan.md')
for checkout,revision in [(ROOT,freeze['driver_revision']),(REFERENCE,freeze['reference_revision'])]:
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=checkout,text=True).strip()==revision
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=checkout,text=True).strip()
completed=[e for e in events if e['kind']=='phase_completed']
assert len(completed)==3 and [e['phase'] for e in completed]==['reference','baseline','supervised']
for e in completed:
    assert e['exit_status']==0
    for name,h in e['artifact_sha256'].items():assert sha(ATTEMPT/e['phase']/name)==h
for previous,current in [('reference','baseline'),('baseline','supervised')]:
    previous_end=next(e['at'] for e in completed if e['phase']==previous)
    assert metadata[current]['started_at']>=previous_end
scan=next(e for e in events if e['kind']=='eligibility_scan')
assert scan['prefix_bytes']==item['observations_bytes'] and scan['prefix_sha256']==item['observations_sha256']
assert scan['at']>receipt['at'] and scan['prefix_matches_original']
# Read only the sealed byte-length prefix, not any newly appended capture.
with (RECORDINGS/'market-observations.jsonl').open('rb') as f:original_prefix=f.read(scan['prefix_bytes'])
assert hashlib.sha256(original_prefix).hexdigest()==scan['prefix_sha256']
attempt_start=next(e for e in events if e['kind']=='attempt_started')
assert attempt_start['spec_sha256']==sha(ATTEMPT/'spec.json')

import numpy as np
lib=ROOT/'ctc/analog_library.npz'
assert sha(lib)=='22694387c3b612f5c20853feb9143e1bf8b8f5722a845da8ed584ab1b30bdf09'
with np.load(lib,allow_pickle=False) as z:tracks=z['tracks'].copy()
assert tracks.shape==(1350,241,4) and np.isfinite(tracks).all()
overlap=[]
for rnd in (1,2,3):
    points={};repeat=0
    for f in frames:
        m=f.get('message',{})
        if f['type']=='news' and m.get('type')=='storm' and m.get('round')==rnd:
            age=m['age'];point=[m[k] for k in ('x','y','radius','intensity')]
            if age in points:assert points[age]==point;repeat+=1
            points[age]=point
    assert sorted(points)==list(range(0,481,2))
    a=np.array([points[age] for age in sorted(points)])
    exact=np.flatnonzero(np.all(tracks==a[None,:,:],axis=(1,2))).tolist()
    overlap.append({'round':rnd,'observations':len(points),'repeated_identical':repeat,'exact_library_rows_zero_based':exact,
        'closest_rmse':float(np.sqrt(np.mean((tracks-a[None,:,:])**2,axis=(1,2))).min()),
        'track_sha256_float64le':hashlib.sha256(a.astype('<f8').tobytes()).hexdigest()})

def stats(rs,field):
    vals=[r[field] for r in rs]
    return {'runs':len(rs),'negative':sum(v<0 for v in vals),'positive':sum(v>0 for v in vals),
        'mean':math.fsum(vals)/len(vals),'worst':min(vals),'best':max(vals)}
report={'capture':249,'competition_id':CID,'completed_at':time.time(),'receipt':receipt,'cache':cache_info,
    'source_sha256':sources,'spec_sha256':sha(ATTEMPT/'spec.json'),
    'worker24':stats(worker_rows,'simulated_settlement_pnl'),
    'serialized16':stats(serial_rows,'simulated_settlement_pnl'),
    'supervised16':stats(rows['supervised'],'terminal_settlement_pnl'),
    'trial_states':dict(collections.Counter(r['trial_state'] for r in rows['supervised'])),
    'cleanup_states':dict(collections.Counter(r['cleanup']['state'] for r in rows['supervised'])),
    'attention':attention,'journal_files':112,'journals':journals,'phase_events':events,
    'overlap':overlap,'npz_sha256':sha(lib),'forbidden_attempts':FORBIDDEN,
    'receipt_frame_hashes_match_all_phases':True,'all_88_result_rows_checked':True,
    'phase_results_sha256':expected_phase_hashes,
    'input_audit_sha256':sha(OUT/'input-audit.json'),
    'news':input_audit['news'],'quote_gaps':input_audit['quote_gaps'],
    'fills_after_final_receipt_requests':[{**dict(zip(('rtt','depth','basket'),key(r))),'fills':r['fills_after_final_receipt_requests']} for r in rows['supervised']],
    'primary_supervised':next(r for r in rows['supervised'] if key(r)==(.25,1.,True)),
    'limitations':['Variants of one captured path are not independent seasons.',
        'Quote path completeness and disconnect counts remain unknown.',
        'Chronological source freezes do not establish absence of fitted-weather overlap.',
        'Settled positions need not be flat; completed trial classification is checked separately.',
        'No live account P&L, market impact or unobserved quote path is verified.']}
assert not FORBIDDEN and all(sha(p)==h for p,h in sources.items())
dump('audit.json',report)
print(json.dumps({k:report[k] for k in ['worker24','serialized16','supervised16','trial_states','cleanup_states','overlap','journal_files','forbidden_attempts']}),flush=True)
