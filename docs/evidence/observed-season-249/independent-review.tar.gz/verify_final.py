"""Final artifact checks only; does not import or rerun an evaluator."""
import collections
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path

OUT=Path(__file__).resolve().parent
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,v):(OUT/name).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
audit=load(OUT/'audit.json');cache=load(OUT/'249.json');frames=cache['frames']
assert audit['all_88_result_rows_checked'] and audit['journal_files']==112
assert audit['forbidden_attempts']==[] and audit['trial_states']=={'completed':16} and audit['cleanup_states']=={'settled':16}
assert all(sha(p)==h for p,h in audit['source_sha256'].items())
messages=[f['message'] for f in frames if f.get('type')=='news']
seqs=[m['seq'] for m in messages if m.get('seq') is not None]
assert sorted(seqs)==list(range(cache['receipt']['coverage']['last_seq']+1))
finals=[(m['round'],m['seq']) for m in messages if m.get('type')=='damage_report' and m.get('stage')=='final']
assert [list(x) for x in finals]==audit['news']['final_rounds_and_sequences']
windows=audit['cache']['coverage']['round_windows'];groups=collections.defaultdict(list)
for f in frames:
    if f.get('type')!='quote':continue
    if not all(type(f.get(k)) in(int,float) and math.isfinite(f[k]) for k in ('bid','ask','bid_size','ask_size')):continue
    if not (0<f['bid']<=f['ask'] and min(f['bid_size'],f['ask_size'])>=0):continue
    for rnd,w in windows.items():
        if w['first_at']<=f['received_at']<=w['closed_at']:
            groups[rnd,f['symbol']].append(f['received_at']);break
gaps=[(b-a,int(rnd),s,a,b) for (rnd,s),times in groups.items() for a,b in zip(times,times[1:])]
worst_gap=max(gaps)
first_gaps={s:times[0]-windows['1']['first_at'] for (rnd,s),times in groups.items() if rnd=='1'}
expected={'reference':[(.25,1.,True),(1.,.5,False)],'supervised':[(.25,1.,True),(1.,.5,False),(0.,1.,False)],'worker':[(.25,1.,True)]}
reruns=[];journal_count=0
for mode,settings in expected.items():
    summary=load(OUT/f'rerun-{mode}/summary.json')
    assert summary['changed_sources']==summary['forbidden_attempts']==[]
    assert [tuple(r['setting']) for r in summary['rows']]==settings
    assert all(sha(p)==h for p,h in summary['source_sha256'].items())
    assert summary['cache_sha256']==audit['cache']['file_sha256']
    for r in summary['rows']:
        assert r['all_result_fields_match'] and r['different_fields']==[] and not r['forbidden_attempts']
        rtt,depth,basket=r['setting'];d=OUT/f'rerun-{mode}'/f'{rtt}-{depth}-{int(basket)}'
        assert sha(d/'result.json')==r['result_sha256']
        assert sha(d/'request-trace.json.gz')==r['request_file_sha256']
        assert sha(d/'fill-trace.json.gz')==r['fill_file_sha256']
        if mode=='supervised':
            assert len(r['journal_byte_comparisons'])==7 and all(x['byte_identical'] and x['original_sha256']==x['rerun_sha256'] for x in r['journal_byte_comparisons'].values())
            journal_count+=7
        reruns.append(dict(mode='serialized' if mode=='reference' else mode,setting=r['setting'],pnl=r['pnl'],
            exact_fields=True,trace_hashes=r['trace_hashes'],first_settlement_access=r['first_settlement_value_access'],
            cutoff=r['cutoff'],receipt_available=r['receipt_available_at'],journal_byte_identical=mode=='supervised'))
assert len(reruns)==6 and journal_count==21
assert not list(OUT.rglob('failed-attempt.json'))
primary=audit['primary_supervised']
verification=dict(six_authorized_reruns=reruns,performance_rerun_count=6,candidate_runs=0,
    replay_failures=[],original_rows_checked=88,original_standard_journals_checked=112,
    reproduced_supervised_journal_files_byte_identical=21,source_files_unchanged=len(audit['source_sha256']),
    news_sequence_range=[min(seqs),max(seqs)],unique_news_sequences=len(set(seqs)),final_report_round_and_seq=finals,
    largest_later_valid_quote_gap={'seconds':worst_gap[0],'round':worst_gap[1],'symbol':worst_gap[2],'from':worst_gap[3],'to':worst_gap[4]},
    initial_round1_snapshot_to_first_valid_quote_gaps=first_gaps,
    subscription_acknowledgements=audit['cache']['coverage']['subscription_acknowledgements'],
    primary_terminal_settlement_pnl=primary['terminal_settlement_pnl'],primary_final_receipt_mark_pnl=primary['final_receipt']['pnl'],
    primary_settled_not_flat=primary['cleanup']['state']=='settled' and not primary['final_receipt']['flat'],
    source_receipt_cache_hashes={'spec':audit['spec_sha256'],'npz':audit['npz_sha256'],
        'frames_value':audit['cache']['frames_value_sha256'],'receipt_value':audit['cache']['receipt_value_sha256'],
        'cache_file':audit['cache']['file_sha256']})
save('verification.json',verification)

# Dynamic report: no outcome assumptions copied from capture 248.
def utc(value):return datetime.fromtimestamp(value,timezone.utc).isoformat()
inputs=load(OUT/'input-audit.json');cov=audit['cache']['coverage'];receipt=audit['receipt']
assert audit['input_audit_sha256']==sha(OUT/'input-audit.json')
assert verification['largest_later_valid_quote_gap']==inputs['quote_gaps']['largest_later_interquote_gap']
assert all(r['fills']==0 for r in audit['fills_after_final_receipt_requests'])
assert len(audit['source_sha256'])==91
primary=audit['primary_supervised'];peak_gap=verification['largest_later_valid_quote_gap']
opening=max(verification['initial_round1_snapshot_to_first_valid_quote_gaps'].values())
summary_rows='\n'.join(f"| {label} | {audit[key]['runs']} | {audit[key]['positive']} | {audit[key]['negative']} | {audit[key]['mean']:.6f} | {audit[key]['worst']:.2f} | {audit[key]['best']:.2f} |" for label,key in [('Original fixed worker','worker24'),('Serialized client','serialized16'),('Supervised client','supervised16')])
repro_rows='\n'.join(f"| {r['mode']} | {r['setting'][0]} / {r['setting'][1]} / {'on' if r['setting'][2] else 'off'} | {r['pnl']:.2f} | exact |" for r in reruns)
text=f"""# Independent original capture 249 audit

## Verdict

The original evidence checks and exactly six authorized reproductions passed. No blocker was found in the reported original results. These are virtual outcomes on one captured market path, with exact fitted-weather overlap and incomplete quote coverage; they are not actual account attribution or evidence about unseen weather.

CID: `7d19a254-8c3b-4c4a-b4f3-32c84a138b79`; fictional year `1778`.

## Closure and provenance

- Official observer receipt: **{utc(receipt['at'])}**, epoch `{receipt['at']}`. Both clocks are ready and identify the same CID/year; all 12 finite positive settlement prices and three final reports are present.
- Selected interval: **{utc(audit['cache']['first_at'])}** through **{utc(audit['cache']['last_at'])}**; **{audit['cache']['frame_count']} selected frames**, all before the official receipt. The last-frame fence leaves **{receipt['at']-audit['cache']['last_at']:.6f} seconds** until receipt availability.
- The entire selected interval follows the frozen serialized source `505a5ad2`, supervisor driver `c5c35a30`, and corrected runtime `cd3eb239`. The fixed worker remains `49a690ef`. All **91 manifested source/model paths** remain unchanged; runtime blobs are also bound to their declared Git revision.
- Sealed scan-005 observations: **302,691 bytes**, SHA256 `7bc07715c40590111d460f54a2aca74108b7c2fa5673de91aa643fefed43338f`. Its exact byte-length prefix matches the original observer ledger without reading later appended observations.
- Sealed feed: **66,111,365 bytes**, SHA256 `3f65b4d278b84dc2947fd0954c28de636fe1fcd0cc2898aeba30f31733b12207`. Its exact byte-length prefix also matches the original append-only feed. Canonical selected frames and receipt match every original evaluator.
- All three supervisor phases have 16 rows, zero errors/mismatches/source changes, and successful completion hashes. Reference/baseline fields and request/fill hashes reproduce the original serialized grid. Baseline and supervised prerequisites are bound by result hashes and phase order. The reference phase starts after the recorded serialized completion. Supplemental bounded worker/serialized/supervised ledger prefixes and their audit-created hashes are retained; these new prefix hashes are not represented as pre-existing execution seals.
- Ready-receipt validation preceded selector and fitted-track loading. Network, credentials, downloaded history and library-build manifests were denied. No active capture-250 outcomes were inspected.

## Original results

**88 original rows** were checked: 24 worker, 16 serialized, and 48 reference/baseline/supervised rows. The phase rows repeat settings and must not be counted as independent trials.

| Evaluation | Rows | Positive | Negative | Mean virtual P&L | Worst | Best |
|---|---:|---:|---:|---:|---:|---:|
{summary_rows}

All 16 supervised trials are completed and settled; none require attention. All **112 standard journal files** reconcile with their rows, receipts, actions and status. Ownership is clear and reported position maxima satisfy the 10% caps. No fills occur after final receipt requests in these runs.

Primary `.25/full/on`: terminal settlement **${primary['terminal_settlement_pnl']:.2f}**; final-receipt contemporaneous mark **${primary['final_receipt']['pnl']:.2f}**. Its nine nonzero settled holdings and zero open orders mean it is **settled, not flat**. Settlement success does not mean liquidation. The primary server's lowest marked P&L is **${primary['lowest_marked_pnl']:.2f}**, and peak-to-trough marked drawdown is **${primary['maximum_marked_drawdown']:.2f}**. These are different measures; drawdown is not the fresh-batch loss-trigger value.

## Exactly six authorized reproductions

| Evaluator | RTT / depth / baskets | Virtual P&L | Original fields |
|---|---|---:|---|
{repro_rows}

All five serialized/supervised request and fill hashes match the original rows. The three supervised reruns reproduce **21 journal files byte for byte**. Every rerun reconciles fill cash and terminal holdings to its reported terminal settlement value. Full request/fill traces are retained; the worker retains virtual action traces and uses current snapshot behavior (`reset_warmup_each_snapshot=False`). No candidate-policy run or additional setting was evaluated. Zero forbidden-access attempts and zero reproduction failures were observed.

Settlement-value access was guarded until matching closed; supervised reads also waited for official receipt availability. This is an accounting/timing constraint, not a claim about executable liquidity in the unobserved tail.

## Coverage and training overlap

- **{len(set(seqs))} unique contiguous news messages**, sequences **{min(seqs)}–{max(seqs)}**, with no duplicate sequences. Final damage reports are at **283 / 569 / 861** for rounds 1 / 2 / 3.
- **{cov['quote_count']} quote frames**, including **{cov['unusable_quotes']} unusable quotes**. There are zero explicit disconnect frames and zero subscription acknowledgements. This does not establish absence of disconnects or complete capture of the quote path.
- Initial round-one snapshot-to-first-valid-quote delay reaches **{opening:.6f} seconds**. The separate largest later within-round valid interquote gap is **{peak_gap['seconds']:.6f} seconds**, **{peak_gap['symbol']} round {peak_gap['round']}**. Receive-time gaps do not prove missing server events.
- Each weather track has all **241 observations at ages 0–480 by two seconds**. After closure, all four channels `(x, y, radius, intensity)` exactly match fitted NPZ rows **744 / 745 / 746**, respectively, with closest RMSE **0**. The NPZ SHA256 is `22694387c3b612f5c20853feb9143e1bf8b8f5722a845da8ed584ab1b30bdf09`.

Chronological freezing does not remove training overlap. Quote-path completeness, unseen-weather generalization, live P&L, impact, competing traders and execution on unobserved liquidity remain unverified. No live activation is implied.

## Artifacts

`audit.json` records all 88 rows, 112 journal hashes, source checks, phase evidence and fitted-track overlap. `input-audit.json` and `verification.json` retain independent coverage arithmetic and all six exact reproductions. `249.json` is the reconstructed closed cache. `original/` holds copied producer artifacts, logs, sealed observation prefix and all 112 journals. Each rerun directory retains full traces and comparisons. `artifact-hashes.json` binds every packaged artifact.

Canonical frames SHA256: `{audit['cache']['frames_value_sha256']}`. Canonical receipt SHA256: `{audit['cache']['receipt_value_sha256']}`. Independently serialized cache SHA256: `{audit['cache']['file_sha256']}`. Different JSON whitespace may change raw bytes without changing canonical input values.
"""
(OUT/'README.md').write_text(text)
print(json.dumps({'original_rows':88,'standard_journals':112,'exact_reruns':6,'identical_rerun_journals':21,'source_paths':len(audit['source_sha256']),'supervised':audit['supervised16'],'cache_sha256':audit['cache']['file_sha256'],'forbidden_attempts':[]},indent=2))
