"""Verify bounded producer ledger/feed prefixes; no performance evaluations."""
from pathlib import Path
import hashlib,json,sys
BASE=Path('/Users/arjunhans/Documents/ctc2026/recordings/consistency-20261024')
OUT=Path(__file__).resolve().parent
CID='7d19a254-8c3b-4c4a-b4f3-32c84a138b79'
ATTEMPT=BASE/'supervised-forward'/CID/'attempt-01'
forbidden=[]
allowed={str(BASE/'feed.jsonl'),str(BASE/'serialized-forward/attempts.jsonl'),str(BASE/'supervised-forward/attempts.jsonl'),str(BASE/'fixed-observed-evaluation/ledger.jsonl')}
def guard(event,args):
    if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
        forbidden.append(event);raise RuntimeError('Network forbidden')
    if event=='open' and isinstance(args[0],(str,bytes)):
        s=str(args[0]);low=s.lower()
        if any(x in low for x in ('/data/history/','.botkey','/.env','credentials','manifest')) or ('/recordings/' in s and CID not in s and s not in allowed):
            forbidden.append(s);raise RuntimeError('Forbidden input')
sys.addaudithook(guard)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def bounded(label,path,last):
    raw=bytearray();events=[];done=False
    with path.open('rb') as f:
        for line in f:
            assert line.endswith(b'\n');raw.extend(line);e=json.loads(line)
            if e.get('competition_id')==CID:events.append(e)
            if e.get('competition_id')==CID and last(e):done=True;break
    assert done,label
    dst=OUT/f'{label}-ledger-prefix.jsonl';dst.write_bytes(raw)
    return {'path':str(path),'audit_prefix_path':str(dst),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'capture_events':events}
spec=load(ATTEMPT/'spec.json');item=spec['captures'][0]
with (BASE/'feed.jsonl').open('rb') as f:raw=f.read(item['feed_bytes'])
assert len(raw)==item['feed_bytes'] and hashlib.sha256(raw).hexdigest()==item['feed_sha256']
serial=bounded('serialized',BASE/'serialized-forward/attempts.jsonl',lambda e:e.get('kind')=='attempt_completed')
sup=bounded('supervised',BASE/'supervised-forward/attempts.jsonl',lambda e:e.get('kind')=='phase_completed' and e.get('phase')=='supervised')
worker=bounded('worker',BASE/'fixed-observed-evaluation/ledger.jsonl',lambda e:e.get('kind')=='evaluated')
starts=[e for e in serial['capture_events'] if e['kind']=='attempt_started'];ends=[e for e in serial['capture_events'] if e['kind']=='attempt_completed']
assert len(starts)==len(ends)==1
start,end=starts[0],ends[0]
assert start['receipt_at']==1792841026.283543 and start['receipt_sha256']=='b067d33043f12a2f8f11552f14b589a50f5130932a70eca59026a3a6b4d0bdcc'
assert start['source_revision']=='505a5ad2d5a6f81e7c711cb550871ce7aa7f3734'
assert start['at']>start['receipt_at'] and end['at']>=start['at']
assert end['exit_status']==end['scenario_errors']==0 and end['scenario_count']==16
for name,h in end['artifact_sha256'].items():assert sha(BASE/'serialized-forward'/CID/name)==h
assert start['observations_sha256']==item['observations_sha256'] and start['feed_prefix_sha256']==item['feed_sha256']
assert load(ATTEMPT/'reference/metadata.json')['started_at']>=end['at']
completed=[e for e in sup['capture_events'] if e['kind']=='phase_completed']
assert [e['phase'] for e in completed]==['reference','baseline','supervised']
for e in completed:
    assert e['exit_status']==0
    for name,h in e['artifact_sha256'].items():assert sha(ATTEMPT/e['phase']/name)==h
assert len(worker['capture_events'])==1
w=worker['capture_events'][0]
assert w['artifact_sha256']==sha(BASE/'fixed-observed-evaluation'/f'{CID}.json')
assert w['receipt_sha256']==start['receipt_sha256']
assert not forbidden
report={'serialized':serial,'supervised':sup,'worker':worker,'original_feed_prefix_bytes':len(raw),'original_feed_prefix_sha256':hashlib.sha256(raw).hexdigest(),'original_feed_prefix_matches_sealed':True,'reference_started_after_serialized_completion':True,'forbidden_attempts':forbidden,'note':'Audit-created bounded ledger-prefix hashes; no claim that these supplemental prefix hashes existed at original execution.'}
(OUT/'ledger-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'ledger_prefixes':3,'original_feed_prefix_match':True,'forbidden_attempts':forbidden}))
