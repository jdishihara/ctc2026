# Independent original capture 249 audit

## Verdict

The original evidence checks and exactly six authorized reproductions passed. No blocker was found in the reported original results. These are virtual outcomes on one captured market path, with exact fitted-weather overlap and incomplete quote coverage; they are not actual account attribution or evidence about unseen weather.

CID: `7d19a254-8c3b-4c4a-b4f3-32c84a138b79`; fictional year `1778`.

## Closure and provenance

- Official observer receipt: **2026-10-24T11:23:46.283543+00:00**, epoch `1792841026.283543`. Both clocks are ready and identify the same CID/year; all 12 finite positive settlement prices and three final reports are present.
- Selected interval: **2026-10-24T10:36:43.060110+00:00** through **2026-10-24T11:23:44.083031+00:00**; **22930 selected frames**, all before the official receipt. The last-frame fence leaves **2.200512 seconds** until receipt availability.
- The entire selected interval follows the frozen serialized source `505a5ad2`, supervisor driver `c5c35a30`, and corrected runtime `cd3eb239`. The fixed worker remains `49a690ef`. All **91 manifested source/model paths** remain unchanged; runtime blobs are also bound to their declared Git revision.
- Sealed scan-005 observations: **302,691 bytes**, SHA256 `7bc07715c40590111d460f54a2aca74108b7c2fa5673de91aa643fefed43338f`. Its exact byte-length prefix matches the original observer ledger without reading later appended observations.
- Sealed feed: **66,111,365 bytes**, SHA256 `3f65b4d278b84dc2947fd0954c28de636fe1fcd0cc2898aeba30f31733b12207`. Its exact byte-length prefix also matches the original append-only feed. Canonical selected frames and receipt match every original evaluator.
- All three supervisor phases have 16 rows, zero errors/mismatches/source changes, and successful completion hashes. Reference/baseline fields and request/fill hashes reproduce the original serialized grid. Baseline and supervised prerequisites are bound by result hashes and phase order. The reference phase starts after the recorded serialized completion. Supplemental bounded worker/serialized/supervised ledger prefixes and their audit-created hashes are retained; these new prefix hashes are not represented as pre-existing execution seals.
- Ready-receipt validation preceded selector and fitted-track loading. Network, credentials, downloaded history and library-build manifests were denied. No active capture-250 outcomes were inspected.

## Original results

**88 original rows** were checked: 24 worker, 16 serialized, and 48 reference/baseline/supervised rows. The phase rows repeat settings and must not be counted as independent trials.

| Evaluation | Rows | Positive | Negative | Mean virtual P&L | Worst | Best |
|---|---:|---:|---:|---:|---:|---:|
| Original fixed worker | 24 | 24 | 0 | 1333.137083 | 1162.77 | 1556.01 |
| Serialized client | 16 | 16 | 0 | 1345.688750 | 1144.23 | 1711.86 |
| Supervised client | 16 | 16 | 0 | 1485.758125 | 1014.34 | 1795.95 |

All 16 supervised trials are completed and settled; none require attention. All **112 standard journal files** reconcile with their rows, receipts, actions and status. Ownership is clear and reported position maxima satisfy the 10% caps. No fills occur after final receipt requests in these runs.

Primary `.25/full/on`: terminal settlement **$1760.14**; final-receipt contemporaneous mark **$1755.61**. Its nine nonzero settled holdings and zero open orders mean it is **settled, not flat**. Settlement success does not mean liquidation. The primary server's lowest marked P&L is **$-50.47**, and peak-to-trough marked drawdown is **$388.62**. These are different measures; drawdown is not the fresh-batch loss-trigger value.

## Exactly six authorized reproductions

| Evaluator | RTT / depth / baskets | Virtual P&L | Original fields |
|---|---|---:|---|
| serialized | 0.25 / 1.0 / on | 1244.04 | exact |
| serialized | 1.0 / 0.5 / off | 1150.31 | exact |
| supervised | 0.25 / 1.0 / on | 1760.14 | exact |
| supervised | 1.0 / 0.5 / off | 1348.52 | exact |
| supervised | 0.0 / 1.0 / off | 1287.35 | exact |
| worker | 0.25 / 1.0 / on | 1309.52 | exact |

All five serialized/supervised request and fill hashes match the original rows. The three supervised reruns reproduce **21 journal files byte for byte**. Every rerun reconciles fill cash and terminal holdings to its reported terminal settlement value. Full request/fill traces are retained; the worker retains virtual action traces and uses current snapshot behavior (`reset_warmup_each_snapshot=False`). No candidate-policy run or additional setting was evaluated. Zero forbidden-access attempts and zero reproduction failures were observed.

Settlement-value access was guarded until matching closed; supervised reads also waited for official receipt availability. This is an accounting/timing constraint, not a claim about executable liquidity in the unobserved tail.

## Coverage and training overlap

- **862 unique contiguous news messages**, sequences **0–861**, with no duplicate sequences. Final damage reports are at **283 / 569 / 861** for rounds 1 / 2 / 3.
- **21974 quote frames**, including **46 unusable quotes**. There are zero explicit disconnect frames and zero subscription acknowledgements. This does not establish absence of disconnects or complete capture of the quote path.
- Initial round-one snapshot-to-first-valid-quote delay reaches **120.324696 seconds**. The separate largest later within-round valid interquote gap is **58.935127 seconds**, **REIN round 1**. Receive-time gaps do not prove missing server events.
- Each weather track has all **241 observations at ages 0–480 by two seconds**. After closure, all four channels `(x, y, radius, intensity)` exactly match fitted NPZ rows **744 / 745 / 746**, respectively, with closest RMSE **0**. The NPZ SHA256 is `22694387c3b612f5c20853feb9143e1bf8b8f5722a845da8ed584ab1b30bdf09`.

Chronological freezing does not remove training overlap. Quote-path completeness, unseen-weather generalization, live P&L, impact, competing traders and execution on unobserved liquidity remain unverified. No live activation is implied.

## Artifacts

`audit.json` records all 88 rows, 112 journal hashes, source checks, phase evidence and fitted-track overlap. `input-audit.json` and `verification.json` retain independent coverage arithmetic and all six exact reproductions. `249.json` is the reconstructed closed cache. `original/` holds copied producer artifacts, logs, sealed observation prefix and all 112 journals. Each rerun directory retains full traces and comparisons. `artifact-hashes.json` binds every packaged artifact.

Canonical frames SHA256: `46c86a377736e0657c30f68cd1249ae85d0788981acacf7aa0794dc6639b1c2e`. Canonical receipt SHA256: `b067d33043f12a2f8f11552f14b589a50f5130932a70eca59026a3a6b4d0bdcc`. Independently serialized cache SHA256: `60cfdef5b57632b984a248a2123d3cc4d0cff1e0564413db9419e3d0467fb3ad`. Different JSON whitespace may change raw bytes without changing canonical input values.
