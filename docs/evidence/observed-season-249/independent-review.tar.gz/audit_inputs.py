"""Closed capture-249 input, original worker/core rows, coverage and weather audit; no replay."""
import collections
import hashlib
import itertools
import json
import math
from pathlib import Path
import subprocess
import sys
import time

BASE=Path('/Users/arjunhans/Documents/ctc2026')
OUT=Path(__file__).resolve().parent
REC=BASE/'recordings/consistency-20261024'
CID='7d19a254-8c3b-4c4a-b4f3-32c84a138b79'
ROOT=BASE/'.worktrees/supervised-forward'
REFERENCE=BASE/'.worktrees/serialized-forward'
WORKER=BASE/'.worktrees/closed-season-evaluation'
ATTEMPT=REC/'supervised-forward'/CID/'attempt-01'
forbidden=[];opened=set()
allowed_recording_files={str(REC/'supervised-forward/scans/scan-005.observations.jsonl'),str(REC/'market-observations.jsonl'),str(REC/'fixed-observed-evaluation/manifest.json'),str(REC/'fixed-observed-evaluation/ledger.jsonl')}
def guard(event,args):
    if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
        forbidden.append(event);raise RuntimeError('Network forbidden')
    if event=='open' and isinstance(args[0],(str,bytes)):
        name=str(args[0]);low=name.lower()
        if any(part in low for part in ('/data/history/','.botkey','/.env','credentials')) or ('manifest' in low and name not in allowed_recording_files):
            forbidden.append(name);raise RuntimeError('Forbidden outcome/credential/manifest read')
        if '/recordings/' in name and CID not in name and name not in allowed_recording_files:
            forbidden.append(name);raise RuntimeError('Unsealed or unrelated recording read')
        if '/ctc2026/' in name:opened.add(name)
sys.addaudithook(guard)
def load(p):return json.loads(Path(p).read_text())
def lines(p):return [json.loads(x) for x in Path(p).read_text().splitlines()]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def vh(x):return hashlib.sha256(json.dumps(x,sort_keys=True,allow_nan=False).encode()).hexdigest()
def dump(name,x):(OUT/name).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def key(r):return (r['rtt_seconds'],r['displayed_depth_fraction'],r['basket_enabled'])
def stats(rows,field):
    a=[r[field] for r in rows];assert all(math.isfinite(x) for x in a)
    return {'runs':len(a),'positive':sum(x>0 for x in a),'negative':sum(x<0 for x in a),'zero':sum(x==0 for x in a),'mean':math.fsum(a)/len(a),'worst':min(a),'best':max(a)}
assert sha(ATTEMPT/'spec.json')=='095faaf54718ac8cadb77d888eccf4a27ef29b06e072a9f27b8da7873b888bda'
spec=load(ATTEMPT/'spec.json');assert len(spec['captures'])==1
item=spec['captures'][0];assert item['capture']==249 and item['competition_id']==CID
for field,expected_bytes,expected_sha in [('observations',302691,'7bc07715c40590111d460f54a2aca74108b7c2fa5673de91aa643fefed43338f'),('feed',66111365,'3f65b4d278b84dc2947fd0954c28de636fe1fcd0cc2898aeba30f31733b12207')]:
    b=Path(item[field]).read_bytes()
    assert len(b)==item[field+'_bytes']==expected_bytes and b.endswith(b'\n')
    assert hashlib.sha256(b).hexdigest()==item[field+'_sha256']==expected_sha
receipts=[r for r in lines(item['observations']) if r.get('competition_id')==CID and r.get('kind')=='settlement']
assert len(receipts)==1
receipt=receipts[0]
assert vh(receipt)=='b067d33043f12a2f8f11552f14b589a50f5130932a70eca59026a3a6b4d0bdcc'
assert receipt['at']==1792841026.283543 and receipt['year']=='1778'
assert receipt['clock']==receipt['end_clock'] and receipt['clock']['state']=='ready'
assert receipt['source']=='read_only_market_observer' and receipt['clock']['competition_id']==CID
assert 1792829252<receipt['at']<1792843200
# Only after the ready gate is established do we import the selector / read fitted tracks.
sys.path.insert(0,str(ROOT))
from scripts.evaluate_observed_season import observed_capture
case=load(ROOT/'data/case.json')
selected,frames,coverage=observed_capture(item['observations'],item['feed'],CID,case['limits'])
assert selected==receipt and set(receipt['prices'])==set(case['limits'])
assert len(frames)==22930 and frames[0]['received_at']==1792838203.06011 and frames[-1]['received_at']==1792841024.083031
assert frames[0]['received_at']>1792829252 and frames[-1]['received_at']<receipt['at']
cache=OUT/'249.json';blob=(json.dumps({'frames':frames,'receipt':receipt},allow_nan=False)+'\n').encode()
if cache.exists():assert cache.read_bytes()==blob
else:cache.write_bytes(blob)
cache_info={'path':str(cache),'file_sha256':sha(cache),'frames_value_sha256':vh(frames),'receipt_value_sha256':vh(receipt),'frame_count':len(frames),'first_at':frames[0]['received_at'],'last_at':frames[-1]['received_at'],'receipt_at':receipt['at'],'coverage':coverage}
# Byte-bounded original observer prefix; never consume later appended observations.
with (REC/'market-observations.jsonl').open('rb') as f:prefix=f.read(item['observations_bytes'])
assert hashlib.sha256(prefix).hexdigest()==item['observations_sha256']
serial=REC/'serialized-forward'/CID
sm=load(serial/'metadata.json');sr=lines(serial/'results.jsonl');ss=load(serial/'summary.json')
for name in ('results','metadata','summary'):
    suffix='jsonl' if name=='results' else 'json'
    assert sha(serial/f'{name}.{suffix}')==item[f'archive_{name}_sha256']
assert sm['official_receipt']==receipt and sm['coverage']==coverage and sm['fraction']==.1
assert sm['source_revision']==spec['reference_revision']=='505a5ad2d5a6f81e7c711cb550871ce7aa7f3734'
assert sm['frames_sha256']==vh(frames) and sm['receipt_sha256']==vh(receipt) and sm['frame_count']==len(frames)
grid=set(itertools.product([0.,.05,.25,1.],[1.,.5],[False,True]))
assert len(sr)==16 and {key(r) for r in sr}==grid and all(r['status']=='ok' for r in sr)
assert ss['runs']==16 and ss['errors']==0
worker_path=REC/'fixed-observed-evaluation'/f'{CID}.json';w=load(worker_path);wr=w['results']
assert w['competition_id']==CID and w['year']=='1778' and w['fraction']==.1
assert w['official_receipt']==receipt and w['coverage']==coverage and w['worker']['receipt_sha256']==vh(receipt)
wgrid=set(itertools.product([.25,1.,3.],[1.,.5],[False,True],[True,False]))
assert len(wr)==24 and {(r['latency_seconds'],r['displayed_depth_fraction'],r['basket_enabled'],r['reset_warmup_each_snapshot']) for r in wr}==wgrid
manifest=load(REC/'fixed-observed-evaluation/manifest.json')
assert manifest['sources']==w['worker']['sources']
worker_events=[]
for line in (REC/'fixed-observed-evaluation/ledger.jsonl').open():
    e=json.loads(line)
    if e.get('competition_id')==CID:
        worker_events.append(e)
        if e.get('kind')=='evaluated':break
sources={str(REFERENCE/rel):h for rel,h in sm['source_sha256'].items()}
sources.update(w['worker']['sources'])
for name,h in sources.items():assert sha(name)==h,name
heads={}
for root,revision in [(ROOT,'c5c35a30e0c5f521f12324eec854f405b681b8c0'),(REFERENCE,spec['reference_revision']),(WORKER,'49a690ef')]:
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
    assert head.startswith(revision)
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
    heads[str(root)]=head
    for name,h in sources.items():
        p=Path(name)
        if p.is_relative_to(root):
            content=subprocess.check_output(['git','show',head+':'+p.relative_to(root).as_posix()],cwd=root)
            assert hashlib.sha256(content).hexdigest()==h,name
# Independent news and receive-gap arithmetic, based on observed round windows.
news=[f['message'] for f in frames if f.get('type')=='news'];seqs=[m['seq'] for m in news if 'seq' in m]
assert len(set(seqs))==receipt['coverage']['seq_count'] and set(seqs)==set(range(receipt['coverage']['last_seq']+1))
seq_duplicates=len(seqs)-len(set(seqs))
finals=[(m['round'],m['seq']) for m in news if m.get('type')=='damage_report' and m.get('stage')=='final']
assert {r for r,s in finals}=={1,2,3}
windows=coverage['round_windows'];groups=collections.defaultdict(list);invalid=0
for f in frames:
    if f.get('type')!='quote':continue
    valid=all(type(f.get(k)) in (int,float) and math.isfinite(f[k]) for k in ('bid','ask','bid_size','ask_size'))
    if not valid or not (0<f['bid']<=f['ask'] and min(f['bid_size'],f['ask_size'])>=0):invalid+=1;continue
    for rnd,window in windows.items():
        if window['first_at']<=f['received_at']<window['closed_at']:
            groups[rnd,f['symbol']].append(f['received_at']);break
assert invalid==coverage['unusable_quotes']
all_gaps=[];initial_gaps={};tail_gaps={}
for rnd,wnd in windows.items():
    for symbol in case['limits']:
        times=groups[rnd,symbol]
        assert len(times)==coverage['quote_count_by_round'][rnd][symbol] and times
        all_gaps.extend((b-a,int(rnd),symbol,a,b) for a,b in zip(times,times[1:]))
        checkpoints=[wnd['first_at'],*times,wnd['closed_at']];gs=[b-a for a,b in zip(checkpoints,checkpoints[1:])]
        assert {'max_seconds':max(gs),'over_five_seconds':sum(g>5 for g in gs)}==coverage['observed_quote_gaps'][rnd][symbol]
        initial_gaps[f'{rnd}:{symbol}']=times[0]-wnd['first_at'];tail_gaps[f'{rnd}:{symbol}']=wnd['closed_at']-times[-1]
worst=max(all_gaps)
import numpy as np
lib=ROOT/'ctc/analog_library.npz';assert sha(lib)=='22694387c3b612f5c20853feb9143e1bf8b8f5722a845da8ed584ab1b30bdf09'
with np.load(lib,allow_pickle=False) as z:tracks=z['tracks'].copy()
assert tracks.shape==(1350,241,4) and np.isfinite(tracks).all()
overlap=[]
for rnd in (1,2,3):
    points={}
    for m in news:
        if m.get('type')=='storm' and m.get('round')==rnd:
            p=[m[k] for k in ('x','y','radius','intensity')]
            if m['age'] in points:assert points[m['age']]==p
            points[m['age']]=p
    assert sorted(points)==list(range(0,481,2))
    a=np.array([points[k] for k in sorted(points)])
    exact=np.flatnonzero(np.all(tracks==a[None,:,:],axis=(1,2))).tolist()
    overlap.append({'round':rnd,'observations':len(points),'exact_library_rows_zero_based':exact,'closest_rmse':float(np.sqrt(np.mean((tracks-a[None,:,:])**2,axis=(1,2))).min()),'track_sha256_float64le':hashlib.sha256(a.astype('<f8').tobytes()).hexdigest()})
assert all(sha(p)==h for p,h in sources.items()) and not forbidden
report={'capture':249,'competition_id':CID,'checked_at':time.time(),'spec_sha256':sha(ATTEMPT/'spec.json'),'cache':cache_info,'receipt':receipt,'source_sha256':sources,'frozen_heads':heads,'worker24':stats(wr,'simulated_settlement_pnl'),'serialized16':stats(sr,'simulated_settlement_pnl'),'worker_events':worker_events,'worker_artifact_sha256':sha(worker_path),'worker_manifest_sha256':sha(REC/'fixed-observed-evaluation/manifest.json'),'news':{'unique_sequences':len(set(seqs)),'range':[min(seqs),max(seqs)],'duplicate_sequences':seq_duplicates,'final_rounds_and_sequences':finals},'quote_gaps':{'largest_later_interquote_gap':{'seconds':worst[0],'round':worst[1],'symbol':worst[2],'from':worst[3],'to':worst[4]},'initial_quote_delays':initial_gaps,'final_quote_to_close_delays':tail_gaps},'overlap':overlap,'npz_sha256':sha(lib),'forbidden_attempts':forbidden,'repository_files_opened':sorted(opened),'performance_replays_run':0}
dump('input-audit.json',report)
print(json.dumps({k:report[k] for k in ['worker24','serialized16','news','overlap','forbidden_attempts','performance_replays_run']},indent=2))
