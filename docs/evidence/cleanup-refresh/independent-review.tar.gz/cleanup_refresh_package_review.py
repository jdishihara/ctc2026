"""Package only retained offline audit evidence, without modifying source/output."""
import collections, hashlib, json, os, pathlib, shutil, sys, tarfile, tempfile
T=pathlib.Path('/var/folders/5_/4_9w4ch971l2mm9c6fqtg5400000gn/T')
forbidden=[]
def guard(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
  forbidden.append(event);raise RuntimeError('network forbidden')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  name=os.fsdecode(args[0]).lower()
  if '.botkey' in name or '/.env' in name or '/data/history/' in name or 'credentials' in name:
   forbidden.append(name);raise RuntimeError('credentials/downloaded-history forbidden')
sys.addaudithook(guard)
def H(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def J(p):return json.loads(p.read_text())
out=pathlib.Path(tempfile.mkdtemp(prefix='cleanup-refresh-independent-evidence-'))
for phase,folder in [('baseline','cleanup-refresh-independent-baseline-qh32mmd5'),('candidate','cleanup-refresh-independent-candidate-vcfw_q5b')]:
 shutil.copytree(T/folder,out/phase)
for name,path in [('artifact-audit.json',T/'cleanup-refresh-artifact-audit-zy8f73vf/audit.json'),('analysis-audit.json',T/'cleanup-refresh-analysis-audit-e2793szo/audit.json')]:
 shutil.copyfile(path,out/name);assert H(path)==H(out/name)
for name in ('cleanup_refresh_artifact_audit.py','cleanup_refresh_guarded_rerun.py','cleanup_refresh_analysis_audit.py','cleanup_refresh_package_review.py'):
 shutil.copyfile(pathlib.Path('/tmp')/name,out/name)
a=J(out/'artifact-audit.json');b=J(out/'baseline/independent-audit.json');c=J(out/'candidate/independent-audit.json');d=J(out/'analysis-audit.json')
counts=collections.Counter(b['counts']);counts.update(c['counts'])
assert all(not x['forbidden_attempts'] for x in (a,b,c,d))
assert len(b['cases'])==len(c['cases'])==6 and all(x['files_exact']==8 for phase in (b,c) for x in phase['cases'])
verdict={'verdict':'Approve negative execution evidence; reject promotion under the predeclared worse-worst-loss and higher-losing-setting-count rules.', 'candidate_revision':c['revision'],'baseline_revision':b['revision'],'all_pairs':80,'representative_runs':12,'representative_files_byte_exact':96,'guard_counts':dict(counts),'forbidden_attempts':forbidden,'frozen_sources_unchanged':b['sources_unchanged'] and c['sources_unchanged'],'pair_counts':a['pair_counts'],'metrics':a['metrics'],'loss_cleanup_mean':d['loss_cleanup_mean'],'analysis_exact':d['analysis_exact'],'limitations':['All 15 weather tracks are reported to overlap the fitted model library; this is an execution diagnostic on reused paths, not novel alpha or live profitability evidence.','Correlated settings, captured quote gaps, fixed latency/depth assumptions, independent fresh-batch zero prior P&L, and unresolved shared-account ownership remain.','Only closed captures 241-245 were loaded; no active/future outcomes, network or credentials were accessed.'],'audit_notes':['One assertion in the new analysis audit initially used incorrect endpoint names; it was corrected to the observed and source-defined /competitions/time and /orders endpoints. No runtime or retained experiment files changed.']}
(out/'verdict.json').write_text(json.dumps(verdict,indent=2,sort_keys=True)+'\n')
manifest={str(p.relative_to(out)):H(p) for p in sorted(out.rglob('*')) if p.is_file()}
(out/'artifact-manifest.json').write_text(json.dumps({'artifacts':manifest,'count':len(manifest)},indent=2,sort_keys=True)+'\n')
archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(out.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(out)),recursive=False)
with tarfile.open(archive) as tar:
 members=tar.getmembers();assert len(members)==len(manifest)+1
 for member in members:
  assert member.isfile();data=tar.extractfile(member).read();assert data==(out/member.name).read_bytes()
assert not forbidden
print(json.dumps({'directory':str(out),'archive':str(archive),'archive_sha256':H(archive),'manifest_sha256':H(out/'artifact-manifest.json'),'hashed_files':len(manifest),'archive_files':len(manifest)+1,'counts':dict(counts),'forbidden_attempts':forbidden}))
