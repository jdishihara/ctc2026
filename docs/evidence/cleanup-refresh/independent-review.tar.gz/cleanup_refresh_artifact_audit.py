"""Independent read-only audit of the complete frozen cleanup comparison."""
import collections, hashlib, itertools, json, math, os, pathlib, statistics, subprocess, sys, tempfile
ROOT=pathlib.Path('/Users/arjunhans/Documents/ctc2026'); O=ROOT/'out/cleanup-refresh-v1-20261024'
C=ROOT/'.worktrees/cleanup-empty-cancel'; B=ROOT/'.worktrees/practice-history'
REVS={C:'74c81f4d288f72e1248a6956ffcb15fea3970005',B:'cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026'}
forbidden=[]
def guard(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
  forbidden.append(event);raise RuntimeError('network forbidden')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  name=os.fsdecode(args[0]).lower()
  if '.botkey' in name or '/.env' in name or '/data/history/' in name or 'credentials' in name:
   forbidden.append(name);raise RuntimeError('sensitive/downloaded-history read forbidden')
sys.addaudithook(guard)
def J(p):return json.loads(pathlib.Path(p).read_text())
def R(p):return [json.loads(x) for x in pathlib.Path(p).read_text().splitlines()]
def H(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def VH(x):return hashlib.sha256(json.dumps(x,sort_keys=True,allow_nan=False).encode()).hexdigest()
def K(r):return r['capture'],r['rtt_seconds'],r['displayed_depth_fraction'],r['basket_enabled']
def near(a,b):assert math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-6),(a,b)
def directory(base,k):return base/f'capture-{k[0]}-{k[1]}-{k[2]}-{int(k[3])}'
JOURNALS=['observations.json','actions.jsonl','status.json','final-receipt.json','startup-feed.jsonl','result.json','run.lock']
grid=list(itertools.product(range(241,246),[0.,.05,.25,1.],[1.,.5],[False,True]))
phases={};source_hashes={};git_paths={}
for root,rev in REVS.items():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==rev
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root,text=True)
for phase in ('baseline','candidate'):
 d=O/phase;m=J(d/'metadata.json');s=J(d/'summary.json');rows=R(d/'results.jsonl');index={K(r):r for r in rows}
 assert len(rows)==len(index)==80 and [K(r) for r in rows]==grid
 assert m['phase']==phase and m['grid']==[list(k) for k in grid] and m['runtime_changes']==['bot/practice.py']
 assert m['candidate_revision']==REVS[C] and m['baseline_revision']==REVS[B]
 assert s['runs']==80 and s['errors']==0 and not s['changed_sources'] and not s['forbidden_attempts']
 assert math.isfinite(s['finished_at']) and s['finished_at']>=m['started_at']
 assert s['results_sha256']==H(d/'results.jsonl')
 for name,expected in m['source_sha256'].items():
  p=pathlib.Path(name);assert H(p)==expected,p;source_hashes[name]=expected
  for root,rev in REVS.items():
   if p.is_relative_to(root):
    blob=subprocess.check_output(['git','show',f'{rev}:{p.relative_to(root)}'],cwd=root)
    assert hashlib.sha256(blob).hexdigest()==expected,p
    git_paths[name]=expected
 for r in rows: assert r['status']=='ok' and not r['errors'] and r['comparison_status']==('exact_archive' if phase=='baseline' else 'identical_before_cleanup')
 phases[phase]=(m,s,index)
bm,bs,br=phases['baseline'];cm,cs,cr=phases['candidate']
assert bm['spec']==cm['spec']==J(O/'spec.json') and bm['source_sha256']==cm['source_sha256']
assert bs['finished_at']<=cm['started_at']<=cs['finished_at']
assert cm['baseline_results_sha256']==H(O/'baseline/results.jsonl')
for name,expected in cm['baseline_artifact_sha256'].items():assert H(name)==expected,name
case=J(C/'data/case.json');caps={s:max(1,math.floor(q*.1)) for s,q in case['limits'].items()}
inputs={};metas={};archive_rows={};archive_dirs={}
for item in bm['spec']['captures']:
 c=item['capture'];a=pathlib.Path(item['archive']);data=J(item['input']);am=J(a/'metadata.json');sm=J(a/'summary.json')
 assert H(item['input'])==item['input_sha256']
 if (O/'inputs'/f'{c}.json').exists():assert H(O/'inputs'/f'{c}.json')==item['input_sha256']
 for name,expected in item['archive_sha256'].items():assert H(a/name)==expected
 assert sm['errors']==sm['mismatches']==0 and not sm['changed_sources'] and sm['results_sha256']==H(a/'results.jsonl')
 selected=next(x for x in am['captures'] if x['capture']==c)
 assert VH(data['frames'])==selected['frames_sha256'] and VH(data['receipt'])==selected['receipt_sha256']
 assert data['receipt']['competition_id']==selected['competition_id']
 assert selected['year']==str(2027-c) and data['receipt']['clock']['state']=='ready'
 assert data['receipt']['clock']['competition_id']==selected['competition_id']
 assert str(data['receipt']['clock']['fictional_time']).startswith(selected['year']+'-')
 assert len(data['frames'])==selected['frame_count'] and data['frames'][0]['received_at']==selected['first_at'] and data['frames'][-1]['received_at']==selected['last_at']
 assert selected['last_at']<=data['receipt']['at']==selected['receipt_at']
 assert set(data['receipt']['prices'])==set(caps) and all(type(p) in (int,float) and math.isfinite(p) and p>0 for p in data['receipt']['prices'].values())
 seqs={f['message']['seq'] for f in data['frames'] if f.get('type')=='news' and 'seq' in f['message']}
 assert seqs==set(range(len(seqs))) and len(seqs)==selected['coverage']['news_count']
 inputs[c]=data;metas[c]=selected;archive_dirs[c]=a
 for r in R(a/'results.jsonl'):
  if r['capture']==c:assert K(r) not in archive_rows;archive_rows[K(r)]=r
assert set(archive_rows)==set(grid)
extra={'capture','comparison_status','pre_cleanup_trace','journal_sha256'}
fixed=['stop_reason','stop_at','stop_phase','stop_market_open','monitor_started_at','monitor_detected_at','cleanup_started_at','final_report_rounds','history_block_reason','prefix_messages','client_steps']
for k in grid:
 a,b=br[k],cr[k]
 assert a['journal_sha256']['observations.json']==b['journal_sha256']['observations.json']
 assert a['journal_sha256']['startup-feed.jsonl']==b['journal_sha256']['startup-feed.jsonl']
 assert {f:v for f,v in a.items() if f not in extra}=={f:v for f,v in archive_rows[k].items() if f not in ('capture','comparison_status')},k
 assert a['pre_cleanup_trace']==b['pre_cleanup_trace'] and all(a[f]==b[f] for f in fixed),k
 for name in JOURNALS:assert (directory(O/'baseline',k)/name).read_bytes()==(directory(archive_dirs[k[0]],k)/name).read_bytes(),(k,name)
profiles=[];stops=[];attention=[];journal_files=0
for phase,(_,_,rows) in phases.items():
 for k,r in rows.items():
  c,rtt,depth,basket=k;d=directory(O/phase,k);meta=metas[c];cid=meta['competition_id']
  assert set(r['journal_sha256'])==set(JOURNALS+['cleanup-profile.json'])
  for name,sha in r['journal_sha256'].items():assert H(d/name)==sha,(phase,k,name);journal_files+=1
  assert J(d/'result.json')=={f:v for f,v in r.items() if f not in extra}
  status=J(d/'status.json');receipt=J(d/'final-receipt.json');obs=J(d/'observations.json');actions=R(d/'actions.jsonl')
  assert r['observed_final_receipt']==receipt and r['final_receipt']==status['latest']['final_receipt'] and r['cleanup']==status['latest']['cleanup']
  assert r['trial']==status['trials'][cid] and r['stop_reason']==status['stop_reason']
  assert (status['fraction'],status['loss_trigger'],status['target_seasons'])==(.1,250.,1)
  assert not status['ownership_blocks'] and status['owned_order_count']==r['orders'] and r['orders']<500
  assert r['terminal_closed'] and r['history_block_reason'] is None
  assert not r['server_orders_after_final_receipt'] and not r['fills_after_final_receipt_requests']
  assert r['server_positions_after_final_receipt']==r['final_positions']
  assert r['request_count']==sum(r['request_counts'].values())
  assert r['stop_at']<=r['monitor_detected_at']<=r['cleanup_started_at']<=r['cleanup_completed_at']==r['final_client_time']
  near((r['monitor_detected_at']-r['monitor_started_at'])/.5,round((r['monitor_detected_at']-r['monitor_started_at'])/.5))
  near(r['cutoff_seconds'],meta['last_at']-meta['first_at']);near(r['settlement_available_at'],meta['receipt_at']-meta['first_at'])
  assert all(abs(r['final_positions'][s])<=limit and r['maximum_absolute_positions'][s]<=limit for s,limit in caps.items())
  assert all(receipt[f] for f in ('identity_verified','history_ownership_clear','account_valid','verified')) and receipt['account_error'] is None
  assert receipt['clock']['competition_id']==receipt['end_clock']['competition_id']==cid
  rr=receipt['positions']['positions'];assert {p['symbol']:p['quantity'] for p in rr}==r['final_positions']
  near(sum(p['realized_pnl']+p['unrealized_pnl'] for p in rr),r['final_receipt']['pnl'])
  terminal=sum(p['realized_pnl']+(p['quantity']*(inputs[c]['receipt']['prices'][p['symbol']]-p['average_price']) if p['quantity'] else 0) for p in rr)
  near(terminal,r['terminal_settlement_pnl'])
  assert r['final_receipt']['flat']==all(p['quantity']==0 for p in rr)
  assert len(r['final_receipt_requests'])==5
  for request in r['final_receipt_requests']:
   assert request['method']=='GET' and r['cleanup_started_at']<=request['started_at']<=request['executed_at']<=request['completed_at']<=r['cleanup_completed_at']
   near(request['executed_at']-request['started_at'],rtt/2);near(request['completed_at']-request['started_at'],rtt)
  assert [o['observed_at'] for o in obs]==sorted(o['observed_at'] for o in obs)
  for o in obs:
   assert o['positions_started_at']<=o['positions_executed_at']<=o['positions_completed_at']<=o['observed_at']
   near(o['positions_executed_at']-o['positions_started_at'],rtt/2)
  for a in actions:
   if a['kind']=='request_attempt':assert a['at']-meta['first_at']<=r['stop_at']+1e-6
  assert r['trial']['attempt_count']==sum(a['kind']=='request_attempt' for a in actions)
  settlements=[a for a in actions if a['kind']=='settlement']
  if r['trial_state']=='completed':
   assert r['trial']['completed'] and r['cleanup']['state']=='settled' and len(settlements)==1 and r['final_report_rounds']==[1,2,3]
   assert settlements[0]['at']>=meta['receipt_at'] and r['stop_at']>=r['settlement_available_at']
   near(settlements[0]['pnl'],terminal);near(r['trial']['settlement_pnl'],terminal)
  else:
   assert r['trial_state']=='incomplete_trial' and not r['trial']['completed'] and not settlements
   assert r['stop_reason'].startswith('cumulative simulated P&L reached loss trigger')
   atstop=[o for o in obs if abs(o['observed_at']-r['stop_at'])<1e-7];assert atstop and atstop[0]['pnl']<=-250
   stops.append(dict(phase=phase,setting=k,stop_sample=atstop[0],pnl=r['terminal_settlement_pnl']))
  if r['cleanup']['state']=='flat':assert receipt['flat'] and not any(r['final_positions'].values())
  if r['cleanup']['state']=='attention':
   assert not receipt['flat'] and r['cleanup']['reason']=='cleanup retry limit'
   attention.append(dict(phase=phase,setting=k,positions={s:q for s,q in r['final_positions'].items() if q},pnl=terminal))
  prof=J(d/'cleanup-profile.json');previous=r['cleanup_started_at'];books={};position=None;orders=None;lastclock=None;ages=[];posts=[];direct_checks=0
  assert prof and prof[0]['request']['started_at']==r['cleanup_started_at']
  for i,entry in enumerate(prof):
   req=entry['request'];method,path=req['method'],req['path'];start,mid,end=(req[x] for x in ('started_at','executed_at','completed_at'))
   assert previous-1e-7<=start<=mid<=end<=r['cleanup_completed_at']+1e-7
   near(mid-start,rtt/2);near(end-start,rtt);previous=end
   if method=='GET' and path=='/positions?include_zero=true':position={p['symbol']:p['quantity'] for p in req['response']['positions']}
   if method=='GET' and path=='/orders/open':orders=req['response']['orders']
   if method=='GET' and path=='/competitions/time':lastclock=req['response']
   if method=='GET' and path.startswith('/orderbook/'):
    symbol=path.split('/')[2].split('?')[0];books[symbol]=req
    expected_paths=['/competitions/time','/orders/open','/positions?include_zero=true','/trades','/orders?limit=500','/competitions/time']
    actual_sequence=[(x['request']['method'],x['request']['path']) for x in prof[i+1:i+7]]
    assert actual_sequence==[('GET',p) for p in expected_paths],(phase,k,'post-book reconciliation sequence',actual_sequence)
    direct_checks+=1
   if method=='POST':
    assert path=='/orders' and not orders and lastclock['competition_id']==cid and lastclock['state']=='running'
    body=req['body'];symbol=body['symbol'];q=position[symbol]
    assert q and body['side']==('sell' if q>0 else 'buy') and 0<body['quantity']<=abs(q)
    book=books[symbol];age=mid-book['executed_at'];near(age,rtt*9);ages.append(age)
    levels=book['response']['bids' if q>0 else 'asks'];raw=max(.01,levels[0]['price']*(.99 if q>0 else 1.01))
    expected=round((math.ceil(raw/.01-1e-9) if q>0 else math.floor(raw/.01+1e-9))*.01,2);near(body['price'],expected)
    posts.append(dict(symbol=symbol,quantity=body['quantity'],side=body['side'],price=body['price'],executed_at=mid,quote_age=age))
  near(prof[-1]['request']['completed_at'],r['cleanup_completed_at'])
  profiles.append(dict(phase=phase,setting=k,duration=r['cleanup_completed_at']-r['cleanup_started_at'],requests=len(prof),request_seconds=len(prof)*rtt,closing_posts=posts,quote_ages=ages,postbook_checks=direct_checks))
metrics={}
for phase,(_,_,rows) in phases.items():
 vals=[r['terminal_settlement_pnl'] for r in rows.values()]
 metrics[phase]=dict(count=len(vals),sum=sum(vals),mean=statistics.mean(vals),min=min(vals),max=max(vals),positive=sum(v>0 for v in vals),negative=sum(v<0 for v in vals),cleanup=dict(collections.Counter(r['cleanup']['state'] for r in rows.values())),trial=dict(collections.Counter(r['trial_state'] for r in rows.values())))
pairs=[]
for k in grid:
 a,b=br[k],cr[k];delta=b['terminal_settlement_pnl']-a['terminal_settlement_pnl']
 pairs.append(dict(setting=k,baseline_pnl=a['terminal_settlement_pnl'],candidate_pnl=b['terminal_settlement_pnl'],delta=delta,baseline_duration=a['cleanup_completed_at']-a['cleanup_started_at'],candidate_duration=b['cleanup_completed_at']-b['cleanup_started_at'],baseline_receipt_pnl=a['final_receipt']['pnl'],candidate_receipt_pnl=b['final_receipt']['pnl'],changed_fields=[f for f in a if f not in extra and a[f]!=b[f]]))
assert sum(abs(p['delta'])>1e-7 for p in pairs)==4
assert (O/'baseline/results.jsonl').read_bytes()==(ROOT/'out/cleanup-quotes-v1-20261024/baseline/results.jsonl').read_bytes()
assert all(H(name)==sha for name,sha in source_hashes.items()) and not forbidden
out=pathlib.Path(tempfile.mkdtemp(prefix='cleanup-refresh-artifact-audit-'))
result=dict(precleanup_observations_identical_pairs=80,startup_feed_identical_pairs=80,pair_counts=dict(pnl_improved=sum(p['delta']>1e-7 for p in pairs),pnl_declined=sum(p['delta']< -1e-7 for p in pairs),pnl_unchanged=sum(abs(p['delta'])<=1e-7 for p in pairs),cleanup_faster=sum(p['candidate_duration']<p['baseline_duration']-1e-7 for p in pairs),cleanup_slower=sum(p['candidate_duration']>p['baseline_duration']+1e-7 for p in pairs),all_result_fields_unchanged=sum(not p['changed_fields'] for p in pairs)),source_files_verified=len(source_hashes),git_source_files_verified=len(git_paths),baseline_bound_artifacts=len(cm['baseline_artifact_sha256']),model_overlap_limitation='All 15 weather tracks are reported to overlap the fitted library; this is execution evidence only.',journal_profile_hashes_verified=journal_files,baseline_journals_byte_exact=80*len(JOURNALS),pairs=pairs,metrics=metrics,profiles=profiles,stops=stops,attention=attention,source_hashes=source_hashes,results_sha256={p:s['results_sha256'] for p,(_,s,_) in phases.items()},forbidden_attempts=forbidden)
(out/'audit.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(path=str(out/'audit.json'),metrics=metrics,source_files_verified=len(source_hashes),git_source_files_verified=len(git_paths),bound_baseline_artifacts=len(cm['baseline_artifact_sha256']),journal_profile_hashes=journal_files,baseline_journals_byte_exact=560,pnl_changes=[p for p in pairs if abs(p['delta'])>1e-7],attention=attention,forbidden_attempts=forbidden),indent=2))
