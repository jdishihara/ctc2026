"""Read-only independent arithmetic and retained table reproduction."""
import collections, contextlib, hashlib, io, json, math, os, pathlib, runpy, statistics, sys, tempfile
O=pathlib.Path('/Users/arjunhans/Documents/ctc2026/out/cleanup-refresh-v1-20261024')
forbidden=[]
def guard(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
  forbidden.append(event);raise RuntimeError('network forbidden')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  name=os.fsdecode(args[0]).lower()
  if '.botkey' in name or '/.env' in name or '/data/history/' in name or 'credentials' in name:
   forbidden.append(name);raise RuntimeError('credentials/downloaded-history forbidden')
sys.addaudithook(guard)
def H(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def J(p):return json.loads(p.read_text())
def K(r):return r['capture'],r['rtt_seconds'],r['displayed_depth_fraction'],r['basket_enabled']
def P(k):return f'capture-{k[0]}-{k[1]}-{k[2]}-{int(k[3])}'
before={p.name:H(p) for p in (O/'analysis.json',O/'analyze.py')}
stream=io.StringIO();sys.argv=[str(O/'analyze.py'),str(O)]
with contextlib.redirect_stdout(stream):runpy.run_path(str(O/'analyze.py'),run_name='__main__')
recomputed=json.loads(stream.getvalue());assert recomputed==J(O/'analysis.json')
rows={phase:{K(r):r for s in (O/phase/'results.jsonl').read_text().splitlines() if (r:=json.loads(s))} for phase in ('baseline','candidate')}
a,b=rows['baseline'],rows['candidate'];assert a.keys()==b.keys() and len(a)==80
changes=[]
for k in a:
 delta=b[k]['terminal_settlement_pnl']-a[k]['terminal_settlement_pnl']
 if abs(delta)>1e-7:changes.append({'setting':k,'before':a[k]['terminal_settlement_pnl'],'after':b[k]['terminal_settlement_pnl'],'delta':delta})
assert len(changes)==4 and sum(x['delta']>0 for x in changes)==2
means={};reasons={}
for phase in rows:
 loss=[r for r in rows[phase].values() if 'loss' in r['stop_reason']]
 assert len(loss)==12
 means[phase]=statistics.mean(r['cleanup_completed_at']-r['cleanup_started_at'] for r in loss)
 reasons[phase]=dict(collections.Counter(r['stop_reason'] for r in rows[phase].values()))
assert means['baseline']==96 and math.isclose(means['candidate'],89.66666666666667)
assert b[(245,1.,1.,False)]['terminal_settlement_pnl']<0<a[(245,1.,1.,False)]['terminal_settlement_pnl']
k=(243,1.,.5,False)
profiles={p:J(O/p/P(k)/'cleanup-profile.json') for p in ('baseline','candidate')}
assert not [x for x in profiles['baseline'] if x['request']['method']=='DELETE']
delidx=[i for i,x in enumerate(profiles['candidate']) if x['request']['method']=='DELETE'];assert len(delidx)==1
i=delidx[0];delete=profiles['candidate'][i]['request'];assert delete['path']=='/orders/75'
after=[]
for item in profiles['candidate'][i+1:]:
 r=item['request'];after.append({'method':r['method'],'path':r['path'],'executed_at':r['executed_at']})
 if r['method']=='POST':break
assert len(after)>6 and [(x['method'],x['path'].split('?')[0]) for x in after[:6]]==[('GET','/competitions/time'),('GET','/orders/open'),('GET','/positions'),('GET','/trades'),('GET','/orders'),('GET','/competitions/time')]
assert all(H(O/n)==sha for n,sha in before.items()) and not forbidden
proof=dict(analysis_exact=True,analysis_sha256=before['analysis.json'],analyze_sha256=before['analyze.py'],pair_count=80,improved=2,declined=2,unchanged=76,changes=changes,loss_cleanup_mean=means,cancellation_path={'setting':k,'request':delete,'following_requests_to_next_post':after},forbidden_attempts=forbidden)
out=pathlib.Path(tempfile.mkdtemp(prefix='cleanup-refresh-analysis-audit-'))/'audit.json';out.write_text(json.dumps(proof,sort_keys=True,indent=2)+'\n')
print(json.dumps({'audit_path':str(out),'analysis_exact':True,'pairs':80,'loss_cleanup_mean':means,'candidate_cancel_path':delete['path'],'forbidden_attempts':forbidden}))
