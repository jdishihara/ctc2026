"""Run synthetic safety checks only, retaining stdout and guard receipts."""
from datetime import datetime,timezone
import hashlib,importlib.util,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/Users/arjunhans/Documents/ctc2026/.worktrees/cleanup-empty-cancel');OUT=Path(__file__).resolve().parent
HEAD='74c81f4d288f72e1248a6956ffcb15fea3970005';BASE='cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True)
 sp=importlib.util.spec_from_file_location('reviewed_driver',ROOT/'scripts/compare_cleanup_refresh.py');mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod)
 files=mod.runtime_files(ROOT);changes=[]
 for p in files:
  rel=p.relative_to(ROOT).as_posix();committed=subprocess.check_output(['git','show',HEAD+':'+rel],cwd=ROOT);baseline=subprocess.check_output(['git','show',BASE+':'+rel],cwd=ROOT)
  assert committed==p.read_bytes()
  if committed!=baseline:changes.append(rel)
 assert changes==['bot/practice.py'] and len(files)==28,changes
 files+= [ROOT/'scripts/compare_cleanup_refresh.py',ROOT/'docs/cleanup-empty-cancel-plan.md',ROOT/'tests/test_cleanup_empty_cancel.py',ROOT/'tests/test_practice.py']
 old=subprocess.check_output(['git','show','5832359:scripts/compare_cleanup_quotes.py'],cwd=ROOT,text=True)
 expected=old.replace('predeclared cleanup quote-order change','predeclared empty-cancel cleanup refresh change').replace('docs/cleanup-quote-plan.md','docs/cleanup-empty-cancel-plan.md')
 assert (ROOT/'scripts/compare_cleanup_refresh.py').read_text()==expected
 return dict(head=HEAD,base=BASE,runtime_paths=28,runtime_changes=changes,driver_equal_except_header_and_plan_path=True,sha256={str(p.relative_to(ROOT)):sha(p) for p in files})
start=datetime.now(timezone.utc).isoformat();before=snapshot();results=[]
for name,baseline,args in [
 ('candidate-races',False,['pytest','-q','-s','-p','no:cacheprovider',str(OUT/'test_position_race.py'),str(OUT/'test_transition_review.py')]),
 ('baseline-races',True,['pytest','-q','-s','-p','no:cacheprovider',str(OUT/'test_position_race.py'),str(OUT/'test_transition_review.py')]),
 ('focused-65',False,['pytest','-q','-p','no:cacheprovider','tests/test_practice.py','tests/test_cleanup_empty_cancel.py'])]:
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');env.pop('REVIEW_BASELINE',None)
 if baseline:env['REVIEW_BASELINE']='1'
 cmd=[sys.executable,str(OUT/'run_guarded.py'),*args]
 r=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,text=True)
 (OUT/(name+'.stdout.txt')).write_text(r.stdout);(OUT/(name+'.stderr.txt')).write_text(r.stderr)
 guards=[json.loads(s.removeprefix('REVIEW_GUARD ')) for s in r.stdout.splitlines() if s.startswith('REVIEW_GUARD ')]
 entry=dict(name=name,command=cmd,baseline=baseline,exit_code=r.returncode,guard_receipts=guards);results.append(entry)
 print(json.dumps(entry,sort_keys=True),flush=True)
 assert r.returncode==0,entry
 assert len(guards)==1 and guards[0]==dict(exit_code=0,forbidden_attempts=[]),entry
 assert ('65 passed' if name=='focused-65' else '27 passed') in r.stdout,r.stdout
assert snapshot()==before
meta=dict(kind='pre-performance safety review',started_at=start,completed_at=datetime.now(timezone.utc).isoformat(),source=before,runs=results,counts=dict(candidate_adversarial_passed=27,baseline_adversarial_passed=27,focused_tests_passed=65,forbidden_access_attempts=0,captured_performance_runs=0),limitations=['The API remains non-atomic after its last account snapshot; this candidate retains that existing submission sequence.'])
(OUT/'review-metadata.json').write_text(json.dumps(meta,indent=2,sort_keys=True)+'\n')
print(json.dumps(meta['counts'],sort_keys=True))
