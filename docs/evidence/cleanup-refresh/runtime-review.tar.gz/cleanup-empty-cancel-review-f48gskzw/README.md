# Empty-cancel cleanup pre-performance review

Exact candidate: 74c81f4d288f72e1248a6956ffcb15fea3970005.
Reference runtime: cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026.
Verdict: no introduced safety blocker; approved to run the declared guarded
80-setting offline comparison. This is not production-promotion or live-order
approval, and no captured-market performance was run during this review.

## Evidence

- Candidate: 27 independent adversarial probes passed.
- Baseline: the identical 27 probes passed using the old reconcile_stop AST,
  loaded without editing source files.
- Existing/new focused production tests: 65 passed.
- All three guarded processes: zero network, credential or downloaded-history
  access attempts. Each stdout ends with its REVIEW_GUARD record.
- Candidate remained clean at the exact frozen HEAD before/after verification.
- All 28 runtime dependencies match cd3 except bot/practice.py.
- The comparison driver matches reviewed 5832359 byte for byte after only its
  descriptive header and plan-path substitutions. Its prerequisite, settlement,
  fatal-latch and source/artifact guards are unchanged.

The independent matrix tests both exposure signs with: uncertain cancellation
that fills, reverses or partially reduces exposure; a late known open order;
competition rollover, closure, missing clock identity or history failure during
the send-time audit; initially flat exposure changing; initially closed market
reopening; five empty-book retries; and five unresolved cancellation attempts.
The three additional book-time position probes cover flattening, partial
reduction and reversal. test_position_race.py was adapted from the retained
probe for the earlier rejected quote-order proposal; its historical docstring
refers to that earlier issue. The tests here verify that this candidate retains
the original reconciliation after the book read.

The tests use real cleanup control flow with a fake local transport. No POST or
DELETE reaches a network. Every permitted fake closing POST in the transition
matrix is checked against current fake server exposure, not just cached client
positions. Cancellation attempts retain a subsequent positions read, and retry
exhaustion retains attention rather than asserting flatness.

## Scope boundary

A fresh per-symbol reconciliation and both ownership audits remain before a
closing POST. The new conditional saves only the second initial refresh/audit
when no cancellation was needed and the audited account is open with exposure.
Initially flat/closed accounts and every cancellation attempt keep that refresh.
The API is still non-atomic: an external conversion after the last positions
snapshot can race a later POST. That existing window is unchanged by this diff;
these tests do not certify exclusive account ownership or atomic reductions.

## Reproduction

Run with the repository virtual environment:

    PYTHONDONTWRITEBYTECODE=1 /Users/arjunhans/Documents/ctc2026/.venv/bin/python run_review.py

This reruns only synthetic checks and replaces the stdout/metadata files in
this directory. Preserve the archive first and regenerate its manifest after
any deliberate rerun. review-metadata.json records exact commands, times,
source hashes, guard receipts and counts.
