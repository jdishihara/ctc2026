"""Guard installed before source imports; no capture evaluations are invoked."""
import json
import os
from pathlib import Path
import runpy
import sys
violations = []
def guard(event, args):
    if event in ('socket.connect', 'socket.getaddrinfo', 'socket.bind'):
        violations.append(event)
        raise RuntimeError('review forbids network')
    if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)):
        path = os.fsdecode(args[0]).lower()
        if '.botkey' in path or '/.env' in path or '/data/history/' in path or 'credentials' in path:
            violations.append(path)
            raise RuntimeError('review forbids sensitive/history input')
sys.addaudithook(guard)
code = 1
try:
    if sys.argv[1] == 'pytest':
        import pytest
        code = int(pytest.main(sys.argv[2:]))
    elif sys.argv[1] == 'script':
        runpy.run_path(sys.argv[2], run_name='__main__')
        code = 0
    else:
        raise ValueError('expected pytest or script')
finally:
    print('REVIEW_GUARD ' + json.dumps({'forbidden_attempts': violations, 'exit_code': code}, sort_keys=True), flush=True)
raise SystemExit(code)
