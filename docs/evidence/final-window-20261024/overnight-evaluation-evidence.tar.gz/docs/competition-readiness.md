# Competition readiness — 2026-10-24

Status updated after the final evaluation boundary at 12:00:00.008254 UTC
(08:00:00.008254 EDT). One completed clean small-size live trial remains
at +$141.16. Later shared-account activity is mixed and not attributable.
Live practice remains stopped pending shared-account ownership clarification.
The overnight offline evaluation and recording are complete.

**Validation limitation:** all 27 complete storm tracks in closed captures
241–249 exactly match tracks in the fitted analog training library. Their
replays and the +$141.16 actual completed trial therefore do not establish
performance on unfamiliar weather. Source-freeze dates describe chronology,
not independence from model training. See
[training-overlap-audit.md](training-overlap-audit.md) for the exact matches,
retained evidence and implications for the prior reports.

## What the evidence supports

The historical strategy is profitable on average in the local simulator, but
losing seasons remain. The earlier live loss exposed execution defects; reviewed
corrections have been regression-tested. A bounded retry candidate closes the
five known stranded portfolios in a fixed offline comparison, with final
independent verification complete and the correction merged in PR 28. One completed live season was
positive; consistent live profitability has not been established. Neither the historical average nor the test count
establishes a probability of winning the competition.

The full production-supervisor replay exposed a false history stop between
storms. A reviewed correction eliminates all 40 such stops in the fixed
comparison: 53 of 64 settings now complete, 11 hit the loss trigger, and
12 finish negative. The worst terminal outcome is −$420.64; two cleanup cases
retain residual positions. The primary capture-244 result remains −$261.00,
versus +$628.14 without the supervisor. All 64 baseline outputs and request/fill
traces match exactly. Independent corrected result audit is complete; full evidence and
limitations are in [practice-round-transition.md](practice-round-transition.md).
The independently reviewed original comparison remains in
[supervised-client-replay.md](supervised-client-replay.md). These offline
findings do not change the actual +$141.16 completed practice record.

The next closed recorded path, capture 245, passed independent audit: its
supervised primary earns +$362.85, all 16 settings finish positive, 15 complete
and one hits the loss trigger then finishes flat at +$5.42. Its interval began
before the corrected-runtime freeze, and the receipt precedes the separate
forward-driver freeze by 1.181 seconds. This is not prospective evidence for
the correction or an untouched holdout. Full results and timing are in
[observed-season-245.md](observed-season-245.md).

Capture 246 also passed independent audit. All 16 supervised settings complete
all three storms and finish positive, with a primary result of +$1,539.17
and a range of +$1,439.61 to +$1,937.04. Its entire selected interval follows
the source freezes, but its three weather tracks exactly match fitted-library
rows 735–737. These remain offline execution diagnostics on known training
weather; see [observed-season-246.md](observed-season-246.md).

Capture 247 reverses that result: 15 of 16 full-supervisor settings lose money,
with mean −$332.11, worst −$573.91 and primary −$239.99. Only four complete;
nine finish flat after stopping and three retain REIN −6. Eleven independent
reruns and the complete source/input/output audit confirm the result. Its three
weather tracks also repeat training. See
[observed-season-247.md](observed-season-247.md).

A separate 80-setting cleanup experiment was rejected after independent
review. Its newer quotes did not consistently reduce risk: mean cleanup time
across the twelve loss stops rose from 96.00 to 98.25 seconds, and the worst
terminal loss increased from $420.64 to $441.76. The current runtime and frozen
forward evaluations are unchanged. See
[cleanup-quote-ordering.md](cleanup-quote-ordering.md) for every outcome and
the safety issue caught before the candidate evaluation.

A narrower cleanup experiment also failed its predeclared promotion rules.
Skipping one redundant refresh after an empty cancellation pass improved mean
cleanup time from 96.00 to 89.67 seconds, but worsened the worst terminal loss
from $420.64 to $434.39 and added one negative setting. Independent review
reproduced all 80 pairs and twelve representative reruns. It remains out of
production; see [cleanup-empty-cancel.md](cleanup-empty-cancel.md).

An exact-prefix recognition experiment also fails its risk rules. Across six
known-training paths and 96 execution settings, mean simulated P&L rises from
$678.13 to $1,093.27, but the worst loss worsens to $514.88, negative settings
increase from 12 to 14, and cleanup attention receipts increase from 2 to 6.
All 75 unmatched development pairs remain identical. Independent audits and
representative reruns verify both findings. The candidate stays out of
production; see [repeat-prefix.md](repeat-prefix.md).

A fixed 50/50 recognition blend passes all 96 settings on captures 241–246,
but fails the supplemental capture-247 check: twelve of sixteen settings lose,
the primary falls to −$319.63, and two attention outcomes retain more exposure
than baseline. Independent audits confirm both sets of results. Its reviewed
optional launcher remains unmerged. See [repeat-blend.md](repeat-blend.md).

A fixed bounded cleanup retry preserves all first-five-pass requests and all
pre-cleanup behavior in 112 paired settings. It closes all five previously
stranded portfolios, while 85 positive and 27 negative outcomes and the worst
loss of $573.91 remain unchanged. Two closures improve terminal P&L by $17.52
each; three cost an additional $0.96 each. These are reused known-training paths,
and the improvement does not establish consistent profitability. The full
comparison, limits and independent review status are in
[cleanup-retry-window.md](cleanup-retry-window.md).

Capture 248 passes independent audit: all 16 full-supervisor settings complete
and settle positive, with mean $897.99, worst $295.45 and primary $985.54.
The bounded-retry runtime reproduces all sixteen outcomes unchanged; no extra
cleanup was needed. Its three weather tracks also repeat training. The selected
interval predates the retry declaration and freeze, although both precede its
closing receipt. Full results and limits are in
[observed-season-248.md](observed-season-248.md) and
[cleanup-retry-forward.md](cleanup-retry-forward.md).

Capture 249 is also independently verified: all sixteen full-supervisor
settings complete and settle positive, with mean $1,485.76, worst $1,014.34
and primary $1,760.14. Six representative reruns reproduce the original
evaluators exactly. The bounded retry preserves all sixteen outcomes, with
no extra cleanup required. Its two representative reproductions also match.
The selected interval follows all relevant freezes, but all three weather
tracks match fitted rows 744–746. An initial retry invocation used a file
where a directory was required and failed before evaluation; its logs and the
corrected attempt remain retained. See [observed-season-249.md](observed-season-249.md).

The final overnight review covers three frozen engines across the first
post-cutoff receipt prefix: the earlier market replay has 7 seasons / 168
settings (140 positive, 28 negative); the serialized client has 6 / 96 (82
positive, 14 negative); and the full practice controller has 5 / 80 (65
positive, 15 negative). The controller's primary setting averages +$881.54
across these five seasons, with one losing season; its best single setting is
+$1,937.04. All 27 weather tracks still match the fitted training library.
These outcomes are offline results at 10% position limits, not evidence of
consistent live profitability. See [overnight-final-window.md](overnight-final-window.md)
for every season, completion state, risk and boundary source hash.

## Other case tools

The other case tools have separate local checks: the derivatives extension
passes 152 unit tests, 22 timezone test executions and all three browser
scenarios after correction of unit identification and approval invalidation.
Four additional build checks verify that the mock extension cannot inject into
Cornell and that both packages disclose optional order submission. Saved
auto-submit settings must be disarmed before the live manual dry run.
The Mario desk maps all 46 mock contracts and receives all eight race results
with automatic orders off. These checks establish the stated local behavior,
not competitive returns. Builds, failures and reviews are retained in
[game-day-verification.md](game-day-verification.md).

## Historical data and evaluation

`data/history` contains 600 complete season directories, each with `feed.jsonl`,
`market.csv`, and `settlement.json`. Model fitting uses seasons 1–450; tuning uses
451–525. Seasons 526–600 were inspected during previous research and are reused
confirmation data, not an untouched holdout.

Earlier confirmation at normal simulated position limits, before the latest
execution-price correction:

| Liquidity assumption | Mean season P&L | Losing seasons | Worst season |
| --- | ---: | ---: | ---: |
| Deep | +$9,925.95 | 7 / 75 | −$15,710.93 |
| Thin | +$6,412.88 | 13 / 75 | −$17,076.71 |

These simulated results do not reproduce every live request delay, queue
position, partial fill, or exchange transition. Availability of historical data
does not establish that live code consumes it correctly or that future paths
will be profitable.

The latest entry-corrected comparison repeats all 675 scenarios on development
seasons 451–525 at **10% limits**, with three liquidity assumptions and three
delays. Shorter-delay means range from $1,434.31 to $1,584.50, with six losing
seasons per 75. At three seconds, means range from $1,027.27 to $1,118.30, with
8–9 losses per 75; the worst is −$1,097.41. Positive means do not imply that every
season, or a competition round, will be positive. Full paired results are in
[executable-entry.md](executable-entry.md).

## Earlier practice loss

The first full-size attempt lost $2,589.19 including cleanup ($2,589.80 including
earlier smoke trades). It started late with incomplete season history and placed
large positions from unreliable valuations. Delayed requests also allowed stale
decisions. Cleanup added $619.01 to the loss.

Merged fixes enforce complete history, fresh quotes, pending-news checks,
announcement pauses, and consistent season identity before submissions. The
captured failed-start replay now produces zero orders or conversions. Details and causal limitations are in
[practice-loss-review.md](practice-loss-review.md).

Three captured advisories differed from the published feed. With complete prior
history, replacing those advisories changed fair value by at most $0.265 per
share across the captured checkpoints. That is a valuation sensitivity result,
not a counterfactual profit calculation.

## Controlled live batch

Batch 01 ran the frozen version `59603dd` with 10% of normal per-symbol limits,
a three-complete-season target, a $250 cumulative net-loss trigger, and a
three-hour deadline ending 06:44:57 UTC. The trigger is not a guaranteed maximum
loss because in-flight fills and cleanup may add costs.

| Trial | Status | Result |
| --- | --- | --- |
| 1 | Completed; official settlement verified | +$141.16 |
| 2 | Interrupted; another trader's orders detected | Mixed account activity; not attributable to this strategy |
| 3 | Not started | — |

Live status is in `recordings/consistency-20261024/batch-01/status.json`.
`actions.jsonl` records submissions and settlement receipts; `final-receipt.json`
was written when the batch exited. Its clock identity check passed, but the
receipt contains reopened exposure and an unidentified order; it does not
establish successful cleanup or exclusive strategy P&L. Inter-round marked profit is not a completed
season result. No future outcomes from the active published season are used to
tune parameters or guide orders.

## Reviewed work merged in PR 4

[PR 4](https://github.com/jdishihara/ctc2026/pull/4) merged at 05:21 UTC as
`c9bdd50`. It contains the following independently reviewed changes and includes
the team's preceding main (`bb3a8ff`);
all **312 Python tests passed** on the combined code. Tests verify specified
behavior, not profitability.

- Bounded practice supervision, reconciliation, and official settlement receipts.
- Sticky account-ownership checks for unknown filled and open orders, missing
  acknowledgements, malformed account state, and reopened exposure. These checks
  do not lock the server account; another actor can trade between observations.
- Healthy periodic snapshots preserve completed warm-up; reconnects retain their
  required warm-up. Integrated commit `b3eb368` (reviewed source `c583144`).
- Per-leg basket retry clocks resume unsent hedge orders promptly. Integrated
  commit `afe2880` (reviewed source `b6d1111`). The first actual basket took about
  63 seconds and had −$8.73 market-trade cashflow.
- A recorded-market replay and a read-only official-settlement recorder. Neither
  sends orders or treats virtual profits as actual account returns.

The snapshot and basket changes were not in batch 01. Their live profitability
has not been demonstrated.

## Later integrated changes and experiments

- PR 5 preserves the fixed recorded-market evaluation grid.
- PR 6 corrects historical simulator activation times and final-round closure.
- PR 7 retains the execution-cost grid and season-242 capture evidence, including
  its recorder reconnect and uncertainty about quote completeness.
- [PR 8](https://github.com/jdishihara/ctc2026/pull/8) enforces entry-price bounds
  and checks stale partial/pending orders and fills during cancellation. The
  reviewed implementation and paired evidence are merged. Profit effects are
  mixed: shorter-delay historical means improve slightly, three-second means
  decline slightly, and two cost profiles gain an additional losing season.
- [PR 9](https://github.com/jdishihara/ctc2026/pull/9) adds an offline final-report-only
  diagnostic. It gives up most profit and still loses in some scenarios, so it
  does not replace the competition strategy. Future evaluation manifests now
  include model NPZ hashes; the older manifest limitation is documented.
- [PR 10](https://github.com/jdishihara/ctc2026/pull/10) adds the fixed closed-season
  worker, with source/output integrity checks and a final drain at the deadline.
- [PR 11](https://github.com/jdishihara/ctc2026/pull/11) adds optional HTTP connection
  reuse, with no automatic retries, proxy compatibility, and connection cleanup.
  It remains **off by default**. Read-only clock benchmarks and local failure
  tests are documented in [http-connection-reuse.md](http-connection-reuse.md);
  they do not demonstrate higher profit.
- [PR 12](https://github.com/jdishihara/ctc2026/pull/12) audits all 150 development
  scenarios at two delays. Every fill contribution reconciles with the unchanged
  baseline. HAVEN contributes the most to the worst loss and also has the largest
  positive average contribution. This does not justify removing it based on
  selected losses. See [loss-contributions.md](loss-contributions.md).

After integrating the teammate's Mario/Derivatives commit `aca0ec4`, the combined
branch passes **460 Python tests**, including the offline worker's
restart-integrity and cutoff checks. Independent reviews reproduced
representative results and checked every stored scenario pair. Neither the
entry correction nor final-report-only research has a new attributable live
trial. No live size increase or automatic strategy promotion follows from these
merges.

The subsequent uncertainty-guard experiment repeated 225 development pairs and
12 pairs on each of captures 241–243. It is **not promoted**: the three-second
development mean falls by $13.09 without reducing losses, and every scenario
on captures 242 and 243 earns less. Review fixes and all unfavorable evidence
are preserved in [uncertainty-guard-experiment.md](uncertainty-guard-experiment.md).
The research branch, including teammate main `870d31f`, passes 497 Python tests.
The candidate is offline only; the live strategy and frozen worker are unchanged.

The direct launcher also had a startup identity bug: initializing the strategy
before the first account refresh could erase loaded weather history on the
first quote callback. It now confirms the account and season identity before
initialization and refuses startup when that snapshot is unavailable. Supervised
practice already used the correct order; this does not explain its earlier loss.
See [startup-identity-fix.md](startup-identity-fix.md) for reproduction and scope.

## Why historical profit overstated the first live result

On the completed first season, historical-price replay at the same 10% limits
earned **+$1,628.94**. Replay of captured live quotes with a 0.25-second order delay,
baskets, and the old snapshot reset behavior earned **+$181.48**, closer to the
actual **+$141.16**. The replays differ jointly in executable prices, spread,
depth, timing, and live session handling; this is not a single-cause estimate.

The updated snapshot-and-basket version earned +$86.32 at a modeled 0.25-second
delay and **−$21.70 at three seconds** on that same captured path. More trading
does not automatically improve results. That earlier engine does not model
serialized HTTP requests or cancellation races; queue priority, own market
impact, and actual conversion execution remain unmodeled.

Full evidence: [recorded-market-diagnostic.md](recorded-market-diagnostic.md).

A separate production-client replay now models serial REST calls, status-only
acknowledgements, and account reconciliation. Its fixed 48 scenarios on
captures 241–243 completed after the startup identity correction. One loses
$29.72 (capture 243, one-second RTT, half depth, baskets enabled), and request
timing changes returns substantially. Eight independent reruns matched every
output field. These are reused paths under fixed latency assumptions, not
new live trials or 48 independent seasons. Full results, original failures,
and limitations: [serialized-client-replay.md](serialized-client-replay.md).

## Completed captured markets after the entry correction

The later research comparison reran the full strategy with current snapshot
behavior, three delays, full/half depth, and basket off/on: 12 scenarios for each
completed capture. The first three captures below were already examined;
capture 244 was added after its official close by the frozen worker.

| Captured season | Full-strategy range | Negative scenarios | Actual attributable result |
| --- | ---: | ---: | --- |
| 241 | −$21.70 to +$88.19 | 3 / 12 | +$141.16 on earlier runtime |
| 242 | +$1,462.74 to +$2,172.95 | 0 / 12 | None; shared account activity |
| 243 | +$156.65 to +$389.27 | 0 / 12 | None; no owned live trial |
| 244 | +$1,031.57 to +$1,189.38 | 0 / 12 | None; no owned live trial |

Capture 243 was evaluated by the frozen worker after its official 06:29 UTC
closing receipt. All 24 preselected scenarios, including older snapshot
behavior, were positive. News sequences 0–859 are complete; quote-path
completeness remains unproven. [Receipt, all results, and capture limits](observed-season-243.md).

Capture 244's selected interval begins at 06:31:19 UTC, after the earlier
worker's actual 06:11:57 startup (06:06 is its configured eligibility-window
start). All 24 of that worker's scenarios are positive. The serial REST grid
also has 16 positive rows, from $533.32 to $1,238.28. Its predeclared primary
scenario earns $628.14 but reaches a −$263.29 mark; supervisor loss stops and
cleanup are not modeled. For that later serial plan, 244 is carryover whose
receipt precedes its effective freeze, not prospective evidence. Both engines
were independently checked. [Full results, timing, risk, and provenance](observed-season-244.md).

The full older-snapshot ablations and unfavorable changes are also preserved in
[executable-entry.md](executable-entry.md). Waiting for all final reports earns
only $19.25–$22.25 on capture 241 and −$4.00–$5.60 on capture 242; it is retained
as a diagnostic baseline. All pairs and assumptions are in
[final-report-experiment.md](final-report-experiment.md).

## Remaining evaluation

Retain every result from batch 01, including its mixed second trial. Detect
unknown filled orders as well as open orders, and resolve the account conflict
before another live batch. The new ownership checks enforce the observed-history
requirement. A read-only observer now records official completed seasons until
12:00 UTC for offline evaluation. Evaluate execution
changes in a later run with their own version and bounds. Three positive
small-size seasons would be encouraging; they would not establish consistent
profitability, full-size performance, or performance against unseen competition
seasons and other teams.

Operational details: [controlled-practice.md](controlled-practice.md).

Completed-season diagnostic: [season-241-diagnostic.md](season-241-diagnostic.md).
Shared-account incident: [shared-account-incident.md](shared-account-incident.md).
