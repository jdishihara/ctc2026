"""Guarded representative reruns; imports only an unchanged frozen evaluator."""
import argparse
from dataclasses import asdict
import gzip
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch

parser=argparse.ArgumentParser()
parser.add_argument('mode',choices=['reference','baseline','supervised','worker'])
args=parser.parse_args()
BASE=Path('/Users/arjunhans/Documents/ctc2026')
OUT=Path(__file__).resolve().parent
CID='fd1ebff9-0f96-4533-b283-bc0a5c60cd4b'
RECORDINGS=BASE/'recordings/consistency-20261024'
ATTEMPT=RECORDINGS/'supervised-forward'/CID/'attempt-01'
root=BASE/'.worktrees'/('serialized-forward' if args.mode=='reference' else
    'closed-season-evaluation' if args.mode=='worker' else 'supervised-forward')
forbidden=[];opened=set()
def guard(event,values):
    if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
        forbidden.append(event);raise RuntimeError('Network forbidden')
    if event=='open' and isinstance(values[0],(str,bytes)):
        name=str(values[0]);low=name.lower()
        if any(x in low for x in ['/data/history/','.botkey','/.env','credentials','manifest']):
            forbidden.append(name);raise RuntimeError('History, manifests and credentials forbidden')
        if '/ctc2026/' in name:opened.add(name)
sys.addaudithook(guard)
def load(p):return json.loads(Path(p).read_text())
def lines(p):return [json.loads(l) for l in Path(p).read_text().splitlines()]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def vh(x):return hashlib.sha256(json.dumps(x,sort_keys=True,allow_nan=False).encode()).hexdigest()
def save(p,x):Path(p).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def key(r):return (r['rtt_seconds'],r['displayed_depth_fraction'],r['basket_enabled'])
audit=load(OUT/'audit.json');cache=load(OUT/'247.json')
assert sha(OUT/'247.json')==audit['cache']['file_sha256']
assert vh(cache['frames'])==audit['cache']['frames_value_sha256']
assert vh(cache['receipt'])==audit['cache']['receipt_value_sha256']
assert cache['receipt']['clock']['state']==cache['receipt']['end_clock']['state']=='ready'
case=load(root/'data/case.json');frames=cache['frames'];receipt=cache['receipt']
before={p:h for p,h in audit['source_sha256'].items() if str(root)+'/' in p}
assert before and all(sha(p)==h for p,h in before.items())
sys.path.insert(0,str(root))
if args.mode!='worker':
    from scripts import replay_serialized_client as core
if args.mode in ['baseline','supervised']:
    from scripts import replay_practice_supervisor as sup
if args.mode=='worker':
    from scripts import replay_captured_market as worker
    archived=load(RECORDINGS/'fixed-observed-evaluation'/f'{CID}.json')['results']
else:
    archived=lines(ATTEMPT/args.mode/'results.jsonl')
result_rows=[]
settings=[(.25,1.,True),(.05,.5,False),(0.,.5,False)] if args.mode!='worker' else [(.25,1.,True),(3.,.5,False)]
mode_out=OUT/('rerun-'+args.mode);mode_out.mkdir(exist_ok=False)
for rtt,depth,basket in settings:
    created=[];accesses=[]
    cutoff=frames[-1]['received_at']-frames[0]['received_at']
    available=receipt['at']-frames[0]['received_at']
    class GuardedSettlement(dict):
        def __getitem__(self,s):
            assert len(created)==1
            server=created[0];market=server if args.mode=='worker' else server.market
            now=market.t
            assert not market.market_open and now>=cutoff
            if args.mode!='worker':assert server.terminal
            if args.mode=='supervised':assert now>=available
            accesses.append(now)
            return super().__getitem__(s)
    prices=GuardedSettlement(receipt['prices'])
    d=mode_out/f'{rtt}-{depth}-{int(basket)}'
    if args.mode!='supervised':d.mkdir()
    if args.mode=='worker':
        original=worker.ReplayExchange
        class Recording(original):
            def __init__(self,*a,**kw):super().__init__(*a,**kw);created.append(self)
        with patch.object(worker,'ReplayExchange',Recording):
            result=worker.replay(case,frames,receipt['year'],prices,.1,rtt,depth,basket,False)
        expected=next(r for r in archived if (r['latency_seconds'],r['displayed_depth_fraction'],r['basket_enabled'],r['reset_warmup_each_snapshot'])==(rtt,depth,basket,False))
        trace={};market=created[0];requests=[]
    else:
        module=core if args.mode=='reference' else sup
        attr='ReplayServer' if args.mode=='reference' else 'PracticeReplayServer'
        original=getattr(module,attr)
        class Recording(original):
            def __init__(self,*a,**kw):super().__init__(*a,**kw);created.append(self)
        with patch.object(module,attr,Recording):
            if args.mode=='reference':
                result=core.replay_client(case,frames,receipt['year'],CID,prices,rtt=rtt,depth_scale=depth,basket=basket)
            elif args.mode=='baseline':
                result,trace=sup.replay_baseline(case,frames,receipt['year'],CID,prices,rtt=rtt,depth_scale=depth,basket=basket)
            else:
                result=sup.replay_supervised(case,frames,receipt['year'],CID,prices,receipt_at=receipt['at'],out=d,rtt=rtt,depth_scale=depth,basket=basket)
        server=created[0];market=server.market;requests=server.requests
        trace={'request_trace_sha256':vh([{k:v for k,v in r.items() if k!='response' or r['method']!='GET'} for r in requests]),
               'fill_trace_sha256':vh([asdict(f) for f in market.fills])}
        expected=next(r for r in archived if key(r)==(rtt,depth,basket))
        assert all(expected[k]==v for k,v in trace.items())
        for request in requests:
            if request['path']=='/symbols' and request['executed_at']<available:
                assert all(not s['settlement_active'] and s['settlement_price'] is None for s in request['response']['symbols'])
    differences=[k for k,v in result.items() if expected.get(k)!=v]
    assert not differences,differences
    assert accesses and not forbidden
    fills=[asdict(f) for f in market.fills]
    fill_cash=math.fsum((1 if f['side']=='sell' else -1)*f['qty']*f['price'] for f in fills)
    assert math.isclose(fill_cash,market.cash,rel_tol=0,abs_tol=1e-7)
    terminal=market.cash+math.fsum(q*receipt['prices'][s] for s,q in market.position.items())
    field='terminal_settlement_pnl' if args.mode=='supervised' else 'simulated_settlement_pnl'
    assert math.isclose(terminal,result[field],rel_tol=0,abs_tol=1e-7)
    for name,data in [('request-trace.json.gz',requests),('fill-trace.json.gz',fills)]:
        with gzip.open(d/name,'wt') as f:json.dump(data,f,allow_nan=False)
    save(d/'result.json',result)
    summary={'setting':[rtt,depth,basket],'all_result_fields_match':True,'different_fields':differences,
        'pnl':result[field],'cash':market.cash,'conversions':market.conversions,'positions':market.position,
        'trace_hashes':trace,'first_settlement_value_access':min(accesses),'cutoff':cutoff,
        'receipt_available_at':available,'forbidden_attempts':list(forbidden),
        'result_sha256':sha(d/'result.json'),'request_file_sha256':sha(d/'request-trace.json.gz'),
        'fill_file_sha256':sha(d/'fill-trace.json.gz')}
    save(d/'reproduction.json',summary);result_rows.append(summary)
    print(json.dumps({'mode':args.mode,'setting':summary['setting'],'pnl':summary['pnl'],'exact_result_and_trace_match':True}),flush=True)
assert all(sha(p)==h for p,h in before.items()) and not forbidden
save(mode_out/'summary.json',{'mode':args.mode,'source_root':str(root),'source_sha256':before,
    'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    'cache_sha256':sha(OUT/'247.json'),'rows':result_rows,'changed_sources':[],
    'forbidden_attempts':forbidden,'repository_files_opened':sorted(opened)})
