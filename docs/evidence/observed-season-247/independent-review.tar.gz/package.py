"""Package existing closed-247 audit artifacts; no runtime or ledger mutation."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import shutil
import tarfile

OUT=Path(__file__).resolve().parent
BASE=Path('/Users/arjunhans/Documents/ctc2026/recordings/consistency-20261024')
CID='fd1ebff9-0f96-4533-b283-bc0a5c60cd4b'
ATTEMPT=BASE/'supervised-forward'/CID/'attempt-01'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(source,dest):
    target=OUT/'original'/dest
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)
    assert sha(source)==sha(target)
copy(BASE/'fixed-observed-evaluation'/f'{CID}.json','worker24.json')
copy(ATTEMPT/'spec.json','spec.json')
copy(Path(json.loads((ATTEMPT/'spec.json').read_text())['captures'][0]['observations']),'sealed-observations.jsonl')
for name in ('metadata.json','results.jsonl','summary.json'):
    copy(BASE/'serialized-forward'/CID/name,Path('serialized')/name)
for phase in ('reference','baseline','supervised'):
    for name in ('metadata.json','results.jsonl','summary.json'):
        copy(ATTEMPT/phase/name,Path(phase)/name)
    for suffix in ('stdout.log','stderr.log'):
        copy(ATTEMPT/f'{phase}.{suffix}',f'{phase}.{suffix}')
for directory in sorted((ATTEMPT/'supervised').glob('capture-247-*')):
    for f in directory.iterdir():copy(f,Path('supervised')/directory.name/f.name)
audit=json.loads((OUT/'audit.json').read_text())
assert audit['journal_files']==112 and audit['forbidden_attempts']==[]
for mode in ('reference','baseline','supervised','worker'):
    summary=json.loads((OUT/f'rerun-{mode}'/'summary.json').read_text())
    assert summary['changed_sources']==[] and summary['forbidden_attempts']==[]
    assert len(summary['rows'])==(2 if mode=='worker' else 3)
    assert all(r['all_result_fields_match'] for r in summary['rows'])
hashes={str(p.relative_to(OUT)):sha(p) for p in sorted(OUT.rglob('*'))
        if p.is_file() and p.name!='artifact-hashes.json'}
(OUT/'artifact-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
archive=OUT.with_suffix('.tar.gz')
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as tar:
            for p in sorted(OUT.rglob('*')):
                if not p.is_file():continue
                data=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(OUT)))
                info.size=len(data);info.mtime=0;info.mode=0o644
                tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    names=tar.getnames()
    assert len(names)==len(hashes)+1
    for name,h in hashes.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==h
print(json.dumps({'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,
                  'payload_files':len(names),'cache_sha256':sha(OUT/'247.json')}))
