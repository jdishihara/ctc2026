from pathlib import Path
s=Path('/tmp/repeat_prefix_artifact_audit.py').read_text()
s=s.replace('repeat-prefix-v1-20261024','repeat-blend-v1-20261024').replace("C=ROOT/'.worktrees/repeat-prefix'","C=ROOT/'.worktrees/repeat-blend'").replace('357d9986babf2b21bd3bbdcc2e69550059f16154','7a2fe81b1167bb1b355357b0d105ea91ed29cd05').replace("prefix='repeat-prefix-artifact-audit-'","prefix='repeat-blend-artifact-audit-'")
s=s.replace("assert sum(p['delta']>1e-7 for p in pairs)==80 and sum(p['delta']< -1e-7 for p in pairs)==16","assert sum(p['delta']>1e-7 for p in pairs)==92 and sum(p['delta']< -1e-7 for p in pairs)==4\nassert all((p['delta']<0)==(p['setting'][0]==245 and p['setting'][1]==0) for p in pairs)")
s=s.replace("assert per_capture_pairs[242]==dict(improved=14,worsened=2) and per_capture_pairs[244]==dict(improved=2,worsened=14)\nassert all(per_capture_pairs[c]==dict(improved=16,worsened=0) for c in (241,243,245,246))","assert per_capture_pairs[245]==dict(improved=12,worsened=4)\nassert all(per_capture_pairs[c]==dict(improved=16,worsened=0) for c in (241,242,243,244,246))")
s=s.replace("assert ns['report']['decision']=='reject'","assert ns['report']['decision']=='passes_declared_offline_gates_pending_independent_review'")
s=s.replace("assert ns['report']['failed_rules']==['new_attention_outcome','increased_residual_exposure','more_negative_capture_settings','worse_worst_capture_result']","assert not ns['report']['failed_rules']\nassert metrics['candidate']['positive']==96 and metrics['candidate']['trial']=={'completed':96} and metrics['candidate']['cleanup']=={'settled':96}")
insert=s.index("case=J(C/'data/case.json')")
s=s[:insert]+'''OLD=ROOT/'out/repeat-prefix-v1-20261024'
assert (O/'spec.json').read_bytes()==(OLD/'spec.json').read_bytes()
assert (O/'baseline/results.jsonl').read_bytes()==(OLD/'baseline/results.jsonl').read_bytes()
assert H(O/'baseline/results.jsonl')=='b80a8693a4b2923efd0f917fd970a3b666f00840ccb1f935b211f680d01ca23c'
assert H(O/'candidate/results.jsonl')=='bc380b30d37324d135a96d89bcce79c63c2dfd7fcc9fc1d61cf4c24213609d09'
assert (O/'analyze.py').read_bytes()==(OLD/'analyze.py').read_bytes()
assert bm['repeat_weight']==0 and cm['repeat_weight']==.5
assert subprocess.check_output(['git','show','-s','--format=%ct','146e8b22fc39dff6136b89fc5fe19170db9786b0'],cwd=C,text=True).strip()=='1792834285'
assert int(subprocess.check_output(['git','show','-s','--format=%ct','HEAD'],cwd=C,text=True))==1792834513<bm['started_at']
for k,row in br.items():
 for name,sha in row['journal_sha256'].items():
  assert (directory(O/'baseline',k)/name).read_bytes()==(directory(OLD/'baseline',k)/name).read_bytes()
for name in ['results.jsonl','prefix-scan.json']:
 assert (O/'development'/name).read_bytes()==(OLD/'development'/name).read_bytes()
dev_audit=J(O/'independent-development-audit/audit.json')
assert dev_audit['source_revision']==REVS[C] and dev_audit['repeat_weight']==.5
assert dev_audit['rows']==150 and dev_audit['paired_rows_exact']==75 and dev_audit['storm_scans']==225
assert dev_audit['activations']==dev_audit['divergences']==dev_audit['mismatches']==0
assert not dev_audit['forbidden_attempts'] and not dev_audit['changed_sources_inputs'] and dev_audit['network_requests']==0
# Development input hash verification is reused from its separate independent audit;
# this capture review does not open any downloaded historical file.
for name,sha in dev_audit['source_input_artifact_sha256'].items():
 if '/data/history/' not in name: assert H(name)==sha,name
''' +s[insert:]
s=s.replace("result=dict(startup_feed_identical_pairs=96,","result=dict(baseline_result_and_all864_files_byte_identical_to_prior_audit=True,repeat_weight=.5,development_output_byte_identical_to_prior_audit=True,development_audit_sha256=H(O/'independent-development-audit/audit.json'),startup_feed_identical_pairs=96,")
s=s.replace("assert all(H(name)==sha for name,sha in source_hashes.items()) and not forbidden","assert all(H(name)==sha for name,sha in source_hashes.items()) and not forbidden\nfor root,rev in REVS.items():\n assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==rev\n assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root,text=True)")
Path('/tmp/repeat_blend_artifact_audit.py').write_text(s)
s=Path('/tmp/repeat_prefix_guarded_rerun.py').read_text()
s=s.replace('only already closed captures 241-245','only the seven requested closed-capture settings')
s=s.replace('repeat-prefix-v1-20261024','repeat-blend-v1-20261024').replace("else 'repeat-prefix'","else 'repeat-blend'").replace('357d9986babf2b21bd3bbdcc2e69550059f16154','7a2fe81b1167bb1b355357b0d105ea91ed29cd05').replace("prefix='repeat-prefix-independent-'","prefix='repeat-blend-independent-'")
s=s.replace("assert PHASE in ('baseline','candidate')","assert PHASE=='candidate'")
s=s.replace("cases=[(244,.25,1.,True),(244,.25,.5,True),(244,.05,.5,True),(241,.25,1.,True),(246,.25,1.,True)]","cases=[(245,0.,1.,False),(245,0.,1.,True),(245,0.,.5,False),(245,0.,.5,True),(245,1.,.5,True),(244,.25,1.,True),(246,.25,1.,True)]")
s=s.replace("oracle=cache[key]\n result=old_weights(ensemble,obs,official,wire,adv)","""oracle=cache[key]
 shadows=active.setdefault('ordinary_shadows',{})
 if ensemble not in shadows:
  shadow=copy.copy(ensemble)
  for name in ('_observed','_track_error','_repeat_observed','_repeat_candidates'):
   setattr(shadow,name,getattr(ensemble,name).copy())
  shadow.repeat_prefix=False;shadow.repeat_match=None;shadows[ensemble]=shadow
 shadow=shadows[ensemble]
 ordinary=old_weights(shadow,obs,official,wire,adv)
 result=old_weights(ensemble,obs,official,wire,adv)
 enforce(ensemble.repeat_prefix is True and ensemble.repeat_weight==.5,'half-weight option not applied')
 enforce(np.array_equal(ensemble._observed,shadow._observed) and np.array_equal(ensemble._track_error,shadow._track_error),'ordinary cache diverged')""")
s=s.replace("exact=np.zeros(len(result));exact[match]=1\n  enforce(np.array_equal(result,exact),'recognition did not return exact one-hot')","exact=ordinary*.5;exact[match]+=.5\n  enforce(np.array_equal(result,exact),'recognition did not return exact fixed half blend')")
s=s.replace("counts['recognized_prefix_calls']+=1\n profile=", "counts['recognized_prefix_calls']+=1\n else:\n  enforce(np.array_equal(result,ordinary),'unmatched fallback differs from ordinary')\n  counts['exact_fallback_calls']+=1\n profile=")
s=s.replace("{'repeat_prefix':True} if PHASE=='candidate' else {}","{'repeat_prefix':True,'repeat_weight':.5} if PHASE=='candidate' else {}")
Path('/tmp/repeat_blend_guarded_rerun.py').write_text(s)
