"""Package the fixed seven-case review; no additional performance runs."""
import collections, datetime, hashlib, json, os, pathlib, shutil, subprocess, sys, tarfile, tempfile
R=pathlib.Path('/Users/arjunhans/Documents/ctc2026');O=R/'out/repeat-blend-v1-20261024';C=R/'.worktrees/repeat-blend'
T=pathlib.Path('/var/folders/5_/4_9w4ch971l2mm9c6fqtg5400000gn/T');REV='7a2fe81b1167bb1b355357b0d105ea91ed29cd05'
forbidden=[]
def guard(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
  forbidden.append(event);raise RuntimeError('network forbidden')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=os.fsdecode(args[0]).lower()
  if '.botkey' in p or '/.env' in p or '/data/history/' in p or 'credentials' in p:
   forbidden.append(p);raise RuntimeError('credential/history access forbidden')
sys.addaudithook(guard)
def H(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def J(p):return json.loads(p.read_text())
def cp(source,target):target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target);assert H(source)==H(target)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=C,text=True).strip()==REV
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=C,text=True)
out=pathlib.Path(tempfile.mkdtemp(prefix='repeat-blend-independent-evidence-'))
shutil.copytree(T/'repeat-blend-independent-candidate-hjvugtjp',out/'candidate-reruns')
cp(T/'repeat-blend-artifact-audit-ze6cgofz/audit.json',out/'artifact-audit.json')
cp(T/'repeat-blend-regression-audit-nvsnu2aj/regressions.json',out/'regressions.json')
for name in ['repeat_blend_audit_setup.py','repeat_blend_artifact_audit.py','repeat_blend_guarded_rerun.py','repeat_blend_regression_audit.py','repeat_blend_package_audit.py']:
 cp(pathlib.Path('/tmp')/name,out/'scripts'/name)
for name in ['repeat_blend_artifact_audit','repeat_blend_candidate_rerun','repeat_blend_regression_audit']:
 for suffix in ['stdout.log','stderr.log']:cp(pathlib.Path('/tmp')/f'{name}.{suffix}',out/'logs'/f'{name}.{suffix}')
originals=['spec.json','analysis.json','analyze.py','baseline/metadata.json','baseline/results.jsonl','baseline/summary.json','candidate/metadata.json','candidate/results.jsonl','candidate/summary.json','baseline.stdout.log','baseline.stderr.log','candidate.stdout.log','candidate.stderr.log','candidate-invocation-01.stdout.log','candidate-invocation-01.stderr.log','full-suite.log','development/metadata.json','development/results.jsonl','development/summary.json','development/prefix-scan.json','independent-development-audit/audit.json','independent-development-audit/file-manifest.json','independent-development-audit/independent-repeat-blend-development-audit.tar.gz','preflight-review.tar.gz']
for name in originals:cp(O/name,out/'original-artifacts'/name)
cp(C/'docs/repeat-blend-plan.md',out/'frozen-plan.md')
for depth,basket in [(1.,False),(1.,True),(.5,False),(.5,True)]:
 folder=f'capture-245-0.0-{depth}-{int(basket)}'
 d=O/'baseline'/folder
 for p in sorted(d.iterdir()):
  if p.is_file():cp(p,out/'regression-baseline-journals'/folder/p.name)
a=J(out/'artifact-audit.json');rerun=J(out/'candidate-reruns/independent-audit.json');econ=J(out/'regressions.json')
assert a['journal_profile_hashes_verified']==1728 and a['baseline_journals_byte_exact']==672 and a['analysis_exact']
assert a['baseline_result_and_all864_files_byte_identical_to_prior_audit']
assert len(rerun['cases'])==7 and all(x['files_exact']==9 for x in rerun['cases'])
assert not a['forbidden_attempts'] and not rerun['forbidden_attempts'] and not econ['forbidden_attempts']
rows=[json.loads(l) for l in (O/'candidate/results.jsonl').read_text().splitlines()]
missed=[]
for r in rows:
 if r['lowest_marked_pnl']<=-250:
  key=[r['capture'],r['rtt_seconds'],r['displayed_depth_fraction'],r['basket_enabled']]
  obs=J(O/'candidate'/f'capture-{key[0]}-{key[1]}-{key[2]}-{int(key[3])}'/'observations.json')
  minimum=min(x['pnl'] for x in obs);assert minimum> -250 and r['trial_state']=='completed'
  missed.append(dict(setting=key,server_marked_low=r['lowest_marked_pnl'],minimum_observed_supervisor_pnl=minimum,terminal_pnl=r['terminal_settlement_pnl']))
assert len(missed)==4 and all(x['setting'][:2]==[244,.05] for x in missed)
for p,sha in a['source_hashes'].items():assert H(pathlib.Path(p))==sha
for p,sha in rerun['source_hashes'].items():assert H(pathlib.Path(p))==sha
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=C,text=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=C,text=True).strip()==REV
verdict=dict(completed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),verdict='Pass all predeclared offline gates after independent review; no source/input, result, accounting or causality blocker found. This is not approval of live deployment or evidence of unfamiliar-weather profitability.',candidate_revision=REV,baseline_revision='cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026',repeat_weight=.5,settings=96,source_files_verified=a['source_files_verified'],git_source_files_verified=a['git_source_files_verified'],baseline_bound_artifacts=a['baseline_bound_artifacts'],all_journal_profile_hashes_verified=1728,baseline_original_journals_verified=672,baseline_result_and_all864_files_equal_previous_audit=True,reused_baseline_audit_archive_sha256='210bf673a2a3716188648c9d1f264f30210f9c797fb3a21981f2c04277f69067',candidate_reruns=7,candidate_files_byte_exact=63,extra_request_fill_quote_observation_files=21,full_request_and_fill_traces_retained=True,metrics=a['metrics'],pair_counts=a['pair_counts'],per_capture_pairs=a['per_capture_pairs'],all_four_regressions_explained=[dict(setting=x['setting'],delta=x['delta'],components={c['symbol']:c['pnl_delta'] for c in x['components']}) for x in econ['cases']],guard_counts=rerun['counts'],sources_unchanged=rerun['sources_unchanged'],forbidden_attempts=[],new_baseline_reruns=0,new_development_reruns=0,development_results_and_scans_identical_to_prior_independent_audit=True,development_recognition_activations=0,server_lows_below_trigger_without_observed_trigger=missed,maximum_marked_drawdown=max(r['maximum_marked_drawdown'] for r in rows),failed_candidate_invocation=dict(retained=True,stage='Baseline prerequisite metadata read at line141, before output directory creation and any scenario evaluation.',error='NotADirectoryError from baseline/results.jsonl/metadata.json',stderr_sha256=H(O/'candidate-invocation-01.stderr.log'),corrected_invocation_completed_all96=True),limitations=['All six captures use exact fitted-library weather and were reused after observing the rejected one-hot experiment; results are not an unfamiliar-weather holdout or a live-profitability claim.','96 execution settings share six captured paths and are correlated.','The fixed .5 coefficient was declared before this evaluation; no alternate coefficient was tested in this review.','Receive-time gaps, truncated tails, displayed-depth matching, queue uncertainty and serial-call assumptions remain.','The $250 trigger uses sampled account observations; four server-low crossings are not observed by the supervisor.','Development zero activations show unchanged unmatched fallback, not the benefit or safety of activation.','Regression attribution reconciles the realized fill paths; it does not isolate a single model feature through an additional intervention.','Account ownership remains unresolved; no trading or production activation occurred.'])
(out/'verdict.json').write_text(json.dumps(verdict,indent=2,sort_keys=True)+'\n')
manifest={str(p.relative_to(out)):H(p) for p in sorted(out.rglob('*')) if p.is_file()}
(out/'artifact-manifest.json').write_text(json.dumps({'count':len(manifest),'files':manifest},indent=2,sort_keys=True)+'\n')
archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(out.rglob('*')):
  if p.is_file():t.add(p,arcname=str(p.relative_to(out)),recursive=False)
with tarfile.open(archive) as t:
 members=t.getmembers();assert len(members)==len(manifest)+1 and len({m.name for m in members})==len(members)
 for m in members:assert m.isfile() and t.extractfile(m).read()==(out/m.name).read_bytes()
assert not forbidden
print(json.dumps(dict(directory=str(out),archive=str(archive),archive_sha256=H(archive),manifest_sha256=H(out/'artifact-manifest.json'),verdict_sha256=H(out/'verdict.json'),hashed_files=len(manifest),archive_files=len(manifest)+1,archive_bytes=archive.stat().st_size,guard_counts=rerun['counts'],forbidden_attempts=forbidden)))
