"""Explain all four regressions from retained complete trade histories, without more replays."""
import collections, hashlib, json, math, os, pathlib, sys, tempfile
R=pathlib.Path('/Users/arjunhans/Documents/ctc2026');O=R/'out/repeat-blend-v1-20261024'
T=pathlib.Path('/var/folders/5_/4_9w4ch971l2mm9c6fqtg5400000gn/T')
RUN=T/'repeat-blend-independent-candidate-hjvugtjp'
forbidden=[]
def guard(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
  forbidden.append(event);raise RuntimeError('network forbidden')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=os.fsdecode(args[0]).lower()
  if '.botkey' in p or '/.env' in p or '/data/history/' in p or 'credentials' in p:
   forbidden.append(p);raise RuntimeError('credential/history read forbidden')
sys.addaudithook(guard)
def J(p):return json.loads(p.read_text())
def H(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def K(r):return r['capture'],r['rtt_seconds'],r['displayed_depth_fraction'],r['basket_enabled']
def near(a,b):assert math.isclose(a,b,rel_tol=0,abs_tol=1e-6),(a,b)
rows={ph:{K(r):r for l in (O/ph/'results.jsonl').read_text().splitlines() if (r:=json.loads(l))} for ph in ['baseline','candidate']}
item=next(x for x in J(O/'spec.json')['captures'] if x['capture']==245)
assert H(pathlib.Path(item['input']))==item['input_sha256'];data=J(pathlib.Path(item['input']));prices=data['receipt']['prices']
assert data['receipt']['clock']['state']=='ready' and data['frames'][-1]['received_at']<=data['receipt']['at']
cases=[]
for depth,basket in [(1.,False),(1.,True),(.5,False),(.5,True)]:
 k=(245,0.,depth,basket);phases={}
 for ph in ['baseline','candidate']:
  folder=f'capture-245-0.0-{depth}-{int(basket)}';d=O/ph/folder;r=rows[ph][k]
  assert r['trial_state']=='completed' and r['cleanup']['state']=='settled' and not r['fills_after_final_receipt_requests']
  profile=J(d/'cleanup-profile.json');retrieved=[e['request']['response']['trades'] for e in profile if e['request']['path']=='/trades']
  assert len(retrieved)==2 and retrieved[0]==retrieved[1]
  trades=list(reversed(retrieved[0]));assert len(trades)==r['fills']<100
  assert [x['trade_id'] for x in trades]==[f'virtual-{i}' for i in range(r['fills'])]
  actions=[json.loads(l) for l in (d/'actions.jsonl').read_text().splitlines()]
  conversions=[x for x in actions if x['kind']=='request' and x.get('method')=='POST' and x.get('path')!='/orders']
  assert len(conversions)==r['conversions']
  if ph=='candidate':
   filltrace=J(RUN/folder/'fill-trace.json')
   assert len(filltrace)==len(trades)
   for t,f in zip(trades,filltrace):
    assert t['symbol']==f['symbol'] and t['side']==f['side'] and t['quantity']==f['qty'] and t['price']==f['price'] and float(t['executed_at'])==f['t']
  cash={s:0. for s in prices};position={s:0 for s in prices}
  for t in trades:
   s=t['symbol'];signed=t['quantity']*(1 if t['side']=='buy' else -1)
   cash[s]-=signed*t['price'];position[s]+=signed
  receipt={p['symbol']:p for p in J(d/'final-receipt.json')['positions']['positions']}
  phases[ph]=dict(complete_fills=trades,conversions=conversions,cash_from_fills=cash,positions_from_fills=position,receipt=receipt,terminal_positions=r['final_positions'],terminal_pnl=r['terminal_settlement_pnl'],original_profile_sha256=H(d/'cleanup-profile.json'))
 assert phases['baseline']['conversions']==phases['candidate']['conversions']
 components=[]
 for sym in prices:
  b=phases['baseline'];c=phases['candidate']
  cash_delta=c['cash_from_fills'][sym]-b['cash_from_fills'][sym]
  position_delta=c['positions_from_fills'][sym]-b['positions_from_fills'][sym]
  assert position_delta==c['terminal_positions'][sym]-b['terminal_positions'][sym]
  pnl_delta=cash_delta+position_delta*prices[sym]
  def score(p):return p['realized_pnl']+(p['quantity']*(prices[sym]-p['average_price']) if p['quantity'] else 0.)
  near(pnl_delta,score(c['receipt'][sym])-score(b['receipt'][sym]))
  if abs(pnl_delta)>1e-6:
   def reduced(t):return dict(time=float(t['executed_at']),side=t['side'],quantity=t['quantity'],price=t['price'])
   bb=[reduced(t) for t in b['complete_fills'] if t['symbol']==sym];cc=[reduced(t) for t in c['complete_fills'] if t['symbol']==sym]
   common=collections.Counter(json.dumps(t,sort_keys=True) for t in bb)&collections.Counter(json.dumps(t,sort_keys=True) for t in cc)
   def difference(ts):
    remaining=common.copy();result=[]
    for t in ts:
     v=json.dumps(t,sort_keys=True)
     if remaining[v]:remaining[v]-=1
     else:result.append(t)
    return result
   components.append(dict(symbol=sym,cash_delta=cash_delta,terminal_position_delta=position_delta,settlement_price=prices[sym],pnl_delta=pnl_delta,baseline_differing_fills=difference(bb),candidate_differing_fills=difference(cc)))
 pnl_delta=phases['candidate']['terminal_pnl']-phases['baseline']['terminal_pnl'];near(sum(c['pnl_delta'] for c in components),pnl_delta)
 expected={'AQUA':-23.98,'RECON':-33.5 if depth==1 else -31.2,'GRID':(30.60 if basket else 29.02) if depth==1 else (28.2 if basket else 26.62)}
 if depth==.5:expected['PORT']=9.15
 assert set(expected)=={c['symbol'] for c in components}
 for c in components:near(c['pnl_delta'],expected[c['symbol']])
 cases.append(dict(setting=k,baseline_pnl=phases['baseline']['terminal_pnl'],candidate_pnl=phases['candidate']['terminal_pnl'],delta=pnl_delta,components=components,conversion_requests_responses_and_times_identical=True,phases=phases))
assert not forbidden
out=pathlib.Path(tempfile.mkdtemp(prefix='repeat-blend-regression-audit-'))
proof=dict(cases=cases,forbidden_attempts=forbidden,new_performance_runs=0,baseline_trade_source='Both archived cleanup GET /trades responses; all complete chronological fills fit below the100-trade response limit.',candidate_trade_source='Same archived responses, independently matched to the seven-case rerun full fill trace.',interpretation='Arithmetic attribution of each realized execution path, not a separate intervention on any one order or model input.',explanation=['All four settings have identical accepted ETF conversions between baseline and candidate; differences therefore reconcile entirely through fill cash and terminal quantities.','AQUA: the candidate buys4 shares at30.32 instead of baseline11 shares totaling336.91; seven fewer shares valued at34.23 yield -23.98.','RECON: full depth sale proceeds decline by50*(.23+.44)=33.50; half depth by40*.23+50*.44=31.20, with the same net quantity.','GRID changed sale/rebuy timing offsets some of that loss: +29.02/+30.60 at full depth basket off/on, +26.62/+28.20 at half depth.','Half depth PORT adds9.15 by selling three shares at73.46 rather than70.41.','Every other symbol contributes zero difference; all four simulations finish completed/settled, with no cleanup fills.'])
(out/'regressions.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(path=str(out/'regressions.json'),cases=[dict(setting=x['setting'],delta=x['delta'],components={c['symbol']:round(c['pnl_delta'],2) for c in x['components']}) for x in cases],forbidden_attempts=forbidden)))
