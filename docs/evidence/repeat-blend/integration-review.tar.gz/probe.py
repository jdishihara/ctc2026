from __future__ import annotations
import ast,asyncio,contextlib,hashlib,io,json,os,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
ROOT=Path('/Users/arjunhans/Documents/ctc2026/.worktrees/repeat-blend-integration');OUT=Path(__file__).resolve().parent;HEAD='c4f7a8f069ddb0adfba22d05d3c3cec612abae02';BASE='c7daa8f';MODEL='7a2fe81b1167bb1b355357b0d105ea91ed29cd05';forbidden=[]
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):forbidden.append(event);raise RuntimeError('no review network')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  lexical=Path(os.fsdecode(args[0])).absolute();resolved=lexical.resolve()
  if any('/data/history' in str(p).lower() or '/recordings/' in str(p).lower() or '.botkey' in str(p).lower() or '/.env' in str(p).lower() or 'credentials' in str(p).lower() for p in (lexical,resolved)):
   forbidden.append(str(lexical));raise RuntimeError('no real history, recordings or credentials')
sys.addaudithook(audit)
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
assert git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain','--untracked-files=normal').strip()
changed=git('diff','--name-only',BASE+'..'+HEAD).decode().splitlines()
expected=['bot/live.py','bot/practice.py','ctc/analog.py','docs/repeat-blend-integration-plan.md','tests/test_repeat_blend_launch.py','tests/test_repeat_prefix.py'];assert changed==expected
source_hashes={p:sha((ROOT/p).read_bytes()) for p in changed}
assert (ROOT/'ctc/analog.py').read_bytes()==git('show',MODEL+':ctc/analog.py') and source_hashes['ctc/analog.py']=='aeea09c8bbc40a6884290169d364e2b2e3c34289a4c6da0274ad4eea1965903b'
assert (ROOT/'tests/test_repeat_prefix.py').read_bytes()==git('show',MODEL+':tests/test_repeat_prefix.py')
git('merge-base','--is-ancestor','2b43523',HEAD)
assert (ROOT/'docs/repeat-blend-integration-plan.md').read_bytes()==git('show','2b43523:docs/repeat-blend-integration-plan.md')
def definitions(b):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(b).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
function_changes={}
for file,allowed in [('bot/live.py',{'repeat_prefix_options','run','run_exchange','main'}),('bot/practice.py',{'practice','main'})]:
 a=definitions(git('show',BASE+':'+file));b=definitions((ROOT/file).read_bytes());changes={k for k in set(a)|set(b) if a.get(k)!=b.get(k)};assert changes==allowed
 function_changes[file]=sorted(changes)
# Everything else in launcher modules, including account/session/cleanup classes, is AST-identical.
sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
import numpy as np
from bot import live,practice
from test_live_startup import ColdExchange,arguments
checks=[]
def record(name,**kw):checks.append(dict(name=name,passed=True,**kw))
class TruthTrap:
 def __bool__(self):raise AssertionError('invalid selection must not coerce truthiness')
invalid=[0,1,-1,0.,.5,float('nan'),float('inf'),'false','true','',None,[],{},np.bool_(True),np.bool_(False),TruthTrap()]
for value in invalid:
 for name in ('practice','run','run_exchange'):
  args=SimpleNamespace(repeat_prefix_blend=value,nowcast=False)
  coroutine=practice.practice(args,object()) if name=='practice' else live.run(args) if name=='run' else live.run_exchange(args,object())
  try:asyncio.run(coroutine)
  except ValueError as exc:assert str(exc)=='repeat_prefix_blend must be a bool'
  else:raise AssertionError(('invalid accepted',name,type(value).__name__))
record('48 strict-invalid cases fail before any credential/account attribute access',cases=len(invalid)*3)
for name in ('practice','run','run_exchange'):
 args=SimpleNamespace(repeat_prefix_blend=True,nowcast=True)
 coroutine=practice.practice(args,object()) if name=='practice' else live.run(args) if name=='run' else live.run_exchange(args,object())
 try:asyncio.run(coroutine)
 except ValueError as exc:assert 'requires the analog model' in str(exc)
 else:raise AssertionError('conflict accepted')
record('nowcast conflicts precede I/O through all three entry points',cases=3)
a=live.repeat_prefix_options(SimpleNamespace(repeat_prefix_blend=True));a['repeat_weight']=1
assert live.repeat_prefix_options(SimpleNamespace(repeat_prefix_blend=True))=={'repeat_prefix':True,'repeat_weight':.5}
assert live.repeat_prefix_options(SimpleNamespace())==live.repeat_prefix_options(SimpleNamespace(repeat_prefix_blend=False))=={}
record('selection mapping is fresh per call, fixed half weight, and empty for old/disabled namespaces')
original_live_session=live.LiveSession;original_practice_session=practice.PracticeSession;original_read_text=Path.read_text
runs=[];startup_logs=[]
class HandoffComplete(Exception):pass
for launcher in ('live','practice'):
 for selection in ('absent',False,True):
  ex=ColdExchange();ex.responses['/positions']={'positions':[]};ex.responses['/system/bot-trading']={'mode':'full'}
  args=arguments(OUT);args.url='http://example.invalid';args.key='synthetic-placeholder';args.dry_run=True;args.rate=90;args.key_file=str(OUT/'synthetic-placeholder.txt')
  if selection!='absent':args.repeat_prefix_blend=selection
  expected=selection is True;events=[];observed={};closed=[];fake_reads=[]
  journal=SimpleNamespace(event=lambda kind,**data:events.append((kind,data)),trials={},allowed=lambda:True)
  def fake_read(path,*a,**kw):
   if str(path)==args.key_file:fake_reads.append(str(path));return 'synthetic-placeholder'
   return original_read_text(path,*a,**kw)
  def inspect(exchange,strategy,*a,**kw):
   session=(original_live_session if launcher=='live' else original_practice_session)(exchange,strategy,*a,**kw)
   initial=strategy.model.ensemble
   assert initial.repeat_prefix is expected and initial.repeat_weight==(.5 if expected else 1.)
   assert strategy.analog_kw.get('repeat_prefix',False) is expected
   assert not session.submission_allowed(('PORT',))
   # A confirmed account-led rollover rebuilds the real ensemble without losing selection.
   exchange.competition_id='synthetic-season-2';exchange.season_year='1785'
   assert session._competition_changed() and strategy.model.ensemble is not initial
   assert strategy.model.ensemble.repeat_prefix is expected and strategy.model.ensemble.repeat_weight==(.5 if expected else 1.)
   assert strategy.competition_id==exchange.competition_id and not session.submission_allowed(('PORT',))
   # A news-led rollover keeps the same configured model while fencing its account.
   session._news_season_changed('1784')
   assert strategy.model.ensemble.repeat_prefix is expected and strategy.model.ensemble.repeat_weight==(.5 if expected else 1.)
   assert session.awaiting_competition_id==exchange.competition_id and not exchange.state_ready
   assert not session.submission_allowed(('PORT',))
   observed.update(launcher=launcher,selection=selection,enabled=expected,weight=.5 if expected else 1.,account_rollover_preserves_selection=True,news_rollover_preserves_selection=True,submission_remains_blocked_without_history=True)
   raise HandoffComplete
  log=io.StringIO()
  with patch.object(live,'LiveSession',inspect),patch.object(practice,'PracticeSession',inspect),patch.object(live,'LiveExchange',return_value=ex),patch.object(practice,'PracticeExchange',return_value=ex),patch.object(live,'replay_feed_log',return_value=('',0,0)),patch.object(ex,'close',side_effect=lambda:closed.append(True)),patch.object(Path,'read_text',fake_read),contextlib.redirect_stdout(log):
   try:asyncio.run(live.run(args) if launcher=='live' else practice.practice(args,journal))
   except HandoffComplete:pass
   else:raise AssertionError('launcher did not reach real model')
  if launcher=='live':
   assert closed==[True] and fake_reads==[]
   assert f'repeat-prefix blend={expected} weight={.5 if expected else None}' in log.getvalue()
  else:
   assert len(fake_reads)==1 and events.count(('model_selection',{'repeat_prefix_blend':expected,'repeat_weight':.5 if expected else None}))==1
  runs.append(observed);startup_logs.append(dict(launcher=launcher,selection=selection,stdout=log.getvalue(),journal_events=events))
record('both launchers construct real selected models, report diagnostics, and preserve selection and history vetoes through both rollover directions',cases=6)
# The direct nowcast path remains available with absent or explicitly false blend selection.
for selection in ('absent',False):
 ex=ColdExchange();args=arguments(OUT,nowcast=True)
 if selection!='absent':args.repeat_prefix_blend=selection
 seen={}
 def inspect_nowcast(exchange,strategy,*a,**kw):seen['analog']=strategy.analog;assert not strategy.analog;raise HandoffComplete
 with patch.object(live,'LiveSession',inspect_nowcast),contextlib.redirect_stdout(io.StringIO()):
  try:asyncio.run(live.run_exchange(args,ex))
  except HandoffComplete:pass
  else:raise AssertionError('nowcast did not construct')
 assert seen=={'analog':False}
record('ordinary nowcast startup remains available with absent/false option',cases=2)
assert forbidden==[] and source_hashes=={p:sha((ROOT/p).read_bytes()) for p in changed}
assert git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain','--untracked-files=normal').strip();git('diff','--check')
(OUT/'startup-diagnostics.json').write_text(json.dumps(startup_logs,indent=2)+'\n')
report=dict(head=HEAD,base=git('rev-parse',BASE).decode().strip(),model_source_revision=MODEL,model_bytes_equal_frozen=True,model_tests_equal_frozen=True,source_sha256=source_hashes,changed_top_level_definitions=function_changes,all_other_launcher_definitions_unchanged=True,checks=checks,launcher_runs=runs,forbidden_attempts=forbidden,actual_history_reads=0,actual_account_io=0,actual_credentials_read=0,actual_performance_runs=0,source_head_worktree_unchanged=True)
(OUT/'probe.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
