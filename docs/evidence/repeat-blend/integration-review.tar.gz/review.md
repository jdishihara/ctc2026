# Optional repeat-prefix blend integration review

## Assessment

**Approved:** exact code head `c4f7a8f069ddb0adfba22d05d3c3cec612abae02`
against base `c7daa8f1f8b47f1d120196330e02fb4281aa5829`. No blocking,
important or minor code issue found. This approves the optional integration;
it does not activate it or certify live readiness. The later report/evidence
packaging commit was not part of this exact-head review.

## Strengths

- The model is byte-identical to frozen `7a2fe81b1167bb1b355357b0d105ea91ed29cd05`:
  SHA-256 `aeea09c8bbc40a6884290169d364e2b2e3c34289a4c6da0274ad4eea1965903b`.
  Model tests also match that frozen revision exactly.
- `bot/live.py:688` validates an actual bool and returns a fresh fixed
  `{repeat_prefix: True, repeat_weight: 0.5}` mapping only for explicit true.
  Missing attributes and false select the original disabled model.
- Direct `run`, direct `run_exchange`, and practice validate before credential
  or account I/O. Both direct entry points reject a simultaneous nowcast mode;
  the direct CLI rejects it before entering the runner.
- Both launchers pass the fixed selection into the real constructed ensemble.
  The live diagnostic and practice `model_selection` journal event record the
  selected mode. No coefficient or one-hot CLI control was introduced.
- AST comparison against the base confirms all account, session, ownership,
  history, submission, rate and cleanup class/function definitions are
  unchanged. Only live's new helper/run/run_exchange/main and practice's
  practice/main differ among launcher definitions.
- The implementation plan is unchanged from ancestor commit `2b43523`.
  The reviewed working tree and source bytes remained clean and unchanged.

## Independent verification

- **80 relevant synthetic pytest cases passed**: model contracts, both CLI
  parsers, launch selection and existing cold-start identity/history tests.
- **48 additional invalid-value cases** across practice/run/run_exchange fail
  before other account/credential attributes can be accessed. These include
  numeric values, NumPy booleans, containers and an object whose truthiness
  raises. Three nowcast conflicts also reject before I/O.
- **Six real model startup probes** cover absent/false/true selection through
  both launchers. Diagnostics match selection. Account-led and news-led
  rollover recreate the model with the same selected weight; incomplete
  history and pending account transition continue to veto submissions.
- Default and explicitly disabled direct nowcast startup remain available.
  Direct run closes its exchange when the synthetic handoff raises.
- Zero network, actual credentials, downloaded history, captured outcomes or
  performance reruns were used. Startup uses only synthetic exchange responses
  and the existing fitted model. An outer Python audit hook blocks forbidden
  I/O and records zero attempted accesses.
- `git diff --check` passed. Owner logs reporting 71 focused / 706 full passes
  and the preceding failing test runs are retained and hash-bound. This reviewer
  independently ran the 80-case relevant suite, not the entire 706-case suite.

## Declined to judge

- Frozen capture performance and its risk gates: handled by the separate result
  audit; no captured-market rerun was needed for this integration review.
- Account exclusivity, live profitability and activation: outside this optional
  code integration; ownership remains unresolved.
- The upcoming report/evidence packaging delta: not yet present in this head.

## Evidence

`probe.py`, `probe.json` and startup diagnostics retain the independent checks.
`run_tests.py` and logs retain the guarded test run. `reviewed-sources/` contains
all six changed files from the approved commit, and `runtime.diff` binds the
reviewed delta. Owner test logs are retained under `owner-logs/`. The manifest
and archive are verified byte-for-byte.
