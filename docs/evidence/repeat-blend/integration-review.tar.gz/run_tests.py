import hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/Users/arjunhans/Documents/ctc2026/.worktrees/repeat-blend-integration');OUT=Path(__file__).resolve().parent
forbidden=[]
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):forbidden.append(event);raise RuntimeError('review forbids network')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  paths=(Path(os.fsdecode(args[0])).absolute(),Path(os.fsdecode(args[0])).resolve())
  if any('/data/history' in str(p).lower() or '/recordings/' in str(p).lower() or '.botkey' in str(p).lower() or '/.env' in str(p).lower() or 'credentials' in str(p).lower() for p in paths):
   forbidden.append(str(paths[0]));raise RuntimeError('review forbids real credentials/history/recordings')
sys.addaudithook(audit)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()=='c4f7a8f069ddb0adfba22d05d3c3cec612abae02'
import pytest
code=pytest.main(['-q','-p','no:cacheprovider','tests/test_repeat_blend_launch.py','tests/test_repeat_prefix.py','tests/test_live_startup.py'])
(OUT/'pytest-result.json').write_text(json.dumps(dict(exit_code=code,forbidden_attempts=forbidden,new_performance_runs=0))+'\n');assert not forbidden
raise SystemExit(code)
