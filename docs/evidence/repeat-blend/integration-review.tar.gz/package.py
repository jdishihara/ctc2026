import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
P=Path(__file__).resolve().parent;ROOT=Path('/Users/arjunhans/Documents/ctc2026/.worktrees/repeat-blend-integration');HEAD='c4f7a8f069ddb0adfba22d05d3c3cec612abae02'
def sha(b):return hashlib.sha256(b).hexdigest()
a=json.loads((P/'probe.json').read_text());t=json.loads((P/'pytest-result.json').read_text());assert a['head']==HEAD and a['model_bytes_equal_frozen'] and all(x['passed'] for x in a['checks'])
assert not a['forbidden_attempts'] and t=={'exit_code':0,'forbidden_attempts':[],'new_performance_runs':0}
assert not (P/'probe.stderr.log').read_text() and not (P/'pytest.stderr.log').read_text()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==HEAD
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=normal'],cwd=ROOT).strip()
for name,h in a['source_sha256'].items():
 b=(ROOT/name).read_bytes();assert sha(b)==h and b==subprocess.check_output(['git','show',HEAD+':'+name],cwd=ROOT)
 target=P/'reviewed-sources'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
(P/'runtime.diff').write_bytes(subprocess.check_output(['git','diff',a['base']+'..'+HEAD,'--','bot/live.py','bot/practice.py','ctc/analog.py'],cwd=ROOT))
logs={'ctc-repeat-blend-integration-red.log':'66 failed, 1 passed','ctc-repeat-blend-integration-red-corrected.log':'66 failed, 1 passed','ctc-repeat-blend-launch-red.log':'17 failed, 5 passed','ctc-repeat-blend-integration-focused.log':'71 passed','ctc-repeat-blend-integration-full.log':'706 passed'}
(P/'owner-logs').mkdir(exist_ok=True)
for name,expected in logs.items():
 b=(Path('/tmp')/name).read_bytes();assert expected.encode() in b;(P/'owner-logs'/name).write_bytes(b)
excluded={'file-manifest.json','package.json','independent-integration-review.tar.gz'}
files=sorted(p for p in P.rglob('*') if p.is_file() and p.name not in excluded)
manifest={p.relative_to(P).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in files}
(P/'file-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(P/'file-manifest.json');files.sort()
archive=P/'independent-integration-review.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
   for p in files:
    b=p.read_bytes();m=tarfile.TarInfo(p.relative_to(P).as_posix());m.size=len(b);m.mode=0o644;m.mtime=0;tar.addfile(m,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(files)
 for m,p in zip(members,files):assert m.name==p.relative_to(P).as_posix() and m.isfile() and tar.extractfile(m).read()==p.read_bytes()
report=dict(approved_head=HEAD,archive=str(archive),archive_sha256=sha(archive.read_bytes()),archive_bytes=archive.stat().st_size,archive_file_count=len(files),all_members_verified_byte_for_byte=True,manifest_sha256=sha((P/'file-manifest.json').read_bytes()),probe_sha256=sha((P/'probe.json').read_bytes()),source_sha256=a['source_sha256'])
(P/'package.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
