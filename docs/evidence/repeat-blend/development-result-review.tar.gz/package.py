import gzip,hashlib,io,json,tarfile
from pathlib import Path
P=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
a=json.loads((P/'audit.json').read_text());assert a['rows']==150 and a['paired_rows_exact']==75 and a['storm_scans']==225 and a['frozen_half_weight_plumbing_verified']
assert a['results_byte_identical_to_prior_audited_artifact'] and a['prefix_scan_byte_identical_to_prior_audited_artifact'] and a['source_and_inputs_verified_before_after']
assert a['changed_sources_inputs']==a['forbidden_attempts']==[] and a['new_performance_runs']==0
assert not (P/'audit.stderr.log').read_text()
excluded={'file-manifest.json','package.json','independent-repeat-blend-development-audit.tar.gz'}
files=sorted(p for p in P.rglob('*') if p.is_file() and p.name not in excluded)
manifest={p.relative_to(P).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in files}
(P/'file-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(P/'file-manifest.json');files.sort()
archive=P/'independent-repeat-blend-development-audit.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
   for p in files:
    b=p.read_bytes();t=tarfile.TarInfo(p.relative_to(P).as_posix());t.size=len(b);t.mode=0o644;t.mtime=0;tar.addfile(t,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(files)
 for m,p in zip(members,files):assert m.name==p.relative_to(P).as_posix() and m.isfile() and tar.extractfile(m).read()==p.read_bytes()
report=dict(source_revision=a['source_revision'],archive=str(archive),archive_sha256=sha(archive.read_bytes()),archive_bytes=archive.stat().st_size,archive_file_count=len(files),all_members_verified_byte_for_byte=True,manifest_sha256=sha((P/'file-manifest.json').read_bytes()),audit_sha256=sha((P/'audit.json').read_bytes()),results_sha256=a['results_sha256'],scan_sha256=a['scan_sha256'],new_performance_runs=0)
(P/'package.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
