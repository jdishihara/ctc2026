from __future__ import annotations
import ast,datetime,hashlib,io,itertools,json,math,os,statistics,subprocess,sys,tarfile
from pathlib import Path
ROOT=Path('/Users/arjunhans/Documents/ctc2026');SRC=ROOT/'.worktrees/repeat-blend';ART=ROOT/'out/repeat-blend-v1-20261024/development';OLDART=ROOT/'out/repeat-prefix-v1-20261024/development';OUT=Path(__file__).resolve().parent;HISTORY=(ROOT/'data/history').resolve();REV='7a2fe81b1167bb1b355357b0d105ea91ed29cd05'
PRIOR=Path('/var/folders/5_/4_9w4ch971l2mm9c6fqtg5400000gn/T/independent-repeat-development-results-ibh_nmvm/independent-repeat-development-results.tar.gz')
PREFLIGHT=Path('/var/folders/5_/4_9w4ch971l2mm9c6fqtg5400000gn/T/independent-repeat-blend-preflight-zxrnhcfq/independent-repeat-blend-preflight.tar.gz')
# Retained copies make reuse independent of temporary-review directory lifetime.
if (OUT/'reused-evidence/prior-development-audit.tar.gz').exists():PRIOR=OUT/'reused-evidence/prior-development-audit.tar.gz'
if (OUT/'reused-evidence/blend-preflight.tar.gz').exists():PREFLIGHT=OUT/'reused-evidence/blend-preflight.tar.gz'
ALLOWED={HISTORY/f'season-{n:03d}'/name for n in range(451,526) for name in ('feed.jsonl','market.csv','settlement.json')}
forbidden=[];inputs_read=set();hashes={}
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):forbidden.append(event);raise RuntimeError('independent audit forbids network')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  lexical=Path(os.fsdecode(args[0])).absolute();resolved=lexical.resolve();paths=(lexical,resolved)
  if any('.botkey' in str(p).lower() or '/.env' in str(p).lower() or 'credentials' in str(p).lower() for p in paths):forbidden.append(str(lexical));raise RuntimeError('independent audit forbids credentials')
  if any('/recordings/' in str(p).lower() for p in paths):forbidden.append(str(lexical));raise RuntimeError('independent development audit forbids capture reads')
  history_read=any(p.is_relative_to(HISTORY) or '/data/history/' in str(p).lower() or p.name in ('feed.jsonl','market.csv','settlement.json') for p in paths)
  if history_read:
   if resolved not in ALLOWED:forbidden.append(str(lexical));raise RuntimeError('history outside451–525')
   inputs_read.add(str(resolved))
sys.addaudithook(audit)
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):
 p=Path(p);b=p.read_bytes();hashes[str(p)]=sha(b);return b
def load(p):return json.loads(read(p))
def git(*args):return subprocess.check_output(['git',*args],cwd=SRC,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
def archive(path,expected,manifest_name):
 b=read(path);assert sha(b)==expected
 with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as tar:
  members=tar.getmembers();assert all(m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts for m in members)
  assert len({m.name for m in members})==len(members)
  content={m.name:tar.extractfile(m).read() for m in members}
 manifest=json.loads(content[manifest_name]);entries=manifest.get('files',manifest)
 assert set(entries)==set(content)-{manifest_name}
 for name,item in entries.items():assert sha(content[name])==item['sha256'] and len(content[name])==item['bytes']
 return b,content
assert git('rev-parse','HEAD').decode().strip()==REV and not git('status','--porcelain','--untracked-files=normal').strip()
priorbytes,prior=archive(PRIOR,'6bcc115268b2902814f26fab5f3b6a3d4c6659b8aff9fe5db6f0498c8366f99f','file-manifest.json')
preflightbytes,preflight=archive(PREFLIGHT,'813250e5991e2300fad028963248c5cff99dc0dd645b93594250c1897f7ebee4','file-manifest.json')
oldmeta=json.loads(prior['original-artifacts/metadata.json']);prior_audit=json.loads(prior['audit.json']);prior_reruns=json.loads(prior['reproduction.json']);preflight_static=json.loads(preflight['static-review.json'])
assert prior_audit['independent_scan_equals_all225_archived_records'] and prior_audit['all_prefixes_examined']==54225 and prior_audit['eligible_prefixes_at_minimum21_points']==49725
assert prior_reruns['all_six_results_match_archives_exactly'] and prior_reruns['all_three_pairs_match_exactly']
assert preflight_static['freeze_head']==REV and preflight_static['freeze_source_equals_reviewed_bytes']
meta=load(ART/'metadata.json');summary=load(ART/'summary.json');results=read(ART/'results.jsonl');scan=read(ART/'prefix-scan.json')
for name,b in [('results.jsonl',results),('prefix-scan.json',scan)]:
 assert b==prior['original-artifacts/'+name]==read(OLDART/name)
assert meta['revision']==REV and meta['seasons']==list(range(451,526)) and meta['repeat_weight']==.5
settings={'fraction':.1,'latency':.25,'rate_limit':90,'ladder_scale':.5,'refill_seconds':30}
assert all(meta[k]==v==oldmeta[k] for k,v in settings.items()) and meta['parameters']==oldmeta['parameters']
assert type(meta['started_at']) in (int,float) and math.isfinite(meta['started_at'])
assert type(summary['finished_at']) in (int,float) and math.isfinite(summary['finished_at']) and summary['finished_at']>=meta['started_at']
assert summary['results_sha256']==sha(results)=='0f1b73b4368d66528659c5dd0dd4e95037b382cabc861b63d6a57f045c67c3d2'
assert summary['scan_sha256']==sha(scan)=='0aa8e682f55e8b8ac4269df91faaef45206481ffee730bc0bc2d28328d4880c7'
sources=sorted([*SRC.glob('ctc/*.py'),*SRC.glob('ctc/*.json'),*SRC.glob('ctc/*.npz'),SRC/'data/case.json',SRC/'scripts/check_repeat_blend_development.py',SRC/'docs/repeat-blend-plan.md',SRC/'scripts/experiment_execution_costs.py'])
assert len(sources)==21 and set(meta['source_sha256'])=={str(p) for p in sources}
for p in sources:
 b=read(p);assert sha(b)==meta['source_sha256'][str(p)] and b==git('show',REV+':'+p.relative_to(SRC).as_posix())
for relative,h in preflight_static['source_sha256'].items():assert sha(read(SRC/relative))==h
oldroot=ROOT/'.worktrees/repeat-prefix';oldrelative={str(Path(p).relative_to(oldroot)):h for p,h in oldmeta['source_sha256'].items()};newrelative={str(Path(p).relative_to(SRC)):h for p,h in meta['source_sha256'].items()}
oldrelative['scripts/check_repeat_blend_development.py']=oldrelative.pop('scripts/check_repeat_development.py');oldrelative['docs/repeat-blend-plan.md']=oldrelative.pop('docs/repeat-prefix-plan.md')
source_delta=sorted(k for k in oldrelative if oldrelative[k]!=newrelative[k]);assert source_delta==['ctc/analog.py','docs/repeat-blend-plan.md','scripts/check_repeat_blend_development.py']
assert set(meta['input_sha256'])=={str(p) for p in ALLOWED} and len(meta['input_sha256'])==225
assert meta['input_sha256']==oldmeta['input_sha256']
for p,h in meta['input_sha256'].items():assert sha(read(p))==h
# Inspect exact frozen constructor calls and metadata; this invokes no simulation.
tree=ast.parse(read(SRC/'scripts/check_repeat_blend_development.py'))
calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)]
def only_call(name):
 found=[c for c in calls if c.func.id==name];assert len(found)==1;return found[0]
def keywords(call):return {kw.arg:kw.value for kw in call.keywords}
recognizer=keywords(only_call('AnalogEnsemble'));assert ast.literal_eval(recognizer['repeat_prefix']) is True and ast.literal_eval(recognizer['repeat_weight'])==.5
trader=keywords(only_call('FairValueTrader'));assert isinstance(trader['repeat_prefix'],ast.Name) and trader['repeat_prefix'].id=='enabled' and ast.literal_eval(trader['repeat_weight'])==.5 and isinstance(trader[None],ast.Name) and trader[None].id=='PARAMETERS'
trader_call=only_call('FairValueTrader')
loops=[n for n in ast.walk(tree) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='enabled' and trader_call in list(ast.walk(n))];assert len(loops)==1 and ast.literal_eval(loops[0].iter)==(False,True)
metadata_assign=next(n for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='metadata' for t in n.targets));assert ast.literal_eval(keywords(metadata_assign.value)['repeat_weight'])==.5
parameter_tree=ast.parse(read(SRC/'scripts/experiment_execution_costs.py'));parameter_assign=next(n for n in parameter_tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PARAMETERS' for t in n.targets));assert {k:ast.literal_eval(v) for k,v in keywords(parameter_assign.value).items()}==meta['parameters']
rows=[json.loads(line) for line in results.splitlines()];scans=json.loads(scan)
assert len(rows)==150 and [(r['season'],r['repeat_prefix']) for r in rows]==list(itertools.product(range(451,526),(False,True)))
assert len(scans)==225 and [(s['season'],s['round']) for s in scans]==list(itertools.product(range(451,526),(1,2,3)))
assert all(s['observations']==241 and s['recognized_prefixes']==0 and s['first_match'] is None and s['final_match'] is None and s['diverged_after_match'] is False for s in scans)
assert all({k:v for k,v in a.items() if k!='repeat_prefix'}=={k:v for k,v in b.items() if k!='repeat_prefix'} for a,b in zip(rows[::2],rows[1::2]))
groups={}
for enabled in (False,True):
 values=[r['pnl'] for r in rows if r['repeat_prefix']==enabled];assert len(values)==75 and all(math.isfinite(p) for p in values)
 groups[str(enabled)]={'mean':statistics.mean(values),'worst':min(values),'best':max(values),'negative':sum(v<0 for v in values)}
assert groups==summary['groups']==prior_audit['groups_recomputed']
assert summary['runs']==150 and summary['storm_scans']==225 and summary['activated_storms']==summary['diverged_storms']==0
for key in ('paired_mismatches','unmatched_paired_mismatches','changed_sources_or_inputs','forbidden_attempts','guard_violations'):assert summary[key]==[]
# Reuse every original row's independent terminal score and the original prefix computation;
# exact result/input bytes and the hash-verified evidence bind these checks to the new artifact.
assert len(prior_audit['independent_terminal_score_checks'])==150 and all(x['exactly_matches_reported_pnl'] for x in prior_audit['independent_terminal_score_checks'])
suite=read(ROOT/'out/repeat-blend-v1-20261024/full-suite.log');assert b'698 passed in 2.95s' in suite
changed=[p for p,h in hashes.items() if sha(Path(p).read_bytes())!=h];assert changed==[] and forbidden==[] and inputs_read=={str(p) for p in ALLOWED}
assert git('rev-parse','HEAD').decode().strip()==REV and not git('status','--porcelain','--untracked-files=normal').strip()
originals=OUT/'original-artifacts';originals.mkdir(exist_ok=True)
for name in ('metadata.json','results.jsonl','prefix-scan.json','summary.json'):(originals/name).write_bytes((ART/name).read_bytes())
evidence=OUT/'reused-evidence';evidence.mkdir(exist_ok=True);(evidence/'prior-development-audit.tar.gz').write_bytes(priorbytes);(evidence/'blend-preflight.tar.gz').write_bytes(preflightbytes)
report=dict(audit_harness_note='Initial AST probe counted the separate summary aggregation loop; corrected to select the loop containing FairValueTrader. Frozen source unchanged.',verdict='verified development-only unmatched fallback result',source_revision=REV,source_count=21,input_count=225,source_and_inputs_verified_before_after=True,source_equals_frozen_git_blobs=True,source_delta_from_prior_development=source_delta,input_hashes_identical_to_prior_audit=True,repeat_weight=.5,fixed_settings=settings,parameters=meta['parameters'],frozen_half_weight_plumbing_verified=True,rows=150,paired_rows_exact=75,storm_scans=225,complete_observations_per_storm=241,results_byte_identical_to_prior_audited_artifact=True,prefix_scan_byte_identical_to_prior_audited_artifact=True,groups=groups,negative_seasons=[r['season'] for r in rows if not r['repeat_prefix'] and r['pnl']<0],activations=0,divergences=0,mismatches=0,reused_prefix_checks=54225,reused_eligible_prefix_checks=49725,reused_independent_terminal_score_checks=150,reused_representative_reruns={'source_revision':prior_reruns['source_revision'],'seasons':[451,488,525],'runs':6,'new_reruns_performed':0},prior_evidence_sha256=sha(priorbytes),blend_preflight_sha256=sha(preflightbytes),results_sha256=sha(results),scan_sha256=sha(scan),source_input_artifact_sha256=hashes,changed_sources_inputs=changed,forbidden_attempts=forbidden,history_read_seasons=list(range(451,526)),history_access_purpose='byte hashing only; no newly parsed historical observations or simulation',active_capture247_or_later_reads=0,network_requests=0,new_performance_runs=0,full_suite_log='698 passed in 2.95s',started_at_utc=datetime.datetime.fromtimestamp(meta['started_at'],datetime.timezone.utc).isoformat(),finished_at_utc=datetime.datetime.fromtimestamp(summary['finished_at'],datetime.timezone.utc).isoformat(),limitations=['Reused development data, not a holdout.','Zero activations establish unchanged unmatched behavior; no recognition benefit or activated divergence behavior is established.','Original representative reruns use frozen357d9986 and are reused through exact output/input equality; no new7a2fe81 historical reruns were performed.','Historical simulation does not reproduce full production supervision or real queue competition.','Capture baseline/candidate outputs and production activation were not evaluated here.'])
(OUT/'audit.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['source_input_artifact_sha256','parameters','history_read_seasons']},indent=2))
