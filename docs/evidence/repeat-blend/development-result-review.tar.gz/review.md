# Independent half-weight development result audit

**Verified:** the complete development result at frozen source
`7a2fe81b1167bb1b355357b0d105ea91ed29cd05`. No reporting blocker found.

- All 150 rows / 75 pairs and 225 storm scans are complete. Every pair is
  identical except its enable flag, including fill and P&L trace hashes,
  cash, positions, round P&L, fill count and rejections.
- Results and prefix-scan files are byte-identical to the independently audited
  one-hot development artifacts. The prior archive and every member hash were
  checked before reuse. Its independent 54,225-prefix scan, 49,725 eligible
  prefix checks, 150 terminal score reconciliations and six representative
  reruns are retained here. No new historical simulation was run.
- All 21 declared source hashes equal frozen Git blobs and preflight bytes.
  Only analog.py, the plan and the renamed development driver differ from the
  prior source manifest after normalizing paths. All 225 declared input hashes
  match both the files and the prior independently audited manifest. Files and
  frozen HEAD stayed unchanged across this audit.
- Metadata records repeat_weight=0.5. Frozen AST inspection confirms explicit
  0.5 in the recognizer and both enabled/disabled trader calls, the fixed two-mode
  loop and unchanged PARAMETERS. The retained synthetic preflight independently
  exercised this plumbing. Other fixed controls remain 10% limits, 0.25-second
  latency, rate 90, ladder scale 0.5 and refill 30 seconds.
- Zero activations, divergences or mismatches. The run records no forbidden
  attempts, guard violations or changed source/input hashes. This audit recorded
  zero forbidden accesses; historical files were accessed only for byte hashes.
  No network, credentials or active capture 247+ outcomes were accessed.
- The owner's retained full-suite log says 698 passed in 2.95 seconds. That log
  was hash-bound; this result audit did not rerun the suite.

| Per-mode metric | Verified value |
|---|---:|
| Mean | 1476.4297796871826 |
| Worst | -723.1007052140435 |
| Best | 4132.793328384176 |
| Negative seasons | 6 |

The six negative seasons are 462, 468, 485, 489, 508 and 520.

Results SHA-256:
`0f1b73b4368d66528659c5dd0dd4e95037b382cabc861b63d6a57f045c67c3d2`

Prefix scan SHA-256:
`0aa8e682f55e8b8ac4269df91faaef45206481ffee730bc0bc2d28328d4880c7`

## Limits

This is reused development data, not a holdout. Zero activations verify ordinary
fallback in this set; they establish no benefit from half-weight recognition
or behavior after an activated prefix diverges. The six reused representative
reruns used source 357d9986, not the new source; exact output and input equality
and the independently reviewed source delta justify reuse. The historical
simulator does not reproduce full production supervision or real queue
competition. No capture comparison or production activation is approved by
this audit.

## Retained evidence

`audit.py`, `audit.json` and logs record the new checks. `original-artifacts/`
contains all four new development files. `reused-evidence/` preserves the prior
full development audit and half-weight synthetic preflight archives, avoiding
a dependency on temporary review directories. The file manifest and archive
are verified byte-for-byte. An initial audit-harness AST selector also counted
the summary aggregation loop; it was narrowed to the trader-construction loop.
That failed diagnostic is retained; the source under review was unchanged.
