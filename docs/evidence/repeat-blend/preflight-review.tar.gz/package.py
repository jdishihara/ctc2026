import gzip,hashlib,io,json,tarfile
from pathlib import Path
P=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
static=json.loads((P/'static-review.json').read_text());model=json.loads((P/'model-probe.json').read_text());dev=json.loads((P/'development-probe.json').read_text());cap=json.loads((P/'capture-probe.json').read_text());tests=json.loads((P/'pytest-result.json').read_text())
assert tests=={'exit_code':0,'forbidden_attempts':[]}
assert all(c['passed'] for c in model['checks']+dev['checks']) and len(dev['checks'])==34
assert [c['exit_code'] for c in cap['checks']]==[0,0,1] and not cap['forbidden_outer_attempts']
assert model['source_sha256']==static['source_sha256']['ctc/analog.py']
assert dev['driver_sha256']==static['source_sha256']['scripts/check_repeat_blend_development.py']
assert cap['driver_sha256']==static['source_sha256']['scripts/compare_repeat_blend.py']
names=['model_probe.py','model-probe.json','run_tests.py','pytest.stdout.log','pytest.stderr.log','pytest-result.json','development_probe.py','reviewed-development-driver.py','development.stdout.log','development.stderr.log','development-probe.json','synthetic-main.stdout.log','capture_probe.py','capture.stdout.log','capture.stderr.log','capture-probe.json','capture-baseline-synthetic-results.stdout.log','capture-candidate-synthetic-results.stdout.log','capture-guard-synthetic-results.stdout.log','static.py','static-review.json','driver-deltas.diff','runtime.diff','review.md','package.py']
files=[P/n for n in names]+list((P/'reviewed-sources').rglob('*'))
for directory in ['synthetic-unmatched-results','capture-baseline-synthetic-results','capture-candidate-synthetic-results','capture-guard-synthetic-results']:
 files.extend(P/directory/name for name in ['metadata.json','results.jsonl','summary.json'])
files.append(P/'synthetic-unmatched-results/prefix-scan.json');files=sorted(p for p in files if p.is_file())
manifest={p.relative_to(P).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files}
(P/'file-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(P/'file-manifest.json');files.sort()
archive=P/'independent-repeat-blend-preflight.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
   for p in files:
    b=p.read_bytes();info=tarfile.TarInfo(p.relative_to(P).as_posix());info.size=len(b);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(files)
 for m,p in zip(members,files):assert m.name==p.relative_to(P).as_posix() and m.isfile() and tar.extractfile(m).read()==p.read_bytes()
report=dict(freeze_revision=static['freeze_head'],archive=str(archive),archive_sha256=sha(archive.read_bytes()),archive_bytes=archive.stat().st_size,archive_member_count=len(files),all_members_verified_byte_for_byte=True,manifest_sha256=sha((P/'file-manifest.json').read_bytes()),source_sha256=static['source_sha256'])
(P/'package.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
