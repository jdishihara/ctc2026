import os,sys,json
from pathlib import Path
out=Path(__file__).resolve().parent;forbidden=[]
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):forbidden.append(event);raise RuntimeError('synthetic tests forbid network')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).absolute();q=p.resolve()
  if any('/data/history' in str(x).lower() or '/recordings/' in str(x).lower() or '.botkey' in str(x).lower() or '/.env' in str(x).lower() or 'credentials' in str(x).lower() for x in (p,q)):
   forbidden.append(str(p));raise RuntimeError('synthetic tests forbid real inputs/credentials')
sys.addaudithook(audit)
import pytest
rc=pytest.main(['-q','-p','no:cacheprovider','tests/test_repeat_prefix.py','tests/test_repeat_development_guards.py'])
(out/'pytest-result.json').write_text(json.dumps(dict(exit_code=rc,forbidden_attempts=forbidden))+'\n')
assert not forbidden
raise SystemExit(rc)
