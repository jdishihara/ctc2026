from __future__ import annotations
import copy, hashlib, importlib, json, math, os, subprocess, sys, types
from pathlib import Path
ROOT=Path('/Users/arjunhans/Documents/ctc2026/.worktrees/repeat-blend');OUT=Path(__file__).resolve().parent
forbidden=[]
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):forbidden.append(event);raise RuntimeError('no network')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).absolute();q=p.resolve()
  if any('/data/history' in str(x).lower() or '.botkey' in str(x).lower() or '/.env' in str(x).lower() or 'credentials' in str(x).lower() or '/recordings/' in str(x).lower() for x in (p,q)):
   forbidden.append(str(p));raise RuntimeError('synthetic preflight forbids history/credentials/recordings')
sys.addaudithook(audit);sys.path.insert(0,str(ROOT))
import numpy as np
from ctc.analog import AnalogEnsemble,GRID_AGES
from ctc.wind import PHYS
oldsource=subprocess.check_output(['git','show','357d9986babf2b21bd3bbdcc2e69550059f16154:ctc/analog.py'],cwd=ROOT).decode()
old=types.ModuleType('ctc.independent_old_analog');old.__package__='ctc';old.__file__=str(OUT/'old_analog.py');exec(compile(oldsource,old.__file__,'exec'),old.__dict__)
tracks=np.zeros((4,241,4));tracks[:,:,0]=np.array([.1,.2,-.1,.3])[:,None]*GRID_AGES;tracks[:,:,1]=500;tracks[:,:,2]=100;tracks[:,:,3]=1
lib=OUT/'synthetic-library.npz';np.savez(lib,tracks=tracks,pattern=np.arange(4),flip=np.full(4,-1),C_off=np.full((6,6),1/6),C_wire=np.full((6,6),1/6))
case={'islands':{'synthetic':{}},'companies':{s:{'sites':[{'x':40,'y':500,'weight':1,'island':'synthetic'}]} for s in PHYS}}
def create(cls=AnalogEnsemble,**kw):return cls(case,lib=lib,sigma=15,k=0,**kw)
def obs(row=0,n=21):return [dict(age=int(GRID_AGES[i]),**dict(zip(('x','y','radius','intensity'),map(float,tracks[row,i])))) for i in range(n)]
checks=[]
def record(name,**kw):checks.append(dict(name=name,passed=True,**kw))
def equal(a,b):np.testing.assert_array_equal(a,b)
ordinary=create(repeat_prefix=False);oneold=create(old.AnalogEnsemble,repeat_prefix=True);disabledold=create(old.AnalogEnsemble,repeat_prefix=False)
variants={'default':create(),'zero':create(repeat_prefix=True,repeat_weight=0),'one':create(repeat_prefix=True,repeat_weight=1),'implicit_one':create(repeat_prefix=True),'half':create(repeat_prefix=True,repeat_weight=.5),'disabled_half':create(repeat_prefix=False,repeat_weight=.5)}
for n in (1,20,21,22,70,200,241):
 observations=obs(n=n);base=ordinary.weights(observations,[],[]);equal(base,disabledold.weights(observations,[],[]));oldone=oneold.weights(observations,[],[])
 for key in ('default','zero','disabled_half'):equal(variants[key].weights(observations,[],[]),base)
 for key in ('one','implicit_one'):equal(variants[key].weights(observations,[],[]),oldone)
 expected=base.copy()
 if n>=21:expected*=.5;expected[0]+=.5
 actual=variants['half'].weights(observations,[],[]);equal(actual,expected);assert np.isfinite(actual).all() and np.all(actual>=0) and math.isclose(float(actual.sum()),1,abs_tol=1e-15)
record('default, zero, one and half endpoints over seven prefix lengths agree exactly with frozen ordinary/one-hot implementations')
# Repeated corrections, shortening and switching storms must retain the ordinary cache.
sequence=[obs(n=140),obs(n=141),obs(n=10),obs(row=3,n=21),obs(row=3,n=22)]
sequence[1][-1]['radius']+=1
for observations in sequence:
 base=ordinary.weights(observations,[],[]);actual=variants['half'].weights(observations,[],[]);expected=base.copy()
 if len(observations)>=21 and observations[-1]['radius']==100:expected*=.5;expected[3 if observations[1]['x']==tracks[3,1,0] else 0]+=.5
 equal(actual,expected)
record('divergence, shortening and new-storm reset retain exact ordinary cache')
for channel in ('x','y','radius','intensity'):
 observations=obs();observations[0][channel]=np.nextafter(observations[0][channel],np.inf)
 equal(create(repeat_prefix=True,repeat_weight=.5).weights(observations,[],[]),create(repeat_prefix=False).weights(observations,[],[]))
record('one-bit change in every observed channel preserves exact unmatched fallback')
# Recognition still contributes half when the ordinary top-k distribution excludes that row.
kwargs=dict(lib=lib,sigma=1000,k=1)
base=AnalogEnsemble(case,repeat_prefix=False,**kwargs);half=AnalogEnsemble(case,repeat_prefix=True,repeat_weight=.5,**kwargs)
for model in (base,half):model.C_off[:]=1e-100;model.C_off[2,2]=1.
b=base.weights(obs(),[(40,'recurve')],[]);assert b[0]==0 and b[2]==1
h=half.weights(obs(),[(40,'recurve')],[]);equal(h,[.5,0,.5,0]);record('half mix restores matched row outside ordinary top-k support')
# Recognition must not depend on unobserved suffix values.
changed=tracks.copy();changed[:,21:,:]=np.random.default_rng(11).uniform(1,10,changed[:,21:,:].shape)
lib2=OUT/'synthetic-mutated-suffix.npz';np.savez(lib2,tracks=changed,pattern=np.arange(4),flip=np.full(4,-1),C_off=np.full((6,6),1/6),C_wire=np.full((6,6),1/6))
a=create(repeat_prefix=True,repeat_weight=.5).weights(obs(),[],[])
b=AnalogEnsemble(case,lib=lib2,sigma=15,k=0,repeat_prefix=True,repeat_weight=.5).weights(obs(),[],[]);equal(a,b);record('half blend weights do not depend on unobserved library suffix')
invalid=[-.1,1.1,float('nan'),float('inf'),-float('inf'),True,False,np.bool_(True),np.bool_(False),'0.5',None,[],{},complex(.5,0),np.array(.5),np.array([.5]),np.float32('nan'),np.float64('inf')]
for value in invalid:
 try:create(repeat_prefix=True,repeat_weight=value)
 except ValueError as exc:assert 'repeat_weight' in str(exc)
 else:raise AssertionError(('invalid accepted',repr(value)))
record('invalid values reject before library use',count=len(invalid))
for value in (0,1,.5,np.int32(0),np.int64(1),np.float32(.5),np.float64(.5),np.longdouble(.5)):
 model=create(repeat_prefix=True,repeat_weight=value);assert type(model.repeat_weight) is float and model.repeat_weight==float(value)
record('finite Python and numpy numeric types accepted and normalized',count=8)
# Unbounded Python ints are rejected too; retain actual exception class for API calibration.
exceptions=[]
for value in (10**1000,-10**1000):
 try:create(repeat_prefix=True,repeat_weight=value)
 except (ValueError,OverflowError) as exc:exceptions.append(type(exc).__name__)
 else:raise AssertionError('huge out-of-range integer accepted')
record('unbounded out-of-range integers rejected',exception_types=exceptions)
from ctc.strategies import FairValueTrader
trader=FairValueTrader(analog=True,repeat_prefix=True,repeat_weight=.5);assert trader.analog_kw=={'repeat_prefix':True,'repeat_weight':.5};record('FairValueTrader passes both options into existing analog kwargs')
assert forbidden==[]
report=dict(source_sha256=hashlib.sha256((ROOT/'ctc/analog.py').read_bytes()).hexdigest(),checks=checks,forbidden_attempts=forbidden,actual_history_reads=0,actual_performance_runs=0)
(OUT/'model-probe.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
