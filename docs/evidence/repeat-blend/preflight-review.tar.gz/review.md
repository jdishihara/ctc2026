# Independent half-weight repeat-prefix preflight

## Assessment

Approved for the predeclared offline evaluation at frozen commit
`7a2fe81b1167bb1b355357b0d105ea91ed29cd05`, subject to the owner's full-suite
gate. No correctness or provenance blocker found. This is not approval to
enable the option in production or a performance claim.

The plan was committed at `146e8b22fc39dff6136b89fc5fe19170db9786b0` before
implementation. During evidence packaging the owner froze the implementation;
the committed source bytes exactly equal the bytes used by these probes and
the worktree is clean. The reviewer made no source changes.

## Strengths and verified behavior

- Of all 28 runtime manifest files, only `ctc/analog.py` differs from frozen
  one-hot `357d9986`. Its matching criteria and ordinary-cache updates are
  unchanged. The default remains recognition disabled; the new weight defaults
  to 1.0 and exactly preserves the old enabled one-hot result.
- Independent synthetic comparisons against the old implementation verify
  exact default, zero and one endpoints over seven prefix lengths; half is
  exactly half the ordinary distribution plus half the unique matching row.
  This also works when ordinary top-k selection excludes the matching row.
- Corrections, divergence, shortening, new storms, one-bit changes in all four
  observed channels, and changing unobserved suffixes preserve the expected
  cache, selection and fallback behavior.
- Python/numpy finite numeric values are accepted and normalized. Booleans,
  strings, containers, complex values, arrays, NaN, infinities and out-of-range
  values are rejected. Very large Python integers are also rejected, via
  `OverflowError`; the experiment passes the fixed finite value 0.5.
- Each driver is byte-for-byte equivalent to the previously reviewed original
  after only the declared descriptions, plan path, coefficient metadata and
  explicit parameter replacements. Every prior guard is preserved.
- Actual capture-driver `main()` control flow ran on deterministic synthetic
  replay stubs for baseline 96 and candidate 96. The baseline receives neither
  repeat option; the candidate receives `repeat_prefix=True, repeat_weight=0.5`.
  The shared parameter dictionary is restored after each phase. Metadata and
  all baseline journal/prerequisite gates were exercised. A separate synthetic
  early-settlement attack was swallowed inside the stub but stayed latched:
  one error and exit 1, with diagnostics retained.
- Actual development-driver `main()` ran on 150 synthetic simulation stubs and
  225 synthetic storm scans. The recognizer and every trader receive 0.5; both
  enable modes remain explicit, shared PARAMETERS are not mutated, and metadata
  records 0.5. All 75 intentionally mismatched unmatched pairs are diagnosed
  and cause exit 1. The previous terminal-price, history allowlist, symlink,
  sticky violation and prefix-divergence probes pass on the cloned driver.

## Verification

- 63 focused synthetic pytest cases passed in 0.18 seconds.
- 34 independent development-driver probes passed.
- Nine independent model contract groups passed, including 18 invalid-value
  inputs, eight accepted numeric types and frozen-implementation comparisons.
- Three synthetic capture-main runs completed with expected outcomes:
  baseline 96/0 errors/exit 0; candidate 96/0/0; attacked candidate 96/1/1.
- Outer audit hooks recorded zero forbidden accesses. No real historical
  inputs, captured-market performance, active capture 247+ data, credentials
  or network calls were used. No frozen evaluator was modified.
- `git diff --check` passed; freeze source bytes match the reviewed hashes.

## Issues

No blocking or important issues found. The changed validation rejects invalid
input before loading a library; uniform exception classes for unbounded
integers are not required for the fixed experiment.

## Declined to judge

- Capture or development P&L, risk-rule outcomes and coefficient usefulness:
  no actual performance evaluation was authorized for this preflight.
- Production activation and unfamiliar-weather validation: outside this fixed,
  optional offline experiment.
- The complete test suite: the owner runs that separate gate; this reviewer
  executed only the relevant synthetic cases.

## Evidence

The retained scripts regenerate all synthetic fixtures. The archive includes
reviewed source bytes, exact driver deltas, per-probe JSON, stdout/stderr,
synthetic main summaries/rows/metadata and a hash manifest. Bulk synthetic
journal/input fixtures are omitted because the retained scripts construct
and verify them. No real market data is included.
