from __future__ import annotations
import difflib,hashlib,importlib.util,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;ROOT=Path('/Users/arjunhans/Documents/ctc2026/.worktrees/repeat-blend');REV='357d9986babf2b21bd3bbdcc2e69550059f16154'
def sha(b):return hashlib.sha256(b).hexdigest()
def old(path):return subprocess.check_output(['git','show',REV+':'+path],cwd=ROOT)
checks=[];diffs=[]
for original,current,replacements in [
 ('scripts/check_repeat_development.py','scripts/check_repeat_blend_development.py',[
  ('Predeclared development-only prefix scan and paired historical simulation.','Predeclared development-only half-weight blend scan and paired simulation.'),
  ('docs/repeat-prefix-plan.md','docs/repeat-blend-plan.md'),
  ('parameters=PARAMETERS, limitations=','parameters=PARAMETERS, repeat_weight=.5, limitations='),
  ('AnalogEnsemble(case, repeat_prefix=True)','AnalogEnsemble(case, repeat_prefix=True, repeat_weight=.5)'),
  ('FairValueTrader(**PARAMETERS, repeat_prefix=enabled)','FairValueTrader(**PARAMETERS, repeat_prefix=enabled, repeat_weight=.5)')]),
 ('scripts/compare_repeat_prefix.py','scripts/compare_repeat_blend.py',[
  ('Guarded offline comparison for optional recognition of repeated weather prefixes.','Guarded offline comparison for a fixed half-weight repeated-weather blend.'),
  ('docs/repeat-prefix-plan.md','docs/repeat-blend-plan.md'),
  ("metadata = dict(phase=args.phase, repeat_prefix_enabled=args.phase == 'candidate',\n", "metadata = dict(phase=args.phase, repeat_prefix_enabled=args.phase == 'candidate',\n                    repeat_weight=.5 if args.phase == 'candidate' else 0.,\n"),
  ("{'repeat_prefix': True} if args.phase == 'candidate' else {}","{'repeat_prefix': True, 'repeat_weight': .5} if args.phase == 'candidate' else {}")])]:
 before=old(original).decode();after=(ROOT/current).read_text();expected=before
 for a,b in replacements:
  assert a in expected;expected=expected.replace(a,b)
 assert after==expected
 checks.append(dict(original=original,current=current,exact_equivalence_after_listed_replacements=True,replacements=replacements,sha256=sha(after.encode())))
 diffs.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=REV+':'+original,tofile=current))
(P/'driver-deltas.diff').write_text(''.join(diffs))
s=importlib.util.spec_from_file_location('static_capture_driver',ROOT/'scripts/compare_repeat_blend.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
runtime=[p.relative_to(ROOT).as_posix() for p in m.runtime_files(ROOT)]
changes=[p for p in runtime if (ROOT/p).read_bytes()!=old(p)];assert changes==['ctc/analog.py']
files=['ctc/analog.py','scripts/compare_repeat_blend.py','scripts/check_repeat_blend_development.py','docs/repeat-blend-plan.md','tests/test_repeat_prefix.py','tests/test_repeat_development_guards.py']
expected={'ctc/analog.py':'aeea09c8bbc40a6884290169d364e2b2e3c34289a4c6da0274ad4eea1965903b','scripts/compare_repeat_blend.py':'d9894af8fa4f53564e6dc5681ede943b3d9b900ae43664913b80fca4a5aa270b','scripts/check_repeat_blend_development.py':'620fcc4e7b9c829042ffbb4ada01d82b8488f31aaf7b032463691ce21b705f58'}
source={name:sha((ROOT/name).read_bytes()) for name in files}
assert all(source[k]==v for k,v in expected.items())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip();plan='146e8b22fc39dff6136b89fc5fe19170db9786b0'
assert head=='7a2fe81b1167bb1b355357b0d105ea91ed29cd05'
subprocess.check_call(['git','merge-base','--is-ancestor',plan,head],cwd=ROOT)
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=normal'],cwd=ROOT).strip()
for name in files:assert (ROOT/name).read_bytes()==subprocess.check_output(['git','show',head+':'+name],cwd=ROOT)
assert (ROOT/'docs/repeat-blend-plan.md').read_bytes()==subprocess.check_output(['git','show',plan+':docs/repeat-blend-plan.md'],cwd=ROOT)
subprocess.check_call(['git','diff','--check'],cwd=ROOT)
for name in files:
 dest=P/'reviewed-sources'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((ROOT/name).read_bytes())
(P/'runtime.diff').write_bytes(subprocess.check_output(['git','diff',REV,'--','ctc/analog.py'],cwd=ROOT))
report=dict(base_revision=REV,plan_head=plan,freeze_head=head,freeze_source_equals_reviewed_bytes=True,plan_bytes_equal_committed_blob=True,runtime_file_count=len(runtime),runtime_changes=changes,driver_equivalence=checks,source_sha256=source,source_bytes_unchanged_across_probes=True,diff_check_passed=True)
(P/'static-review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='driver_equivalence'},indent=2))
