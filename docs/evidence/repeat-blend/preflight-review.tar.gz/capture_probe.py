from __future__ import annotations
import contextlib,copy,hashlib,importlib.util,io,json,os,sys,types
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
OUT=Path(__file__).resolve().parent;SRC=Path('/Users/arjunhans/Documents/ctc2026/.worktrees/repeat-blend');forbidden=[]
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):forbidden.append(event);raise RuntimeError('synthetic preflight forbids network')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).absolute();q=p.resolve()
  if any('/data/history' in str(x).lower() or '/recordings/' in str(x).lower() or '.botkey' in str(x).lower() or '/.env' in str(x).lower() or 'credentials' in str(x).lower() for x in (p,q)):
   forbidden.append(str(p));raise RuntimeError('synthetic preflight forbids real inputs/credentials')
sys.addaudithook(audit)
fixture=OUT/'capture-synthetic-source';frozen=OUT/'capture-synthetic-frozen'
for p in (fixture,frozen):
 for name in ('scripts','ctc','data','docs'):(p/name).mkdir(parents=True,exist_ok=True)
 (p/'data/case.json').write_text('{"limits":{"SYNTH":1}}\n')
 (p/'ctc/analog.py').write_text('# synthetic '+('baseline' if p==frozen else 'candidate')+'\n')
source=(SRC/'scripts/compare_repeat_blend.py').read_bytes();path=fixture/'scripts/compare_repeat_blend.py';path.write_bytes(source);(fixture/'docs/repeat-blend-plan.md').write_text('synthetic plan only\n')
spec=importlib.util.spec_from_file_location('capture_blend_under_test',path);driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def vh(v):return hashlib.sha256(json.dumps(v,sort_keys=True,allow_nan=False).encode()).hexdigest()
def result(rtt,depth,basket):return dict(status='ok',errors=[],rtt_seconds=rtt,displayed_depth_fraction=depth,basket_enabled=basket,synthetic_result=True)
items=[]
for capture in range(241,247):
 data={'frames':[],'receipt':{'competition_id':f'synthetic-{capture}','prices':{'SYNTH':1},'at':10.}}
 cached=OUT/f'capture-{capture}-synthetic-input.json';cached.write_text(json.dumps(data))
 archive=OUT/f'capture-{capture}-synthetic-archive';archive.mkdir()
 rows=[]
 for cap,rtt,depth,basket in driver.GRID:
  if cap!=capture:continue
  rows.append(dict(capture=capture,comparison_status='synthetic_archive',**result(rtt,depth,basket)))
  d=archive/f'capture-{capture}-{rtt}-{depth}-{int(basket)}';d.mkdir()
  for name in driver.JOURNALS:(d/name).write_text('synthetic journal '+name+'\n')
 (archive/'metadata.json').write_text(json.dumps({'captures':[dict(capture=capture,competition_id=data['receipt']['competition_id'],frames_sha256=vh(data['frames']),receipt_sha256=vh(data['receipt']))]}))
 (archive/'results.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
 (archive/'summary.json').write_text(json.dumps(dict(errors=0,mismatches=0,changed_sources=[],results_sha256=sha(archive/'results.jsonl'))))
 items.append(dict(capture=capture,input=str(cached),input_sha256=sha(cached),archive=str(archive),archive_sha256={n:sha(archive/n) for n in ('metadata.json','results.jsonl','summary.json')}))
specpath=OUT/'capture-synthetic-spec.json';specpath.write_text(json.dumps(dict(baseline_root=str(frozen),captures=items)))
parameters={'unchanged_parameter':'sentinel'};seen=[];server_refs=[];attack=False
class FakeServer:
 def __init__(self,*a,**kw):
  self.requests=[];self.market=SimpleNamespace(fills=[],market_open=True);self.terminal=False;self.now=0.;self.settlement_available_at=10.;self.fatal_errors=[];server_refs.append(self)
 def request(self,*a,**kw):return {}
 def latch(self,exc):self.fatal_errors.append(str(exc))
class FakeSession:
 def __init__(self,*a,**kw):pass
class FakeAnalog:
 def __init__(self,enabled):self.repeat_match=0 if enabled else None
 def weights(self,obs,official,wire,adv=None):return [1.]
class FakeTrader:
 def __init__(self,**kw):
  seen.append(copy.deepcopy(kw));self.kw=kw;self.competition_id='synthetic';self.model=SimpleNamespace(reported_rounds=set(),live_history_ready=True);self.ensemble=FakeAnalog(kw.get('repeat_prefix',False))
 def on_quotes(self,exchange):return None
class FakeTransport:
 def send(self,*a,**kw):return None
mods={n:types.ModuleType(n) for n in ('scripts','scripts.replay_practice_supervisor','bot','bot.practice','ctc','ctc.strategies','ctc.analog')}
for n in ('scripts','bot','ctc'):mods[n].__path__=[]
replay=mods['scripts.replay_practice_supervisor'];practice=mods['bot.practice'];mods['ctc.strategies'].FairValueTrader=FakeTrader;mods['ctc.analog'].AnalogEnsemble=FakeAnalog
replay.PARAMETERS=parameters;replay.PracticeReplayServer=FakeServer;replay.ServerTransport=FakeTransport;replay.OfflinePracticeExchange=type('UnusedPractice',(),{});replay.OfflineCleanupExchange=type('UnusedCleanup',(),{})
practice.PracticeSession=FakeSession;practice.finish=lambda journal:None
calls=0

def run_stub(case,frames,year,cid,settlement,*,receipt_at,out,rtt,depth_scale,basket):
 global calls
 calls+=1
 assert case=={'limits':{'SYNTH':1}} and frames==[] and year in [str(2027-n) for n in range(241,247)]
 server=replay.PracticeReplayServer();practice.PracticeSession();trader=FakeTrader(**{**replay.PARAMETERS,'basket_edge':.01 if basket else 0})
 trader.on_quotes(SimpleNamespace(competition_id='synthetic'))
 trader.ensemble.weights([{'age':40}],[],[])
 if attack and calls==1:
  try:settlement['SYNTH']
  except AssertionError:pass
  else:raise AssertionError('early read did not fail')
 practice.finish(None)
 server.terminal=True;server.market.market_open=False;server.now=receipt_at
 assert dict(settlement)=={'SYNTH':1}
 out.mkdir()
 for name in driver.JOURNALS:(out/name).write_text('synthetic journal '+name+'\n')
 return result(rtt,depth_scale,basket)
replay.replay_supervised=run_stub

def fake_git(args,**kw):
 root=Path(kw.get('cwd'))
 if args[1:3]==['rev-parse','HEAD']:return (driver.FROZEN if root==frozen else 'synthetic-candidate-revision')+'\n'
 if args[1]=='status':return b''
 if args[1]=='show':return (root/args[2].split(':',1)[1]).read_bytes()
 raise AssertionError(args)

def phase(name,out,baseline=None,guard_attack=False):
 global calls,attack
 calls=0;seen.clear();server_refs.clear();attack=guard_attack
 replay.__file__=str((frozen if name=='baseline' else fixture)/'scripts/replay_practice_supervisor.py')
 argv=[str(path),'--phase',name,'--spec',str(specpath),'--out',str(out)]
 if baseline:argv+=['--baseline',str(baseline)]
 code=0;log=io.StringIO()
 with patch.dict(sys.modules,mods),patch.object(driver.subprocess,'check_output',fake_git),patch.object(driver,'runtime_files',lambda root:sorted([root/'data/case.json',root/'ctc/analog.py'])),patch.object(driver.sys,'argv',argv),contextlib.redirect_stdout(log):
  try:driver.main()
  except SystemExit as exc:code=exc.code
 (OUT/(out.name+'.stdout.log')).write_text(log.getvalue())
 assert calls==96 and len(seen)==96 and parameters=={'unchanged_parameter':'sentinel'}
 for (_,_,_,basket),kw in zip(driver.GRID,seen):
  expected={'unchanged_parameter':'sentinel','basket_edge':.01 if basket else 0}
  if name=='candidate':expected.update(repeat_prefix=True,repeat_weight=.5)
  assert kw==expected
 metadata=json.loads((out/'metadata.json').read_text());summary=json.loads((out/'summary.json').read_text());rows=[json.loads(x) for x in (out/'results.jsonl').read_text().splitlines()]
 assert metadata['repeat_prefix_enabled']==(name=='candidate') and metadata['repeat_weight']==(.5 if name=='candidate' else 0.)
 assert summary['runs']==len(rows)==96 and not summary['forbidden_attempts'] and not summary['changed_sources']
 assert summary['errors']==int(guard_attack) and code==int(guard_attack)
 if guard_attack:assert len(server_refs[0].fatal_errors)==1 and rows[0]['status']=='error'
 return dict(phase=name,synthetic_guard_attack=guard_attack,rows=96,exit_code=code,errors=summary['errors'],parameters_restored=True,parameter_plumbing_exact=True,metadata_coefficient_exact=True)
base=OUT/'capture-baseline-synthetic-results';cand=OUT/'capture-candidate-synthetic-results';attackdir=OUT/'capture-guard-synthetic-results'
checks=[phase('baseline',base),phase('candidate',cand,base),phase('candidate',attackdir,base,True)]
assert not forbidden
report=dict(driver_sha256=hashlib.sha256(source).hexdigest(),checks=checks,forbidden_outer_attempts=forbidden,actual_history_reads=0,actual_performance_runs=0,notes=['All replays are deterministic synthetic stubs, not captured-market simulations.','Actual main control flow retains complete 96-row provenance and baseline journal gates.','Swallowed early-settlement violation remains latched and makes the candidate synthetic run fail.'])
(OUT/'capture-probe.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
