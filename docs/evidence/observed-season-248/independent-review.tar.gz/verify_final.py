"""Final artifact checks only; does not import or rerun an evaluator."""
import collections
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path

OUT=Path(__file__).resolve().parent
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,v):(OUT/name).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
audit=load(OUT/'audit.json');cache=load(OUT/'248.json');frames=cache['frames']
assert audit['all_88_result_rows_checked'] and audit['journal_files']==112
assert audit['forbidden_attempts']==[] and audit['trial_states']=={'completed':16} and audit['cleanup_states']=={'settled':16}
assert all(sha(p)==h for p,h in audit['source_sha256'].items())
messages=[f['message'] for f in frames if f.get('type')=='news']
seqs=[m['seq'] for m in messages if m.get('seq') is not None]
assert sorted(seqs)==list(range(865))
finals=[(m['round'],m['seq']) for m in messages if m.get('type')=='damage_report' and m.get('stage')=='final']
assert finals==[(1,288),(2,575),(3,864)]
windows=audit['cache']['coverage']['round_windows'];groups=collections.defaultdict(list)
for f in frames:
    if f.get('type')!='quote':continue
    if not all(type(f.get(k)) in(int,float) and math.isfinite(f[k]) for k in ('bid','ask','bid_size','ask_size')):continue
    if not (0<f['bid']<=f['ask'] and min(f['bid_size'],f['ask_size'])>=0):continue
    for rnd,w in windows.items():
        if w['first_at']<=f['received_at']<=w['closed_at']:
            groups[rnd,f['symbol']].append(f['received_at']);break
gaps=[(b-a,int(rnd),s,a,b) for (rnd,s),times in groups.items() for a,b in zip(times,times[1:])]
worst_gap=max(gaps)
first_gaps={s:times[0]-windows['1']['first_at'] for (rnd,s),times in groups.items() if rnd=='1'}
expected={'reference':[(.25,1.,True),(1.,.5,False)],'supervised':[(.25,1.,True),(1.,.5,False),(0.,1.,False)],'worker':[(.25,1.,True)]}
reruns=[];journal_count=0
for mode,settings in expected.items():
    summary=load(OUT/f'rerun-{mode}/summary.json')
    assert summary['changed_sources']==summary['forbidden_attempts']==[]
    assert [tuple(r['setting']) for r in summary['rows']]==settings
    assert all(sha(p)==h for p,h in summary['source_sha256'].items())
    assert summary['cache_sha256']==audit['cache']['file_sha256']
    for r in summary['rows']:
        assert r['all_result_fields_match'] and r['different_fields']==[] and not r['forbidden_attempts']
        rtt,depth,basket=r['setting'];d=OUT/f'rerun-{mode}'/f'{rtt}-{depth}-{int(basket)}'
        assert sha(d/'result.json')==r['result_sha256']
        assert sha(d/'request-trace.json.gz')==r['request_file_sha256']
        assert sha(d/'fill-trace.json.gz')==r['fill_file_sha256']
        if mode=='supervised':
            assert len(r['journal_byte_comparisons'])==7 and all(x['byte_identical'] and x['original_sha256']==x['rerun_sha256'] for x in r['journal_byte_comparisons'].values())
            journal_count+=7
        reruns.append(dict(mode='serialized' if mode=='reference' else mode,setting=r['setting'],pnl=r['pnl'],
            exact_fields=True,trace_hashes=r['trace_hashes'],first_settlement_access=r['first_settlement_value_access'],
            cutoff=r['cutoff'],receipt_available=r['receipt_available_at'],journal_byte_identical=mode=='supervised'))
assert len(reruns)==6 and journal_count==21
assert not list(OUT.rglob('failed-attempt.json'))
primary=audit['primary_supervised']
verification=dict(six_authorized_reruns=reruns,performance_rerun_count=6,candidate_runs=0,
    replay_failures=[],original_rows_checked=88,original_standard_journals_checked=112,
    reproduced_supervised_journal_files_byte_identical=21,source_files_unchanged=len(audit['source_sha256']),
    news_sequence_range=[0,864],unique_news_sequences=865,final_report_round_and_seq=finals,
    largest_later_valid_quote_gap={'seconds':worst_gap[0],'round':worst_gap[1],'symbol':worst_gap[2],'from':worst_gap[3],'to':worst_gap[4]},
    initial_round1_snapshot_to_first_valid_quote_gaps=first_gaps,
    subscription_acknowledgements=audit['cache']['coverage']['subscription_acknowledgements'],
    primary_terminal_settlement_pnl=primary['terminal_settlement_pnl'],primary_final_receipt_mark_pnl=primary['final_receipt']['pnl'],
    primary_settled_not_flat=primary['cleanup']['state']=='settled' and not primary['final_receipt']['flat'],
    source_receipt_cache_hashes={'spec':audit['spec_sha256'],'npz':audit['npz_sha256'],
        'frames_value':audit['cache']['frames_value_sha256'],'receipt_value':audit['cache']['receipt_value_sha256'],
        'cache_file':audit['cache']['file_sha256']})
save('verification.json',verification)
def utc(value):return datetime.fromtimestamp(value,timezone.utc).isoformat()
stats='\n'.join(f"| {label} | {audit[key]['runs']} | {audit[key]['positive']} | {audit[key]['mean']:.6f} | {audit[key]['worst']:.2f} | {audit[key]['best']:.2f} |" for label,key in [('Original fixed worker','worker24'),('Serialized client','serialized16'),('Supervised client','supervised16')])
repro='\n'.join(f"| {r['mode']} | {r['setting'][0]} / {r['setting'][1]} / {'on' if r['setting'][2] else 'off'} | {r['pnl']:.2f} | exact |" for r in reruns)
text=f'''# Independent original capture 248 audit

## Verdict

All requested original evidence checks and **exactly six authorized reproductions passed**. No blocker was found in the reported original results. This is virtual performance on one captured market path, with exact fitted-weather overlap and incomplete quote coverage; it is not live account attribution or unseen-weather validation.

CID: `789097b1-a48b-4e68-95b4-5e15b047e149`; fictional year 1779.

## Closure, timing and source gates

- Official receipt: **{utc(audit['cache']['receipt_at'])}**, epoch 1792838086.3271759. Both clocks are ready and identify the same CID/year; all 12 finite positive settlement prices and three final reports are present.
- Selected interval: **{utc(audit['cache']['first_at'])}** through **{utc(audit['cache']['last_at'])}**. All 25,213 selected frames precede the receipt.
- Original runtime freeze 1792828815 and supervisor-driver freeze 1792829252 both precede the selected interval. Serialized reference is `505a5ad2`; supervisor driver `c5c35a30`; runtime `cd3eb239`; fixed worker `49a690ef`. Frozen source hashes remain unchanged.
- Sealed observation/feed byte counts and hashes match the immutable spec. The sealed observation prefix also matches exactly that many bytes from the observer ledger; no later appended observations were read.
- All three phase artifacts match the supplied result hashes, report 16 rows/zero errors/zero mismatches/no source changes, and their completion events have exit 0. Prerequisite result hashes and phase timing are consistent.
- Closure was established before loading the approved selector or fitted NPZ. Guards denied network, credentials, downloaded history and manifests. No active 249 outcome was read.

## Original results

**88 original rows** were checked: 24 fixed-worker + 16 serialized + 48 reference/baseline/supervised comparison rows. The comparison rows repeat configurations; they are not 88 independent trials. Reference and baseline fields match the original serialized rows.

| Evaluation | Rows | Positive | Mean virtual P&L | Worst | Best |
|---|---:|---:|---:|---:|---:|
{stats}

All 16 supervised trials are **completed and settled**, with no attention cases. Every one of the 16 settings has all seven standard journals, totaling **112 files**; results, status, observations, actions, startup feeds, final receipts and run locks reconcile. Ownership is clear, caps are respected and no fills occur after final receipt requests.

Primary `.25/full/on` terminal settlement P&L is **+$985.54**. Its final receipt's contemporaneous mark is **+$986.42**; these are different valuation bases. The primary is settled with seven nonzero symbol holdings and zero open orders, **not flat**. Settlement success must not be described as completed liquidation.

## Exactly six authorized reruns

| Evaluator | RTT / depth / baskets | Virtual P&L | Original fields |
|---|---|---:|---|
{repro}

All five serialized/supervised request and fill hashes match their original rows. The three supervised reruns additionally reproduce all seven journal files byte for byte: **21 identical files**. Cash plus holdings reconciles to terminal settlement in every rerun. The fixed-worker run uses current snapshot behavior (`reset_warmup_each_snapshot=False`); it has no HTTP requests, and its full virtual action/fill traces are retained. There were zero rerun failures and zero candidate-policy runs.

Each rerun retains its full request/fill traces, result, field comparison, source checks and guarded settlement-access timing. Serialized/worker settlement reads are confined to terminal scoring after market close; supervised reads additionally wait until receipt availability.

## Coverage and fitted-weather overlap

- News sequences 0–864 are contiguous, unique and complete: 865 messages. Final reports are at sequence 288/575/864 for rounds 1/2/3.
- 25,213 selected frames include 24,253 quote frames, 41 unusable quotes, and one subscription acknowledgement in round 3. Zero explicit disconnect frames were recorded; the acknowledgement may indicate a reconnect but cannot establish disconnect onset or reconstruct missed quotes.
- Initial round 1 snapshot-to-first-valid-quote delay is approximately 120.318 seconds. The largest later within-round valid-quote interval is **52.438055 seconds, RECON round 3**. Receive-time gaps do not prove missing server events, and quote-path completeness remains unproven.
- Every storm has all 241 observations at ages 0–480 by 2 seconds. Comparing all four channels `(x,y,radius,intensity)` after closure gives exact fitted NPZ matches at zero-based rows **741,742,743**, respectively; each closest RMSE is 0. No downloaded history or library-build manifest was opened.

Chronological evaluator freezes do not remove this training overlap. All scenario outcomes share one recorded path and should not be reported as an independent-trial success rate.

## Durable artifacts

- `audit.json`: original 88-row/112-file audit, full coverage, source hashes, phase events, receipt and track overlap.
- `verification.json`: independent news/gap recomputation and exact six-run reconciliation.
- `248.json`: reconstructed closed cache, exactly `{{frames,receipt}}`.
- `original/`: copied original result artifacts, sealed spec/observations, phase logs and 112 supervised journal files.
- `rerun-reference/`, `rerun-supervised/`, `rerun-worker/`: all six retained runs and complete traces. The `reference` directory denotes runs of the frozen serialized evaluator.
- `artifact-hashes.json`: every archived file hash; original source and input feed files are preserved at their existing paths and identified by hash.

| Object | SHA256 |
|---|---|
| Spec | `{audit['spec_sha256']}` |
| Sealed observations | `{next(e for e in audit['phase_events'] if e.get('kind')=='eligibility_scan')['prefix_sha256']}` |
| Sealed feed | `734690b1b1e868113faf5af30caae0ae6d442408e1e7710a3b43f34a56ff1cd8` |
| Frames canonical value | `{audit['cache']['frames_value_sha256']}` |
| Receipt canonical value | `{audit['cache']['receipt_value_sha256']}` |
| Independently serialized cache file | `{audit['cache']['file_sha256']}` |
| Fitted NPZ | `{audit['npz_sha256']}` |

Canonical value hashes match the original supervised metadata. A different JSON whitespace serialization can have a different raw cache hash while retaining these canonical values. This independent cache was preserved unchanged.

## Declined to judge

Actual account P&L, unobserved quote updates or liquidity, market impact and competing traders; generalization to unseen weather; retry-candidate performance; outcomes of active capture 249 or later. No live activation is implied by this audit.
'''
(OUT/'README.md').write_text(text)
print(json.dumps(dict(original_rows=88,standard_journals=112,exact_reruns=6,identical_rerun_journals=21,
    largest_later_gap=verification['largest_later_valid_quote_gap'],cache_sha256=audit['cache']['file_sha256'],failures=[]),indent=2))
