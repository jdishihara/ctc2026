"""Independent paired representative reruns; only already closed captures 241-245."""
import collections, copy, hashlib, json, os, pathlib, subprocess, sys, tempfile
from collections.abc import Mapping
from dataclasses import asdict
from unittest.mock import patch
ROOT=pathlib.Path('/Users/arjunhans/Documents/ctc2026');O=ROOT/'out/cleanup-quotes-v1-20261024'
PHASE=sys.argv[1];assert PHASE in ('baseline','candidate')
W=ROOT/'.worktrees'/('practice-history' if PHASE=='baseline' else 'cleanup-latency')
REV='cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026' if PHASE=='baseline' else '5832359d4705ac70303d80b7c1b9af2d02a6a25a'
violations=[]
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
  violations.append(event);raise RuntimeError('network forbidden')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  name=os.fsdecode(args[0]).lower()
  if '.botkey' in name or '/.env' in name or '/data/history/' in name or 'credentials' in name:
   violations.append(name);raise RuntimeError('credentials/downloaded-history forbidden')
sys.addaudithook(audit)
def J(p):return json.loads(pathlib.Path(p).read_text())
def H(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def VH(v):return hashlib.sha256(json.dumps(v,sort_keys=True,allow_nan=False).encode()).hexdigest()
def K(r):return r['capture'],r['rtt_seconds'],r['displayed_depth_fraction'],r['basket_enabled']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==REV
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=W,text=True)
m=J(O/PHASE/'metadata.json');source_hashes=m['source_sha256']
assert all(H(p)==sha for p,sha in source_hashes.items())
expected={K(r):r for line in (O/PHASE/'results.jsonl').read_text().splitlines() if (r:=json.loads(line))}
items={i['capture']:i for i in m['spec']['captures']}
sys.path.insert(0,str(W))
from scripts import replay_practice_supervisor as replay
from bot import practice
from ctc.strategies import FairValueTrader
assert pathlib.Path(replay.__file__).resolve().is_relative_to(W.resolve())
case=J(W/'data/case.json');out=pathlib.Path(tempfile.mkdtemp(prefix='cleanup-independent-'+PHASE+'-'))
cases=[(243,1.,.5,True),(245,1.,1.,False),(244,.25,1.,True),(242,.25,1.,True),(244,0.,.5,True)]
active={};counts=collections.Counter();results=[]
OServer=replay.PracticeReplayServer;OSession=practice.PracticeSession
old_finish=practice.finish;old_quotes=FairValueTrader.on_quotes;old_send=replay.ServerTransport.send

def enforce(condition,message):
 if not condition:
  exc=AssertionError(message)
  if 'server' in active:active['server'].latch(exc)
  raise exc
class RecordingServer(OServer):
 def __init__(self,*a,**kw):
  super().__init__(*a,**kw);active['server']=self;self.cleanup_profile=[]
 def request(self,*a,**kw):
  stack=[]
  if 'cleanup_request_index' in active:
   frame=sys._getframe(1)
   while frame:
    if frame.f_code.co_filename.endswith(('/bot/practice.py','/bot/live.py')):
     stack.append(dict(file=pathlib.Path(frame.f_code.co_filename).name,function=frame.f_code.co_name,line=frame.f_lineno))
    frame=frame.f_back
  response=super().request(*a,**kw)
  if 'cleanup_request_index' in active:
   self.cleanup_profile.append(dict(request=copy.deepcopy(self.requests[-1]),stack=stack))
  return response
class RecordingSession(OSession):
 def __init__(self,*a,**kw):
  super().__init__(*a,**kw);active['session']=self
class GuardedSettlement(Mapping):
 def __init__(self,values):self._prices=dict(values)
 def _check(self):
  s=active['server'];counts['settlement_reads']+=1
  enforce(s.terminal and not s.market.market_open and s.now>=s.settlement_available_at,'premature settlement access')
 def __getitem__(self,key):self._check();return self._prices[key]
 def __iter__(self):return iter(self._prices)
 def __len__(self):return len(self._prices)
 def copy(self):self._check();return dict(self)
 def __copy__(self):return self.copy()
 def __deepcopy__(self,memo):self._check();return GuardedSettlement(dict(self))
def finish(journal):
 s=active['server'];active['cleanup_request_index']=len(s.requests);active['cleanup_fill_index']=len(s.market.fills)
 return old_finish(journal)
def quotes(trader,exchange):
 counts['quote_callbacks']+=1
 enforce(trader.competition_id==exchange.competition_id and isinstance(trader.competition_id,str) and bool(trader.competition_id.strip()),'identity mismatch')
 model=trader.model;reports=set(model.reported_rounds);ready=model.live_history_ready
 result=old_quotes(trader,exchange)
 enforce(trader.model is model and model.reported_rounds==reports and model.live_history_ready==ready,'quotes changed model history')
 return result
def send(exchange,method,path,body=None):
 if method=='POST' and isinstance(exchange,replay.OfflinePracticeExchange):
  counts['strategy_posts']+=1;session=active['session']
  enforce(not session._valid_weather_wait() and session.strat.model.live_history_ready,'strategy POST without ready news')
  enforce(session.competition_id==exchange.competition_id==session.strat.competition_id,'strategy POST identity mismatch')
 if method=='POST' and isinstance(exchange,replay.OfflineCleanupExchange):
  counts['cleanup_posts']+=1;q=exchange.position[body['symbol']]
  enforce(exchange.state_ready and exchange.market_open and not exchange.open_orders,'unsafe cached cleanup state')
  enforce(exchange.competition_id==exchange.expected_id,'cleanup identity mismatch')
  enforce(q and body['side']==('sell' if q>0 else 'buy') and 0<body['quantity']<=abs(q),'cleanup not reducing cached exposure')
  actual=active['server'].market.position[body['symbol']]
  enforce(actual and body['side']==('sell' if actual>0 else 'buy') and 0<body['quantity']<=abs(actual),'cleanup not reducing actual server exposure at request start')
 return old_send(exchange,method,path,body)
with patch.object(replay,'PracticeReplayServer',RecordingServer),patch.object(practice,'PracticeSession',RecordingSession),patch.object(practice,'finish',finish),patch.object(FairValueTrader,'on_quotes',quotes),patch.object(replay.ServerTransport,'send',send):
 for k in cases:
  active.clear();c,rtt,depth,basket=k;item=items[c];assert H(item['input'])==item['input_sha256']
  data=J(item['input']);receipt=data['receipt'];meta=next(x for x in J(pathlib.Path(item['archive'])/'metadata.json')['captures'] if x['capture']==c)
  assert VH(data['frames'])==meta['frames_sha256'] and VH(receipt)==meta['receipt_sha256']
  assert receipt['clock']['state']=='ready' and meta['year']==str(2027-c)
  d=out/f'capture-{c}-{rtt}-{depth}-{int(basket)}'
  result=replay.replay_supervised(case,data['frames'],str(2027-c),receipt['competition_id'],GuardedSettlement(receipt['prices']),receipt_at=receipt['at'],out=d,rtt=rtt,depth_scale=depth,basket=basket)
  want={f:v for f,v in expected[k].items() if f not in ('capture','comparison_status','pre_cleanup_trace','journal_sha256')}
  assert result==want,(k,[f for f in set(result)|set(want) if result.get(f)!=want.get(f)])
  server=active['server'];assert not server.fatal_errors
  prefix=dict(requests_sha256=VH(server.requests[:active['cleanup_request_index']]),fills_sha256=VH([asdict(f) for f in server.market.fills[:active['cleanup_fill_index']]]))
  assert prefix==expected[k]['pre_cleanup_trace']
  (d/'cleanup-profile.json').write_text(json.dumps(server.cleanup_profile,indent=2)+'\n')
  for name,sha in expected[k]['journal_sha256'].items():assert H(d/name)==sha,(k,name)
  result_entry=dict(setting=k,pnl=result['terminal_settlement_pnl'],cleanup=result['cleanup'],duration=result['cleanup_completed_at']-result['cleanup_started_at'],files_exact=8,pre_cleanup_trace=prefix)
  results.append(result_entry);print(json.dumps(dict(phase=PHASE,setting=k,pnl=result_entry['pnl'],cleanup=result['cleanup']['state'],duration=result_entry['duration'],verified='all result fields, pre-cleanup traces and eight files exact')),flush=True)
assert not violations and all(H(p)==sha for p,sha in source_hashes.items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==REV
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=W,text=True)
proof=dict(phase=PHASE,revision=REV,cases=results,counts=dict(counts),forbidden_attempts=violations,sources_unchanged=True,source_hashes=source_hashes)
(out/'independent-audit.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(audit_path=str(out/'independent-audit.json'),phase=PHASE,cases=len(results),counts=dict(counts),forbidden_attempts=violations)),flush=True)
