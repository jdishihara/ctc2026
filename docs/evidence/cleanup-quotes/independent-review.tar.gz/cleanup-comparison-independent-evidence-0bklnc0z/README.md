# Independent cleanup comparison audit

Frozen candidate: 5832359d4705ac70303d80b7c1b9af2d02a6a25a.
Frozen baseline: cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026.
The production decision supported by this audit is to retain the baseline.
This is descriptive evidence on five reused closed captures, not a live-readiness
or profitability certification.

all-80-audit.json records the complete pair, accounting, input identity and
profile audit: 630 manifest-bound files, 58 Git source/model paths, 643 bound
baseline artifacts, 1,280 journal/profile hashes and 560 baseline journals
byte-identical to earlier archives. All 80 stop fields, pre-cleanup traces,
observations and startup feed contents match between implementations. Eight
terminal P&L values change (three improve, five decline); 72 are unchanged.
Twelve full result objects change because cleanup requests/timings can change
without changing P&L.

baseline/ and candidate/ retain five independent reruns each: capture 243 at
1 s/half depth/baskets; 245 at 1 s/full depth/no baskets; 244 at 0.25 s/full
depth/baskets; 242 at 0.25 s/full depth/baskets; and 244 at zero RTT/half
depth/baskets. Every result field, pre-cleanup trace and all eight result/journal/
profile files matched the frozen output exactly. Combined guard counters:
45,486 quote callbacks, 370 strategy POSTs, 54 cleanup POSTs, and 168 settlement
reads. All guards recorded zero forbidden attempts. No real network, credentials,
downloaded history or active capture outcomes were accessed.

The profile audit checks every closing POST's observed side/quantity, price
rounding, call order and book-read-to-POST execution interval: nine RTTs for
baseline, four RTTs for candidate. This interval is not the age of the underlying
market quote. All candidate book reads were followed by positions verification.
The two residual attention portfolios remain AQUA -8, GRID -5, REIN -20.

Audit entry points (read-only source and temporary output):
- audit_artifacts.py verifies the complete 160-row evidence set.
- rerun_representatives.py baseline (or candidate) runs the five fixed cases.
Use the ctc2026 virtual-environment Python with PYTHONDONTWRITEBYTECODE=1.
Both entry points create fresh temporary outputs; they do not update this archive.

Copied artifact origins and SHA-256 values are in artifact-manifest.json.
No frozen source or original comparison output was modified.
