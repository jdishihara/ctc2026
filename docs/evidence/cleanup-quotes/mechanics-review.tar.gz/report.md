# Independent cleanup profile audit

Scope: four completed scenario pairs only. No runtime/replay execution, source edits, network, credentials, downloaded history, or future246 data.

| Scenario | Elapsed seconds | Requests | Sleep seconds | Outer passes | Books (empty) | Added positions GETs | Closing orders | P&L change |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 243, full depth, basket on | 230 → 253 | 228 → 251 | 2 → 2 | 3 → 3 | 11 (2) → 12 (3) | 12 | 9 → 9 | $+36.56 |
| 243, half depth, basket off | 260 → 283 | 255 → 278 | 5 → 5 | 5 → 5 | 13 (5) → 14 (6) | 14 | 8 → 8 | $-7.19 |
| 243, half depth, basket on | 238 → 290 | 236 → 285 | 2 → 5 | 3 → 5 | 11 (2) → 13 (4) | 13 | 9 → 9 | $-21.12 |
| 245, full depth, basket off | 228 → 174 | 223 → 172 | 5 → 2 | 5 → 3 | 11 (4) → 8 (2) | 8 | 6 → 6 | $-17.75 |

## Exact duration decomposition

All requests take1 second and all gaps are1-second cleanup sleeps. Components below sum exactly to each duration change.

- capture-243-1.0-1.0-1: +23s = acknowledgement_refresh +4, book +1, post_book_positions +12, symbol_checks +6.

- capture-243-1.0-0.5-0: +23s = acknowledgement_refresh -4, book +1, post_book_positions +14, symbol_checks +12.

- capture-243-1.0-0.5-1: +52s = acknowledgement_refresh -8, book +2, final_tail_checks +6, outer_checks +24, post_book_positions +13, sleep_seconds +3, symbol_checks +12.

- capture-245-1.0-1.0-0: -54s = acknowledgement_refresh -8, book -3, final_tail_checks -6, outer_checks -24, post_book_positions +8, sleep_seconds -3, symbol_checks -18.

## Book age and fill behavior

All32 baseline closing POSTs use books sampled9 seconds earlier; all32 candidate POSTs use books sampled4 seconds earlier. This measures REST book sampling to POST execution, not age of the underlying captured quote. Captured quotes can already be almost5 seconds old at the book read.

Every empty book in these eight profiles corresponds to the latest captured quote being older than5 seconds, with positive recorded bid/ask sizes. The replay freshness rule therefore explains the empty response. This does not establish absent liquidity in the actual exchange.

All16 initially pending acknowledgements across both phases encounter a newest captured quote older than5 seconds at POST execution, despite a marketable limit against the latest recorded touch. They fill on later quotes. Filled/partial acknowledgements trigger an additional four-request account refresh inside place(); pending acknowledgements do not. These changes in acknowledgement state explain the acknowledgement-refresh duration components.

No pair adds a closing order or cancellation. Each target symbol receives one closing order, possibly filled in multiple pieces. All four candidate and baseline accounts finish flat.

## Mechanism highlights

-243/full/on: one additional stale-book visit plus12 added position checks and one additional acknowledgement refresh produce+23s. AQUA and GRID move to a later pass; RECON closes earlier. P&L improves$36.56 despite slower cleanup.
-243/half/off: six empty-book reads replace five; PORT still working during a later per-symbol reconciliation causes one extra check without a book. REBLD becomes the late residual and fills at2705.012272, versus2587.858992. Net duration+23s; P&L−$7.19.
-243/half/on: PORT reads are empty at2297.5,2478.5,2499.5,2520.5; it finally submits at2545.5, versus2300.5 baseline. The fifth pass and final check add time. PORT fill VWAP rises99.50→100.61 for20 units, costing$22.20; all other symbols together improve$1.08, leaving−$21.12 overall.
-245/full/off: FERRY moves from five book reads to one, posting at2503.5 instead of2635.5. Outer passes fall5→3, offsetting8 new position GETs. FERRY closes128.722778s earlier; HAVEN closes76.106025s later and becomes the final fill. Duration improves54s, but FERRY costs$8.00 and HAVEN$9.75 relative to baseline, totaling−$17.75.

## Narrow next hypothesis

Separately predeclare testing whether an empty/invalid book can be rejected before the new post-book positions GET, while preserving full position-vector validation and all submission guards for every prospective POST. The candidate currently pays3,6,4,2 such GETs on empty books in these four scenarios. Their direct cost is only1 second each here; this cannot by itself explain or promise to reverse the52-second worst-case regression. Subsequent sampling times and fills would change, so no P&L improvement is inferred. This audit ran no such alternative.

The evidence supports rejecting production promotion of this completed candidate. The proposed follow-up is a diagnostic hypothesis, not approval to loosen freshness checks, change retry limits, or activate live trading.

Detailed times, fills, cash decomposition, request categories and all input SHA256s are in analysis.json.
