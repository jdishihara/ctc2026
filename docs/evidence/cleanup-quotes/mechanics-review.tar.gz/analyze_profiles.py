from __future__ import annotations
import bisect, hashlib, json, math, os, sys
from collections import Counter, defaultdict
from pathlib import Path
ROOT=Path('/Users/arjunhans/Documents/ctc2026/out/cleanup-quotes-v1-20261024')
OUT=Path(sys.argv[1]); hashes={}; forbidden=[]
def audit(event,args):
    if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
        forbidden.append(event); raise RuntimeError('read-only profile audit forbids network')
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        name=os.fsdecode(args[0]).lower()
        if '.botkey' in name or '/.env' in name or '/data/history/' in name or 'credentials' in name:
            forbidden.append(name); raise RuntimeError('read-only profile audit forbids credentials/history')
sys.addaudithook(audit)
def read(path):
    data=Path(path).read_bytes(); hashes[str(path)]=hashlib.sha256(data).hexdigest(); return data
spec=json.loads(read(ROOT/'spec.json')); quotes={}
for item in spec['captures']:
    if item['capture'] not in (243,245): continue
    data=json.loads(read(item['input'])); assert hashes[item['input']]==item['input_sha256']
    start=data['frames'][0]['received_at']; by_symbol=defaultdict(list)
    for f in data['frames']:
        if f['type']=='quote': by_symbol[f['symbol']].append((f['received_at']-start,f))
    quotes[item['capture']]=by_symbol
rows={}
for phase in ('baseline','candidate'):
    rows[phase]={ (r['capture'],r['displayed_depth_fraction'],r['basket_enabled']):r for line in read(ROOT/phase/'results.jsonl').decode().splitlines() if (r:=json.loads(line))['rtt_seconds']==1.}
    meta=json.loads(read(ROOT/phase/'metadata.json'))
    assert meta['candidate_revision'].startswith('5832359')
def latest_quote(capture,symbol,at):
    q=quotes[capture][symbol]; i=bisect.bisect_right([v[0] for v in q],at)-1
    assert i>=0; t,f=q[i]
    assert all(type(f[k]) in (int,float) and math.isfinite(f[k]) for k in ('bid','ask','bid_size','ask_size')) and 0<f['bid']<=f['ask']
    return t,f
def category(item,phase):
    r=item['request']; s=item['stack']; funcs=[v['function'] for v in s]
    rec=next((v['line'] for v in s if v['function']=='reconcile_stop'),None)
    if 'final_receipt' in funcs:return 'final_receipt'
    if '__init__' in funcs:return 'constructor'
    if r['path'].startswith('/orderbook/'):return 'book'
    if r['method']=='POST':return 'closing_POST'
    if 'send' in funcs and 'scope_ok' in funcs:return 'send_scope'
    if rec in (549,550,558,559):return 'outer_checks'
    if rec in ((601,602) if phase=='baseline' else (614,615)):return 'final_tail_checks'
    if rec in ((582,583) if phase=='baseline' else (581,582)):return 'symbol_checks'
    if rec==(595 if phase=='baseline' else 608) and 'refresh' in funcs:return 'acknowledgement_refresh'
    if rec in ((597,598) if phase=='baseline' else (610,611)):return 'post_order_checks'
    if phase=='candidate' and rec==595 and r['path'].startswith('/positions'):return 'post_book_positions'
    raise AssertionError((phase,item))
settings=[(243,1.,True),(243,.5,False),(243,.5,True),(245,1.,False)]
report={'scope':'read-only analysis of completed profiles; no replay or alternative runtime execution','scenarios':[]}
for capture,depth,basket in settings:
    name=f'capture-{capture}-1.0-{depth}-{int(basket)}'; pair={'directory':name,'capture':capture,'depth':depth,'basket':basket}
    for phase in ('baseline','candidate'):
        row=rows[phase][capture,depth,basket]; profile=ROOT/phase/name/'cleanup-profile.json'; arr=json.loads(read(profile))
        assert hashes[str(profile)]==row['journal_sha256']['cleanup-profile.json']
        reqs=[v['request'] for v in arr]; start=reqs[0]['started_at']; stop=reqs[-1]['completed_at']
        assert start==row['cleanup_started_at'] and stop==row['cleanup_completed_at']
        counts=Counter(category(x,phase) for x in arr); counts['post_book_positions']+=0
        assert sum(counts.values())==len(reqs)
        gaps=[(reqs[i-1]['completed_at'],reqs[i]['started_at']) for i in range(1,len(reqs)) if reqs[i]['started_at']>reqs[i-1]['completed_at']]
        assert all(b-a==1. for a,b in gaps) and all(r['completed_at']-r['started_at']==1. for r in reqs)
        assert stop-start==len(reqs)+len(gaps)
        trades={t['trade_id']:t for r in reqs if r['path'].startswith('/trades') for t in r['response']['trades'] if float(t['executed_at'])>=start}
        fills=defaultdict(list)
        for t in trades.values():fills[t['symbol']].append(t)
        books=[]; orders=[]; recent={}; deletes=[]
        for r in reqs:
            if r['method']=='DELETE':deletes.append(r)
            if r['path'].startswith('/orderbook/'):
                symbol=r['path'].split('/')[2].split('?')[0]; qt,q=latest_quote(capture,symbol,r['executed_at'])
                book={'symbol':symbol,'executed_at':r['executed_at'],'bids':r['response']['bids'],'asks':r['response']['asks'],'latest_capture_quote_at':qt,'captured_quote_age':r['executed_at']-qt,'last_bid_size':q['bid_size'],'last_ask_size':q['ask_size']}
                book['empty']=not book['bids'] and not book['asks']
                if book['empty']: assert book['captured_quote_age']>5 and q['bid_size']>0 and q['ask_size']>0
                books.append(book); recent[symbol]=book
            if r['method']=='POST':
                assert r['path']=='/orders'; b=r['body']; symbol=b['symbol']; book=recent[symbol]
                book_age=r['executed_at']-book['executed_at']; assert book_age==(9 if phase=='baseline' else 4)
                qt,q=latest_quote(capture,symbol,r['executed_at']); status=r['response']['status']
                if status=='pending':
                    assert r['executed_at']-qt>5
                    assert (b['price']>=q['ask'] if b['side']=='buy' else b['price']<=q['bid'])
                ts=sorted(fills[symbol],key=lambda t:float(t['executed_at'])); qty=sum(t['quantity'] for t in ts); gross=sum(t['price']*t['quantity'] for t in ts)
                assert qty==b['quantity']
                orders.append({'symbol':symbol,'side':b['side'],'quantity':qty,'limit':b['price'],'post_executed_at':r['executed_at'],'ack_status':status,'book_sample_age':book_age,'sampled_capture_quote_age_at_post':r['executed_at']-book['latest_capture_quote_at'],'newest_quote_age_at_post':r['executed_at']-qt,'fills':ts,'first_fill_at':float(ts[0]['executed_at']),'last_fill_at':float(ts[-1]['executed_at']),'vwap':gross/qty,'cash_flow':gross*(1 if b['side']=='sell' else -1)})
        assert not deletes and not any(row['server_positions_after_final_receipt'].values()) and row['cleanup']['state']=='flat'
        pair[phase]={'elapsed':stop-start,'requests':len(reqs),'sleep_seconds':len(gaps),'outer_passes':counts['outer_checks']//12,'symbol_checks':counts['symbol_checks']//6,'ack_refreshes':counts['acknowledgement_refresh']//4,'request_categories':dict(sorted(counts.items())),'empty_books':sum(b['empty'] for b in books),'books':books,'orders':orders,'cleanup_fills':len(trades),'cash_flow':sum(o['cash_flow'] for o in orders),'pnl':row['terminal_settlement_pnl'],'last_fill_at':max(o['last_fill_at'] for o in orders),'cleanup_completed_at':stop}
    b,c=pair['baseline'],pair['candidate']; assert len(b['orders'])==len(c['orders'])
    delta={k:c['request_categories'].get(k,0)-b['request_categories'].get(k,0) for k in set(c['request_categories'])|set(b['request_categories'])}
    delta['sleep_seconds']=c['sleep_seconds']-b['sleep_seconds']
    assert sum(delta.values())==c['elapsed']-b['elapsed']
    pair['elapsed_delta']=c['elapsed']-b['elapsed']; pair['elapsed_delta_components']={k:v for k,v in sorted(delta.items()) if v}
    pair['pnl_delta']=c['pnl']-b['pnl']; assert math.isclose(pair['pnl_delta'],c['cash_flow']-b['cash_flow'],abs_tol=1e-8)
    bc={o['symbol']:o['cash_flow'] for o in b['orders']}; cc={o['symbol']:o['cash_flow'] for o in c['orders']}
    pair['pnl_delta_by_symbol']={s:round(cc[s]-bc[s],8) for s in bc}
    report['scenarios'].append(pair)
report['input_sha256']=hashes; report['forbidden_attempts']=forbidden
report['alternative_runs']=0
(OUT/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
lines=['# Independent cleanup profile audit','', 'Scope: four completed scenario pairs only. No runtime/replay execution, source edits, network, credentials, downloaded history, or future246 data.', '', '| Scenario | Elapsed seconds | Requests | Sleep seconds | Outer passes | Books (empty) | Added positions GETs | Closing orders | P&L change |', '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
for p in report['scenarios']:
    b,c=p['baseline'],p['candidate']; label=f"{p['capture']}, {'full' if p['depth']==1 else 'half'} depth, basket {'on' if p['basket'] else 'off'}"
    lines.append(f"| {label} | {b['elapsed']:.0f} → {c['elapsed']:.0f} | {b['requests']} → {c['requests']} | {b['sleep_seconds']} → {c['sleep_seconds']} | {b['outer_passes']} → {c['outer_passes']} | {len(b['books'])} ({b['empty_books']}) → {len(c['books'])} ({c['empty_books']}) | {c['request_categories']['post_book_positions']} | {len(b['orders'])} → {len(c['orders'])} | ${p['pnl_delta']:+.2f} |")
lines+=['','## Exact duration decomposition','', 'All requests take1 second and all gaps are1-second cleanup sleeps. Components below sum exactly to each duration change.']
for p in report['scenarios']:
    lines+=['',f"- {p['directory']}: {p['elapsed_delta']:+.0f}s = "+', '.join(f'{k} {v:+}' for k,v in p['elapsed_delta_components'].items())+'.']
lines+=['','## Book age and fill behavior','', 'All32 baseline closing POSTs use books sampled9 seconds earlier; all32 candidate POSTs use books sampled4 seconds earlier. This measures REST book sampling to POST execution, not age of the underlying captured quote. Captured quotes can already be almost5 seconds old at the book read.', '', 'Every empty book in these eight profiles corresponds to the latest captured quote being older than5 seconds, with positive recorded bid/ask sizes. The replay freshness rule therefore explains the empty response. This does not establish absent liquidity in the actual exchange.', '', 'All16 initially pending acknowledgements across both phases encounter a newest captured quote older than5 seconds at POST execution, despite a marketable limit against the latest recorded touch. They fill on later quotes. Filled/partial acknowledgements trigger an additional four-request account refresh inside place(); pending acknowledgements do not. These changes in acknowledgement state explain the acknowledgement-refresh duration components.', '', 'No pair adds a closing order or cancellation. Each target symbol receives one closing order, possibly filled in multiple pieces. All four candidate and baseline accounts finish flat.']
lines+=['','## Mechanism highlights','', '-243/full/on: one additional stale-book visit plus12 added position checks and one additional acknowledgement refresh produce+23s. AQUA and GRID move to a later pass; RECON closes earlier. P&L improves$36.56 despite slower cleanup.', '-243/half/off: six empty-book reads replace five; PORT still working during a later per-symbol reconciliation causes one extra check without a book. REBLD becomes the late residual and fills at2705.012272, versus2587.858992. Net duration+23s; P&L−$7.19.', '-243/half/on: PORT reads are empty at2297.5,2478.5,2499.5,2520.5; it finally submits at2545.5, versus2300.5 baseline. The fifth pass and final check add time. PORT fill VWAP rises99.50→100.61 for20 units, costing$22.20; all other symbols together improve$1.08, leaving−$21.12 overall.', '-245/full/off: FERRY moves from five book reads to one, posting at2503.5 instead of2635.5. Outer passes fall5→3, offsetting8 new position GETs. FERRY closes128.722778s earlier; HAVEN closes76.106025s later and becomes the final fill. Duration improves54s, but FERRY costs$8.00 and HAVEN$9.75 relative to baseline, totaling−$17.75.', '', '## Narrow next hypothesis','', 'Separately predeclare testing whether an empty/invalid book can be rejected before the new post-book positions GET, while preserving full position-vector validation and all submission guards for every prospective POST. The candidate currently pays3,6,4,2 such GETs on empty books in these four scenarios. Their direct cost is only1 second each here; this cannot by itself explain or promise to reverse the52-second worst-case regression. Subsequent sampling times and fills would change, so no P&L improvement is inferred. This audit ran no such alternative.', '', 'The evidence supports rejecting production promotion of this completed candidate. The proposed follow-up is a diagnostic hypothesis, not approval to loosen freshness checks, change retry limits, or activate live trading.', '', 'Detailed times, fills, cash decomposition, request categories and all input SHA256s are in analysis.json.']
(OUT/'report.md').write_text('\n'.join(lines)+'\n')
for p in report['scenarios']:print(p['directory'],p['elapsed_delta'],p['elapsed_delta_components'],'pnl_delta',round(p['pnl_delta'],2))
print(json.dumps({'output':str(OUT),'profile_pairs':len(settings),'all_POST_book_ages_verified':64,'forbidden_attempts':forbidden,'alternative_runs':0}))
