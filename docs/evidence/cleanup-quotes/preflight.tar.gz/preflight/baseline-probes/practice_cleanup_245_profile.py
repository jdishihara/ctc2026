import os,sys,json,pathlib,hashlib,math,tempfile,collections
from unittest.mock import patch
ROOT=pathlib.Path('/Users/arjunhans/Documents/ctc2026');W=ROOT/'.worktrees/practice-history'; V2=ROOT/'recordings/consistency-20261024/supervised-forward/a7e77935-0ddd-4c77-8ce9-5494a9941962/attempt-01/supervised'; CACHE=pathlib.Path('/var/folders/5_/4_9w4ch971l2mm9c6fqtg5400000gn/T/practice-245-independent-input-or60g0fo')
forbidden=[]
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
  forbidden.append(event);raise RuntimeError('external network forbidden')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=os.fsdecode(args[0]).lower()
  if '.botkey' in p or '/.env' in p or '/data/history/' in p or 'credentials' in p:
   forbidden.append(p);raise RuntimeError('credential or downloaded history access forbidden')
sys.addaudithook(audit)
sys.path.insert(0,str(W))
from scripts import replay_practice_supervisor as replay
from bot import practice
from ctc.strategies import FairValueTrader
from dataclasses import asdict
case=json.loads((W/'data/case.json').read_text()); meta=json.loads((V2/'metadata.json').read_text())
expected={(r['capture'],r['rtt_seconds'],r['displayed_depth_fraction'],r['basket_enabled']):r for line in (V2/'results.jsonl').read_text().splitlines() if (r:=json.loads(line))}
sourcehashes={n:hashlib.sha256((pathlib.Path(n) if pathlib.Path(n).is_absolute() else W/n).read_bytes()).hexdigest() for n in meta['source_sha256']}
assert sourcehashes==meta['source_sha256']
cases=[(245,1.,1.,False)]
out=pathlib.Path(tempfile.mkdtemp(prefix='practice-cleanup-245-profile-')); results=[]; active={}; quote_callbacks=[0]; live_posts=[0]; settlement_reads=[0]
OriginalServer=replay.PracticeReplayServer; OriginalSession=practice.PracticeSession
class RecordingServer(OriginalServer):
 def __init__(self,*a,**kw):
  super().__init__(*a,**kw);active['server']=self;self.profile=[]
 def request(self,*a,**kw):
  frame=sys._getframe(1);stack=[]
  while frame:
   if frame.f_code.co_filename.endswith(('/bot/practice.py','/bot/live.py')):
    stack.append(dict(file=pathlib.Path(frame.f_code.co_filename).name,function=frame.f_code.co_name,line=frame.f_lineno))
   frame=frame.f_back
  started=self.now;response=super().request(*a,**kw)
  self.profile.append(dict(start=started,end=self.now,args=a,kwargs=kw,stack=stack,request=dict(self.requests[-1])))
  return response
class RecordingSession(OriginalSession):
 def __init__(self,*a,**kw):
  super().__init__(*a,**kw);active['session']=self;self.independent_wait_events=[]
 def _news(self,message):
  before=self.waiting_for_weather
  super()._news(message)
  after=self.waiting_for_weather
  if before!=after:
   self.independent_wait_events.append(dict(at=self.ex.t,type=message.get('type'),seq=message.get('seq'),round=self.strat.model.round,age=message.get('age'),waiting=after is not None,ready=self.strat.model.live_history_ready,complete=self.news_complete,reports=sorted(self.strat.model.reported_rounds),stop=self.journal.stop_reason))
  if self._valid_weather_wait():
   assert not self.strat.model.live_history_ready and not self.submission_allowed(tuple(self.ex.symbols))
class GuardedSettlement(dict):
 def _check(self):
  server=active['server'];settlement_reads[0]+=1
  assert server.terminal and not server.market.market_open and server.now>=server.settlement_available_at,('premature settlement',server.now)
 def __getitem__(self,key):self._check();return super().__getitem__(key)
 def get(self,key,*default):self._check();return super().get(key,*default)
 def items(self):self._check();return super().items()
 def values(self):self._check();return super().values()
original_quotes=FairValueTrader.on_quotes
original_send=replay.ServerTransport.send
def checked_quotes(self,exchange):
 quote_callbacks[0]+=1
 assert self.competition_id==exchange.competition_id and isinstance(self.competition_id,str) and self.competition_id.strip()
 model=self.model; reports=set(model.reported_rounds); ready=model.live_history_ready
 result=original_quotes(self,exchange)
 assert self.model is model and self.model.reported_rounds==reports and self.model.live_history_ready==ready
 return result
def checked_send(self,method,path,body=None):
 if method=='POST' and isinstance(self,replay.OfflinePracticeExchange):
  live_posts[0]+=1;session=active['session']
  assert not session._valid_weather_wait() and session.strat.model.live_history_ready
  assert session.competition_id==self.competition_id==session.strat.competition_id
 return original_send(self,method,path,body)
with patch.object(replay,'PracticeReplayServer',RecordingServer),patch.object(practice,'PracticeSession',RecordingSession),patch.object(FairValueTrader,'on_quotes',checked_quotes),patch.object(replay.ServerTransport,'send',checked_send):
 for k in cases:
  active.clear();c,rtt,depth,basket=k;data=json.loads((CACHE/f'{c}.json').read_text());inp=data['meta'];receipt=data['receipt'];frames=data['frames'];directory=out/f'capture-{c}-{rtt}-{depth}-{int(basket)}'
  assert hashlib.sha256(json.dumps(frames,sort_keys=True,allow_nan=False).encode()).hexdigest()==next(m for m in meta['captures'] if m['capture']==c)['frames_sha256']
  result=replay.replay_supervised(case,frames,str(2027-c),receipt['competition_id'],GuardedSettlement(receipt['prices']),receipt_at=receipt['at'],out=directory,rtt=rtt,depth_scale=depth,basket=basket)
  original=expected[k];want={name:value for name,value in original.items() if name not in ('capture','comparison_status')}
  assert result==want,(k,[name for name in set(result)|set(want) if result.get(name)!=want.get(name)])
  original_dir=V2/directory.name
  for name in ['observations.json','actions.jsonl','status.json','final-receipt.json','startup-feed.jsonl','result.json','run.lock']:
   assert (directory/name).read_bytes()==(original_dir/name).read_bytes(),(k,name)
  server=active['server'];events=active['session'].independent_wait_events
  cleanup_profile=[p for p in server.profile if p['start']>=result['cleanup_started_at'] and p['end']<=result['cleanup_completed_at']]
  (directory/'cleanup-request-profile.json').write_text(json.dumps(cleanup_profile,indent=2)+'\n')
  assert not server.fatal_errors
  transitions=[e for e in events if e['waiting']]
  for e in transitions:assert e['complete'] and not e['ready'] and not e['stop'] and e['reports']==list(range(1,e['round']))
  closes=[e for e in events if not e['waiting']]
  for e in closes:assert e['type']=='storm' and e['age']==0 and e['ready'] and not e['stop'],e
  fills=[asdict(f) for f in server.market.fills]
  stop_fills=[f for f in fills if f.get('t',-1)>=result['stop_at']]
  entry=dict(setting=k,pnl=result['terminal_settlement_pnl'],trial=result['trial_state'],cleanup=result['cleanup']['state'],wait_events=events,stop_at=result['stop_at'],monitor_detected_at=result['monitor_detected_at'],cleanup_started_at=result['cleanup_started_at'],cleanup_completed_at=result['cleanup_completed_at'],fills_after_stop=stop_fills)
  results.append(entry);print(json.dumps(dict(setting=k,pnl=entry['pnl'],trial=entry['trial'],cleanup=entry['cleanup'],wait_transitions=len(transitions),verified='all fields and seven files exact')),flush=True)
assert not forbidden
assert all(hashlib.sha256((pathlib.Path(n) if pathlib.Path(n).is_absolute() else W/n).read_bytes()).hexdigest()==v for n,v in sourcehashes.items())
proof=dict(cases=results,quote_callbacks=quote_callbacks[0],strategy_posts=live_posts[0],guarded_settlement_reads=settlement_reads[0],forbidden_attempts=forbidden,sources_unchanged=True)
(out/'independent-audit.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(dict(audit_path=str(out/'independent-audit.json'),count=len(results),quote_callbacks=quote_callbacks[0],strategy_posts=live_posts[0],guarded_settlement_reads=settlement_reads[0],forbidden_attempts=forbidden)),flush=True)
