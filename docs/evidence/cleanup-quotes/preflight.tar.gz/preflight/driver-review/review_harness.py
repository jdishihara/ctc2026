from __future__ import annotations
import ast, copy, hashlib, importlib.util, json, math, os, subprocess, sys
from collections.abc import Mapping
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
ROOT=Path(sys.argv[1]); OUT=Path(sys.argv[2]); DRIVER=ROOT/'scripts/compare_cleanup_quotes.py'
forbidden=[]
def offline_audit(event, args):
    if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
        forbidden.append(event); raise RuntimeError('synthetic review forbids network')
    if event=='open' and isinstance(args[0], (str,bytes,os.PathLike)):
        name=os.fsdecode(args[0]).lower()
        if '.botkey' in name or '/.env' in name or '/data/history/' in name or 'credentials' in name:
            forbidden.append(name); raise RuntimeError('synthetic review forbids credentials/history')
sys.addaudithook(offline_audit)
source=DRIVER.read_text(); tree=ast.parse(source); main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
spec=importlib.util.spec_from_file_location('reviewed_cleanup_driver', DRIVER)
driver=importlib.util.module_from_spec(spec); spec.loader.exec_module(driver)
checks=[]
def passed(name):
    checks.append(name); print('PASS: '+name,flush=True)
class FakeServer:
    def __init__(self):
        self.fatal_errors=[]; self.terminal=False; self.now=0.; self.settlement_available_at=100.; self.market=SimpleNamespace(market_open=True)
    def latch(self,exc): self.fatal_errors.append(f'{type(exc).__name__}: {exc}')
class FakePractice: pass
class FakeCleanup: pass
server=FakeServer()
active={'server':server}
ns={'Mapping':Mapping, 'active':active, 'replay':SimpleNamespace(OfflinePracticeExchange=FakePractice,OfflineCleanupExchange=FakeCleanup), 'original_send':lambda *a: {'sent':True}}
selected=[n for n in main.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in {'enforce','GuardedSettlement','checked_send','checked_quotes'}]
exec(compile(ast.fix_missing_locations(ast.Module(body=selected,type_ignores=[])),str(DRIVER),'exec'),ns)
g=ns['GuardedSettlement']({'SYNTHETIC':123})
reads={'item':lambda:g['SYNTHETIC'],'get':lambda:g.get('SYNTHETIC'),'items':lambda:list(g.items()),'values':lambda:list(g.values()),'dict':lambda:dict(g),'copy_method':lambda:g.copy(),'copy':lambda:copy.copy(g),'deepcopy':lambda:copy.deepcopy(g)}
for name,fn in reads.items():
    before=len(server.fatal_errors)
    try: fn()
    except AssertionError: assert len(server.fatal_errors)==before+1
    else: raise AssertionError(f'{name} leaked prices')
    passed('premature settlement '+name+' rejected and latched')
assert '123' not in repr(g)
server.terminal=True; server.market.market_open=False; server.now=100.
for fn in reads.values(): fn()
assert dict(g)=={'SYNTHETIC':123}
passed('all settlement operations succeed only at terminal availability; repr excludes prices')
# Exercise the actual production exception-swallowing cleanup path with dummy state.
sys.path.insert(0,str(ROOT)); from bot import practice
exchange=FakeCleanup(); exchange.position={'SYNTHETIC':5}; exchange.state_ready=False; exchange.market_open=True; exchange.open_orders={}; exchange.expected_id=exchange.competition_id='synthetic'
journal=practice.Journal(OUT/'synthetic-finish',seasons=1)
journal.exchange=SimpleNamespace(close=lambda:None)
server.fatal_errors.clear()
with patch.object(practice,'reconcile_stop',lambda *a:ns['checked_send'](exchange,'POST','/orders',{'symbol':'SYNTHETIC','side':'sell','quantity':5})), patch.object(practice,'final_receipt',lambda *a:None):
    practice.finish(journal)
assert server.fatal_errors and journal.latest['cleanup']['state']=='attention'
passed('actual production finish catches guard exception but fatal latch survives')
# Quote callbacks cannot mutate the captured model/history state unnoticed.
for mode in ('identity','model','reports','ready'):
    server.fatal_errors.clear()
    model=SimpleNamespace(reported_rounds={1}, live_history_ready=True)
    strategy=SimpleNamespace(competition_id='synthetic',model=model)
    ex=SimpleNamespace(competition_id='wrong' if mode=='identity' else 'synthetic')
    def changed(s,e):
        if mode=='model': s.model=SimpleNamespace(reported_rounds={1},live_history_ready=True)
        if mode=='reports': s.model.reported_rounds.add(2)
        if mode=='ready': s.model.live_history_ready=False
    ns['original_quotes']=changed
    try: ns['checked_quotes'](strategy,ex)
    except AssertionError: assert server.fatal_errors
    else: raise AssertionError('unchecked quote '+mode)
    passed('quote guard '+mode+' failure latched')
# Execute the exact candidate prerequisite AST against a complete synthetic 80-row baseline.
gate=next(n for n in main.body if isinstance(n,ast.If) and ast.unparse(n.test)=="args.phase == 'candidate'")
gate_code=compile(ast.fix_missing_locations(ast.Module(body=[gate],type_ignores=[])),str(DRIVER),'exec')
baseline=OUT/'synthetic-baseline'; baseline.mkdir()
rows=[]
for capture,rtt,depth,basket in driver.GRID:
    directory=baseline/f'capture-{capture}-{rtt}-{depth}-{int(basket)}'; directory.mkdir()
    hashes={}
    for name in driver.JOURNALS+['cleanup-profile.json']:
        p=directory/name; p.write_text('synthetic '+name+'\n'); hashes[name]=driver.digest(p)
    rows.append(dict(capture=capture,rtt_seconds=rtt,displayed_depth_fraction=depth,basket_enabled=basket,status='ok',errors=[],comparison_status='exact_archive',journal_sha256=hashes))
prior=dict(phase='baseline',source_sha256={'synthetic':'sha'},spec={'synthetic':True},candidate_revision='synthetic-revision',started_at=1.)
(baseline/'metadata.json').write_text(json.dumps(prior))
base_summary=dict(runs=80,errors=0,changed_sources=[],forbidden_attempts=[],finished_at=2.)
def write_case(case_rows=rows, changes=None):
    (baseline/'results.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in case_rows))
    summary={**base_summary,'results_sha256':driver.digest(baseline/'results.jsonl'),**(changes or {})}
    (baseline/'summary.json').write_text(json.dumps(summary))
def check_gate():
    env={'args':SimpleNamespace(phase='candidate',baseline=baseline), 'json':json, 'math':math, 'source_hashes':{'synthetic':'sha'},'spec':{'synthetic':True},'candidate_revision':'synthetic-revision','GRID':driver.GRID,'JOURNALS':driver.JOURNALS,'digest':driver.digest,'row_key':driver.row_key,'baseline_rows':{},'baseline_hashes':{},'metadata':{}}
    exec(gate_code,env)
    return env
write_case(); env=check_gate(); assert len(env['baseline_hashes'])==643
passed('complete 80-row prerequisite accepted and all 643 produced files bound')
mutations={
'forbidden attempt':(rows,{'forbidden_attempts':['socket.connect']}),
'duplicate raw row':(rows+[rows[0]],{}),
'error status':([{**rows[0],'status':'error'}]+rows[1:],{}),
'row errors':([{**rows[0],'errors':['synthetic']}]+rows[1:],{}),
'wrong comparison':([{**rows[0],'comparison_status':'failed'}]+rows[1:],{}),
'missing completion':(rows,{'finished_at':None}),
'nonfinite completion':(rows,{'finished_at':float('nan')}),
'completion before start':(rows,{'finished_at':0.}),
'boolean completion':(rows,{'finished_at':True}),
'journal tampering':([{**rows[0],'journal_sha256':{**rows[0]['journal_sha256'],'status.json':'bad'}}]+rows[1:],{}),
}
for name,(case_rows,changes) in mutations.items():
    write_case(case_rows,changes)
    try: check_gate()
    except AssertionError: pass
    else: raise AssertionError('accepted '+name)
    passed('baseline prerequisite rejects '+name)
write_case()
# Optimization must fail before trying to read the nonexistent spec or create output.
cmd=[sys.executable,'-B','-O',str(DRIVER),'--phase','candidate','--spec',str(OUT/'does-not-exist.json'),'--out',str(OUT/'must-not-be-created')]
r=subprocess.run(cmd,capture_output=True,text=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
(OUT/'optimization.stderr').write_text(r.stderr)
assert r.returncode!=0 and 'requires Python assertions enabled' in r.stderr
assert 'FileNotFoundError' not in r.stderr and not (OUT/'must-not-be-created').exists()
passed('actual -O CLI exits before spec read or output creation')
assert not forbidden
report={'driver_sha256':hashlib.sha256(source.encode()).hexdigest(),'plan_sha256':driver.digest(ROOT/'docs/cleanup-quote-plan.md'),'checks_passed':checks,'checks_count':len(checks),'forbidden_attempts':forbidden,'captured_market_performance_runs':0,'scope':'read-only driver review using synthetic values and baseline artifacts only'}
(OUT/'review-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'driver_sha256':report['driver_sha256'],'output':str(OUT)}))
