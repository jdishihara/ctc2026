from pathlib import Path
import tarfile,tempfile
out=Path(tempfile.mkdtemp(prefix='repeat-blend247-preflight-'))
arc=Path('/Users/arjunhans/Documents/ctc2026/out/repeat-blend-v1-20261024/preflight-review.tar.gz')
with tarfile.open(arc) as t:s=t.extractfile('capture_probe.py').read().decode()
s=s.replace(".worktrees/repeat-blend'",".worktrees/repeat-blend-247'").replace('scripts/compare_repeat_blend.py','scripts/compare_repeat_blend_247.py').replace('docs/repeat-blend-plan.md','docs/repeat-blend-247-plan.md').replace('range(241,247)','[247]').replace('==96','==16').replace('rows=96','rows=16').replace('96-row','16-row')
s=s.replace('attack=False',"attack=None")
s=s.replace(" def on_quotes(self,exchange):return None"," def on_quotes(self,exchange):\n  if calls==1 and attack=='quote_history':self.model.live_history_ready=False\n  return None")
s=s.replace("replay.OfflinePracticeExchange=type('UnusedPractice',(),{});replay.OfflineCleanupExchange=type('UnusedCleanup',(),{})", "replay.OfflinePracticeExchange=type('SyntheticPractice',(FakeTransport,),{});replay.OfflineCleanupExchange=type('SyntheticCleanup',(FakeTransport,),{})")
s=s.replace("server=replay.PracticeReplayServer();practice.PracticeSession();trader=FakeTrader", "server=replay.PracticeReplayServer();session=practice.PracticeSession();trader=FakeTrader")
old=""" trader.on_quotes(SimpleNamespace(competition_id='synthetic'))
 trader.ensemble.weights([{'age':40}],[],[])
 if attack and calls==1:
  try:settlement['SYNTH']
  except AssertionError:pass
  else:raise AssertionError('early read did not fail')
"""
new=""" session.strat=trader;session.competition_id='synthetic';session._valid_weather_wait=lambda:False
 def reject(fn):
  try:fn()
  except AssertionError:pass
  else:raise AssertionError('guard '+str(attack)+' did not fail')
 if calls==1 and attack in ('quote_identity','quote_history'):
  reject(lambda:trader.on_quotes(SimpleNamespace(competition_id='wrong' if attack=='quote_identity' else 'synthetic')))
  trader.model.live_history_ready=True
 else:trader.on_quotes(SimpleNamespace(competition_id='synthetic'))
 trader.ensemble.weights([{'age':40}],[],[])
 if attack and calls==1:
  if attack in ('settlement_open','settlement_before_receipt','settlement_copy','settlement_shallow_copy','settlement_deep_copy'):
   if attack=='settlement_before_receipt':server.terminal=True;server.market.market_open=False;server.now=9.
   fn={'settlement_open':lambda:settlement['SYNTH'],'settlement_before_receipt':lambda:settlement['SYNTH'],'settlement_copy':settlement.copy,'settlement_shallow_copy':lambda:copy.copy(settlement),'settlement_deep_copy':lambda:copy.deepcopy(settlement)}[attack]
   reject(fn)
  elif attack.startswith('strategy_'):
   exchange=replay.OfflinePracticeExchange();exchange.competition_id='synthetic'
   if attack=='strategy_history':trader.model.live_history_ready=False
   if attack=='strategy_weather_wait':session._valid_weather_wait=lambda:True
   if attack=='strategy_identity':exchange.competition_id='wrong'
   reject(lambda:exchange.send('POST','/orders',{'symbol':'SYNTH','quantity':1,'side':'buy'}))
   trader.model.live_history_ready=True;session._valid_weather_wait=lambda:False
  elif attack.startswith('cleanup_'):
   exchange=replay.OfflineCleanupExchange();exchange.position={'SYNTH':1};exchange.state_ready=True;exchange.market_open=True;exchange.open_orders=[];exchange.expected_id=exchange.competition_id='synthetic'
   body={'symbol':'SYNTH','side':'sell','quantity':1}
   if attack=='cleanup_unready':exchange.state_ready=False
   if attack=='cleanup_closed':exchange.market_open=False
   if attack=='cleanup_working_order':exchange.open_orders=[{}]
   if attack=='cleanup_identity':exchange.expected_id='wrong'
   if attack=='cleanup_side':body['side']='buy'
   if attack=='cleanup_quantity':body['quantity']=2
   if attack=='cleanup_zero':body['quantity']=0
   reject(lambda:exchange.send('POST','/orders',body))
"""
assert old in s;s=s.replace(old,new)
s=s.replace('guard_attack=False','guard_attack=None').replace('int(guard_attack)','int(bool(guard_attack))')
start=s.index("base=OUT/'capture-baseline-synthetic-results'")
s=s[:start]+"""base=OUT/'capture-baseline-synthetic-results';cand=OUT/'capture-candidate-synthetic-results'
checks=[phase('baseline',base),phase('candidate',cand,base)]
for mode in ['settlement_open','settlement_before_receipt','settlement_copy','settlement_shallow_copy','settlement_deep_copy','quote_identity','quote_history','strategy_history','strategy_weather_wait','strategy_identity','cleanup_unready','cleanup_closed','cleanup_working_order','cleanup_identity','cleanup_side','cleanup_quantity','cleanup_zero']:
 checks.append(phase('candidate',OUT/('capture-guard-'+mode),base,mode))
main_rejections=[]
original_spec=specpath.read_bytes()
def prerequisite(name,mutate,restore):
 global calls
 calls=0;target=OUT/('prerequisite-'+name)
 mutate()
 argv=[str(path),'--phase','baseline','--spec',str(specpath),'--out',str(target)]
 replay.__file__=str(frozen/'scripts/replay_practice_supervisor.py')
 try:
  with patch.dict(sys.modules,mods),patch.object(driver.subprocess,'check_output',fake_git),patch.object(driver,'runtime_files',lambda root:sorted([root/'data/case.json',root/'ctc/analog.py'])),patch.object(driver.sys,'argv',argv),contextlib.redirect_stdout(io.StringIO()):
   try:driver.main()
   except AssertionError:pass
   else:raise RuntimeError('invalid prerequisite accepted '+name)
  assert calls==0 and not target.exists() and parameters=={'unchanged_parameter':'sentinel'}
 finally:restore()
 main_rejections.append(dict(probe=name,rejected_before_replay_and_output=True))
def wrongcapture():
 v=json.loads(original_spec);v['captures'][0]['capture']=248;specpath.write_text(json.dumps(v))
prerequisite('wrong_capture248',wrongcapture,lambda:specpath.write_bytes(original_spec))
archive=Path(items[0]['archive']);original_rows=(archive/'results.jsonl').read_bytes();original_summary=(archive/'summary.json').read_bytes()
def missinggrid():
 rr=[json.loads(x) for x in original_rows.splitlines()];rr.pop();(archive/'results.jsonl').write_text(''.join(json.dumps(x)+'\\n' for x in rr))
 ss=json.loads(original_summary);ss['results_sha256']=sha(archive/'results.jsonl');(archive/'summary.json').write_text(json.dumps(ss))
 v=json.loads(original_spec);v['captures'][0]['archive_sha256']={n:sha(archive/n) for n in ('metadata.json','results.jsonl','summary.json')};specpath.write_text(json.dumps(v))
def restoregrid():
 (archive/'results.jsonl').write_bytes(original_rows);(archive/'summary.json').write_bytes(original_summary);specpath.write_bytes(original_spec)
prerequisite('missing_archive_setting',missinggrid,restoregrid)
assert not forbidden
report=dict(driver_sha256=hashlib.sha256(source).hexdigest(),checks=checks,main_prerequisite_rejections=main_rejections,forbidden_outer_attempts=forbidden,actual_history_reads=0,actual_performance_runs=0,synthetic_success_rows=32,synthetic_fault_rows=17*16,notes=['Only synthetic inputs and deterministic replay stubs; no captured-market simulations.','The actual main executes all16 settings and restores parameters on success and latched-guard failure.','All17 swallowed guard attacks remain fatal in their first row, retain the other15 outcomes and exit1.'])
(OUT/'capture-probe.json').write_text(json.dumps(report,indent=2)+'\\n');print(json.dumps(report,indent=2))
"""
(out/'capture_probe.py').write_text(s)
s=Path('/var/folders/5_/4_9w4ch971l2mm9c6fqtg5400000gn/T/repeat-prefix-preflight-9j04zr1w/probe_gate.py').read_text()
s=s.replace(".worktrees/repeat-prefix'",".worktrees/repeat-blend-247'").replace('scripts/compare_repeat_prefix.py','scripts/compare_repeat_blend_247.py').replace('runs=96','runs=16').replace('valid96','valid16').replace('duplicate97','duplicate17').replace('duplicate_within96','duplicate_within16').replace('missing95','missing15').replace('unexpected_capture247','unexpected_capture248').replace('update(capture=247)','update(capture=248)').replace('missing_capture246','missing_capture247').replace("x['capture'] != 246","x['capture'] != 247")
s=s.replace("    probe('valid16', expect_accept=True)","    probe('valid16', expect_accept=True)\n    probe('wrong_phase', lambda p,r,s:p.update(phase='candidate'))\n    probe('summary_error', lambda p,r,s:s.update(errors=1))")
s=s.replace("print('GATE_SUMMARY '","(Path(__file__).resolve().parent/'gate-probe.json').write_text(json.dumps(dict(checks=results,valid_accepted=sum(r['accepted'] for r in results),corruptions_rejected=sum(not r['accepted'] for r in results)),indent=2)+'\\n')\nprint('GATE_SUMMARY '")
# Reuse the enclosing no-network/no-real-input audit hook before importing the driver.
guard=s[s.index('import ast'):s.index('ROOT = Path(')]
addition="""import os,sys
forbidden=[]
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
  forbidden.append(event);raise RuntimeError('network forbidden')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=os.fsdecode(args[0]).lower()
  if '/data/history/' in p or '/recordings/' in p or '.botkey' in p or '/.env' in p or 'credentials' in p:
   forbidden.append(p);raise RuntimeError('real inputs/credentials forbidden')
sys.addaudithook(audit)
"""
s=s.replace(guard,guard+addition)
(out/'probe_gate.py').write_text(s)
print(out)
