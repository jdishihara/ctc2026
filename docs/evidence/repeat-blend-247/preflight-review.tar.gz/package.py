"""Static equivalence verification and compact synthetic review evidence."""
import datetime, hashlib, importlib.util, json, os, pathlib, shutil, subprocess, sys, tarfile, tempfile
R=pathlib.Path('/Users/arjunhans/Documents/ctc2026');W=R/'.worktrees/repeat-blend-247';PRE=R/'.worktrees/repeat-blend'
T=pathlib.Path('/var/folders/5_/4_9w4ch971l2mm9c6fqtg5400000gn/T');RUN=T/'repeat-blend247-preflight-j7f2g3w3'
BASE='7a2fe81b1167bb1b355357b0d105ea91ed29cd05';HEAD='5f71c54a8f0ba9c90ad7e6af6b8b2a0f15291f78'
forbidden=[]
def guard(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
  forbidden.append(event);raise RuntimeError('network forbidden')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=os.fsdecode(args[0]).lower()
  if '/data/history/' in p or '/recordings/' in p or '.botkey' in p or '/.env' in p or 'credentials' in p:
   forbidden.append(p);raise RuntimeError('real inputs/credentials forbidden')
sys.addaudithook(guard)
def H(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def J(p):return json.loads(p.read_text())
def git(*args,cwd=W):return subprocess.check_output(['git',*args],cwd=cwd)
def cp(s,d):d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(s,d);assert H(s)==H(d)
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert git('rev-parse','HEAD',cwd=PRE).decode().strip()==BASE
assert git('status','--porcelain=v1').decode().strip()=='?? scripts/compare_repeat_blend_247.py'
original=git('show',BASE+':scripts/compare_repeat_blend.py').decode()
assert original==(PRE/'scripts/compare_repeat_blend.py').read_text()==(W/'scripts/compare_repeat_blend.py').read_text()
replacements=[('Guarded offline comparison for a fixed half-weight repeated-weather blend.','Guarded offline comparison for a fixed half-weight blend on closed capture 247.'),('all 96 archived','all 16 archived'),('range(241, 247)','[247]'),('list([247])','[247]'),('docs/repeat-blend-plan.md','docs/repeat-blend-247-plan.md')]
normalized=original
for a,b in replacements:normalized=normalized.replace(a,b)
path=W/'scripts/compare_repeat_blend_247.py';assert normalized==path.read_text()
plan=W/'docs/repeat-blend-247-plan.md';assert plan.read_bytes()==git('show',HEAD+':docs/repeat-blend-247-plan.md')
assert git('show','-s','--format=%ct',HEAD).decode().strip()=='1792835490'
assert git('diff','--name-only',BASE,HEAD).decode().splitlines()==['docs/repeat-blend-247-plan.md']
assert not git('diff','--check')
spec=importlib.util.spec_from_file_location('review_fixed247_driver',path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
runtime={}
for p in mod.runtime_files(W):
 rel=p.relative_to(W).as_posix();blob=git('show',BASE+':'+rel)
 assert p.read_bytes()==blob==(PRE/rel).read_bytes();runtime[rel]=H(p)
assert len(runtime)==28 and len(mod.GRID)==16 and {k[0] for k in mod.GRID}=={247}
a=J(RUN/'capture-probe.json');g=J(RUN/'gate-probe.json')
assert a['driver_sha256']==H(path) and not a['forbidden_outer_attempts'] and a['actual_history_reads']==a['actual_performance_runs']==0
assert len(a['checks'])==19 and len(a['main_prerequisite_rejections'])==2
assert sum(x['errors'] for x in a['checks'])==17
assert all(x['rows']==16 and x['parameters_restored'] and x['parameter_plumbing_exact'] and x['metadata_coefficient_exact'] for x in a['checks'])
assert g['valid_accepted']==1 and g['corruptions_rejected']==22 and len(g['checks'])==23
out=pathlib.Path(tempfile.mkdtemp(prefix='repeat-blend247-preflight-evidence-'))
for n in ['capture_probe.py','probe_gate.py','capture-probe.json','gate-probe.json','capture.stdout.log','capture.stderr.log','gate.stdout.log','gate.stderr.log']:
 cp(RUN/n,out/n)
for p in sorted(RUN.glob('capture-*.stdout.log')):cp(p,out/'synthetic-outputs'/p.name)
for p in sorted(RUN.glob('capture-*')):
 if p.is_dir() and (p/'summary.json').exists():
  for n in ['metadata.json','results.jsonl','summary.json']:cp(p/n,out/'synthetic-outputs'/p.name/n)
cp(path,out/'reviewed-driver.py');cp(plan,out/'reviewed-plan.md')
cp(pathlib.Path('/tmp/repeat_blend_247_preflight_setup.py'),out/'setup.py');cp(pathlib.Path(__file__),out/'package.py')
checks=dict(plan_declared_time_utc='2026-10-24T09:51:28+00:00',plan_commit_time_utc='2026-10-24T09:51:30+00:00',reviewed_head=HEAD,approved_base=BASE,driver_sha256=H(path),plan_sha256=H(plan),runtime_files=runtime,runtime_file_count=len(runtime),runtime_changes_from_approved_blend=[],source_equivalent_after_only_declared_substitutions=True,normalization_replacements=replacements,grid=[list(k) for k in mod.GRID],synthetic_main_success_rows=32,synthetic_main_fault_rows=272,synthetic_main_swallowed_guard_failures=17,synthetic_main_prerequisite_rejections=2,candidate_prerequisite_valid16_accepted=True,candidate_prerequisite_corruptions_rejected=22,parameter_restoration_verified_on_success_and_failure=True,guarded_forbidden_access_attempts=[],real_capture_inputs_read=0,real_history_inputs_read=0,performance_runs=0,model_retests=0,guard_attacks=[x['synthetic_guard_attack'] for x in a['checks'] if x['synthetic_guard_attack']],notes=['The wrong capture248 check changes a synthetic numeric identity only; no active input is accessed.','Original modeled behavior and698-test evidence are reused because all28 runtime files match the approved frozen source exactly.','Synthetic fixtures are reconstructable from included setup/probe scripts; compact archive retains every main result/metadata/summary and invocation log.','Plan requires all16 candidate outcomes positive/completed/settled, original risk gates, and explanation of every regression. Those outcome conditions await a separate frozen performance evaluation.'],verdict='Approve this exact driver/plan for freezing and the predeclared16-setting offline comparison. No approval of results or optional integration is given at preflight.',completed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
assert not forbidden and H(path)==a['driver_sha256'] and git('rev-parse','HEAD').decode().strip()==HEAD
(out/'review.json').write_text(json.dumps(checks,indent=2,sort_keys=True)+'\n')
files={str(p.relative_to(out)):H(p) for p in sorted(out.rglob('*')) if p.is_file()}
(out/'artifact-manifest.json').write_text(json.dumps({'count':len(files),'files':files},indent=2,sort_keys=True)+'\n')
arc=out.with_suffix('.tar.gz')
with tarfile.open(arc,'w:gz') as t:
 for p in sorted(out.rglob('*')):
  if p.is_file():t.add(p,arcname=str(p.relative_to(out)),recursive=False)
with tarfile.open(arc) as t:
 ms=t.getmembers();assert len(ms)==len(files)+1
 for m in ms:assert m.isfile() and t.extractfile(m).read()==(out/m.name).read_bytes()
print(json.dumps(dict(directory=str(out),archive=str(arc),archive_sha256=H(arc),archive_files=len(files)+1,review_sha256=H(out/'review.json'),driver_sha256=H(path),plan_sha256=H(plan),main_success_rows=32,main_fault_rows=272,latched_guard_attacks=17,main_prerequisite_rejections=2,prerequisite_corruptions_rejected=22,forbidden_attempts=forbidden,performance_runs=0)))
