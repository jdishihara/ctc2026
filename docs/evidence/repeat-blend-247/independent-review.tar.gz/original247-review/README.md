# Independent closed-capture 247 audit

Capture 247: CID `fd1ebff9-0f96-4533-b283-bc0a5c60cd4b`, fictional year 1780.
The official ready/ready receipt is timestamped `1792835136.260472`
(2026-10-24 09:45:36 UTC). No evaluator, strategy, root ledger or runtime was
modified. The audit uses only already-closed sealed inputs and the fitted NPZ;
network, credentials, downloaded history and model-manifest reads were blocked.

## Findings

No blocker was found in the reported result counts, provenance or reproduced
results. The unfavorable outcomes and attention states remain visible.

| Evaluation | Original rows | Negative / positive | Mean | Worst | Best |
| --- | ---: | ---: | ---: | ---: | ---: |
| Original fixed worker | 24 | 24 / 0 | −$690.89750 | −$799.84 | −$507.47 |
| Serialized core | 16 | 14 / 2 | −$400.598125 | −$738.46 | +$132.47 |
| Full supervisor | 16 | 15 / 1 | −$332.11375 | −$573.91 | +$15.36 |

The three supervisor-comparison phases add 48 rows: reference, baseline and
supervised, 16 each. There are **88 original evaluation rows** in total, with
repeated baseline comparisons, not 88 independent trials. The reference and
baseline match every serialized archived field; request and fill hashes also
match between reference and baseline. All three recorded phase exit statuses
are zero, with zero errors, mismatches or source changes.

Full supervision has **4 completed / 12 incomplete** trials and cleanup states
**4 settled / 9 flat / 3 attention**. The primary (0.25-second RTT, full depth,
basket on) is an incomplete loss-stop trial that finishes verified flat at
**−$239.99**, versus core serialized **−$501.21**. These policy outcomes differ
in supervision, timing and liquidation; their difference does not isolate a
single causal mechanism.

## Independent reproduction

The following three settings were rerun through frozen reference `505a5ad2`,
baseline adapter and full supervisor (the latter two at driver `c5c35a30`,
with runtime bytes verified against `cd3eb239`). All nine reproductions match
every result field and the archived request/fill trace hashes exactly.

| RTT / depth / baskets | Core and baseline P&L | Supervised terminal P&L | Supervised cleanup |
| --- | ---: | ---: | --- |
| 0.25 / full / on | −$501.21 | −$239.99 | flat |
| 0.05 / half / off | −$613.32 | −$573.91 | flat |
| 0 / half / off | −$738.46 | −$522.38 | attention |

Two original-worker settings were also rerun with warmup reset false:
0.25/full/on = −$740.72 and 3/half/off = −$703.86. Every result field matches.
The remaining original worker rows were checked for exact grid coverage,
finite results, source/input provenance and aggregate statistics; they were
not all rerun. A total of **11 representative reproductions** was performed.

All reruns independently reconcile fill cash plus terminal holdings to P&L.
Value-access guards require a closed terminal market; supervised settlement
values additionally require the official receipt to be available. No forbidden
access occurred. Full request/fill traces are retained as compressed JSON.

## All 112 journal files

The original 16 supervised settings each retain seven files:
`observations.json`, `actions.jsonl`, `status.json`, `final-receipt.json`,
`startup-feed.jsonl`, `result.json`, `run.lock` — **112 files, not 112 trials**.
The audit verifies every file, its hash, result-row agreement, status/trial and
receipt consistency, chronology, ownership flags, exposure caps, flat/settled/
attention classification and absence of fills after final receipt requests.

| Attention setting (RTT / depth / baskets) | Final receipt mark | Terminal settlement mark | Residual position |
| --- | ---: | ---: | --- |
| 0 / full / off | −$404.21 | −$403.97 | REIN −6 |
| 0 / half / off | −$522.62 | −$522.38 | REIN −6 |
| 0 / half / on | −$490.95 | −$490.71 | REIN −6 |

All three have no open orders, a non-flat final receipt and no later fills.
Their $0.24 receipt-to-terminal improvement is a valuation change on remaining
exposure, not successful liquidation. In the reproduced half-depth/off case,
REIN cleanup book checks at relative times 2170.5 and 2171.5 return empty.
The last REIN quote was at 2154.025929; the next is at 2173.325811, after cleanup
ends at 2172.5. The five-attempt cleanup limit leaves the short position open.
That observed quote gap does not prove missing server updates or guarantee a
fill under a different cleanup policy.

## Eligibility, coverage and overlap

The sealed scan is 221,524 bytes, ending on a complete line. Its hash matches
the immutable spec, scan record and the corresponding byte prefix of the
observer file. The sealed feed is 50,016,422 bytes with the declared hash.
Only the sealed prefix was consumed; no later appended outcomes were read.

The approved `observed_capture` selector reconstructs 21,974 frames, from
`1792832314.241528` to `1792835135.096904`, and independently reproduces news
0–871 (872 unique sequences), all three final damage reports and round/symbol
quote coverage. The selected interval begins after both the runtime freeze
`1792828815` and driver freeze `1792829252`; phase execution starts only after
the closing receipt and prerequisite phase completion.

Coverage remains incomplete as a claim about the true market path. The first
round has approximately 121.296 seconds from initial snapshot to first quote.
The largest observed interval between usable quotes is **41.959472 seconds**
for REIN in round 2. There are 38 unusable quotes. Zero explicit disconnect
frames and zero subscription acknowledgements were recorded; actual disconnect
count and missed updates remain unknown.

Only after validating closure, the audit compares all 241 observations at
ages 0,2,…,480 for each storm, across x/y/radius/intensity, with the existing
1,350 × 241 × 4 fitted analog array. The three complete tracks match
**zero-based NPZ rows 738, 739 and 740 exactly**, with zero error. No downloaded
historical files or row-identity manifest was read. Therefore chronological
source freezing does **not** make these storms an untouched model holdout.
Track equality does not establish equal quotes, advisories or execution.

## Retained cache and identities

`247.json` is the reconstructed closed cache with exactly `{frames, receipt}`;
the original worker `CID.json` is a result artifact, not this cache. Both cache
value hashes equal `metadata['captures'][0]` in every supervisor phase and the
serialized archive metadata.

| Object | SHA256 |
| --- | --- |
| Cache file `247.json` | `905e7bf98dbd13c913340a9a1999d49a00b6cd6a9209602e089fe20f88d3698e` |
| Frames JSON value | `711f1675a430b10276f5ef35332fef47f6230bb9ee8be145d2dbdc85fdd9e5c5` |
| Receipt JSON value | `49a7b2b53528fc5c2f5ea990eb40bda4b480593955c18e6db2a797b4069d3b63` |
| Sealed observations | `9e98c0fe5b5a503dc6c6f1566b785572896c5e35ba0be8f8fcfae49dd273b195` |
| Sealed feed | `0df79451a59a031710d63271c1558f2711a7d28458b064ae4c4c0340877352f7` |
| Immutable attempt spec | `1a8ff4ca6e93bd30d48e80f214774668b883ad6bd352ef82901916227b08fc73` |
| Comparison driver | `afff0aa65676b6cd0294873498aadfb84ea6d04fa9b6eda6291e2405dc03dcc3` |
| Analog NPZ | `22694387c3b612f5c20853feb9143e1bf8b8f5722a845da8ed584ab1b30bdf09` |

`audit.json` retains the complete source hash map, receipt, coverage, journal
hashes, eligibility/phase records, statistics and overlap details. The four
`rerun-*` directories retain results, compressed traces and reproduction
summaries. `original/` preserves byte-identical original result and journal
artifacts; `artifact-hashes.json` binds all packaged files. `audit.py`,
`rerun.py` and `package.py` preserve the audit procedures.

## Declined to judge

- Actual account P&L or account exclusivity: this is virtual replay evidence.
- True quote completeness, market impact and counterfactual live fills: recordings cannot establish them.
- Unseen-weather generalization: exact fitted-track overlap is present.
- Alternative policy performance or production activation: no tuning or deployment was performed.

The evidence is suitable for reporting with these limits. It supports no
claim of guaranteed profit or production promotion.
