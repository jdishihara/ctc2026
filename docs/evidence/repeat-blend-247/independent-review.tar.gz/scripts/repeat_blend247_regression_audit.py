"""All three regressions reconciled from retained complete fill ledgers; no new replay."""
import collections, hashlib, json, math, os, pathlib, sys, tempfile
R=pathlib.Path('/Users/arjunhans/Documents/ctc2026');O=R/'out/repeat-blend-247-20261024'
T=pathlib.Path('/var/folders/5_/4_9w4ch971l2mm9c6fqtg5400000gn/T');RUN=T/'repeat-blend247-independent-candidate-i20sfu4i'
forbidden=[]
def guard(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
  forbidden.append(event);raise RuntimeError('network forbidden')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=os.fsdecode(args[0]).lower()
  if '.botkey' in p or '/.env' in p or '/data/history/' in p or 'credentials' in p:
   forbidden.append(p);raise RuntimeError('credential/history read forbidden')
sys.addaudithook(guard)
def J(p):return json.loads(p.read_text())
def H(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def K(r):return r['capture'],r['rtt_seconds'],r['displayed_depth_fraction'],r['basket_enabled']
def near(a,b):assert math.isclose(a,b,rel_tol=0,abs_tol=1e-6),(a,b)
rows={ph:{K(r):r for l in (O/ph/'results.jsonl').read_text().splitlines() if (r:=json.loads(l))} for ph in ['baseline','candidate']}
item=J(O/'spec.json')['captures'][0];assert item['capture']==247 and H(pathlib.Path(item['input']))==item['input_sha256']
data=J(pathlib.Path(item['input']));prices=data['receipt']['prices'];assert data['receipt']['clock']['state']=='ready' and data['frames'][-1]['received_at']<=data['receipt']['at']
cases=[]
for rtt,depth,basket in [(.25,.5,True),(.25,1.,True),(1.,.5,False)]:
 k=(247,rtt,depth,basket);phases={}
 for ph in ['baseline','candidate']:
  folder=f'capture-247-{rtt}-{depth}-{int(basket)}';d=O/ph/folder;r=rows[ph][k]
  assert r['cleanup']['state'] in ('flat','settled') and r['fills_after_final_receipt_requests']==0 and r['conversions']==0
  profile=J(d/'cleanup-profile.json');retrieved=[e['request'] for e in profile if e['request']['path']=='/trades']
  trades=list(reversed(retrieved[-1]['response']['trades']));assert len(trades)==r['fills']<100
  assert [x['trade_id'] for x in trades]==[f'virtual-{i}' for i in range(r['fills'])]
  actions=[json.loads(l) for l in (d/'actions.jsonl').read_text().splitlines()]
  assert not [x for x in actions if x['kind']=='request' and x.get('method')=='POST' and x.get('path')!='/orders']
  rerun_path=RUN/folder/'fill-trace.json'
  if ph=='candidate' and rerun_path.is_file():
   filltrace=J(rerun_path);assert len(filltrace)==len(trades)
   for t,f in zip(trades,filltrace):assert t['symbol']==f['symbol'] and t['side']==f['side'] and t['quantity']==f['qty'] and t['price']==f['price'] and float(t['executed_at'])==f['t']
  cash={s:0. for s in prices};position={s:0 for s in prices}
  for t in trades:
   s=t['symbol'];q=t['quantity']*(1 if t['side']=='buy' else -1);cash[s]-=q*t['price'];position[s]+=q
  assert position==r['final_positions']
  scores={s:cash[s]+q*prices[s] for s,q in position.items()};near(sum(scores.values()),r['terminal_settlement_pnl'])
  receipt={p['symbol']:p for p in J(d/'final-receipt.json')['positions']['positions']}
  for s in prices:
   p=receipt[s];score=p['realized_pnl']+(p['quantity']*(prices[s]-p['average_price']) if p['quantity'] else 0.);near(score,scores[s])
  phases[ph]=dict(complete_fills=trades,fill_cash_by_symbol=cash,terminal_positions=position,terminal_pnl_by_symbol=scores,receipt=receipt,terminal_pnl=r['terminal_settlement_pnl'],stop_at=r['stop_at'],cleanup_started_at=r['cleanup_started_at'],cleanup_completed_at=r['cleanup_completed_at'],cleanup_state=r['cleanup']['state'],trade_snapshot_executed_at=retrieved[-1]['executed_at'],original_profile_sha256=H(d/'cleanup-profile.json'))
 components=[]
 for sym in prices:
  b=phases['baseline'];c=phases['candidate'];pnl_delta=c['terminal_pnl_by_symbol'][sym]-b['terminal_pnl_by_symbol'][sym]
  if abs(pnl_delta)>1e-6:
   components.append(dict(symbol=sym,baseline_pnl=b['terminal_pnl_by_symbol'][sym],candidate_pnl=c['terminal_pnl_by_symbol'][sym],pnl_delta=pnl_delta,cash_delta=c['fill_cash_by_symbol'][sym]-b['fill_cash_by_symbol'][sym],terminal_position_delta=c['terminal_positions'][sym]-b['terminal_positions'][sym],settlement_price=prices[sym],baseline_fills=[t for t in b['complete_fills'] if t['symbol']==sym],candidate_fills=[t for t in c['complete_fills'] if t['symbol']==sym]))
 delta=phases['candidate']['terminal_pnl']-phases['baseline']['terminal_pnl'];near(sum(c['pnl_delta'] for c in components),delta)
 expected={(.25,.5,True):-47.63,(.25,1.,True):-79.64,(1.,.5,False):-24.78}[rtt,depth,basket];near(delta,expected)
 cases.append(dict(setting=k,baseline_pnl=phases['baseline']['terminal_pnl'],candidate_pnl=phases['candidate']['terminal_pnl'],delta=delta,components=components,phases=phases))
assert not forbidden
out=pathlib.Path(tempfile.mkdtemp(prefix='repeat-blend247-regression-audit-'))
proof=dict(cases=cases,forbidden_attempts=forbidden,new_performance_runs=0,trade_source='The last retained cleanup GET /trades response contains the complete chronological fill ledger in each case; all six ledgers have fewer than100 fills and contiguous virtual trade IDs. The candidate primary also matches the independent rerun fill trace.',conversions=0,accounting='Each fill independently contributes signed_quantity*(official_settlement_price-fill_price). Fill cash and net positions match every final receipt and terminal result.',interpretation='Arithmetic attribution of each realized path, not an isolated intervention on one order, model feature or cleanup time.',explanation=['At .25s/half/basket-on, HAVEN changes from +162.24 to -82.43 (-244.67). The candidate sells from a small long to short25 and buys back at58.02/58.30; baseline keeps a six-share long until selling at58.51. Avoided RECON loss adds139.70, AQUA70.00 and FERRY64.79, offset by GRID-36.30, GEN-35.88 and smaller differences; total-47.63.','At the primary .25s/full/basket-on, HAVEN changes from +166.50 to -81.65 (-248.15) through the analogous long-to-short then cleanup buyback path. Avoiding baseline RECON loss adds143.00, FERRY67.37 and AQUA43.69, offset by GRID-57.20, GEN-25.20 and smaller differences; total-79.64. Candidate cleanup begins2221.75, baseline2783.75; their liquidation timings differ substantially.','At1s/half/basket-off, the candidate sells12 HAVEN at40.55 instead of baseline50.80, contributing-123.00. Added RECON exposure contributes-110.20, PORT-27.16, offset by AQUA+112.42, FERRY+75.70, GEN+51.35 and smaller differences; total-24.78. Both trials complete and settle, so this comparison has no liquidation fills.'])
(out/'regressions.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(path=str(out/'regressions.json'),cases=[dict(setting=x['setting'],delta=x['delta'],components={c['symbol']:round(c['pnl_delta'],2) for c in x['components']}) for x in cases],forbidden_attempts=forbidden)))
