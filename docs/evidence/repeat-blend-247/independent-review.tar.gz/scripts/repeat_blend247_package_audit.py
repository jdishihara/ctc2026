"""Retain closed247 rejection, prior96 evidence and the exact three-case rerun proof."""
import datetime,hashlib,json,os,pathlib,shutil,subprocess,sys,tarfile,tempfile
R=pathlib.Path('/Users/arjunhans/Documents/ctc2026');O=R/'out/repeat-blend-247-20261024';OLD=R/'out/repeat-blend-v1-20261024';C=R/'.worktrees/repeat-blend-247'
T=pathlib.Path('/var/folders/5_/4_9w4ch971l2mm9c6fqtg5400000gn/T');REV='95f0f90a48944cd3097420a02d8d2535e991b546'
forbidden=[]
def guard(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
  forbidden.append(event);raise RuntimeError('network forbidden')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=os.fsdecode(args[0]).lower()
  if '.botkey' in p or '/.env' in p or '/data/history/' in p or 'credentials' in p:
   forbidden.append(p);raise RuntimeError('credential/history forbidden')
sys.addaudithook(guard)
def H(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def J(p):return json.loads(p.read_text())
def cp(s,d):d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(s,d);assert H(s)==H(d)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=C,text=True).strip()==REV and not subprocess.check_output(['git','status','--porcelain=v1'],cwd=C,text=True)
out=pathlib.Path(tempfile.mkdtemp(prefix='repeat-blend247-independent-evidence-'))
shutil.copytree(T/'repeat-blend247-independent-candidate-i20sfu4i',out/'candidate-reruns')
cp(T/'repeat-blend247-artifact-audit-zn_7npct/audit.json',out/'artifact-audit.json')
cp(T/'repeat-blend247-regression-audit-g8sd_gik/regressions.json',out/'regressions.json')
for n in ['repeat_blend247_audit_setup.py','repeat_blend247_artifact_audit.py','repeat_blend247_guarded_rerun.py','repeat_blend247_regression_audit.py','repeat_blend247_package_audit.py']:cp(pathlib.Path('/tmp')/n,out/'scripts'/n)
for n in ['repeat_blend247_artifact_audit','repeat_blend247_candidate_rerun','repeat_blend247_regression_audit']:
 for suffix in ['stdout.log','stderr.log']:cp(pathlib.Path('/tmp')/(n+'.'+suffix),out/'logs'/(n+'.'+suffix))
for n in ['spec.json','247.json','analysis.json','analyze.py','baseline/metadata.json','baseline/results.jsonl','baseline/summary.json','candidate/metadata.json','candidate/results.jsonl','candidate/summary.json','baseline.stdout.log','baseline.stderr.log','candidate.stdout.log','candidate.stderr.log','full-suite.log','preflight-review.tar.gz']:
 cp(O/n,out/'original-artifacts'/n)
cp(C/'docs/repeat-blend-247-plan.md',out/'frozen-plan.md')
cp(C/'scripts/compare_repeat_blend_247.py',out/'frozen-driver.py')
for phase in ['baseline','candidate']:
 for rtt,depth,basket in [(.25,.5,True),(.25,1.,True),(1.,.5,False),(0.,.5,False),(0.,.5,True)]:
  folder=f'capture-247-{rtt}-{depth}-{int(basket)}'
  if phase=='candidate' and (out/'candidate-reruns'/folder).exists():continue
  for p in (O/phase/folder).iterdir():
   if p.is_file():cp(p,out/'retained-case-journals'/phase/folder/p.name)
previous_archive=T/'repeat-blend-independent-evidence-_tdzkt8w.tar.gz'
assert H(previous_archive)=='23d33af94f82ef80e3467e6c87e4036d081c7217c2daf3308d05ec18c554cbd7'
cp(T/'repeat-blend-independent-evidence-_tdzkt8w/verdict.json',out/'prior96/verdict.json')
for n in ['spec.json','analysis.json','baseline/metadata.json','baseline/results.jsonl','baseline/summary.json','candidate/metadata.json','candidate/results.jsonl','candidate/summary.json']:
 cp(OLD/n,out/'prior96'/n)
assert H(OLD/'candidate/results.jsonl')=='bc380b30d37324d135a96d89bcce79c63c2dfd7fcc9fc1d61cf4c24213609d09'
original247=R/'out/capture-247-independent-review-20261024.tar.gz';assert H(original247)=='8930064de48813f53025be67a6d0db6e00019e86631b36b6e176d38dc9329b93'
with tarfile.open(original247) as t:
 for n in ['audit.json','cache-info.json','README.md','artifact-hashes.json']:
  p=out/'original247-review'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.extractfile(n).read())
a=J(out/'artifact-audit.json');run=J(out/'candidate-reruns/independent-audit.json');econ=J(out/'regressions.json');analysis=J(O/'analysis.json')
assert (a['journal_profile_hashes_verified'],a['baseline_journals_byte_exact'],a['source_files_verified'],a['git_source_files_verified'])==(288,112,175,58)
assert a['analysis_exact'] and len(run['cases'])==3 and all(x['files_exact']==9 for x in run['cases'])
assert not a['forbidden_attempts'] and not run['forbidden_attempts'] and not econ['forbidden_attempts']
assert analysis['decision']=='reject' and analysis['failed_rules']==['increased_residual_exposure','not_all_settings_positive','not_all_trials_completed','not_all_receipts_settled']
rows={ph:[json.loads(x) for x in (O/ph/'results.jsonl').read_text().splitlines()] for ph in ['baseline','candidate']}
attention=[]
for ph,rr in rows.items():
 for r in rr:
  if r['cleanup']['state']=='attention':
   assert not r['server_orders_after_final_receipt'] and r['fills_after_final_receipt_requests']==0
   attention.append(dict(phase=ph,setting=[r['capture'],r['rtt_seconds'],r['displayed_depth_fraction'],r['basket_enabled']],receipt_mark=r['final_receipt']['pnl'],terminal_pnl=r['terminal_settlement_pnl'],holdings={s:q for s,q in r['final_positions'].items() if q},stop_at=r['stop_at'],cleanup_started_at=r['cleanup_started_at'],cleanup_completed_at=r['cleanup_completed_at'],open_orders=[],post_receipt_fills=0))
assert len(attention)==5 and sum(x['phase']=='candidate' for x in attention)==2
sampled_crossings=[]
for r in rows['candidate']:
 if r['trial_state']=='completed' and r['lowest_marked_pnl']<=-250:
  k=[r['capture'],r['rtt_seconds'],r['displayed_depth_fraction'],r['basket_enabled']]
  obs=J(O/'candidate'/f'capture-{k[0]}-{k[1]}-{k[2]}-{int(k[3])}'/'observations.json');minimum=min(x['pnl'] for x in obs);assert minimum> -250
  sampled_crossings.append(dict(setting=k,server_low=r['lowest_marked_pnl'],minimum_observed_pnl=minimum,terminal_pnl=r['terminal_settlement_pnl']))
for p,sha in a['source_hashes'].items():assert H(pathlib.Path(p))==sha
for p,sha in run['source_hashes'].items():assert H(pathlib.Path(p))==sha
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=C,text=True).strip()==REV and not subprocess.check_output(['git','status','--porcelain=v1'],cwd=C,text=True)
verdict=dict(completed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),verdict='Reject optional blend integration under the predeclared supplemental conditions and original increased-residual-exposure rule. Approve retention/reporting of the verified unfavorable evidence; no source, artifact, causality or accounting blocker found.',candidate_revision=REV,unchanged_model_revision='7a2fe81b1167bb1b355357b0d105ea91ed29cd05',baseline_revision='cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026',repeat_weight=.5,settings=16,rows_verified=32,source_input_artifacts_verified=175,git_blobs_verified=58,baseline_bound_artifacts=147,journal_profile_hashes_verified=288,original_baseline_journals_byte_exact=112,original247_audit_archive_sha256=H(original247),original247_audit_member_hashes_verified=208,closed_cache_byte_identical=True,candidate_reruns=3,rerun_files_byte_exact=27,extra_full_request_fill_and_quote_files=9,metrics=a['metrics'],pnl_pair_counts=a['pair_counts'],failed_rules=analysis['failed_rules'],primary=analysis['primary'][0],attention=attention,all_regressions_reconciled=[dict(setting=x['setting'],delta=x['delta'],by_symbol={c['symbol']:c['pnl_delta'] for c in x['components']}) for x in econ['cases']],candidate_lowest_server_mark=min(r['lowest_marked_pnl'] for r in rows['candidate']),candidate_maximum_marked_drawdown=max(r['maximum_marked_drawdown'] for r in rows['candidate']),completed_server_lows_below_sampled_trigger=sampled_crossings,guard_counts=run['counts'],sources_unchanged=run['sources_unchanged'],forbidden_attempts=[],extra_reruns=0,prior96=dict(retained=True,candidate_results_sha256=H(OLD/'candidate/results.jsonl'),independent_archive_sha256=H(previous_archive),candidate_metrics=J(OLD/'analysis.json')['aggregate']['candidate'],pnl_comparison=J(OLD/'analysis.json')['pnl_comparison'],original_offline_gates_passed=True,subsequent247_check_rejected=True),limitations=['The first96 settings and supplemental16 are both preserved. They are correlated counterfactual settings on seven reused captured paths, not112 independent trials.','The fixed model predates capture247 closure, but the supplemental check was declared after original247 results were known and after the season had begun.','All observed weather prefixes match the fitted library; this is not unfamiliar-weather generalization.','The $250 trigger is sampled and is not a hard terminal/realized loss bound.','Attention receipts retain exposure; terminal scoring at official prices does not establish successful liquidation or completed trials.','All three regressions reconcile from existing complete fill ledgers; no alternate settings or extra performance runs were introduced.','Per-symbol attribution explains realized path arithmetic; different stop and liquidation times prevent interpreting it as an isolated feature ablation.','No account access, production activation or live-profit claim is supported.'])
(out/'verdict.json').write_text(json.dumps(verdict,indent=2,sort_keys=True)+'\n')
files={str(p.relative_to(out)):H(p) for p in sorted(out.rglob('*')) if p.is_file()}
(out/'artifact-manifest.json').write_text(json.dumps({'count':len(files),'files':files},indent=2,sort_keys=True)+'\n')
archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(out.rglob('*')):
  if p.is_file():t.add(p,arcname=str(p.relative_to(out)),recursive=False)
with tarfile.open(archive) as t:
 ms=t.getmembers();assert len(ms)==len(files)+1 and len({m.name for m in ms})==len(ms)
 for m in ms:assert m.isfile() and t.extractfile(m).read()==(out/m.name).read_bytes()
assert not forbidden
print(json.dumps(dict(directory=str(out),archive=str(archive),archive_sha256=H(archive),manifest_sha256=H(out/'artifact-manifest.json'),verdict_sha256=H(out/'verdict.json'),hashed_files=len(files),archive_files=len(files)+1,archive_bytes=archive.stat().st_size,forbidden_attempts=forbidden,extra_reruns=0)))
