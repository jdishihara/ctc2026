from pathlib import Path
s=Path('/tmp/repeat_prefix_artifact_audit.py').read_text()
s=s.replace('repeat-prefix-v1-20261024','repeat-blend-247-20261024').replace("C=ROOT/'.worktrees/repeat-prefix'","C=ROOT/'.worktrees/repeat-blend-247'").replace('357d9986babf2b21bd3bbdcc2e69550059f16154','95f0f90a48944cd3097420a02d8d2535e991b546').replace("prefix='repeat-prefix-artifact-audit-'","prefix='repeat-blend247-artifact-audit-'")
s=s.replace('range(241,247)','[247]').replace('==96','==16').replace('startup_feed_identical_pairs=96','startup_feed_identical_pairs=16').replace('baseline_journals_byte_exact=96*','baseline_journals_byte_exact=16*').replace('baseline_journals_byte_exact=672','baseline_journals_byte_exact=112')
s=s.replace("assert sum(p['delta']>1e-7 for p in pairs)==80 and sum(p['delta']< -1e-7 for p in pairs)==16","assert sum(p['delta']>1e-7 for p in pairs)==13 and sum(p['delta']< -1e-7 for p in pairs)==3")
s=s.replace("assert per_capture_pairs[242]==dict(improved=14,worsened=2) and per_capture_pairs[244]==dict(improved=2,worsened=14)\nassert all(per_capture_pairs[c]==dict(improved=16,worsened=0) for c in (241,243,245,246))","assert per_capture_pairs[247]==dict(improved=13,worsened=3)")
s=s.replace("assert ns['report']['failed_rules']==['new_attention_outcome','increased_residual_exposure','more_negative_capture_settings','worse_worst_capture_result']","assert ns['report']['failed_rules']==['increased_residual_exposure','not_all_settings_positive','not_all_trials_completed','not_all_receipts_settled']")
insert=s.index("case=J(C/'data/case.json')")
s=s[:insert]+'''assert bm['repeat_weight']==0 and cm['repeat_weight']==.5
assert H(C/'scripts/compare_repeat_blend_247.py')=='cddb76fbd53c40e131113bce7968df3eb7fb2015ede4d8a36df0b0e6d60b1c6f'
assert H(O/'baseline/results.jsonl')=='11e15305bbaa38506e8ed7ffc95d82fe80b5ac99f26ea15eeb05fb377d7f8fe7'
assert H(O/'candidate/results.jsonl')=='ac5faae13c4b1ee7848746ba5f233654551af2fdc35ca9e151b9e852d4d28753'
BASE='7a2fe81b1167bb1b355357b0d105ea91ed29cd05'
for name,sha in source_hashes.items():
 p=pathlib.Path(name)
 if p.is_relative_to(C) and p.relative_to(C).as_posix() not in ['scripts/compare_repeat_blend_247.py','docs/repeat-blend-247-plan.md']:
  assert hashlib.sha256(subprocess.check_output(['git','show',BASE+':'+p.relative_to(C).as_posix()],cwd=C)).hexdigest()==sha
assert int(subprocess.check_output(['git','show','-s','--format=%ct','HEAD'],cwd=C,text=True))==1792835681<bm['started_at']
import tarfile
original_review=ROOT/'out/capture-247-independent-review-20261024.tar.gz'
assert H(original_review)=='8930064de48813f53025be67a6d0db6e00019e86631b36b6e176d38dc9329b93'
with tarfile.open(original_review) as t:
 members=t.getmembers();assert len({m.name for m in members})==len(members) and all(m.isfile() for m in members)
 vals={m.name:t.extractfile(m).read() for m in members};hashes=json.loads(vals['artifact-hashes.json'])
 assert len(vals)==208 and set(hashes)==set(vals)-{'artifact-hashes.json'}
 for n,sha in hashes.items():assert hashlib.sha256(vals[n]).hexdigest()==sha
 original_audit=json.loads(vals['audit.json']);cache_info=json.loads(vals['cache-info.json'])
 assert original_audit['capture']==247 and original_audit['journal_files']==112 and not original_audit['forbidden_attempts']
 assert original_audit['receipt_frame_hashes_match_all_phases'] and original_audit['all_88_result_rows_checked']
 assert vals['247.json']==(O/'247.json').read_bytes() and cache_info['file_sha256']==H(O/'247.json')
 item=bm['spec']['captures'][0]
 for n in ['metadata.json','results.jsonl','summary.json']:
  assert vals['original/supervised/'+n]==(pathlib.Path(item['archive'])/n).read_bytes()
 for k,row in br.items():
  for n in JOURNALS:
   folder=f'capture-{k[0]}-{k[1]}-{k[2]}-{int(k[3])}'
   assert vals['original/supervised/'+folder+'/'+n]==(O/'baseline'/folder/n).read_bytes()
''' +s[insert:]
s=s.replace("result=dict(startup_feed_identical_pairs=16,","result=dict(repeat_weight=.5,original247_review_archive_sha256=H(original_review),original247_audit_members_verified=208,closed_cache_byte_identical_to_original_audit=True,source_runtime_equal_approved7a2fe81=True,startup_feed_identical_pairs=16,")
s=s.replace("assert all(H(name)==sha for name,sha in source_hashes.items()) and not forbidden","assert all(H(name)==sha for name,sha in source_hashes.items()) and not forbidden\nfor root,rev in REVS.items():\n assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==rev\n assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root,text=True)")
Path('/tmp/repeat_blend247_artifact_audit.py').write_text(s)
s=Path('/tmp/repeat_blend_guarded_rerun.py').read_text().replace('repeat-blend-v1-20261024','repeat-blend-247-20261024').replace("else 'repeat-blend'","else 'repeat-blend-247'").replace('7a2fe81b1167bb1b355357b0d105ea91ed29cd05','95f0f90a48944cd3097420a02d8d2535e991b546').replace("prefix='repeat-blend-independent-'","prefix='repeat-blend247-independent-'")
s=s.replace('only the seven requested closed-capture settings','only the three requested closed-247 candidate settings')
s=s.replace('cases=[(245,0.,1.,False),(245,0.,1.,True),(245,0.,.5,False),(245,0.,.5,True),(245,1.,.5,True),(244,.25,1.,True),(246,.25,1.,True)]','cases=[(247,.25,1.,True),(247,0.,.5,False),(247,0.,.5,True)]')
Path('/tmp/repeat_blend247_guarded_rerun.py').write_text(s)
