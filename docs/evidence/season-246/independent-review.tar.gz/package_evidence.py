from pathlib import Path
import gzip,hashlib,io,json,tarfile
p=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
files=sorted(f for f in p.rglob('*') if f.is_file() and f.name not in ('artifact-manifest.json','independent-capture246-audit.tar.gz','package.json'))
manifest={'files':{str(f.relative_to(p)):{'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())} for f in files},'capture':246,'scope':'read-only closed-capture audit and six repetitions of archived fixed settings'}
(p/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
files.append(p/'artifact-manifest.json'); archive=p/'independent-capture246-audit.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for f in sorted(files):
    b=f.read_bytes(); info=tarfile.TarInfo(str(f.relative_to(p)));info.size=len(b);info.mtime=0;info.uid=info.gid=0;info.mode=0o644;tar.addfile(info,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(files)
 for member in members:assert tar.extractfile(member).read()==(p/member.name).read_bytes()
package={'archive':str(archive),'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'members':len(files),'all_members_byte_equal_retained_files':True,'audit_sha256':sha((p/'audit.json').read_bytes()),'manifest_sha256':sha((p/'artifact-manifest.json').read_bytes()),'audit_script_sha256':sha((p/'audit246.py').read_bytes()),'reproduction_script_sha256':sha((p/'reproduce246.py').read_bytes()),'report_sha256':sha((p/'report.md').read_bytes())}
(p/'package.json').write_text(json.dumps(package,indent=2)+'\n');print(json.dumps(package,indent=2))
