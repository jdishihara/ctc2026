# Independent closed capture246 audit

**Verdict: the recorded capture246 results and their provenance checks pass.** No blocker was found in the audited evidence. This certifies fixed offline recorded-market diagnostics, not owned live profit or performance on unseen weather.

Competition: `83fc18b9-e9fd-4634-bc8e-c7a1a77768a7`, fictional year1781. The official local observer receipt is ready at2026-10-24 08:56:43.484856UTC (`1792832203.4848561`), with matching start/end identity and year and complete positive settlement prices. Its canonical SHA256 is `dd8bb77cdf53d26457baa75631d634de42339ac2f06329e73bfdfd6b76e0d8e3`.

## Complete grids and arithmetic

| Fixed engine/grid | Positive rows | Minimum | Maximum | Mean |
| --- | ---: | ---: | ---: | ---: |
| Original24, including older snapshot-reset comparison |24/24 |1172.78 |1848.21 |1599.4683333333342 |
| Original current snapshot handling subset |12/12 |1471.29 |1848.21 |1731.657500000002 |
| Serialized core |16/16 |1155.06 |1937.04 |1568.3787500000005 |
| Production supervision diagnostic |16/16 |1439.61 |1937.04 |1678.0887500000017 |

Primary settings are0.25s latency/RTT, full displayed depth and basket enabled. Primary current original result1848.21; primary core1393.60 (86 orders,63 fills,1 conversion); primary supervisor1539.17 (71 orders,55 fills,0 conversions). Original and serialized latency models differ; these values are not a controlled estimate of one isolated runtime change.

All16 supervised trials completed, recorded all three final reports, stopped for the requested completed season and ended with cleanup state `settled`. No fills occurred after final-receipt requests. Nonzero final positions are settled holdings in a closed market; they are not unresolved cleanup exposure. All16 official scores were independently recomputed from final quantity, average basis and realized P&L using the official receipt prices. The separate final-receipt `pnl` field is the last-market mark and can differ from official settlement P&L.

The reference phase reproduces every core field for all16 settings. The corrected-runtime baseline reproduces every reference result field and both request/fill trace hashes for all16 settings. Each phase has16 rows, zero errors, zero mismatches, no changed sources and a valid completed summary. Exact result-file SHA256:

- Core: `46676e0a872eedf5b38d0bcae14f9a1ad9ee1ee4025cd9b5a7a210b1802fde82`
- Reference: `26b267e0183a447251400d7a28537959d81fcdea235cfd29d8e24561073a9dc6`
- Baseline: `5018086013f145ceec1813ab69d954d1d7fde926c9f2d33abe3a7954c8273af7`
- Supervised: `60960b091422ac4cbfcc4e9c88f60d561e6ecf095a215405de11818436e591cb`

## Inputs, chronology and source checks

The declared sealed feed (42,629,330 bytes, SHA256 `f5215abcb9756823c4916c060127d2bf7e520a4dad5fe88662a89647120f9ae6`) and scan002 observation copy (181,390 bytes, SHA256 `ce355c7f99d661ad66e03d3fc29de415f84f44841547b29e9a58ffd1c9902485`) are complete-line, byte-identical prefixes of the original growing files. Only those bounded original prefixes were read. The spec SHA256 is `3c0fbf1cb944baca147d4d31c28cb0c4590f040c2b78905b99a82b610408db38`.

The closed-capture loader reproduces the original artifact's receipt and coverage and the core/three-phase canonical frame hash `94e9b08a0044b4392b1cfccee8d225133c7e69cc38e0fa11f6498eb19e4b643e`. The original artifact itself does not record a canonical frame hash; matching receipt/coverage and independent reconstruction provide that additional check.

The selected interval contains22,748 frames:21,790 quotes,863 distinct contiguous news messages(seq0–862), and95 snapshots. Each round has one formation, all241 explicit observations at ages0,2,…,480 and a final damage report. There are no duplicate news sequences or storm ages and no conflicting duplicates. Selected receive times run from08:09:30.028088UTC through08:56:33.677256UTC. The official receipt follows the final selected frame by9.807600259780884s.

All selected frames follow the serialized source freeze(07:18:38UTC), corrected runtime freeze(08:00:15UTC) and separate driver freeze(08:07:32UTC). The first frame follows the driver freeze by118.028088s. The original worker's06:06 value is its configured eligibility start, not independent proof of its actual start or source-freeze time.

Verified all declared current source/input hashes before and after the audit, frozen Git blobs and clean unchanged worktree HEAD/status:

- Original worker23-file source manifest at `49a690efec04f7dcaf6a616de81da2838afbf149`.
- Serialized core28-file source manifest at `505a5ad2d5a6f81e7c711cb550871ce7aa7f3734`.
- Forward driver/protocol at `c5c35a30e0c5f521f12324eec854f405b681b8c0`.
- All28 runtime bindings checked against `cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026` Git blobs.
- Exact phase dependency sets(66 reference,40 baseline,40 supervised), upstream metadata/results/summary hashes, spec/receipt/frame/parameter/grid bindings and predecessor completion/result hashes.
- Original, core and supervised ledger prefixes through246's completed record; all recorded artifact hashes agree. Later ledger tails were not read.
- All112 supervised journal files(16×7) retained by hash and each result journal compared with its serialized result row.

## Independent causal reproductions

| Engine | Existing fixed setting | P&L | All archived fields equal |
| --- | --- | ---: | --- |
| Original, current snapshot handling |0.25s/full/on |1848.21 |Yes |
| Original, current snapshot handling |3s/half/on |1471.29 |Yes |
| Core |0.25s/full/on |1393.60 |Yes |
| Core |1s/half/on |1155.06 |Yes |
| Supervised |0.25s/full/on |1539.17 |Yes |
| Supervised |1s/half/on |1675.82 |Yes |

All22,748 selected frames were processed in every rerun. Guards enforced terminal settlement access, causal frame delivery, unchanged model history across quote callbacks, valid strategy identity/history at submission and reducing/reconciled cleanup submissions. Guard failures latch outside production exception handling. The supervisor only accessed settlement values after terminal close and the recorded receipt-availability time. Original/core scoring occurs after terminal close, as defined by those diagnostic engines; no official settlement values enter strategy callbacks.

Each serialized request had the declared execution/completion offsets and did not overlap its predecessor. Core/supervisor request and fill hashes exactly match archives; both supervised reruns reproduce all seven journal files byte-for-byte. Independent cash and quantities accumulated from actual fills and accepted cash-neutral conversions reproduce all six settlement scores. There were zero forbidden access attempts, zero guard violations and zero source changes. No new setting, strategy variant or model was evaluated.

## Exact fitted-weather overlap

The frozen NPZ SHA256 remains `22694387c3b612f5c20853feb9143e1bf8b8f5722a845da8ed584ab1b30bdf09`, tracks shape1350×241×4. It has identical bytes at introduction commit `51d48f701c6877214e612533280ccff1d955e382` and corrected runtime `cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026`.

| Round | Exact unique zero-based library row | Explicit ages | Max absolute error | Minimum RMSE |
| --- | ---: | ---: | ---: | ---: |
|1 |735 |241 |0 |0 |
|2 |736 |241 |0 |0 |
|3 |737 |241 |0 |0 |

All2,892 scalar weather values `[x,y,radius,intensity]` are exactly equal. Each observed track has exactly one matching row at tolerance1e-9 and exactly one row with exact float64 value equality. Snapshot trajectories were excluded.

Training lineage references in `/Users/arjunhans/Documents/ctc2026/.worktrees/practice-history`:

- `scripts/build_library.py:6` selects `man['seasons'][:450]` (the first450 manifest entries); line7 labels them seasons1–450.
- `ctc/analog.py:42` iterates selected seasons; line44 iterates storms; lines45–54 construct and append the four-channel tracks.
- `ctc/analog.py:191` uses remaining future points from selected library tracks.
- `README.md:187` documents fitting1–450, tuning451–525 and reused confirmation526–600.

Rows735–737 match the expected three-storm-per-season ordering for documented season246. The NPZ does not embed season IDs or a training-manifest digest. No downloaded manifest/history was read and the450-source training selection was not reconstructed. The exact three-track overlap is directly established; the broader manifest lineage remains bounded by those limitations.

Chronological freezes remain valid, but capture246 is not unseen-weather validation. Exact weather equality does not establish identical advisories, quotes or fills, nor any live account/order error. This audit does not estimate profitability without training overlap.

## Declined to judge / limits

- True quote-path completeness and actual disconnect count/duration remain unknown. There are zero recorded disconnect frames and no subscription acknowledgements; absence of those records does not prove no outage.
- There are44 unusable recorded quotes. The serialized core ignores one closed-boundary quote and reports43 unusable quotes inside its processed market path.
- Largest observed receive-time gap is121.49796390533447s at the round1 opening boundary(GEN). Largest nonopening gap is64.73593997955322s(GEN round2). These gaps are observations, not inferred network outages or proof of omitted server events.
- Recorded displayed-depth fills and virtual RTTs remain model assumptions. No real queue priority, hidden liquidity, price impact or owned live profit is certified.
- All grid metadata/result equality and arithmetic were checked; six representative runs were independently rerun, not all56 distinct engine/settings.
- No active247/later outcomes, network, credentials or downloaded history were accessed. No source/runtime/model changes were made.

Full checks, artifact/source hashes, all112 journal hashes, exact overlaps and accounting results are in `audit.json`. The three `*-reproduction.json` files and retained reproduction logs contain the six guarded results. `artifact-manifest.json` binds the retained scripts, reports, logs, prefixes, closed input cache and reproduced journals/traces.
