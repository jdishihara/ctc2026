from __future__ import annotations
import collections, datetime, hashlib, itertools, json, math, os, subprocess, sys
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=Path('/Users/arjunhans/Documents/ctc2026'); REC=ROOT/'recordings/consistency-20261024'
CID='83fc18b9-e9fd-4634-bc8e-c7a1a77768a7'; CAPTURE=246; YEAR='1781'
OR=ROOT/'.worktrees/closed-season-evaluation'; CR=ROOT/'.worktrees/serialized-forward'; SR=ROOT/'.worktrees/supervised-forward'; HR=ROOT/'.worktrees/practice-history'
REVS={OR:'49a690efec04f7dcaf6a616de81da2838afbf149',CR:'505a5ad2d5a6f81e7c711cb550871ce7aa7f3734',SR:'c5c35a30e0c5f521f12324eec854f405b681b8c0',HR:'cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026'}
CORE=REC/'serialized-forward'/CID; ATT=REC/'supervised-forward'/CID/'attempt-01'
forbidden=[]; hashes={}; git_verified={}; prefixes={}
def hook(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
  forbidden.append(event); raise RuntimeError('audit forbids network')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  name=os.fsdecode(args[0]).lower()
  if '.botkey' in name or '/.env' in name or 'credentials' in name or '/data/history/' in name or name.endswith('/data/history'):
   forbidden.append(name); raise RuntimeError('audit forbids credentials and downloaded history')
sys.addaudithook(hook)
def sha(b):return hashlib.sha256(b).hexdigest()
def value_hash(v):return sha(json.dumps(v,sort_keys=True,allow_nan=False).encode())
def read(path):
 p=Path(path); b=p.read_bytes(); hashes[str(p)]=sha(b); return b
def load(path):return json.loads(read(path))
def rows(path):
 b=read(path); assert b.endswith(b'\n'); return [json.loads(x) for x in b.splitlines()]
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
def check_blob(path,rev=None):
 p=Path(path); root=next(r for r in REVS if p.is_relative_to(r)); rev=rev or REVS[root]
 b=read(p); h=sha(git(root,'show',rev+':'+p.relative_to(root).as_posix())); assert sha(b)==h,(p,rev)
 git_verified[str(p)]={'revision':rev,'sha256':h}
heads={str(r):git(r,'rev-parse','HEAD').decode().strip() for r in REVS}
status={str(r):git(r,'status','--porcelain','--untracked-files=normal').decode() for r in REVS}
assert all(heads[str(r)]==rev for r,rev in REVS.items()) and not any(status.values())
spec=load(ATT/'spec.json'); item=spec['captures'][0]
assert len(spec['captures'])==1 and item['capture']==246 and item['competition_id']==CID and item['mode']=='observed'
assert spec['reference_revision']==REVS[CR] and spec['reference_root']==str(CR)
for field,original in [('feed',REC/'feed.jsonl'),('observations',REC/'market-observations.jsonl')]:
 b=read(item[field]); assert len(b)==item[field+'_bytes'] and sha(b)==item[field+'_sha256'] and b.endswith(b'\n')
 with original.open('rb') as f: prefix=f.read(len(b))
 assert b==prefix
 prefixes[field]={'sealed':item[field],'original':str(original),'bytes':len(b),'sha256':sha(b),'byte_equal_original_prefix':True,'complete_line':True}
original_path=REC/'fixed-observed-evaluation'/f'{CID}.json'; original=load(original_path); manifest=load(REC/'fixed-observed-evaluation/manifest.json')
assert manifest['git_revision']==REVS[OR] and original['worker']['sources']==manifest['sources']
for p,h in original['worker']['sources'].items():assert sha(read(p))==h; check_blob(p)
cm=load(CORE/'metadata.json'); cs=load(CORE/'summary.json'); core_rows=rows(CORE/'results.jsonl')
for p,h in cm['source_sha256'].items():assert sha(read(CR/p))==h; check_blob(CR/p)
assert cm['source_revision']==REVS[CR] and cm['competition_id']==CID and cm['year']==YEAR
for name in ('results','metadata','summary'):assert hashes[str(CORE/(name+('.jsonl' if name=='results' else '.json')))]==item['archive_'+name+'_sha256']
sys.path.insert(0,str(SR))
from scripts.evaluate_observed_season import observed_capture
from scripts import compare_practice_supervisor as driver
from scripts.experiment_execution_costs import PARAMETERS
case=load(SR/'data/case.json')
receipt,frames,coverage=observed_capture(item['observations'],item['feed'],CID,case['limits'])
assert receipt==original['official_receipt']==cm['official_receipt'] and coverage==original['coverage']==cm['coverage']
assert receipt['at']==1792832203.4848561 and receipt['year']==YEAR
assert receipt['kind']=='settlement' and receipt['source']=='read_only_market_observer'
for clock in ('clock','end_clock'):
 assert receipt[clock]['competition_id']==CID and receipt[clock]['state']=='ready' and receipt[clock]['fictional_time'].startswith(YEAR+'-')
assert set(receipt['prices'])==set(case['limits']) and all(type(v) in (int,float) and math.isfinite(v) and v>0 for v in receipt['prices'].values())
assert value_hash(receipt)==cm['receipt_sha256']==original['worker']['receipt_sha256']=='dd8bb77cdf53d26457baa75631d634de42339ac2f06329e73bfdfd6b76e0d8e3'
assert value_hash(frames)==cm['frames_sha256']=='94e9b08a0044b4392b1cfccee8d225133c7e69cc38e0fa11f6498eb19e4b643e'
assert len(frames)==cm['frame_count']==22748
assert frames[0]['received_at']==cm['first_at'] and frames[-1]['received_at']==cm['last_at']<=receipt['at']
assert cm['receipt_at']==receipt['at'] and cm['fraction']==.1 and cm['parameters']==PARAMETERS
assert cm['source_sha256']=={str(p.relative_to(CR)):sha(read(p)) for p in driver.source_files(CR)}
assert len(original['worker']['sources'])==23 and original['worker']['start_at']==manifest['start_at'] and original['worker']['until']==manifest['until']
assert [f['received_at'] for f in frames]==sorted(f['received_at'] for f in frames)
cache={'receipt':receipt,'frames':frames,'coverage':coverage}
(OUT/'closed246-input.json').write_text(json.dumps(cache,allow_nan=False)+'\n')
cache_sha=sha((OUT/'closed246-input.json').read_bytes())
# Independent history and coverage reconstruction from selected explicit messages.
ages=list(range(0,481,2)); obs=collections.defaultdict(dict); age_counts=collections.Counter(); dupe_ages=collections.Counter(); seqs={}; duplicate_seq=0; finals={}; formations=collections.Counter(); snapshot_count=0
qt={str(r):{s:[] for s in case['limits']} for r in (1,2,3)}; rnd=None; phase=None; unusable=0; all_quote_count=0; disconnects=0; windows={}
for f in frames:
 if f['type']=='news':
  m=f['message']; assert str(m['time']).startswith(YEAR+'-'); rnd=m.get('round',rnd)
  windows.setdefault(str(rnd),{'first_at':f['received_at'],'closed_at':None})
  if m['type']=='snapshot':
   snapshot_count+=1; phase=m['phase']
   if phase=='closed' and windows[str(rnd)]['closed_at'] is None:windows[str(rnd)]['closed_at']=f['received_at']
  if 'seq' in m:
   seq=m['seq']; assert type(seq) is int and seq>=0
   if seq in seqs:duplicate_seq+=1; assert m==seqs[seq]
   seqs[seq]=m
  if m['type']=='storm_formed':formations[m['round']]+=1
  if m['type']=='damage_report' and m['stage']=='final':assert m['round'] not in finals; finals[m['round']]={'seq':m['seq'],'received_at':f['received_at']}
  if m['type']=='storm':
   r,a=m['round'],m['age']; assert r in (1,2,3) and type(a) is int and a in ages
   v=[m[k] for k in ('x','y','radius','intensity')]; assert all(type(x) in (int,float) and math.isfinite(x) for x in v)
   age_counts[r]+=1
   if a in obs[r]:dupe_ages[r]+=1; assert obs[r][a]==v
   obs[r][a]=v
 elif f['type']=='disconnected':disconnects+=1
 elif f['type']=='quote':
  all_quote_count+=1; v=[f.get(k) for k in ('bid','ask','bid_size','ask_size')]
  valid=all(type(x) in (int,float) and math.isfinite(x) for x in v) and 0<v[0]<=v[1] and min(v[2:])>=0
  if not valid:unusable+=1
  elif phase!='closed':qt[str(rnd)][f['symbol']].append(f['received_at'])
assert set(seqs)==set(range(863)) and len(seqs)==coverage['news_count'] and coverage['advertised_last_seq']==862
assert formations==collections.Counter({1:1,2:1,3:1}) and set(finals)=={1,2,3}
assert all_quote_count==coverage['quote_count']==21790 and unusable==coverage['unusable_quotes']==44 and disconnects==0
assert coverage['quote_count_by_round']=={r:{s:len(t) for s,t in ss.items()} for r,ss in qt.items()}
gaps=[]
for r,ss in qt.items():
 assert windows[r]['first_at']==coverage['round_windows'][r]['first_at'] and windows[r]['closed_at']==coverage['round_windows'][r]['closed_at']
 for s,times in ss.items():
  pts=[windows[r]['first_at'],*times,windows[r]['closed_at']]; gs=[b-a for a,b in zip(pts,pts[1:])]
  assert coverage['observed_quote_gaps'][r][s]=={'max_seconds':max(gs),'over_five_seconds':sum(g>5 for g in gs)}
  for i,g in enumerate(gs):gaps.append({'round':int(r),'symbol':s,'seconds':g,'opening_boundary':i==0,'closing_boundary':i==len(gs)-1,'start_at':pts[i],'end_at':pts[i+1]})
# All fixed row grids, all phase bindings, full equality gates.
grid=list(itertools.product([0.,.05,.25,1.],[1.,.5],[False,True])); required={(246,*x) for x in grid}
def key(r):return (r['rtt_seconds'],r['displayed_depth_fraction'],r['basket_enabled'])
def stats(rr,field):
 pp=[r[field] for r in rr]; assert all(type(x) in (int,float) and math.isfinite(x) for x in pp)
 return {'runs':len(rr),'positive':sum(p>0 for p in pp),'negative':sum(p<0 for p in pp),'worst':min(pp),'best':max(pp),'mean':sum(pp)/len(pp)}
assert len(original['results'])==24 and {(r['latency_seconds'],r['displayed_depth_fraction'],r['basket_enabled'],r['reset_warmup_each_snapshot']) for r in original['results']}==set(itertools.product([.25,1.,3.],[1.,.5],[False,True],[True,False]))
assert len(core_rows)==16 and {key(r) for r in core_rows}==set(grid) and all(r['status']=='ok' for r in core_rows)
assert cs['runs']==16 and cs['errors']==0
for row in core_rows:
 assert row['terminal_closed'] and row['final_report_rounds']==[1,2,3] and row['request_count']==sum(row['request_counts'].values()) and row['ignored_closed_quotes']==1 and row['unusable_quotes']==43
# Independently recompute core per-RTT arithmetic.
by_rtt={}
base0={(r['displayed_depth_fraction'],r['basket_enabled']):r['simulated_settlement_pnl'] for r in core_rows if r['rtt_seconds']==0}
for rtt in (0.,.05,.25,1.):
 rr=[r for r in core_rows if r['rtt_seconds']==rtt]; pp=[r['simulated_settlement_pnl'] for r in rr]; d=[r['simulated_settlement_pnl']-base0[(r['displayed_depth_fraction'],r['basket_enabled'])] for r in rr]
 by_rtt[str(rtt)]={'runs':len(rr),'errors':0,'mean_pnl':sum(pp)/4,'min_pnl':min(pp),'max_pnl':max(pp),'negative_pnl':sum(v<0 for v in pp),'zero_orders':sum(r['orders']==0 for r in rr),'mean_delta_vs_zero_rtt':sum(d)/4}
for rtt,calc in by_rtt.items():
 expected={'scenarios':calc['runs'],'errors':0,'mean_pnl':calc['mean_pnl'],'worst_pnl':calc['min_pnl'],'best_pnl':calc['max_pnl'],'negative_scenarios':calc['negative_pnl'],'zero_order_scenarios':calc['zero_orders'],'paired_mean_change_from_zero_rtt':calc['mean_delta_vs_zero_rtt'],'paired_scenarios':4}
 assert cs['by_rtt'][rtt]==expected

phases={}; phase_meta={}; phase_sum={}; source_counts={}
for ph in ('reference','baseline','supervised'):
 m=load(ATT/ph/'metadata.json'); s=load(ATT/ph/'summary.json'); rr=rows(ATT/ph/'results.jsonl'); phase_meta[ph]=m; phase_sum[ph]=s; phases[ph]={key(r):r for r in rr}
 assert len(rr)==16 and set(phases[ph])==set(grid) and m['phase']==ph and m['grid']==[list(x) for x in grid]
 assert s['runs']==16 and s['errors']==s['mismatches']==0 and s['changed_sources']==[] and s['finished_at']>=m['started_at']>receipt['at']
 assert s['results_sha256']==hashes[str(ATT/ph/'results.jsonl')]
 assert m['forward'] is True and m['fraction']==.1 and m['loss_trigger']==250. and m['prior_pnl']==0
 assert m['driver_revision']==m['forward_plan_revision']==REVS[SR] and m['runtime_revision']==REVS[HR]
 assert m['driver_sha256']==sha(read(SR/'scripts/compare_practice_supervisor.py')) and m['forward_plan_sha256']==sha(read(SR/'docs/supervised-forward-plan.md'))
 assert m['source_revision']==(REVS[CR] if ph=='reference' else REVS[SR])
 assert m['spec']==spec
 dep=driver.source_files(CR if ph=='reference' else SR)
 if ph!='reference':dep += [SR/'bot/practice.py',SR/'scripts/replay_practice_supervisor.py']
 dep += [SR/'scripts/compare_practice_supervisor.py',SR/'docs/supervised-replay-plan.md',SR/'docs/practice-round-transition-plan.md',ATT/'spec.json',SR/'docs/supervised-forward-plan.md',Path(item['observations']),Path(item['feed']),CORE/'results.jsonl',CORE/'metadata.json',CORE/'summary.json']
 dep += [Path(p) for p in m['runtime_sha256']]
 assert m['source_sha256']=={str(p):sha(read(p)) for p in dep}

 cap=m['captures'][0]; assert len(m['captures'])==1
 assert cap['capture']==246 and cap['competition_id']==CID and cap['year']==YEAR and cap['coverage']==coverage
 for name in ('receipt_sha256','frames_sha256','receipt_at','first_at','last_at','frame_count'):assert cap[name]==cm[name]
 assert cap['archive_sha256']==hashes[str(CORE/'results.jsonl')]
 for p,h in m['source_sha256'].items():
  assert sha(read(p))==h,p
  if any(Path(p).is_relative_to(r) for r in REVS):check_blob(p)
 for p,h in m['runtime_sha256'].items():assert sha(read(p))==h; check_blob(p,REVS[HR])
 assert len(m['runtime_sha256'])==28
 assert all(r['status']=='ok' and r['capture']==246 for r in rr)
 source_counts[ph]={'sources':len(m['source_sha256']),'runtime':len(m['runtime_sha256'])}
 if ph!='supervised':driver.completed_phase(ATT/ph/'results.jsonl',ph,required)
assert phase_meta['baseline']['reference_results_sha256']==phase_sum['reference']['results_sha256']
assert phase_meta['supervised']['baseline_results_sha256']==phase_sum['baseline']['results_sha256']
assert phase_meta['baseline']['started_at']>=phase_sum['reference']['finished_at'] and phase_meta['supervised']['started_at']>=phase_sum['baseline']['finished_at']
assert phase_meta['reference']['runtime_sha256']==phase_meta['baseline']['runtime_sha256']==phase_meta['supervised']['runtime_sha256']
for r in core_rows:
 k=key(r); ref=phases['reference'][k]; baseline=phases['baseline'][k]
 assert all(ref[x]==v for x,v in r.items())
 assert ref['comparison_status']=='matched_archive' and baseline['comparison_status']=='matched_archive_and_trace' and ref['different_fields']==baseline['different_fields']==[]
 assert {k:v for k,v in ref.items() if k!='comparison_status'}=={k:v for k,v in baseline.items() if k!='comparison_status'}
driver.verify_forward_archive(item,receipt,frames,cm['source_sha256'],PARAMETERS,reference_revision=REVS[CR])
assert driver.verify_forward_runtime(SR)==phase_meta['supervised']['runtime_sha256']
driver.forward_receipt_in_window(receipt); assert driver.capture_numbers(spec,True)==[246]; driver.sealed_forward_inputs(item)
# Compare each archived supervised result and journals; independently score cost-book rows at official prices.
expected_journals={'actions.jsonl','final-receipt.json','observations.json','result.json','run.lock','startup-feed.jsonl','status.json'}
journals={}; accounting=[]
for k,row in phases['supervised'].items():
 rtt,depth,basket=k; d=ATT/'supervised'/f'capture-246-{rtt}-{depth}-{int(basket)}'
 assert {p.name for p in d.iterdir()}==expected_journals
 journals[d.name]={p.name:sha(read(p)) for p in d.iterdir()}
 local=load(d/'result.json'); assert local=={n:v for n,v in row.items() if n not in ('capture','comparison_status')}
 final=load(d/'final-receipt.json'); assert final==row['observed_final_receipt']
 assert row['comparison_status']=='supervised_after_verified_baseline' and row['errors']==[] and row['trial_state']=='completed'
 assert row['trial']['completed'] and row['cleanup']['state']=='settled' and row['terminal_closed'] and row['final_report_rounds']==[1,2,3]
 assert row['history_block_reason'] is None and row['stop_reason']=='requested complete practice seasons recorded' and row['stop_phase']=='after_receipt'
 assert row['fills_after_final_receipt_requests']==0 and row['server_orders_after_final_receipt']==[]
 assert row['final_receipt']['verified'] and row['final_receipt']['history_ownership_clear']
 assert row['request_count']==sum(row['request_counts'].values())
 assert math.isclose(row['trial']['settlement_pnl'],row['terminal_settlement_pnl'],abs_tol=1e-7)
 positions=final['positions']['positions']
 assert {p['symbol']:p['quantity'] for p in positions}==row['final_positions']==row['server_positions_after_final_receipt']
 score=sum(p['realized_pnl']+p['quantity']*(receipt['prices'][p['symbol']]-(p['average_price'] or 0.)) for p in positions)
 marked=sum(p['realized_pnl']+p['unrealized_pnl'] for p in positions)
 assert math.isclose(score,row['terminal_settlement_pnl'],rel_tol=1e-12,abs_tol=1e-7) and math.isclose(marked,row['final_receipt']['pnl'],abs_tol=1e-7)
 accounting.append({'independent_official_score_from_final_positions':score,'independent_final_account_mark':marked,'setting':list(k),'terminal_settlement_pnl':row['terminal_settlement_pnl'],'trial_settlement_pnl':row['trial']['settlement_pnl'],'final_receipt_marked_pnl':row['final_receipt']['pnl']})
# Preserve only ledger prefixes ending with this capture's completed record.
ledger_records={}
for name,path,kind in [('original',REC/'fixed-observed-evaluation/ledger.jsonl','evaluated'),('core',REC/'serialized-forward/attempts.jsonl','attempt_completed'),('supervised',REC/'supervised-forward/attempts.jsonl','attempt_completed')]:
 b=bytearray(); selected=[]; done=None
 with path.open('rb') as f:
  for line in f:
   assert line.endswith(b'\n'); v=json.loads(line); b.extend(line)
   if v.get('competition_id')==CID:selected.append(v)
   if v.get('competition_id')==CID and v.get('kind')==kind:done=v; break
 assert done is not None
 p=OUT/(name+'-ledger-prefix.jsonl');p.write_bytes(b)
 prefixes[name+'_ledger']={'original':str(path),'bytes':len(b),'sha256':sha(b),'ends_at_target_completion':True}
 ledger_records[name]=selected
 if name=='original':assert done['artifact_sha256']==hashes[str(original_path)] and done['receipt_sha256']==value_hash(receipt)
 elif name=='core':
  assert done['scenario_count']==16 and done['scenario_errors']==0
  for n,h in done['artifact_sha256'].items():assert sha(read(CORE/n))==h
 else:
  for ph,h in done['phase_results_sha256'].items():assert sha(read(ATT/ph/'results.jsonl'))==h
  assert done['aggregate']['positive']==16 and done['aggregate']['negative']==0
  for entry in selected:
   if entry['kind']=='phase_completed':
    ph=entry['phase']; assert entry['summary']==phase_sum[ph] and entry['exit_status']==0
    for n,h in entry['artifact_sha256'].items():assert sha(read(ATT/ph/n))==h
   elif entry['kind']=='attempt_started':assert entry['spec_sha256']==sha(read(ATT/'spec.json'))
# Exact fitted analog overlap of all explicit observed weather points.
import numpy as np
lib=HR/'ctc/analog_library.npz'; lb=read(lib); assert sha(lb)=='22694387c3b612f5c20853feb9143e1bf8b8f5722a845da8ed584ab1b30bdf09'; check_blob(lib)
intro='51d48f701c6877214e612533280ccff1d955e382'; assert lb==git(HR,'show',intro+':ctc/analog_library.npz')
with np.load(lib,allow_pickle=False) as z:tracks=z['tracks'].copy()
assert tracks.shape==(1350,241,4) and np.isfinite(tracks).all()
overlap=[]
for r in (1,2,3):
 assert sorted(obs[r])==ages
 seen=np.array([obs[r][a] for a in ages],dtype=np.float64); delta=tracks-seen[None,:,:]
 ma=np.max(np.abs(delta),axis=(1,2)); rmse=np.sqrt(np.mean(delta*delta,axis=(1,2))); idx=np.flatnonzero(ma<1e-9); exact=np.flatnonzero(np.all(tracks==seen,axis=(1,2)))
 assert idx.tolist()==exact.tolist()==[3*(246-1)+(r-1)] and ma[idx[0]]==rmse[idx[0]]==0
 overlap.append({'round':r,'ages':ages,'age_count':241,'raw_observations':age_counts[r],'duplicate_ages':dupe_ages[r],'exact_unique_row_zero_based':int(idx[0]),'max_abs_error':float(ma[idx[0]]),'min_rmse':float(rmse.min()),'second_best_rmse':float(np.partition(rmse,1)[1]),'float64_track_sha256':sha(seen.tobytes())})
for name in ('scripts/build_library.py','ctc/analog.py','README.md'):check_blob(HR/name)
assert "man['seasons'][:450]" in (HR/'scripts/build_library.py').read_text()
aggregates={'original24':stats(original['results'],'simulated_settlement_pnl'),'original_current12':stats([r for r in original['results'] if not r['reset_warmup_each_snapshot']],'simulated_settlement_pnl'),'core16':stats(core_rows,'simulated_settlement_pnl'),'supervised16':stats(list(phases['supervised'].values()),'terminal_settlement_pnl')}
for key_,lk in [('worst','worst'),('best','best'),('mean','mean')]:assert aggregates['supervised16'][key_]==ledger_records['supervised'][-1]['aggregate'][lk]
changed=[p for p,h in hashes.items() if sha(Path(p).read_bytes())!=h]; assert changed==[] and forbidden==[]
assert all(git(r,'rev-parse','HEAD').decode().strip()==heads[str(r)] and git(r,'status','--porcelain','--untracked-files=normal').decode()==status[str(r)] for r in REVS)
report={'capture':246,'competition_id':CID,'year':YEAR,'receipt_sha256':value_hash(receipt),'frames_sha256':value_hash(frames),'closed_input_sha256':cache_sha,'receipt_at':receipt['at'],'receipt_at_utc':datetime.datetime.fromtimestamp(receipt['at'],datetime.timezone.utc).isoformat(),'first_at':frames[0]['received_at'],'last_at':frames[-1]['received_at'],'receipt_gap_seconds':receipt['at']-frames[-1]['received_at'],'frame_count':len(frames),'history':{'news_seq_count':len(seqs),'min_seq':min(seqs),'max_seq':max(seqs),'duplicate_news_sequences':duplicate_seq,'conflicting_duplicates':0,'snapshots':snapshot_count,'final_reports':finals,'formations':formations},'coverage':coverage,'largest_observed_gap':max(gaps,key=lambda v:v['seconds']),'largest_nonopening_gap':max((v for v in gaps if not v['opening_boundary']),key=lambda v:v['seconds']),'timing':{'original_configured_eligibility_start':1792821960,'serialized_source_freeze':1792826318,'runtime_freeze':1792828815,'driver_freeze':1792829252,'first_frame':frames[0]['received_at'],'all_selected_frames_after_all_freezes':frames[0]['received_at']>1792829252,'driver_to_first_frame_seconds':frames[0]['received_at']-1792829252},'prefixes':prefixes,'aggregates':aggregates,'core_summary_recomputed':by_rtt,'phase_summaries':phase_sum,'source_manifest_counts':source_counts,'source_input_sha256':hashes,'git_blob_verification':git_verified,'heads_before_after':heads,'statuses_unchanged_clean':True,'supervised_journal_sha256':journals,'supervised_accounting':accounting,'library_sha256':sha(lb),'library_same_at_introduction':intro,'overlap':overlap,'overlap_scalar_values':3*241*4,'source_lineage':{'selection':{'path':str(HR/'scripts/build_library.py'),'line':6,'expression':"build_library(root, man['seasons'][:450])"},'row_order':{'path':str(HR/'ctc/analog.py'),'line':42},'future_use':{'path':str(HR/'ctc/analog.py'),'line':191},'source_manifest_read':False,'full450_reconstruction':False},'changed_sources_inputs':changed,'forbidden_attempts':forbidden,'unseen_weather_validation':False,'live_owned_profit_claim':False,'active247_or_later_outcomes_read':False}
(OUT/'audit.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'aggregates':aggregates,'overlap':[{k:v for k,v in x.items() if k!='ages'} for x in overlap],'prefixes':prefixes,'source_manifest_counts':source_counts,'changed':changed,'forbidden':forbidden,'output':str(OUT)},indent=2))
