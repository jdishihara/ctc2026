from __future__ import annotations
import collections, contextlib, copy, hashlib, json, math, os, subprocess, sys
from collections.abc import Mapping
from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch
OUT=Path(__file__).resolve().parent; ENGINE=sys.argv[1]
ROOT=Path('/Users/arjunhans/Documents/ctc2026'); REC=ROOT/'recordings/consistency-20261024'; CID='83fc18b9-e9fd-4634-bc8e-c7a1a77768a7'
R=ROOT/('.worktrees/'+{'original':'closed-season-evaluation','core':'serialized-forward','supervised':'supervised-forward'}[ENGINE])
revs={'original':'49a690efec04f7dcaf6a616de81da2838afbf149','core':'505a5ad2d5a6f81e7c711cb550871ce7aa7f3734','supervised':'c5c35a30e0c5f521f12324eec854f405b681b8c0'}
forbidden=[]; active={}; violations=[]
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
  forbidden.append(event); raise RuntimeError('guarded replay forbids network')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  name=os.fsdecode(args[0]).lower()
  if '.botkey' in name or '/.env' in name or 'credentials' in name or '/data/history/' in name or name.endswith('/data/history'):
   forbidden.append(name); raise RuntimeError('guarded replay forbids credentials and downloaded history')
sys.addaudithook(audit)
def sha(b):return hashlib.sha256(b).hexdigest()
def vh(x):return sha(json.dumps(x,sort_keys=True,allow_nan=False).encode())
def git(*args):return subprocess.check_output(['git',*args],cwd=R,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}).decode().strip()
def enforce(ok,why):
 if not ok:
  violations.append(why); exc=AssertionError(why)
  if 'server' in active:active['server'].fatal_errors.append('AssertionError: '+why)
  raise exc
class GuardedSettlement(Mapping):
 def __init__(self,prices):self._prices=dict(prices)
 def check(self):
  if ENGINE=='original':
   ex=active['market']; good=ex.t>=cutoff and not ex.market_open and active['frames_processed']==len(frames)
  else:
   server=active['server']; good=server.terminal and not server.market.market_open and server.index==len(frames) and server.now>= (available if ENGINE=='supervised' else cutoff)
  enforce(good,'premature settlement price read'); active['settlement_reads']+=1
 def __getitem__(self,key):self.check();return self._prices[key]
 def __iter__(self):return iter(self._prices)
 def __len__(self):return len(self._prices)
 def copy(self):self.check();return dict(self)
 def __copy__(self):return self.copy()
 def __deepcopy__(self,memo):self.check();return GuardedSettlement(dict(self))
assert __debug__ and git('rev-parse','HEAD')==revs[ENGINE] and not git('status','--porcelain','--untracked-files=normal')
static=json.loads((OUT/'audit.json').read_text()); expected_sources={p:h for p,h in static['source_input_sha256'].items() if p.startswith(str(R)+'/')}
for p,h in expected_sources.items():assert sha(Path(p).read_bytes())==h
raw=(OUT/'closed246-input.json').read_bytes();assert sha(raw)==static['closed_input_sha256'];d=json.loads(raw)
receipt,frames=d['receipt'],d['frames']; assert vh(receipt)==static['receipt_sha256'] and vh(frames)==static['frames_sha256']
cutoff=frames[-1]['received_at']-frames[0]['received_at'];available=receipt['at']-frames[0]['received_at']
case=json.loads((R/'data/case.json').read_text())
sys.path.insert(0,str(R))
from ctc.strategies import FairValueTrader
original_quotes=FairValueTrader.on_quotes

def checked_quotes(strategy,exchange):
 enforce(strategy.competition_id==exchange.competition_id and strategy.competition_id,'quote identity mismatch')
 model=strategy.model; before=(set(model.reported_rounds),model.live_history_ready)
 result=original_quotes(strategy,exchange)
 enforce(strategy.model is model and (set(model.reported_rounds),model.live_history_ready)==before,'quote callback mutated history')
 active['quote_callbacks']+=1; return result

def record_conversion(original):
 def wrapped(ex,etf,qty,sign):
  result=original(ex,etf,qty,sign)
  if result:active['conversions'].append({'etf':etf,'qty':qty,'sign':sign,'time':ex.t})
  return result
 return wrapped

if ENGINE=='original':
 from scripts import replay_captured_market as replay
 OrigExchange=replay.ReplayExchange; OrigSession=replay.ReplaySession
 class Exchange(OrigExchange):
  def __init__(self,*a,**kw):super().__init__(*a,**kw);active['market']=self
 class Session(OrigSession):
  def __init__(self,*a,**kw):super().__init__(*a,**kw);active['session']=self
  def step(self,events):
   for frame,at in events:enforce(at<=self.ex.t and at==frame['received_at']-frames[0]['received_at'],'future original event')
   result=super().step(events);active['frames_processed']+=len(events);return result
 settings=[(.25,1.,True),(3.,.5,True)]
 archived=json.loads((REC/'fixed-observed-evaluation'/f'{CID}.json').read_text())['results']
else:
 from scripts import replay_serialized_client as core
 OriginalFrame=core.ReplayServer._frame
 def checked_frame(server,frame,at,closed_boundary=False):
  enforce(at<=server.now and frame['received_at']==server.start+at,'future frame delivery')
  enforce(frame['received_at']<=frames[-1]['received_at'],'frame beyond selected cutoff')
  active['frames_processed']+=1;return OriginalFrame(server,frame,at,closed_boundary)
 settings=[(.25,1.,True),(1.,.5,True)]
 if ENGINE=='core':
  ReplayServer=core.ReplayServer; OrigSession=core.AuditedSession; original_send=core.OfflineExchange.send
  class Server(ReplayServer):
   def __init__(self,*a,**kw):super().__init__(*a,**kw);active['server']=self;active['market']=self.market
  class Session(OrigSession):
   def __init__(self,*a,**kw):super().__init__(*a,**kw);active['session']=self
  def checked_send(exchange,method,path,body=None):
   if method=='POST':
    session=active['session'];enforce(session.strat.model.live_history_ready and session.history_block_reason() is None,'submission without ready history')
    enforce(not session.pending_news.is_set() and not session.stopped.is_set(),'submission with pending news or stopped')
    enforce(session.competition_id==exchange.competition_id==session.strat.competition_id,'submission identity mismatch')
   return original_send(exchange,method,path,body)
  archived=[json.loads(x) for x in (REC/'serialized-forward'/CID/'results.jsonl').read_text().splitlines()]
  refs=[json.loads(x) for x in (REC/'supervised-forward'/CID/'attempt-01/reference/results.jsonl').read_text().splitlines()]
 else:
  from scripts import replay_practice_supervisor as replay
  practice=replay.practice; OriginalServer=replay.PracticeReplayServer; OriginalSession=practice.PracticeSession; original_send=replay.ServerTransport.send
  class Server(OriginalServer):
   def __init__(self,*a,**kw):super().__init__(*a,**kw);active['server']=self;active['market']=self.market
  class Session(OriginalSession):
   def __init__(self,*a,**kw):super().__init__(*a,**kw);active['session']=self
  def checked_send(exchange,method,path,body=None):
   if method=='POST' and isinstance(exchange,replay.OfflinePracticeExchange):
    session=active['session'];enforce(not session._valid_weather_wait() and session.strat.model.live_history_ready,'submission without ready history')
    enforce(session.competition_id==exchange.competition_id==session.strat.competition_id,'submission identity mismatch')
    enforce(not session.pending_news.is_set() and not session.stopped.is_set(),'submission with pending news or stopped')
   if method=='POST' and isinstance(exchange,replay.OfflineCleanupExchange):
    q=exchange.position[body['symbol']]
    enforce(exchange.state_ready and exchange.market_open and not exchange.open_orders,'unreconciled cleanup submission')
    enforce(exchange.expected_id==exchange.competition_id,'cleanup identity mismatch')
    enforce(body['side']==('sell' if q>0 else 'buy') and 0<body['quantity']<=abs(q),'nonreducing cleanup order')
   return original_send(exchange,method,path,body)
  archived=[json.loads(x) for x in (REC/'supervised-forward'/CID/'attempt-01/supervised/results.jsonl').read_text().splitlines()]

def traces(server):
 return {'request_trace_sha256':vh([{k:v for k,v in r.items() if k!='response' or r['method']!='GET'} for r in server.requests]),'fill_trace_sha256':vh([asdict(f) for f in server.market.fills])}
results=[]
for latency,depth,basket in settings:
 active.clear();active.update(conversions=[],quote_callbacks=0,frames_processed=0,settlement_reads=0)
 prices=GuardedSettlement(receipt['prices']); out=OUT/'reproductions'/ENGINE/f'{latency}-{depth}-{int(basket)}';out.mkdir(parents=True,exist_ok=True)
 with contextlib.ExitStack() as stack:
  stack.enter_context(patch.object(FairValueTrader,'on_quotes',checked_quotes))
  if ENGINE=='original':
   stack.enter_context(patch.object(replay,'ReplayExchange',Exchange));stack.enter_context(patch.object(replay,'ReplaySession',Session));stack.enter_context(patch.object(Exchange,'_etf',record_conversion(Exchange._etf)))
   result=replay.replay(case,frames,'1781',prices,.1,latency,depth,basket,False)
   expected=next(r for r in archived if r['latency_seconds']==latency and r['displayed_depth_fraction']==depth and r['basket_enabled']==basket and not r['reset_warmup_each_snapshot'])
  else:
   stack.enter_context(patch.object(core.ReplayServer,'_frame',checked_frame))
   if ENGINE=='core':
    stack.enter_context(patch.object(core,'ReplayServer',Server));stack.enter_context(patch.object(core,'AuditedSession',Session));stack.enter_context(patch.object(core.OfflineExchange,'send',checked_send));stack.enter_context(patch.object(core.ReplayExchange,'_etf',record_conversion(core.ReplayExchange._etf)))
    result=core.replay_client(case,frames,'1781',CID,prices,rtt=latency,depth_scale=depth,basket=basket)
   else:
    stack.enter_context(patch.object(replay,'PracticeReplayServer',Server));stack.enter_context(patch.object(practice,'PracticeSession',Session));stack.enter_context(patch.object(replay.ServerTransport,'send',checked_send));stack.enter_context(patch.object(replay.AccountingReplayExchange,'_etf',record_conversion(replay.AccountingReplayExchange._etf)))
    result=replay.replay_supervised(case,frames,'1781',CID,prices,receipt_at=receipt['at'],out=out,rtt=latency,depth_scale=depth,basket=basket)
   expected=next(r for r in archived if r['rtt_seconds']==latency and r['displayed_depth_fraction']==depth and r['basket_enabled']==basket)
   expected={k:v for k,v in expected.items() if k not in ('capture','comparison_status')}
 different=[k for k in set(result)|set(expected) if result.get(k)!=expected.get(k)]
 assert different==[],different
 market=active['market'];assert active['frames_processed']==len(frames) and not forbidden and not violations
 # Independent cash and quantity accumulation from accepted fills and cash-neutral conversions.
 cash=0.;position=dict.fromkeys(case['limits'],0)
 for fill in market.fills:
  q=fill.qty*(1 if fill.side=='buy' else -1);position[fill.symbol]+=q;cash-=q*fill.price
 for c in active['conversions']:
  position[c['etf']]+=c['sign']*c['qty']
  for s,n in case['etfs'][c['etf']]['basket'].items():position[s]-=c['sign']*c['qty']*n
 assert position==market.position and math.isclose(cash,market.cash,rel_tol=1e-12,abs_tol=1e-8)
 score=cash+sum(q*receipt['prices'][s] for s,q in position.items())
 field='terminal_settlement_pnl' if ENGINE=='supervised' else 'simulated_settlement_pnl';assert math.isclose(score,result[field],abs_tol=1e-8)
 trace={};journal_hashes={}
 if ENGINE!='original':
  server=active['server'];assert not server.fatal_errors;trace=traces(server)
  if ENGINE=='core':
   ref=next(r for r in refs if r['rtt_seconds']==latency and r['displayed_depth_fraction']==depth and r['basket_enabled']==basket)
   assert all(trace[k]==ref[k] for k in trace)
  else:assert all(trace[k]==result[k] for k in trace)
  last=0.
  for request in server.requests:
   assert request['started_at']>=last and math.isclose(request['executed_at'],request['started_at']+latency/2,abs_tol=1e-8) and math.isclose(request['completed_at'],request['started_at']+latency,abs_tol=1e-8)
   last=request['completed_at']
  (out/'requests.audit.json').write_text(json.dumps(server.requests,allow_nan=False)+'\n')
 if ENGINE=='supervised':
  archive=REC/'supervised-forward'/CID/'attempt-01/supervised'/f'capture-246-{latency}-{depth}-{int(basket)}'
  for p in archive.iterdir():
   assert p.read_bytes()==(out/p.name).read_bytes(),p.name;journal_hashes[p.name]=sha(p.read_bytes())
 (out/'result.audit.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
 (out/'fills.audit.json').write_text(json.dumps([asdict(f) for f in market.fills],allow_nan=False)+'\n')
 (out/'conversions.audit.json').write_text(json.dumps(active['conversions'],allow_nan=False)+'\n')
 row={'engine':ENGINE,'setting':{'latency_or_rtt':latency,'depth':depth,'basket':basket,'reset_each_snapshot':False if ENGINE=='original' else None},'result_equal_all_archived_fields':True,'differing_fields':different,'pnl':result[field],'independent_cash':cash,'independent_quantities_equal':True,'independent_settlement_score':score,'orders':result['orders'],'fills':result['fills'],'conversions':result['conversions'],'frames_processed':active['frames_processed'],'quote_callbacks':active['quote_callbacks'],'guarded_settlement_reads':active['settlement_reads'],'journal_byte_equal_count':len(journal_hashes),'journal_sha256':journal_hashes,**trace}
 results.append(row);print(json.dumps(row),flush=True)
changed=[p for p,h in expected_sources.items() if sha(Path(p).read_bytes())!=h]
assert not changed and not forbidden and not violations and git('rev-parse','HEAD')==revs[ENGINE] and not git('status','--porcelain','--untracked-files=normal')
report={'engine':ENGINE,'frozen_revision':revs[ENGINE],'source_sha256':expected_sources,'closed_input_sha256':sha(raw),'runs':results,'changed_sources':changed,'forbidden_attempts':forbidden,'guard_violations':violations,'network_requests':0,'downloaded_history_reads':0,'alternative_settings_run':0,'active247_or_later_outcomes_read':False}
(OUT/(ENGINE+'-reproduction.json')).write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
