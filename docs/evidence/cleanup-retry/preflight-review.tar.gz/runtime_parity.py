"""Synthetic first-five parity plus post-deadline and completion-budget audit."""
import ast,copy,contextlib,hashlib,io,json,os,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
OUT=Path(__file__).parent;ROOT=Path('/Users/arjunhans/Documents/ctc2026/.worktrees/cleanup-retry-window')
forbidden=[]
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):forbidden.append(event);raise RuntimeError('network denied')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  names=[str(Path(os.fsdecode(args[0])).absolute()).lower(),str(Path(os.fsdecode(args[0])).resolve()).lower()]
  if any(any(x in n for x in ('/data/history/','/recordings/','.botkey','/.env','credentials','/ctc2026/out/')) for n in names):
   forbidden.append(names[0]);raise RuntimeError('actual inputs and credentials denied')
sys.addaudithook(audit)
sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from bot import practice
from test_practice_replay import setup,quote
from scripts.replay_practice_supervisor import OfflineCleanupExchange,VirtualTime
base=subprocess.check_output(['git','show','cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026:bot/practice.py'],cwd=ROOT,text=True)
current=(ROOT/'bot/practice.py').read_text()
def vh(v):return hashlib.sha256(json.dumps(v,sort_keys=True,allow_nan=False).encode()).hexdigest()
def function(src):return next(n for n in ast.parse(src).body if isinstance(n,ast.FunctionDef) and n.name=='reconcile_stop')
rows=[]
for mode in ['empty','delayed6','short_delayed6','partial','boundary61','late62','slow_firstfive','close_before_extra','unconfirmed_cancel','lost_ack_extra']:
 pair={}
 for version,src in [('baseline',base),('candidate',current)]:
  directory=OUT/('parity-'+mode+'-'+version);directory.mkdir()
  frames=[quote(0)]
  if mode in ('delayed6','short_delayed6','lost_ack_extra'):frames += [quote(6),quote(7)]
  if mode=='partial':frames += [quote(6,size=2),quote(8,size=2),quote(10,size=1)]
  if mode=='boundary61':frames += [quote(61)]
  if mode=='late62':frames += [quote(62)]
  end=6 if mode=='close_before_extra' else 10000
  server,journal,exchange=setup(directory,frames,end_at=end,available_at=end+1)
  virt=VirtualTime(server)
  with patch.object(practice,'time',virt),contextlib.redirect_stdout(io.StringIO()):
   side='sell' if mode=='short_delayed6' else 'buy'
   assert exchange.place('PORT',side,5,98 if side=='sell' else 101)
   server.market.available[('PORT','buy' if side=='sell' else 'sell')]=0
   if mode=='unconfirmed_cancel':assert exchange.place('PORT','sell',5,150)
  if mode=='slow_firstfive':server.rtt=2
  profile=[];raw=server.request;node=function(src);loop=next(n for n in node.body if isinstance(n,ast.For));scope=(loop.lineno,loop.end_lineno)
  def request(method,path,body=None):
   frame=sys._getframe(1);attempt=None
   while frame:
    if frame.f_code.co_name=='reconcile_stop' and scope[0]<frame.f_lineno<=scope[1]:attempt=frame.f_locals['attempt']
    frame=frame.f_back
   value=raw(method,path,body)
   profile.append(dict(attempt=attempt,request=copy.deepcopy(server.requests[-1])))
   if mode=='lost_ack_extra' and method=='POST' and server.now>=6:return None
   return value
  operation=server._operation
  def ops(method,path,body):
   if mode=='unconfirmed_cancel' and method=='DELETE':return None
   return operation(method,path,body)
  namespace=dict(vars(practice),time=virt,CleanupExchange=OfflineCleanupExchange)
  exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),str(ROOT/'bot/practice.py'),'exec'),namespace)
  with patch.object(practice,'time',virt),patch.object(server,'request',request),patch.object(server,'_operation',ops),contextlib.redirect_stdout(io.StringIO()):
   namespace['reconcile_stop'](journal,exchange)
  first=[r['request'] for r in profile if r['attempt'] is not None and r['attempt']<5]
  info=dict(state=journal.latest['cleanup']['state'],time=server.now,positions=server.market.position.copy(),first_five_hash=vh(first),first_five_requests=len(first),passes=sorted(set(x['attempt'] for x in profile if x['attempt'] is not None)),fatal_errors=server.fatal_errors,ownership_blocks=journal.ownership_blocks)
  assert not info['fatal_errors']
  (directory/'requests.json').write_text(json.dumps(profile,indent=2)+'\n');(directory/'audit.json').write_text(json.dumps(info,indent=2)+'\n')
  pair[version]=info
 assert pair['baseline']['first_five_hash']==pair['candidate']['first_five_hash'],mode
 if mode in ('delayed6','short_delayed6','partial','boundary61'):assert pair['candidate']['state']=='flat'
 if mode in ('empty','late62','unconfirmed_cancel'):
  assert pair['candidate']['state']=='attention' and len(pair['candidate']['passes'])==62
 if mode=='slow_firstfive':assert pair['candidate']['passes']==list(range(5)) and pair['candidate']['time']>61
 if mode=='lost_ack_extra':assert pair['candidate']['state']=='attention' and pair['candidate']['ownership_blocks']
 rows.append(dict(mode=mode,**pair))
# Completion-time timestamps conservatively retain long request windows.
clock=SimpleNamespace(now=0.,wall=1000.)
virt=SimpleNamespace(monotonic=lambda:clock.now,time=lambda:clock.wall)
checks=[]
with patch.object(practice,'time',virt):
 journal=practice.Journal(OUT/'completion-budget')
 clock.now=59.
 for i in range(90):journal.event('request',method='POST',path='/orders',response=None)
 for query,expected in [(60.,False),(119.,False),(119.0001,True)]:
  clock.now=query;actual=journal.extra_cleanup_mutation_allowed();assert actual is expected
  checks.append(dict(check='completion-retention',at=query,allowed=actual))
 for bad in [float('nan'),float('inf'),-1.]:
  clock.now=0.;j=practice.Journal(OUT/('invalid-query-'+str(bad)));j.event('cleanup_order',order_id=None)
  clock.now=bad;assert j.extra_cleanup_mutation_allowed() is False
  clock.now=100.;assert j.extra_cleanup_mutation_allowed() is False
  checks.append(dict(check='invalid-query-latches',bad=str(bad),allowed=False))
assert not forbidden
result=dict(pairs=rows,clock_checks=checks,first_five_pairs_exact=len(rows),forbidden_attempts=forbidden,actual_capture_runs=0,baseline_source_sha256=hashlib.sha256(base.encode()).hexdigest(),candidate_source_sha256=hashlib.sha256(current.encode()).hexdigest())
(OUT/'runtime-parity.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(first_five_pairs_exact=len(rows),clock_checks=len(checks),forbidden_attempts=forbidden,actual_capture_runs=0)))
