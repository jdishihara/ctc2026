synthetic plan only
