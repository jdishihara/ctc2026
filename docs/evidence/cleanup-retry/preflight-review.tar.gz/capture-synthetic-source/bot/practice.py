def reconcile_stop(server):
 for attempt in range(6):
  server.request("GET", "/positions", {"changed": True} if attempt==1 and server.attack=="first_five_changed" else None)
  if attempt==4 and server.attack in ("extra_91","extra_91_inclusive","extra_90_expired"):
   for i in range(90):server.request("DELETE", "/orders/synthetic")
   if server.attack=="extra_91_inclusive":server.now += 60
   if server.attack=="extra_90_expired":server.now += 60.00001
  if attempt==5:
   server.request("POST", "/orders", {"quantity":1})
   server.request("DELETE", "/orders/synthetic")
  if attempt==0 and server.attack=="whole_181":
   for i in range(181):server.request("POST", "/orders", {"quantity":1})
 server.request("GET", "/post-loop-final-receipt")
