import json,os,sys
from pathlib import Path
root=Path('/Users/arjunhans/Documents/ctc2026/.worktrees/cleanup-retry-window')
forbidden=[]
def guard(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
  forbidden.append(event);raise RuntimeError('offline review forbids network')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).absolute(); q=p.resolve()
  if any(any(n in str(x).lower() for n in ('/data/history/','/recordings/','.botkey','/.env','credentials','/ctc2026/out/')) for x in (p,q)):
   forbidden.append(str(p));raise RuntimeError('offline review forbids actual inputs/credentials')
sys.addaudithook(guard)
sys.path[:0]=[str(root),str(root/'tests')]
import runpy
if __debug__:raise RuntimeError('probe must run with -O')
try:runpy.run_path(str(root/'scripts/compare_cleanup_retry.py'),run_name='__main__')
except RuntimeError as exc:
 if 'assertions enabled' not in str(exc):raise
 result=dict(optimized_execution_rejected=True,message=str(exc),forbidden_attempts=forbidden,actual_capture_runs=0)
else:raise RuntimeError('optimized driver was not rejected')
(Path(__file__).parent/'optimized-probe.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
