"""Independent synthetic transition review; fake transport only."""
import ast,contextlib,copy,io,json,os,subprocess,sys
from pathlib import Path
from unittest.mock import patch
import pytest
ROOT=Path('/Users/arjunhans/Documents/ctc2026/.worktrees/cleanup-retry-window')
sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from bot import practice,live
from test_execution import CASE
from test_practice import setup,owned_history

def implementation():
 if os.environ.get('REVIEW_BASELINE')!='1':return practice.reconcile_stop
 source=subprocess.check_output(['git','show','cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026:bot/practice.py'],cwd=ROOT,text=True)
 fn=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='reconcile_stop')
 namespace=dict(vars(practice));exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),'<baseline-cleanup>','exec'),namespace)
 return namespace['reconcile_stop']

@pytest.mark.parametrize('quantity',[5,-5])
@pytest.mark.parametrize('late',[False,True])
@pytest.mark.parametrize('fault',['cancel_filled_uncertain','cancel_reversed_uncertain','cancel_partial_uncertain',
 'late_owned_open','send_rollover','send_closed','send_clock_missing','send_history_failure',
 'initial_flat_changes','initial_closed_reopens','empty_books','cancel_always_uncertain'])
def test_transition(setup,quantity,fault,late):
 if late and fault not in ('late_owned_open','send_rollover','send_closed','send_clock_missing','send_history_failure'):pytest.skip('initial-state condition; covered by normal variant')
 journal,original,_,_=setup;journal.start_trial(original);journal.activity['test-1']=1;journal.owned['test-1']={'mine'}
 state=dict(q=0 if fault=='initial_flat_changes' else quantity,open=fault.startswith('cancel_'),closed=fault=='initial_closed_reopens',cid='test-1',positions=0,clocks=0,book_count=0,history_after_book=0,injected=False)
 calls=[];posts=[]
 def get(path,api=True):
  calls.append(('GET',path))
  if path=='/cases/hurricane.json':return copy.deepcopy(CASE)
  if path=='/competitions/time':
   state['clocks']+=1
   if fault=='initial_closed_reopens' and state['clocks']>=3:state['closed']=False
   if state['history_after_book']>=2 and (not late or state['book_count']>=6):
    if fault=='send_rollover':state['cid']='test-2'
    if fault=='send_closed':state['closed']=True
   result=dict(competition_id=state['cid'],state='ready' if state['closed'] else 'running',fictional_time='1788-05-26T10:00:00')
   if fault=='send_clock_missing' and state['history_after_book']>=2 and (not late or state['book_count']>=6):result.pop('competition_id')
   return result
  if path=='/orders?limit=500':
   if state['book_count']:state['history_after_book']+=1
   if fault=='send_history_failure' and state['history_after_book']>=2 and (not late or state['book_count']>=6):raise OSError('synthetic history unavailable')
   return owned_history(journal,'test-1')
  if path=='/orders/open':return {'orders':[dict(order_id='mine',symbol='PORT',side='sell' if quantity>0 else 'buy',quantity=abs(quantity)*2,filled_quantity=0)] if state['open'] else []}
  if path=='/positions?include_zero=true':
   state['positions']+=1
   if fault=='initial_flat_changes' and state['positions']==2:state['q']=quantity
   return {'positions':[dict(symbol='PORT',quantity=state['q'],realized_pnl=0,unrealized_pnl=0)]}
  if path=='/trades':return {'trades':[]}
  if path=='/symbols':return {'symbols':[dict(symbol=s,settlement_active=True,settlement_price=100) for s in CASE['limits']]}
  if path=='/orderbook/PORT?depth=1':
   state['book_count']+=1
   if state['book_count']==1:state['position_reads_at_first_book']=state['positions']
   if fault=='late_owned_open' and not state['injected'] and (not late or state['book_count']>=6):state['open']=True;state['injected']=True
   levels=[] if fault=='empty_books' or (late and state['book_count']<6) else [dict(price=100)]
   return dict(bids=levels,asks=levels)
  raise AssertionError(path)
 def send(method,path,body=None):
  calls.append((method,path))
  if method=='DELETE':
   assert path=='/orders/mine'
   if fault=='cancel_always_uncertain':return None
   state['open']=False
   if fault=='cancel_filled_uncertain':state['q']=0
   if fault=='cancel_reversed_uncertain':state['q']=-quantity
   if fault=='cancel_partial_uncertain':state['q']=2 if quantity>0 else -2
   return None if fault.startswith('cancel_') else {}
  assert method=='POST' and path=='/orders'
  assert not state['open'] and not state['closed'] and state['cid']=='test-1'
  before=state['q'];delta=body['quantity']*(1 if body['side']=='buy' else -1)
  assert before*delta<0 and abs(delta)<=abs(before),(fault,quantity,before,body)
  posts.append(dict(before=before,body=copy.deepcopy(body),after=before+delta));state['q']+=delta
  return dict(order_id='close-'+str(len(posts)),status='filled',quantity=body['quantity'],filled_quantity=body['quantity'])
 with patch.object(live.LiveExchange,'get',side_effect=get),patch.object(live.LiveExchange,'send',side_effect=send),patch('bot.practice.time.sleep') as sleep,contextlib.redirect_stdout(io.StringIO()):
  implementation()(journal,original)
  sleeps=sleep.call_count
 cleanup=journal.latest['cleanup']['state'];deletes=[i for i,c in enumerate(calls) if c[0]=='DELETE']
 if fault in ('send_rollover','send_clock_missing','send_history_failure'):
  assert not posts and cleanup=='attention'
 elif fault=='send_closed':assert not posts and cleanup in ('settled','attention')
 elif fault=='empty_books':assert not posts and state['book_count']==62 and sleeps==62 and cleanup=='attention' and journal.latest['cleanup']['reason']=='cleanup retry limit'
 elif fault=='cancel_always_uncertain':assert not posts and not state['book_count'] and len(deletes)==62 and sleeps==62 and cleanup=='attention'
 elif fault=='cancel_filled_uncertain':assert not posts and cleanup=='flat' and not state['book_count']
 else:
  assert len(posts)==1 and cleanup=='flat' and state['q']==0
  expected=-quantity if fault=='cancel_reversed_uncertain' else (2 if quantity>0 else -2) if fault=='cancel_partial_uncertain' else quantity
  assert posts[0]['before']==expected
 if deletes:
  for i in deletes:
   nextbook=next((j for j in range(i+1,len(calls)) if calls[j][1].startswith('/orderbook/')),len(calls))
   assert ('GET','/positions?include_zero=true') in calls[i+1:nextbook]
 if fault in ('initial_flat_changes','initial_closed_reopens'):assert state['position_reads_at_first_book']==2
 print(json.dumps(dict(fault=fault,quantity=quantity,late=late,baseline=os.environ.get('REVIEW_BASELINE')=='1',posts=posts,cleanup=cleanup,book_count=state['book_count'],deletes=len(deletes),sleeps=sleeps),sort_keys=True))
