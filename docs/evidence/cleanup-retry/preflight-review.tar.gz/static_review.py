import ast,hashlib,importlib.util,json,os,subprocess,sys,difflib
from pathlib import Path
OUT=Path(__file__).parent;ROOT=Path('/Users/arjunhans/Documents/ctc2026/.worktrees/cleanup-retry-window');BASE=Path('/Users/arjunhans/Documents/ctc2026/.worktrees/practice-history')
SPEC=Path('/Users/arjunhans/Documents/ctc2026/out/cleanup-retry-window-20261024/spec.json')
HEAD='27ab7c4b4784c9aabc92e791b0878d387cd4cc49';FROZEN='cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026'
forbidden=[]
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):forbidden.append(event);raise RuntimeError('network denied')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).absolute();q=p.resolve()
  if any(any(x in str(n).lower() for x in ('/data/history/','/recordings/','.botkey','/.env','credentials')) or '/ctc2026/out/' in str(n).lower() and n!=SPEC for n in (p,q)):
   forbidden.append(str(p));raise RuntimeError('actual inputs and credentials denied')
sys.addaudithook(audit)
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(path):
 sp=importlib.util.spec_from_file_location('driver_review',path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
assert git(ROOT,'rev-parse','HEAD').decode().strip()==HEAD
assert git(BASE,'rev-parse','HEAD').decode().strip()==FROZEN
assert not git(ROOT,'status','--porcelain') and not git(BASE,'status','--porcelain')
driver=load(ROOT/'scripts/compare_cleanup_retry.py');files=driver.runtime_files(BASE)
rows=[];changes=[]
for b in files:
 name=b.relative_to(BASE).as_posix();c=ROOT/name
 old=git(BASE,'show',FROZEN+':'+name);new=git(ROOT,'show',HEAD+':'+name)
 assert b.read_bytes()==old and c.read_bytes()==new
 if old!=new:changes.append(name)
 rows.append(dict(path=name,baseline_sha256=sha(b),candidate_sha256=sha(c),changed=old!=new))
assert changes==['bot/practice.py']
spec=json.loads(SPEC.read_text());assert [x['capture'] for x in spec['captures']]==list(range(241,248))
assert Path(spec['baseline_root']).resolve()==BASE.resolve()
for c in spec['captures']:
 assert len(c['input_sha256'])==64 and set(c['archive_sha256'])=={'metadata.json','summary.json','results.jsonl'}
assert len(driver.GRID)==112 and len(set(driver.GRID))==112
old=Path('/Users/arjunhans/Documents/ctc2026/.worktrees/cleanup-empty-cancel/scripts/compare_cleanup_refresh.py').read_text();new=(ROOT/'scripts/compare_cleanup_retry.py').read_text()
(OUT/'driver-reviewed.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='reviewed74c81f4/compare_cleanup_refresh.py',tofile=HEAD+'/compare_cleanup_retry.py')))
(OUT/'runtime-reviewed.diff').write_bytes(git(ROOT,'diff',FROZEN,'--','bot/practice.py'))
(OUT/'practice-reviewed.py').write_bytes((ROOT/'bot/practice.py').read_bytes())
(OUT/'driver-reviewed.py').write_text(new)
(OUT/'plan-reviewed.md').write_bytes((ROOT/'docs/cleanup-retry-window-plan.md').read_bytes())
(OUT/'tests-reviewed.py').write_bytes((ROOT/'tests/test_cleanup_retry_window.py').read_bytes())
(OUT/'spec-reviewed.json').write_bytes(SPEC.read_bytes())
result=dict(candidate_head=HEAD,baseline_head=FROZEN,candidate_clean=True,baseline_clean=True,source_files=rows,git_blobs_verified=len(rows)*2,only_runtime_change=changes,grid=driver.GRID,spec_sha256=sha(SPEC),spec_capture_ids=[x['capture'] for x in spec['captures']],actual_input_contents_read=False,forbidden_attempts=forbidden,actual_capture_runs=0,plan_commit=git(ROOT,'log','-1','--format=%H %cI','fb0b6b0').decode().strip(),candidate_commit=git(ROOT,'log','-1','--format=%H %cI').decode().strip(),reviewed_sha256={n:sha(ROOT/n) for n in ['bot/practice.py','scripts/compare_cleanup_retry.py','tests/test_cleanup_retry_window.py','docs/cleanup-retry-window-plan.md']})
(OUT/'static-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('source_files','grid')}))
