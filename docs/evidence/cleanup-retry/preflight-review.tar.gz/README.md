# Independent cleanup retry preflight

Exact source: `27ab7c4b4784c9aabc92e791b0878d387cd4cc49`. Read `verdict.json` for scope and decision.

No captured-market performance was run. The complete 112-row main paths use deterministic synthetic replay modules and generated local fixtures. All phase result rows are retained; the first and last generated journal/profile directories are examples. Their complete remaining temporary fixture output remains at the origin directory recorded in the manifest. The scripts regenerate those synthetic fixtures.

`guarded_tests.py` runs the 97 focused production tests. `run_race_tests.py` runs 40 additional position/cancellation/ownership/close races (14 deliberately inapplicable parameter crosses are skipped). `runtime_parity.py` uses the production cleanup adapters and synthetic virtual quotes for ten baseline/candidate first-five trace pairs and six completion-clock checks.

`capture_probe.py` executes the actual comparison main through 23 full synthetic phases, including twenty swallowed safety failures and one changed-first-five case. `expiry-boundary/expiry_probe.py` adds two successful 112-row phases at the strict 60-second expiry boundary. `probe_gate.py` executes the candidate prerequisite AST with valid 112-row artifacts and 22 corruptions. `optimized_probe.py` verifies fail-fast under Python -O.

All retained harnesses install an outer audit hook denying network, credentials, downloaded history, recordings and real performance inputs. `static_review.py` additionally permits only the declared spec JSON; it never reads the listed capture/cache/archive contents. The exact original review logs are retained. No source checkout was written.

Archive members are bound by `artifact-manifest.json`.
