"""Read-only review probe: current order-book placement widens the position race."""
import ast
import contextlib
import copy
import io
import os
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch
import pytest

ROOT = Path('/Users/arjunhans/Documents/ctc2026/.worktrees/cleanup-retry-window')
sys.path[:0] = [str(ROOT), str(ROOT / 'tests')]
from bot import practice, live
from test_execution import CASE
from test_practice import setup, owned_history


def simulate(setup, after_book, implementation, late):
    journal, original, _, _ = setup
    journal.start_trial(original)
    journal.activity['test-1'] = 1
    journal.owned['test-1'] = {'mine'}
    state = {'q': 5, 'book_seen': False, 'books': 0}
    posts = []
    def get(path, api=True):
        if path == '/cases/hurricane.json': return copy.deepcopy(CASE)
        if path == '/competitions/time':
            return {'competition_id': 'test-1', 'state': 'running', 'fictional_time': '1788-05-26T10:00:00'}
        if path == '/orders?limit=500': return owned_history(journal, 'test-1')
        if path == '/orders/open': return {'orders': []}
        if path == '/positions?include_zero=true':
            return {'positions': [{'symbol': 'PORT', 'quantity': state['q'], 'realized_pnl': 0, 'unrealized_pnl': 0}]}
        if path == '/trades': return {'trades': []}
        if path == '/orderbook/PORT?depth=1':
            state['books'] += 1
            if late and state['books']<6:return {'bids':[], 'asks':[]}
            if not state['book_seen']:
                state['q'] = after_book
                state['book_seen'] = True
            return {'bids': [{'price': 100}], 'asks': [{'price': 101}]}
        raise AssertionError(path)
    def send(method, path, body=None):
        assert method == 'POST' and path == '/orders'
        before = state['q']
        delta = body['quantity'] * (1 if body['side'] == 'buy' else -1)
        posts.append({'before': before, 'body': copy.deepcopy(body), 'after': before + delta,
                      'strict_reduction': before * delta < 0 and abs(delta) <= abs(before)})
        state['q'] += delta
        return {'order_id': 'close-' + str(len(posts)), 'status': 'filled',
                'quantity': body['quantity'], 'filled_quantity': body['quantity']}
    with patch.object(live.LiveExchange, 'get', side_effect=get), \
         patch.object(live.LiveExchange, 'send', side_effect=send), \
         patch('bot.practice.time.sleep'), contextlib.redirect_stdout(io.StringIO()):
        implementation(journal, original)
    return posts


@pytest.mark.parametrize('after_book', [0, 2, -5])
@pytest.mark.parametrize('late',[False,True])
def test_cleanup_must_not_add_risk_after_book_time_position_change(setup, after_book,late):
    implementation = practice.reconcile_stop
    if os.environ.get('REVIEW_BASELINE') == '1':
        source = subprocess.check_output(['git', 'show', 'cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026:bot/practice.py'], cwd=ROOT, text=True)
        function = next(node for node in ast.parse(source).body if isinstance(node, ast.FunctionDef) and node.name == 'reconcile_stop')
        namespace = dict(vars(practice))
        exec(compile(ast.fix_missing_locations(ast.Module(body=[function], type_ignores=[])), '<baseline-cleanup>', 'exec'), namespace)
        implementation = namespace['reconcile_stop']
    posts = simulate(setup, after_book, implementation,late)
    assert all(p['strict_reduction'] for p in posts), posts
