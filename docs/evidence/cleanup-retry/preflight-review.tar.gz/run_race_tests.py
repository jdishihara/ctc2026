import json,os,sys
from pathlib import Path
root=Path('/Users/arjunhans/Documents/ctc2026/.worktrees/cleanup-retry-window')
forbidden=[]
def guard(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
  forbidden.append(event);raise RuntimeError('offline review forbids network')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).absolute(); q=p.resolve()
  if any(any(n in str(x).lower() for n in ('/data/history/','/recordings/','.botkey','/.env','credentials','/ctc2026/out/')) for x in (p,q)):
   forbidden.append(str(p));raise RuntimeError('offline review forbids actual inputs/credentials')
sys.addaudithook(guard)
sys.path[:0]=[str(root),str(root/'tests')]
import pytest
code=pytest.main(['-q','-rA','-p','no:cacheprovider',str(Path(__file__).parent/'test_transition_review.py'),str(Path(__file__).parent/'test_position_race.py')])
(Path(__file__).parent/'runtime-race-test-result.json').write_text(json.dumps(dict(exit_code=code,forbidden_attempts=forbidden,actual_capture_runs=0),indent=2)+'\n')
raise SystemExit(code)
