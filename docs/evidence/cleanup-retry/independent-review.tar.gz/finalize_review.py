"""Verify retained audit outputs and package them; no replay execution."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import math
import subprocess
import sys
import tarfile

OUT = Path(__file__).parent
ROOT = Path('/Users/arjunhans/Documents/ctc2026')
SOURCE = ROOT / '.worktrees/cleanup-retry-window'
RUN = ROOT / 'out/cleanup-retry-window-20261024'
REV = '27ab7c4b4784c9aabc92e791b0878d387cd4cc49'
EXPECTED = {(244, 0., .5, False), (244, 0., .5, True), (247, 0., 1., False),
            (247, 0., .5, False), (247, 0., .5, True), (247, .25, 1., True),
            (244, 1., .5, False), (243, 1., .5, False)}


def guard(event, args):
    if event.startswith('socket.'): raise RuntimeError('network forbidden')
    if event == 'open' and isinstance(args[0], (str, bytes)):
        if any(s in str(args[0]).lower() for s in ['.botkey', '/.env', 'credentials', '/data/history/']):
            raise RuntimeError('credentials/history forbidden')


sys.addaudithook(guard)
def sha(data): return hashlib.sha256(data).hexdigest()
def digest(path): return sha(Path(path).read_bytes())
def vh(value): return sha(json.dumps(value, sort_keys=True, allow_nan=False).encode())
def load(path): return json.loads(Path(path).read_bytes())
def case_name(k): return f'capture-{k[0]}-{k[1]}-{k[2]}-{int(k[3])}'


def main():
    baseline, candidate, analyzer = (load(OUT / n) for n in ['baseline-audit.json', 'candidate-audit.json', 'analyzer-check.json'])
    reruns = load(OUT / 'authorized-reruns/independent-reruns.json')
    assert baseline['candidate_revision'] == candidate['candidate_revision'] == reruns['candidate_revision'] == REV
    assert candidate['failed_rules'] == [] and candidate['source_unchanged'] and reruns['sources_unchanged']
    assert all(a['forbidden_attempts'] == [] for a in [baseline, candidate, analyzer, reruns])
    assert analyzer['synthetic_cases'] == 18 and all(c['passed'] for c in analyzer['cases'])
    assert len(reruns['cases']) == 8 and {tuple(c['setting']) for c in reruns['cases']} == EXPECTED
    originals = {tuple(r[n] for n in ['capture', 'rtt_seconds', 'displayed_depth_fraction', 'basket_enabled']): r
                 for r in map(json.loads, (RUN / 'candidate/results.jsonl').read_text().splitlines())}
    source_checks = {p: digest(p) for p in candidate['source_input_hashes']}
    assert source_checks == candidate['source_input_hashes'] == baseline['source_input_hashes']
    assert all(digest(p) == h for p, h in candidate['produced_file_hashes'].items())
    assert subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'], text=True).strip() == REV
    assert not subprocess.check_output(['git', '-C', str(SOURCE), 'status', '--porcelain', '--untracked-files=no'])
    exact_files, full_trace_pairs, budget_checks = 0, 0, []
    retained_cases = []
    for record in reruns['cases']:
        k = tuple(record['setting']); original = originals[k]
        directory = OUT / 'authorized-reruns' / case_name(k)
        assert record['all_result_fields_exact'] and record['fatal_errors'] == []
        assert record['exact_journal_profile_files'] == original['journal_sha256']
        result = load(directory / 'result.json')
        assert all(original[n] == value for n, value in result.items())
        for n, h in original['journal_sha256'].items():
            assert digest(directory / n) == h; exact_files += 1
        with gzip.open(directory / 'request-trace.json.gz', 'rt') as stream: requests = json.load(stream)
        with gzip.open(directory / 'fill-trace.json.gz', 'rt') as stream: fills = json.load(stream)
        normalized = [{n: value for n, value in r.items() if n != 'response' or r['method'] != 'GET'} for r in requests]
        assert vh(requests) == record['full_response_trace_sha256']
        assert vh(normalized) == record['request_trace_sha256'] == original['request_trace_sha256']
        assert vh(fills) == record['fill_trace_sha256'] == original['fill_trace_sha256']
        assert len(requests) == original['request_count'] and len(fills) == original['fills']
        assert math.isclose(record['pnl'], original['terminal_settlement_pnl'], rel_tol=0, abs_tol=1e-7)
        full_trace_pairs += 1; budget_checks.extend(record['budget_checks'])
        retained_cases.append({'setting': record['setting'], 'pnl': original['terminal_settlement_pnl'],
            'stop_reason': original['stop_reason'], 'trial': original['trial_state'], 'cleanup': original['cleanup']['state'],
            'cleanup_seconds': original['cleanup_completed_at'] - original['cleanup_started_at'],
            'requests': len(requests), 'fills': len(fills), 'conversions': original['conversions'], 'exact_files': 9})
    assert exact_files == 72 and full_trace_pairs == 8
    assert len(budget_checks) == 13 and all(c['allowed'] and c['retained_events'] < 90 for c in budget_checks)
    assert max(c['retained_events'] for c in budget_checks) == 26
    duplicate_outputs = [
        (OUT / 'authorized-reruns-invocation-02/capture-244-0.0-0.5-0', (244, 0., .5, False)),
        (OUT / 'authorized-reruns-invocation-03-failed-case', (247, 0., .5, True)),
    ]
    for directory, k in duplicate_outputs:
        for name, h in originals[k]['journal_sha256'].items(): assert digest(directory / name) == h
    for path in ['bot/practice.py', 'scripts/compare_cleanup_retry.py', 'docs/cleanup-retry-window-plan.md', 'tests/test_cleanup_retry_window.py']:
        original = subprocess.check_output(['git', '-C', str(SOURCE), 'show', f'{REV}:{path}'])
        assert original == (SOURCE / path).read_bytes()
        destination = OUT / 'reviewed-source' / path
        destination.parent.mkdir(parents=True, exist_ok=True); destination.write_bytes(original)
    verdict = {
        'verdict': 'APPROVE_EXACT_RETRY_CHANGE_AGAINST_PREDECLARED_OFFLINE_INTEGRATION_GATES',
        'candidate_revision': REV, 'baseline_revision': baseline['baseline_revision'], 'blockers': [],
        'source_input_artifacts_verified': 862, 'runtime_git_blobs_verified': 56,
        'baseline_original_journals_byte_exact': 784, 'produced_journal_profile_hashes_verified': 2016,
        'bound_baseline_artifacts': 1011, 'settings_per_phase': 112,
        'pre_cleanup_and_stop_pairs_equal': 112, 'initialization_and_first_five_request_pairs_equal': 112,
        'unchanged_runtime_results': 107, 'unchanged_original_journals': 749,
        'metrics': candidate['metrics'], 'pnl_pair_counts': candidate['pair_counts'],
        'failed_rules': [], 'previous_attention_cases_now_flat': 5, 'residual_symbol_settings_reduced': 9,
        'extra_pass_actual_mutations': 13, 'extra_post_count': 11, 'extra_delete_count': 2,
        'maximum_whole_stream_rolling_mutations': 33,
        'reproduced_completion_clock_budget_checks': len(budget_checks), 'maximum_prior_completion_events_at_extra_check': 26,
        'unique_authorized_reproductions': 8, 'reproduced_journal_profile_files_byte_exact': 72,
        'full_request_fill_trace_pairs': 8, 'reproductions': retained_cases,
        'analyzer_synthetic_cases_passed': 18, 'other_scenarios_or_variants': 0,
        'audit_invocations': [
            {'invocation': 1, 'replay_executions': 0, 'reason': 'System Python missing websockets; use existing project venv.'},
            {'invocation': 2, 'replay_executions': 1, 'reason': 'Exact result and 9 files; independent trace digest mistakenly included GET responses; repeated same setting to retain full trace.'},
            {'invocation': 3, 'replay_executions': 5, 'successful_cases_retained': 4, 'reason': 'Fifth result and 9 files exact; independent zero-conversion assertion too narrow; accounting corrected for three identical cash-neutral ARCH transfers.'},
            {'invocation': 4, 'replay_executions': 3, 'successful_cases_reused': 4, 'reason': 'Finish original seven unique settings.'},
            {'invocation': 5, 'replay_executions': 1, 'successful_cases_reused': 7, 'reason': 'Explicitly authorized slow loss-stop 243 setting; original requested 244 setting completed.'},
        ],
        'total_replay_executions': 10, 'duplicate_audit_assertion_executions': 2,
        'frozen_runtime_failures': 0, 'forbidden_attempts': [], 'sources_unchanged': True,
        'evidence_sha256': {n: digest(OUT / n) for n in ['baseline-audit.json', 'candidate-audit.json', 'analyzer-check.json', 'authorized-reruns/independent-reruns.json', 'README.md']},
        'declined_to_judge': ['Live account ownership or activation.', 'Consistent live profitability and unfamiliar-weather generalization.',
            'True quote completeness, live fill priority or market impact.', 'Hard total cleanup or loss bound; the original five passes may exceed 61 seconds.'],
    }
    (OUT / 'verdict.json').write_text(json.dumps(verdict, indent=2, sort_keys=True, allow_nan=False) + '\n')
    archive_name, manifest_name = 'independent-review.tar.gz', 'artifact-manifest.json'
    excluded = {archive_name, manifest_name, 'archive-receipt.json'}
    files = [p for p in OUT.rglob('*') if p.is_file() and p.name not in excluded
             and 'analyzer-synthetic' not in p.relative_to(OUT).parts and '__pycache__' not in p.relative_to(OUT).parts]
    payload = {str(p.relative_to(OUT)): p.read_bytes() for p in files}
    manifest = {'files': {n: {'bytes': len(data), 'sha256': sha(data)} for n, data in sorted(payload.items())},
                'payload_files': len(payload), 'source_revision': REV,
                'generated_analyzer_fixture_scope': 'Not copied into archive; retained at origin and regenerated by check_analyzer.py.'}
    (OUT / manifest_name).write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    payload[manifest_name] = (OUT / manifest_name).read_bytes()
    archive = OUT / archive_name
    with tarfile.open(archive, 'w:gz') as tf:
        for name, data in sorted(payload.items()):
            assert '..' not in PurePosixPath(name).parts
            info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o644; info.mtime = 0
            tf.addfile(info, io.BytesIO(data))
    with tarfile.open(archive) as tf:
        assert len(tf.getmembers()) == len(payload)
        for member in tf.getmembers(): assert member.isfile() and tf.extractfile(member).read() == payload[member.name]
    receipt = dict(archive=str(archive), bytes=archive.stat().st_size, sha256=digest(archive), member_files=len(payload),
                   verdict_sha256=digest(OUT / 'verdict.json'), source_revision=REV)
    (OUT / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__': main()
