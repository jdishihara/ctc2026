"""Exercise frozen analyzer decision logic on generated rows; no replay or strategy."""
from pathlib import Path
import contextlib
import copy
import hashlib
import io
import itertools
import json
import math
import runpy
import sys

OUT = Path(__file__).parent
ANALYZER = Path('/Users/arjunhans/Documents/ctc2026/out/cleanup-retry-window-20261024/analyze.py')
EXPECTED = '7abc2a98b45769399ce14e5622e8dabc8fcc236c8b499d71977c9b9a1e071010'
GRID = list(itertools.product(range(241, 248), [0., .05, .25, 1.], [1., .5], [False, True]))
forbidden = []


def guard(event, args):
    if event.startswith('socket.'):
        forbidden.append('network'); raise RuntimeError('network forbidden')
    if event == 'open' and isinstance(args[0], (str, bytes)):
        path = str(args[0]).lower()
        if any(s in path for s in ['.botkey', '/.env', 'credentials', '/data/history/', '/recordings/', '/cleanup-retry-window-20261024/candidate/']):
            forbidden.append('restricted input'); raise RuntimeError('real history/candidate/credentials forbidden')


sys.addaudithook(guard)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def dump(path, obj):
    path.write_text(json.dumps(obj, sort_keys=True, allow_nan=False) + '\n')


def base_rows():
    rows = []
    for c, r, d, b in GRID:
        rows.append(dict(capture=c, rtt_seconds=r, displayed_depth_fraction=d, basket_enabled=b,
            status='ok', errors=[], terminal_settlement_pnl=100., cleanup={'state': 'settled'}, trial_state='completed',
            stop_reason='complete', cleanup_started_at=10., cleanup_completed_at=20.,
            server_positions_after_final_receipt={}, server_orders_after_final_receipt=[],
            lowest_marked_pnl=0., maximum_marked_drawdown=10., maximum_rolling_mutations=10,
            extra_pass_mutations=0, pre_cleanup_trace={'requests_sha256': 'r', 'fills_sha256': 'f'},
            first_five_requests_sha256='unchanged'))
    rows[0].update(cleanup={'state': 'attention'}, trial_state='incomplete_trial', stop_reason='loss trigger',
                   server_positions_after_final_receipt={'REIN': -6})
    return rows


def write_phase(directory, rows, profiles, summary_change=None):
    directory.mkdir(parents=True, exist_ok=True)
    for row in rows:
        c, r, d, b = (row[n] for n in ['capture', 'rtt_seconds', 'displayed_depth_fraction', 'basket_enabled'])
        p = directory / f'capture-{c}-{r}-{d}-{int(b)}'
        p.mkdir(exist_ok=True)
        dump(p / 'cleanup-profile.json', profiles.get((c, r, d, b), []))
    data = b''.join((json.dumps(row, sort_keys=True, allow_nan=False) + '\n').encode() for row in rows)
    (directory / 'results.jsonl').write_bytes(data)
    summary = dict(runs=112, errors=0, changed_sources=[], forbidden_attempts=[], results_sha256=sha(data), finished_at=1.)
    if summary_change: summary.update(summary_change)
    dump(directory / 'summary.json', summary)


def main():
    assert sha(ANALYZER.read_bytes()) == EXPECTED
    results = []
    tests = [
        ('strict_residual_reduction', [], False),
        ('worse_worst', ['worse worst terminal P&L'], False),
        ('negative_increase', ['worse worst terminal P&L', 'more negative settings', 'new negative setting'], False),
        ('new_negative_same_total', ['new negative setting'], False),
        ('new_attention', ['new attention setting'], False),
        ('residual_increase', ['increased absolute residual exposure'], False),
        ('no_residual_reduction', ['no improvement to residual holdings in attention outcomes'], False),
        ('individual_regression_retained', [], False),
        ('profile_metrics', [], False),
        ('pre_cleanup_changed', None, True),
        ('first_five_changed', None, True),
        ('mutation_ceiling', None, True),
        ('source_change', None, True),
        ('forbidden_access', None, True),
        ('error_summary', None, True),
        ('duplicate_grid', None, True),
        ('error_row', None, True),
        ('results_hash_mismatch', None, True),
    ]
    for name, failures, rejects in tests:
        baseline = base_rows(); candidate = copy.deepcopy(baseline)
        candidate[0].update(cleanup={'state': 'flat'}, server_positions_after_final_receipt={})
        summaries, profiles = {}, {}
        if name == 'worse_worst': candidate[1]['terminal_settlement_pnl'] = 99.
        elif name == 'negative_increase': candidate[1]['terminal_settlement_pnl'] = -1.
        elif name == 'new_negative_same_total':
            baseline[1]['terminal_settlement_pnl'] = -10.
            candidate[2]['terminal_settlement_pnl'] = -1.
        elif name == 'new_attention':
            candidate[1].update(cleanup={'state': 'attention'}, server_orders_after_final_receipt=[{'id': 'unconfirmed'}])
        elif name == 'residual_increase': candidate[1]['server_positions_after_final_receipt'] = {'REIN': 1}
        elif name == 'no_residual_reduction': candidate[0] = copy.deepcopy(baseline[0])
        elif name == 'individual_regression_retained':
            baseline[1]['terminal_settlement_pnl'], candidate[1]['terminal_settlement_pnl'] = 200., 150.
        elif name == 'pre_cleanup_changed': candidate[0]['pre_cleanup_trace']['fills_sha256'] = 'changed'
        elif name == 'first_five_changed': candidate[0]['first_five_requests_sha256'] = 'changed'
        elif name == 'mutation_ceiling': candidate[0]['maximum_rolling_mutations'] = 181
        elif name == 'source_change': summaries['changed_sources'] = ['synthetic-source.py']
        elif name == 'forbidden_access': summaries['forbidden_attempts'] = ['synthetic forbidden event']
        elif name == 'error_summary': summaries['errors'] = 1
        elif name == 'duplicate_grid': candidate[-1] = copy.deepcopy(candidate[0])
        elif name == 'error_row': candidate[0]['status'] = 'error'
        elif name == 'results_hash_mismatch': summaries['results_sha256'] = 'bad'
        elif name == 'profile_metrics':
            def request(method, path, start, body=None, response=None):
                return {'request': dict(method=method, path=path, started_at=start, executed_at=start + .1,
                                       completed_at=start + .2, body=body, response=response)}
            old = dict(trade_id='old', executed_at='9.0')
            first = dict(trade_id='first', executed_at='10.95')
            second = dict(trade_id='second', executed_at='11.5')
            profiles[GRID[0]] = [request('GET', '/orderbook/REIN', 10.),
                request('POST', '/orders', 10.8, {'symbol': 'REIN'}),
                request('GET', '/trades', 11., response={'trades': [old, first]}),
                request('GET', '/trades', 12., response={'trades': [first, second]})]
        root = OUT / 'analyzer-synthetic' / name
        write_phase(root / 'baseline', baseline, profiles)
        write_phase(root / 'candidate', candidate, profiles, summaries)
        old_argv = sys.argv
        text = io.StringIO()
        rejected = False
        try:
            sys.argv = [str(ANALYZER), str(root)]
            with contextlib.redirect_stdout(text): runpy.run_path(str(ANALYZER), run_name='__main__')
        except AssertionError:
            rejected = True
        finally:
            sys.argv = old_argv
        assert rejected == rejects, name
        if not rejected:
            report = json.loads(text.getvalue())
            assert report['failed_rules'] == failures, (name, report['failed_rules'])
            assert report['decision'] == ('reject' if failures else 'passes_declared_gates_pending_independent_review')
            assert report['pre_cleanup_pairs_equal'] == report['first_five_passes_equal'] == 112
            if name == 'individual_regression_retained': assert report['worsened_pnl'] == 1
            if name == 'profile_metrics':
                p = report['pairs'][0]['candidate']
                assert p['requests'] == 4 and p['closing_orders'] == 1 and p['observed_cleanup_fills'] == 2
                for field, expected in [('request_seconds', .8), ('min_book_age', .8), ('max_book_age', .8),
                    ('first_closing_order_after', .9), ('last_observed_cleanup_fill_after', 1.5)]:
                    assert math.isclose(p[field], expected, abs_tol=1e-8), (field, p[field])
            dump(root / 'analysis.json', report)
        results.append({'case': name, 'expected_assertion': rejects, 'rejected': rejected,
                        'expected_failed_rules': failures, 'passed': True})
    assert sha(ANALYZER.read_bytes()) == EXPECTED and forbidden == []
    result = {'analyzer_sha256': EXPECTED, 'synthetic_cases': len(results), 'cases': results,
              'forbidden_attempts': forbidden, 'actual_candidate_read': False, 'performance_runs': 0,
              'limits': ['Analyzer trusts producer first-five/pre-cleanup hashes and rolling maxima; independent result audit recomputes them from profiles.',
                  'Extra-pass 90-event checks are enforced by the frozen comparison driver and will be independently checked against candidate mutation profiles.',
                  'Decision comparison tolerance is 1e-7 for worst/paired P&L; new-negative classification uses exact zero as declared.']}
    dump(OUT / 'analyzer-check.json', result)
    print(json.dumps({'synthetic_cases': len(results), 'all_passed': True, 'performance_runs': 0, 'forbidden_attempts': forbidden}, indent=2))


if __name__ == '__main__': main()
