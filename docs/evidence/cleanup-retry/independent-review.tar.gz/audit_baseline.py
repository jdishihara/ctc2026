"""Independent completed-baseline audit; no strategy import or performance run."""
from pathlib import Path, PurePosixPath
from collections import Counter, deque
import hashlib
import itertools
import json
import math
import statistics
import subprocess
import sys
import tarfile

ROOT = Path('/Users/arjunhans/Documents/ctc2026')
SOURCE = ROOT / '.worktrees/cleanup-retry-window'
FROZEN = ROOT / '.worktrees/practice-history'
RUN = ROOT / 'out/cleanup-retry-window-20261024'
OUT = Path(__file__).parent
REVISION = '27ab7c4b4784c9aabc92e791b0878d387cd4cc49'
BASE = 'cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026'
GRID = set(itertools.product(range(241, 248), [0., .05, .25, 1.], [1., .5], [False, True]))
JOURNALS = ['observations.json', 'actions.jsonl', 'status.json', 'final-receipt.json', 'startup-feed.jsonl', 'result.json', 'run.lock']
FILES = JOURNALS + ['cleanup-profile.json', 'mutation-profile.json']
forbidden = []


def audit_hook(event, args):
    if event.startswith('socket.'):
        forbidden.append('network'); raise RuntimeError('network forbidden')
    if event == 'open' and isinstance(args[0], (str, bytes)):
        path = str(args[0]).lower()
        if any(s in path for s in ['.botkey', '/.env', 'credentials', '/data/history/', '/secrets/']):
            forbidden.append('restricted file'); raise RuntimeError('credentials/history forbidden')
        if '/cleanup-retry-window-20261024/candidate/' in path:
            forbidden.append('unfinished candidate'); raise RuntimeError('candidate audit not authorized yet')


sys.addaudithook(audit_hook)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    return sha(Path(path).read_bytes())


def vh(value):
    return sha(json.dumps(value, sort_keys=True, allow_nan=False).encode())


def load(path):
    return json.loads(Path(path).read_bytes())


def rows(path):
    data = Path(path).read_bytes()
    assert data.endswith(b'\n')
    return [json.loads(line) for line in data.splitlines() if line.strip()]


def key(row):
    return tuple(row[x] for x in ['capture', 'rtt_seconds', 'displayed_depth_fraction', 'basket_enabled'])


def dirname(k):
    c, r, d, b = k
    return f'capture-{c}-{r}-{d}-{int(b)}'


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args])


def close(a, b):
    assert math.isclose(a, b, rel_tol=0, abs_tol=1e-8), (a, b)


def finite(value):
    if isinstance(value, float):
        assert math.isfinite(value)
    elif isinstance(value, dict):
        for x in value.values(): finite(x)
    elif isinstance(value, list):
        for x in value: finite(x)


def summarize(rs):
    pnl = [r['terminal_settlement_pnl'] for r in rs]
    loss = [r for r in rs if 'loss' in r['stop_reason']]
    return {'rows': len(rs), 'positive': sum(v > 0 for v in pnl), 'negative': sum(v < 0 for v in pnl),
            'zero': sum(v == 0 for v in pnl), 'mean': statistics.mean(pnl), 'worst': min(pnl), 'best': max(pnl),
            'trials': dict(Counter(r['trial_state'] for r in rs)), 'cleanup': dict(Counter(r['cleanup']['state'] for r in rs)),
            'loss_stops': len(loss), 'loss_cleanup_mean': statistics.mean(r['cleanup_completed_at'] - r['cleanup_started_at'] for r in loss) if loss else None,
            'lowest_marked_pnl': min(r['lowest_marked_pnl'] for r in rs),
            'maximum_marked_drawdown': max(r['maximum_marked_drawdown'] for r in rs),
            'maximum_rolling_mutations': max(r['maximum_rolling_mutations'] for r in rs),
            'extra_pass_mutations': sum(r['extra_pass_mutations'] for r in rs)}


def main():
    assert git(SOURCE, 'rev-parse', 'HEAD').decode().strip() == REVISION
    assert git(FROZEN, 'rev-parse', 'HEAD').decode().strip() == BASE
    assert not git(SOURCE, 'status', '--porcelain', '--untracked-files=no')
    assert not git(FROZEN, 'status', '--porcelain', '--untracked-files=no')
    analyzer_hash = digest(RUN / 'analyze.py')
    assert analyzer_hash == '7abc2a98b45769399ce14e5622e8dabc8fcc236c8b499d71977c9b9a1e071010'
    spec = load(RUN / 'spec.json')
    metadata = load(RUN / 'baseline/metadata.json')
    summary = load(RUN / 'baseline/summary.json')
    result_rows = rows(RUN / 'baseline/results.jsonl')
    indexed = {key(r): r for r in result_rows}
    assert len(result_rows) == len(indexed) == 112 and set(indexed) == GRID
    assert set(map(tuple, metadata['grid'])) == GRID and len(metadata['grid']) == 112
    assert metadata['phase'] == 'baseline' and metadata['spec'] == spec
    assert metadata['candidate_revision'] == REVISION and metadata['baseline_revision'] == BASE
    assert metadata['runtime_changes'] == ['bot/practice.py']
    assert summary['runs'] == 112 and summary['errors'] == 0
    assert summary['changed_sources'] == summary['forbidden_attempts'] == []
    assert summary['results_sha256'] == digest(RUN / 'baseline/results.jsonl') == 'b48e6cc69fc2fcd37cc2a0d77b7356f056eb2d140b0789c9a1f357fb50a58ebb'
    finite(summary); finite(metadata['started_at'])
    assert summary['finished_at'] >= metadata['started_at']
    assert spec['baseline_root'] == str(FROZEN)
    assert [c['capture'] for c in spec['captures']] == list(range(241, 248))
    source_map = metadata['source_sha256']
    assert len(source_map) == 862
    before = {p: digest(p) for p in source_map}
    assert before == source_map

    preflight_path = RUN / 'preflight-review.tar.gz'
    assert digest(preflight_path) == 'e34860662dc15f69c10bc5e099a0102d5a509e8a4f3360779c8306d50c5f5695'
    with tarfile.open(preflight_path) as tf:
        members = tf.getmembers()
        assert len(members) == len({m.name for m in members})
        for m in members:
            assert m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts
        packed = {m.name: tf.extractfile(m).read() for m in members}
    manifest = json.loads(packed['artifact-manifest.json'])
    entries = manifest.get('files', manifest)
    assert set(entries) == set(packed) - {'artifact-manifest.json'}
    for name, expected in entries.items():
        h = expected['sha256'] if isinstance(expected, dict) else expected
        assert sha(packed[name]) == h
    preflight = json.loads(packed['verdict.json'])
    assert preflight['candidate_head'] == REVISION and preflight['baseline_head'] == BASE
    assert preflight['blockers'] == [] and preflight['verdict'] == 'APPROVE_FOR_FIXED_OFFLINE_COMPARISON_ONLY'
    assert preflight['spec_sha256'] == digest(RUN / 'spec.json')
    for name, h in preflight['reviewed_sha256'].items():
        assert digest(SOURCE / name) == h

    # Independently derive the complete manifest; do not trust it to name itself.
    expected_sources = {str(RUN / 'spec.json'), str(SOURCE / 'scripts/compare_cleanup_retry.py'), str(SOURCE / 'docs/cleanup-retry-window-plan.md')}
    runtime_names = ['data/case.json', 'bot/live.py', 'bot/http_transport.py', 'bot/control.py', 'bot/practice.py',
        'scripts/replay_practice_supervisor.py', 'scripts/replay_serialized_client.py', 'scripts/replay_captured_market.py',
        'scripts/evaluate_observed_season.py', 'scripts/observe_market_seasons.py', 'scripts/experiment_execution_costs.py']
    runtime_names += [str(p.relative_to(FROZEN)) for pattern in ['*.py', '*.json', '*.npz'] for p in (FROZEN / 'ctc').glob(pattern)]
    assert len(runtime_names) == len(set(runtime_names)) == 28
    blob_hashes, differences = {}, []
    for name in runtime_names:
        for root, revision in [(FROZEN, BASE), (SOURCE, REVISION)]:
            blob = git(root, 'show', f'{revision}:{name}')
            assert blob == (root / name).read_bytes()
            blob_hashes[f'{revision}:{name}'] = sha(blob)
            expected_sources.add(str(root / name))
        if (SOURCE / name).read_bytes() != (FROZEN / name).read_bytes(): differences.append(name)
    assert differences == ['bot/practice.py']

    archive_rows, archive_roots, captures = {}, {}, []
    for entry in spec['captures']:
        capture, cached, original = entry['capture'], Path(entry['input']), Path(entry['archive'])
        assert digest(cached) == entry['input_sha256']
        data = load(cached)
        assert {'frames', 'receipt'} <= set(data) <= {'frames', 'receipt', 'meta', 'coverage'}
        receipt = data['receipt']
        assert receipt['clock']['state'] == 'ready'
        assert receipt['competition_id'] == receipt['clock']['competition_id']
        year = str(2027 - capture)
        assert receipt['clock']['fictional_time'].startswith(year + '-')
        if capture == 241:
            # The original completed owned receipt predates the observer's
            # double-clock schema; its exact value hash remains pinned.
            assert 'end_clock' not in receipt and receipt['kind'] == 'settlement'
        else:
            assert receipt['end_clock']['state'] == 'ready'
            assert receipt['end_clock']['competition_id'] == receipt['competition_id'] and receipt['year'] == year
        assert max(f['received_at'] for f in data['frames']) <= receipt['at'] < metadata['started_at']
        expected_sources.add(str(cached))
        for name, h in entry['archive_sha256'].items():
            assert digest(original / name) == h
            expected_sources.add(str(original / name))
        original_meta, original_summary = load(original / 'metadata.json'), load(original / 'summary.json')
        assert original_meta['phase'] == 'supervised'
        assert original_meta['fraction'] == .1 and original_meta['loss_trigger'] == 250 and original_meta['prior_pnl'] == 0
        assert original_meta.get('runtime_revision', original_meta['source_revision']) == BASE
        assert original_summary['errors'] == original_summary['mismatches'] == 0 and original_summary['changed_sources'] == []
        assert original_summary['finished_at'] < metadata['started_at']
        assert original_summary['results_sha256'] == digest(original / 'results.jsonl')
        selected = next(c for c in original_meta['captures'] if c['capture'] == capture)
        assert selected['competition_id'] == receipt['competition_id']
        assert selected['frames_sha256'] == vh(data['frames']) and selected['receipt_sha256'] == vh(receipt)
        assert selected['frame_count'] == len(data['frames'])
        assert selected['first_at'] == data['frames'][0]['received_at'] and selected['last_at'] == data['frames'][-1]['received_at']
        assert selected['receipt_at'] == receipt['at']
        selected_rows = [r for r in rows(original / 'results.jsonl') if r['capture'] == capture]
        assert len(selected_rows) == 16 and len({key(r) for r in selected_rows}) == 16
        for r in selected_rows:
            k = key(r); assert k not in archive_rows
            archive_rows[k], archive_roots[k] = r, original
            expected_sources.update(str(original / dirname(k) / name) for name in JOURNALS)
        captures.append({'capture': capture, 'input': str(cached), 'input_sha256': entry['input_sha256'],
            'competition_id': receipt['competition_id'], 'year': year, 'receipt_at': receipt['at'],
            'receipt_clock_count': 1 if capture == 241 else 2,
            'frames': len(data['frames']), 'frames_sha256': selected['frames_sha256'], 'receipt_sha256': selected['receipt_sha256'],
            'original_archive': str(original), 'original_archive_sha256': entry['archive_sha256']})
    assert set(archive_rows) == GRID
    assert set(source_map) == expected_sources, (set(source_map) - expected_sources, expected_sources - set(source_map))

    file_hashes, checks, mutation_count, original_journals = {}, [], 0, 0
    for k, row in indexed.items():
        finite(row)
        assert row['status'] == 'ok' and row['errors'] == [] and row['comparison_status'] == 'exact_archive'
        assert row['extra_pass_mutations'] == 0
        for name, value in archive_rows[k].items():
            if name != 'comparison_status': assert row[name] == value, (k, name)
        directory = RUN / 'baseline' / dirname(k)
        assert {p.name for p in directory.iterdir() if p.is_file()} == set(FILES)
        assert set(row['journal_sha256']) == set(FILES)
        for name, h in row['journal_sha256'].items():
            path = directory / name
            assert digest(path) == h
            file_hashes[str(path)] = h
            if name in JOURNALS:
                assert path.read_bytes() == (archive_roots[k] / dirname(k) / name).read_bytes()
                original_journals += 1
        original_result = {name: value for name, value in archive_rows[k].items() if name not in ('capture', 'comparison_status')}
        assert load(directory / 'result.json') == original_result
        status = load(directory / 'status.json')
        assert status['fraction'] == .1 and status['loss_trigger'] == 250 and status['target_seasons'] == 1
        assert row['trial']['completed'] == (row['trial_state'] == 'completed')
        assert row['request_count'] == sum(row['request_counts'].values())
        profile = load(directory / 'cleanup-profile.json')
        first_five = [p['request'] for p in profile if p['cleanup_attempt'] is not None and p['cleanup_attempt'] < 5]
        assert vh(first_five) == row['first_five_requests_sha256']
        assert all(p['cleanup_attempt'] is None or type(p['cleanup_attempt']) is int and 0 <= p['cleanup_attempt'] < 5 for p in profile)
        for p in profile:
            request = p['request']; finite(request)
            assert row['cleanup_started_at'] <= request['started_at'] <= request['executed_at'] <= request['completed_at'] <= row['final_client_time']
        mutation = load(directory / 'mutation-profile.json')
        expected_mutations = sum(n for endpoint, n in row['request_counts'].items() if endpoint.startswith(('POST ', 'DELETE ')))
        assert len(mutation) == expected_mutations
        window = deque(); computed_max, previous_index, previous_start = 0, -1, -math.inf
        for m in mutation:
            finite(m)
            assert m['method'] in ('POST', 'DELETE')
            assert previous_index < m['request_index'] < row['request_count'] and m['started_at'] >= previous_start
            previous_index, previous_start = m['request_index'], m['started_at']
            while window and window[0] < m['started_at'] - 60: window.popleft()
            window.append(m['started_at'])
            assert len(window) == m['rolling_60s'] <= 180
            computed_max = max(computed_max, len(window))
            assert m['cleanup_attempt'] is None or m['cleanup_attempt'] < 5
        assert computed_max == row['maximum_rolling_mutations']
        mutation_count += len(mutation)
        residual = {s: q for s, q in row['server_positions_after_final_receipt'].items() if q}
        if row['cleanup']['state'] == 'flat':
            assert residual == {} and row['server_orders_after_final_receipt'] == [] and row['final_receipt']['flat']
        if row['cleanup']['state'] == 'attention': assert residual or row['server_orders_after_final_receipt']
        assert row['fills_after_final_receipt_requests'] == 0
        checks.append({'setting': k, 'original_result_exact': True, 'original_journals': 7,
            'produced_files_verified': 9, 'profile_requests': len(profile), 'first_five_requests': len(first_five),
            'first_five_requests_sha256': vh(first_five), 'mutations': len(mutation), 'maximum_rolling_mutations': computed_max,
            'cleanup': row['cleanup']['state'], 'residual': residual, 'pnl': row['terminal_settlement_pnl'],
            'duration': row['cleanup_completed_at'] - row['cleanup_started_at']})
    assert len(file_hashes) == 1008 and original_journals == 784
    after = {p: digest(p) for p in source_map}
    assert before == after == source_map
    assert digest(RUN / 'analyze.py') == analyzer_hash
    assert git(SOURCE, 'rev-parse', 'HEAD').decode().strip() == REVISION
    assert git(FROZEN, 'rev-parse', 'HEAD').decode().strip() == BASE
    assert not git(SOURCE, 'status', '--porcelain', '--untracked-files=no')
    assert not git(FROZEN, 'status', '--porcelain', '--untracked-files=no')
    assert forbidden == []
    evidence = OUT / 'baseline-evidence'; evidence.mkdir(exist_ok=True)
    for name in ['spec.json', 'analyze.py', 'baseline/metadata.json', 'baseline/results.jsonl', 'baseline/summary.json']:
        dest = evidence / name; dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes((RUN / name).read_bytes())
    (evidence / 'preflight-verdict.json').write_bytes(packed['verdict.json'])
    report = {'verdict': 'baseline_verified_candidate_not_yet_audited', 'candidate_revision': REVISION, 'baseline_revision': BASE,
        'baseline_results_sha256': summary['results_sha256'], 'analyzer_sha256': analyzer_hash,
        'preflight_archive_sha256': digest(preflight_path), 'preflight_archive_members': len(packed),
        'runtime_changes': differences, 'git_blobs': blob_hashes, 'source_input_hashes': before,
        'source_input_count': len(before), 'before_after_equal': True, 'captures': captures,
        'settings_verified': len(checks), 'original_journals_byte_exact': original_journals,
        'produced_file_hashes': file_hashes, 'mutation_events_recounted': mutation_count,
        'metrics': summarize(result_rows), 'per_capture': {c: summarize([r for r in result_rows if r['capture'] == c]) for c in range(241, 248)},
        'primary': [check for check in checks if tuple(check['setting'][1:]) == (.25, 1., True)],
        'row_checks': checks, 'baseline_started_at': metadata['started_at'], 'baseline_finished_at': summary['finished_at'],
        'new_performance_runs': 0, 'candidate_results_read': False, 'forbidden_attempts': forbidden,
        'limitations': ['Original source/input guarded reproduction is reused; no new performance run.',
            'Profile rolling counts measure actual POST/DELETE request starts across the stream; the runtime completion ledger is more conservative.',
            'Extra-pass behavior cannot be judged from baseline; every baseline extra-pass count is zero.',
            'Known training-weather overlap, recorded quote gaps, counterfactual fills and unresolved ownership remain limitations.'],
        'script_sha256': digest(Path(__file__))}
    (OUT / 'baseline-audit.json').write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + '\n')
    print(json.dumps({k: report[k] for k in ['verdict', 'settings_verified', 'original_journals_byte_exact', 'source_input_count', 'mutation_events_recounted', 'metrics', 'forbidden_attempts']}, indent=2))


if __name__ == '__main__': main()
