# Independent bounded cleanup retry result audit

## Assessment

**Passes the predeclared offline integration gates.** No source, provenance,
accounting, guard or result blocker was found for frozen candidate
`27ab7c4b4784c9aabc92e791b0878d387cd4cc49`, compared with baseline runtime
`cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026`.

This supports integration of the exact reviewed retry change. It neither
activates live trading nor establishes consistent profitability or account
ownership. Any later integration/report commit remains a separate exact-head
review. The source and frozen evaluators were not edited.

## Complete comparison

All seven closed captures 241–247 retain every setting of the fixed grid:
RTT 0/0.05/0.25/1 second, full/half displayed depth, baskets off/on. Both phases
contain 112 unique settings at 10% limits, 90 strategy actions per minute,
zero prior P&L and the unchanged $250 sampled observed-loss trigger.

| Metric | Baseline | Candidate |
| --- | ---: | ---: |
| Positive / negative | 85 / 27 | 85 / 27 |
| Mean terminal P&L | $533.810714 | $534.097857 |
| Worst terminal P&L | -$573.91 | -$573.91 |
| Best terminal P&L | $2,236.76 | $2,236.76 |
| Completed / incomplete | 88 / 24 | 88 / 24 |
| Settled / flat / attention | 88 / 19 / 5 | 88 / 24 / 0 |
| Loss-stop cleanup mean | 59.177083 s | 59.760417 s |
| Maximum rolling POST/DELETE starts | 33 | 33 |
| Extra-pass mutations | 0 | 13 |

The two improved results add $17.52 each. Three results worsen by $0.96 each.
The remaining 107 are unchanged, for a $32.16 aggregate terminal improvement.
All seven primary settings are unchanged. The primary on capture 247 remains
an incomplete loss-stop trial closing flat at -$239.99.

All rejection rules pass: worst P&L does not worsen, negative count does not
increase, no nonnegative setting becomes negative, no new attention outcome
appears, and no symbol's absolute residual position increases. Existing
attention holdings strictly shrink in nine symbol/settings across five trials.
Those five portfolios are all flat, with no open orders or later fills.

## The five changed outcomes

| Capture / RTT / depth / baskets | Baseline terminal | Candidate terminal | Change | Cleanup |
| --- | ---: | ---: | ---: | --- |
| 244 / 0 / half / off | -$277.86 | -$260.34 | +$17.52 | 5 to 9 s |
| 244 / 0 / half / on | -$277.86 | -$260.34 | +$17.52 | 5 to 9 s |
| 247 / 0 / full / off | -$403.97 | -$404.93 | -$0.96 | 5 to 7 s |
| 247 / 0 / half / off | -$522.38 | -$523.34 | -$0.96 | 5 to 7 s |
| 247 / 0 / half / on | -$490.71 | -$491.67 | -$0.96 | 5 to 7 s |

Each capture-244 case closes residual AQUA -8, GRID -5 and REIN -20. Extra
fills buy AQUA at 29.72, GRID at 37.82 and REIN at a volume-weighted 89.468.
Against unchanged official settlement values 34.03, 32.30 and 90.00, their
contributions to the paired terminal difference are +$34.48, -$27.60 and
+$10.64: exactly +$17.52. Each case adds four POSTs and one DELETE.

Each capture-247 case buys six REIN at 90.16 instead of retaining the short
position to its 90.00 terminal valuation, explaining the -$0.96 difference.
Each adds one POST. No other fills change. Receipt marks and terminal values
are distinct; closing the position removes residual risk without guaranteeing
a better terminal score.

The half-depth/baskets-on capture-247 case also has three identical earlier
cash-neutral ARCH conversions: create 5, redeem 2 and redeem 1. Independent
accounting includes their ETF/component inventory transfers. They contribute
no paired difference. All five cases reconcile complete fill cash plus
conversion-adjusted terminal holdings to both producer results.

## Provenance and full-grid checks

- Verified 862 source/input artifacts before and after the review, all 56
  runtime Git blobs and the approved preflight archive (695 files). Only
  `bot/practice.py` differs in the runtime manifest. The exact preflight spec
  hash is preserved.
- All seven cached inputs match their immutable file hashes and their original
  producer frame/receipt value hashes. Receipts precede execution. Capture 241
  retains the earlier owned-receipt single-clock schema; captures 242–247 use
  the later observer's ready/ready schema. No receipt schema was invented or
  silently upgraded.
- Baseline reproduces every original supervised result field and all 784
  original journal files byte for byte. All 1,008 files/profiles per phase
  match their row hashes, and candidate metadata binds all 1,011 baseline
  outputs including metadata/results/summary.
- All 112 pre-cleanup request/fill hashes and stop fields match. Independently
  extracted initialization requests and every actual request in the first five
  passes match exactly, including their times and responses. The 107 unchanged
  runtime results also retain all 749 original journal files byte for byte.
- Independently recounted actual POST/DELETE starts from both complete mutation
  profiles using the inclusive trailing 60-second window. The entire-stream
  ceiling of 180 holds, as does the 90-event ceiling for every extra-pass
  mutation. The 13 extra mutations are 11 POSTs and two DELETEs.
- Verified every observed extra-pass admission is within 61 seconds of cleanup
  entry and within the 62-pass cap. Successful reproductions also observe all
  13 actual completion-clock budget decisions: all allow, maximum 26 prior
  retained events. These samples do not exercise saturation; preflight
  synthetic tests cover saturation, strict expiry and slow-operation clocks.
- The frozen analyzer SHA is
  `7abc2a98b45769399ce14e5622e8dabc8fcc236c8b499d71977c9b9a1e071010`.
  Eighteen generated-data tests exercise its decision rules, adverse rows,
  provenance/hash rejection and profile metrics. Every actual summary and
  pair description independently recomputes exactly. Synthetic checks execute
  analysis only, with no strategy or performance simulation.

Result SHA-256s:

| Artifact | SHA-256 |
| --- | --- |
| Baseline results | `b48e6cc69fc2fcd37cc2a0d77b7356f056eb2d140b0789c9a1f357fb50a58ebb` |
| Candidate results | `f716948101f1304491dcee002e815ed40b847c1e3787ae86b40beeba2199de76` |
| Producer analysis | `36544315e4a3ec5b7344f003529521153e524ecb52818a2bf21bcd4cc90bb0b3` |
| Approved preflight | `e34860662dc15f69c10bc5e099a0102d5a509e8a4f3360779c8306d50c5f5695` |

## Authorized reproductions

All five affected attention settings, capture-247 primary, and the originally
specified capture-244 / 1-second / half-depth / baskets-off setting reproduce
every result field and all 63 journal/profile files. Full requests, including
GET responses, and all fills are preserved as compressed JSON.

The requested capture-244 slow setting was incorrectly described as a loss
stop in the handoff. It is a completed +$559.01 trial with a 21-second settled
cleanup. The requester then explicitly authorized one additional fixed case:
**capture 243 / 1 second / half depth / baskets off**. It reproduces the
-$391.47 loss-stop outcome and 260-second cleanup exactly. Passes 0–4 begin at
1, 37, 160, 196 and 216 seconds after cleanup entry; no extra-pass mutation
occurs. This verifies that the new horizon preserves the original five passes
even when they take longer than 61 seconds.

The final evidence therefore contains **eight unique authorized settings,
72 exact journal/profile files and eight full request/fill trace pairs**.
The extra setting is disclosed rather than relabeled as one of the original
seven. Guarded reproductions check complete observed history, identities,
quote callbacks, official settlement availability, actual execution-time
cleanup positions, rolling request counts and the completion-clock ledger.
No network, credentials, downloaded history or active capture-248+ data was
accessed; no other scenario, variant or parameter was evaluated.

### Retained audit invocation corrections

The first invocation used system Python and stopped on missing `websockets`
before any replay. The venv invocation reproduced the first authorized 244
case with exact results/files, but an additional audit hash check incorrectly
included GET responses; the frozen trace digest intentionally omits them.
That case was repeated to preserve its full trace after correcting the audit.

The next invocation preserved four successful reproductions, then reproduced
the half-depth/baskets-on 247 case with exact results/files but stopped on an
overly narrow audit assertion requiring zero conversions. Accounting was
corrected to include the three unchanged ARCH transfers, and that same case
was repeated. Completed reproductions were reused rather than restarted.

All failed logs and the two exact duplicate-case outputs remain in the archive.
There were **ten replay executions over eight unique authorized settings**:
eight completed reproductions and two duplicate executions stopped by audit
assertions after exact result/file verification. These were audit-harness
corrections, not source changes, guard violations, performance variants or
unfavorable strategy results omitted from the comparison.

## Declined to judge and limits

- Live account exclusivity, resumed trading or venue readiness: ownership is
  unresolved, and no live operation was authorized by this audit.
- Unfamiliar-weather skill or independent winning probability: these seven
  captured paths repeat fitted training weather and their settings are
  correlated. The plan is a diagnosis-driven reused-data comparison.
- True quote completeness, market impact or live queue fills: recordings have
  receive-time gaps and truncated tails; simulated fills cannot establish them.
- A hard cleanup-duration or loss bound: the 61-second rule admits extra
  passes, not a total wall-clock cap; the original five passes and admitted
  slow operations may overrun it. The $250 trigger is sampled, and 27 negative
  outcomes and the -$573.91 worst result remain.

No retuning or strategy/model change was made during this review.

## Retained evidence

`baseline-audit.json`, `candidate-audit.json`, `analyzer-check.json` and
`verdict.json` bind the checks and explicit scope. The scripts reproduce the
read-only audits and generated analyzer tests. `authorized-reruns/` retains
all eight exact results, journals/profiles, full compressed traces and checks.
Intermediate failed-invocation artifacts are preserved separately. The final
artifact manifest and archive bind every packaged byte. Generated synthetic
fixtures remain at the origin directory and can be regenerated by the script.
