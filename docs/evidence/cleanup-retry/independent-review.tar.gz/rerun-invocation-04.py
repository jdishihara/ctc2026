"""Only the seven explicitly authorized frozen candidate reproductions."""
from pathlib import Path
from collections.abc import Mapping
from dataclasses import asdict
from unittest.mock import patch
import ast
import copy
import gzip
import hashlib
import json
import math
import subprocess
import sys

ROOT = Path('/Users/arjunhans/Documents/ctc2026')
SOURCE = ROOT / '.worktrees/cleanup-retry-window'
RUN = ROOT / 'out/cleanup-retry-window-20261024'
OUT = Path(__file__).parent / 'authorized-reruns'
REV = '27ab7c4b4784c9aabc92e791b0878d387cd4cc49'
SETTINGS = [(244, 0., .5, False), (244, 0., .5, True),
            (247, 0., 1., False), (247, 0., .5, False), (247, 0., .5, True),
            (247, .25, 1., True), (244, 1., .5, False)]
forbidden = []


def guard(event, args):
    if event.startswith('socket.'):
        forbidden.append('network'); raise RuntimeError('network forbidden')
    if event == 'open' and isinstance(args[0], (str, bytes)):
        p = str(args[0]).lower()
        if any(s in p for s in ['.botkey', '/.env', 'credentials', '/data/history/', '/secrets/']):
            forbidden.append('restricted file'); raise RuntimeError('credentials/history forbidden')


sys.addaudithook(guard)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def vh(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()


def load(path):
    return json.loads(Path(path).read_bytes())


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def main():
    assert subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'], text=True).strip() == REV
    assert not subprocess.check_output(['git', '-C', str(SOURCE), 'status', '--porcelain', '--untracked-files=no'])
    metadata = load(RUN / 'candidate/metadata.json')
    assert metadata['candidate_revision'] == REV
    before = {p: digest(p) for p in metadata['source_sha256']}
    assert before == metadata['source_sha256']
    original_rows = {tuple(r[n] for n in ['capture', 'rtt_seconds', 'displayed_depth_fraction', 'basket_enabled']): r
                     for r in map(json.loads, (RUN / 'candidate/results.jsonl').read_text().splitlines())}
    assert len(original_rows) == 112
    inputs = {}
    for item in metadata['spec']['captures']:
        if item['capture'] in {244, 247}:
            assert digest(item['input']) == item['input_sha256']
            data = load(item['input'])
            assert data['receipt']['clock']['state'] == data['receipt']['end_clock']['state'] == 'ready'
            assert data['receipt']['at'] < metadata['started_at']
            inputs[item['capture']] = data
    OUT.mkdir(exist_ok=True)
    sys.path.insert(0, str(SOURCE))
    from scripts import replay_practice_supervisor as replay
    from bot import practice
    from ctc.strategies import FairValueTrader
    assert Path(replay.__file__).resolve().parents[1] == SOURCE.resolve()
    case = load(SOURCE / 'data/case.json')
    tree = ast.parse((SOURCE / 'bot/practice.py').read_text())
    function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'reconcile_stop')
    loop = next(n for n in function.body if isinstance(n, ast.For) and isinstance(n.target, ast.Name) and n.target.id == 'attempt')
    pass_lines = loop.lineno, loop.end_lineno
    active, cases, counts = {}, [], {'settlement_value_reads': 0, 'history_ready_strategy_posts': 0,
                                   'cleanup_posts_at_true_server_position': 0, 'extra_budget_checks': 0}
    OriginalServer, OriginalSession = replay.PracticeReplayServer, practice.PracticeSession
    original_finish, original_send, original_quotes = practice.finish, replay.ServerTransport.send, FairValueTrader.on_quotes
    original_budget = practice.Journal.extra_cleanup_mutation_allowed

    def enforce(condition, message):
        if not condition:
            exc = AssertionError(message)
            active['server'].latch(exc)
            raise exc

    class RecordingServer(OriginalServer):
        def __init__(self, *a, **kw):
            super().__init__(*a, **kw)
            active['server'] = self
            self.cleanup_profile, self.mutation_profile, self.pass_starts = [], [], {}

        def request(self, *a, **kw):
            stack, attempt = [], None
            if 'cleanup_request_index' in active:
                frame = sys._getframe(1)
                while frame:
                    if (frame.f_code.co_name == 'reconcile_stop' and frame.f_code.co_filename.endswith('/bot/practice.py')
                            and pass_lines[0] < frame.f_lineno <= pass_lines[1]):
                        attempt = frame.f_locals['attempt']
                    if frame.f_code.co_filename.endswith(('/bot/practice.py', '/bot/live.py')):
                        stack.append(dict(file=Path(frame.f_code.co_filename).name, function=frame.f_code.co_name, line=frame.f_lineno))
                    frame = frame.f_back
                if attempt is not None:
                    enforce(0 <= attempt < 62, 'pass count exceeded')
                    if attempt not in self.pass_starts:
                        self.pass_starts[attempt] = self.now
                        if attempt >= 5:
                            enforce(0 <= self.now - active['cleanup_started'] <= 61, 'extra pass admitted beyond horizon')
            result = super().request(*a, **kw)
            request = self.requests[-1]
            if 'cleanup_request_index' in active:
                self.cleanup_profile.append(dict(request=copy.deepcopy(request), stack=stack, cleanup_attempt=attempt))
            if request['method'] in ('POST', 'DELETE'):
                now = request['started_at']
                count = sum(r['method'] in ('POST', 'DELETE') and r['started_at'] >= now - 60 for r in self.requests)
                self.mutation_profile.append(dict(request_index=len(self.requests) - 1, started_at=now,
                    method=request['method'], path=request['path'], rolling_60s=count, cleanup_attempt=attempt))
                enforce(count <= 180, 'whole-stream mutation ceiling exceeded')
                if attempt is not None and attempt >= 5: enforce(count <= 90, 'extra-pass mutation ceiling exceeded')
            return result

        def _operation(self, method, path, body):
            if 'cleanup_request_index' in active and method == 'POST':
                enforce(path == '/orders', 'unexpected cleanup conversion')
                actual = self.market.position[body['symbol']]
                enforce(not self.terminal and self.market.market_open and not self.market.open_orders,
                        'cleanup execution with closed market or working orders')
                enforce(actual != 0 and body['side'] == ('sell' if actual > 0 else 'buy')
                        and 0 < body['quantity'] <= abs(actual), 'cleanup POST does not reduce true execution-time position')
                counts['cleanup_posts_at_true_server_position'] += 1
            return super()._operation(method, path, body)

    class Session(OriginalSession):
        def __init__(self, *a, **kw):
            super().__init__(*a, **kw); active['session'] = self

    class TerminalPrices(Mapping):
        def __init__(self, values): self._prices = dict(values)
        def _check(self):
            server = active['server']
            enforce(math.isfinite(server.now) and server.terminal and not server.market.market_open
                    and server.now >= server.settlement_available_at, 'terminal values read before official availability')
        def __getitem__(self, name):
            self._check(); counts['settlement_value_reads'] += 1; return self._prices[name]
        def __iter__(self): return iter(self._prices)
        def __len__(self): return len(self._prices)
        def copy(self): self._check(); return dict(self)
        def __copy__(self): return self.copy()
        def __deepcopy__(self, memo): self._check(); return TerminalPrices(dict(self))

    def finish(journal):
        server = active['server']
        active.update(cleanup_request_index=len(server.requests), cleanup_fill_index=len(server.market.fills), cleanup_started=server.now)
        return original_finish(journal)

    def checked_send(exchange, method, path, body=None):
        if method == 'POST' and isinstance(exchange, replay.OfflinePracticeExchange):
            session = active['session']
            enforce(not session._valid_weather_wait() and session.strat.model.live_history_ready, 'strategy POST lacks complete observed history')
            enforce(session.competition_id == exchange.competition_id == session.strat.competition_id, 'strategy identity mismatch')
            counts['history_ready_strategy_posts'] += 1
        if method == 'POST' and isinstance(exchange, replay.OfflineCleanupExchange):
            q = exchange.position[body['symbol']]
            enforce(exchange.state_ready and exchange.market_open and not exchange.open_orders, 'cleanup state not reconciled')
            enforce(exchange.expected_id == exchange.competition_id, 'cleanup identity mismatch')
            enforce(body['side'] == ('sell' if q > 0 else 'buy') and 0 < body['quantity'] <= abs(q), 'cleanup cached position not reduced')
        return original_send(exchange, method, path, body)

    def checked_quotes(strategy, exchange):
        model = strategy.model
        before_reports, before_ready = set(model.reported_rounds), model.live_history_ready
        enforce(strategy.competition_id == exchange.competition_id and strategy.competition_id, 'quote callback identity mismatch')
        answer = original_quotes(strategy, exchange)
        enforce(strategy.model is model and model.reported_rounds == before_reports and model.live_history_ready == before_ready,
                'quote callback changed news history')
        return answer

    def checked_budget(journal):
        result = original_budget(journal)
        server = active['server']
        counts['extra_budget_checks'] += 1
        retained = sum(t >= server.now - 60 for t in journal._mutation_times)
        enforce(not result or journal._mutation_clock_valid and retained < 90, 'completion-clock ledger accepted saturation')
        active.setdefault('budget_checks', []).append(dict(at=server.now, retained_events=retained, allowed=result))
        return result

    with patch.object(replay, 'PracticeReplayServer', RecordingServer), patch.object(practice, 'PracticeSession', Session), \
            patch.object(practice, 'finish', finish), patch.object(replay.ServerTransport, 'send', checked_send), \
            patch.object(FairValueTrader, 'on_quotes', checked_quotes), \
            patch.object(practice.Journal, 'extra_cleanup_mutation_allowed', checked_budget):
        for capture, rtt, depth, basket in SETTINGS:
            active.clear()
            data = inputs[capture]
            directory = OUT / f'capture-{capture}-{rtt}-{depth}-{int(basket)}'
            if (directory / 'independent-check.json').exists():
                record = load(directory / 'independent-check.json')
                original = original_rows[capture, rtt, depth, basket]
                assert record['setting'] == [capture, rtt, depth, basket]
                assert record['exact_journal_profile_files'] == original['journal_sha256']
                assert all(digest(directory / n) == h for n, h in original['journal_sha256'].items())
                for n, h in [('request-trace.json.gz', record['full_response_trace_sha256']), ('fill-trace.json.gz', record['fill_trace_sha256'])]:
                    with gzip.open(directory / n, 'rt') as stream: assert vh(json.load(stream)) == h
                cases.append(record)
                print(json.dumps({'setting': record['setting'], 'reused_successful_reproduction': True}), flush=True)
                continue
            assert not directory.exists(), 'retain an incomplete invocation separately before retrying'
            result = replay.replay_supervised(case, data['frames'], str(2027 - capture), data['receipt']['competition_id'],
                TerminalPrices(data['receipt']['prices']), receipt_at=data['receipt']['at'], out=directory,
                rtt=rtt, depth_scale=depth, basket=basket)
            enforce(result['status'] == 'ok' and result['errors'] == [], 'reproduction failed')
            server = active['server']; enforce(not server.fatal_errors, 'sticky server guard failed')
            original = original_rows[capture, rtt, depth, basket]
            for name, value in result.items(): enforce(original[name] == value, f'result field differs: {name}')
            dump(directory / 'cleanup-profile.json', server.cleanup_profile)
            dump(directory / 'mutation-profile.json', server.mutation_profile)
            exact = {}
            for name, h in original['journal_sha256'].items():
                enforce(digest(directory / name) == h, f'produced journal/profile bytes differ: {name}')
                exact[name] = h
            prefix = dict(requests_sha256=vh(server.requests[:active['cleanup_request_index']]),
                          fills_sha256=vh([asdict(f) for f in server.market.fills[:active['cleanup_fill_index']]]))
            enforce(prefix == original['pre_cleanup_trace'], 'pre-cleanup trace differs')
            first_five = [p['request'] for p in server.cleanup_profile if p['cleanup_attempt'] is not None and p['cleanup_attempt'] < 5]
            enforce(vh(first_five) == original['first_five_requests_sha256'], 'first five differ')
            fills = [asdict(f) for f in server.market.fills]
            for trace_name, value in [('request-trace.json.gz', server.requests), ('fill-trace.json.gz', fills)]:
                with gzip.open(directory / trace_name, 'wt') as stream: json.dump(value, stream, indent=2, allow_nan=False)
            normalized_requests = [{k: v for k, v in r.items() if k != 'response' or r['method'] != 'GET'} for r in server.requests]
            enforce(vh(normalized_requests) == original['request_trace_sha256'] and vh(fills) == original['fill_trace_sha256'], 'full trace hashes differ')
            cash = math.fsum((-1 if f['side'] == 'buy' else 1) * f['qty'] * f['price'] for f in fills)
            positions = {s: sum((1 if f['side'] == 'buy' else -1) * f['qty'] for f in fills if f['symbol'] == s) for s in case['limits']}
            conversions = [r for r in server.requests if r['method'] == 'POST' and r['path'].startswith('/etf/') and r.get('response') is not None]
            enforce(len(conversions) == original['conversions'], 'accepted conversion count differs')
            for conversion in conversions:
                _, etf, operation = conversion['path'].strip('/').split('/')
                q = conversion['body']['quantity'] * (1 if operation == 'create' else -1)
                positions[etf] += q
                for symbol, ratio in case['etfs'][etf]['basket'].items(): positions[symbol] -= q * ratio
            enforce(positions == original['final_positions'], 'fill/conversion position accounting differs')
            pnl = cash + math.fsum(q * data['receipt']['prices'][s] for s, q in positions.items())
            enforce(math.isclose(pnl, original['terminal_settlement_pnl'], rel_tol=0, abs_tol=1e-7), 'fill cash accounting differs')
            record = dict(setting=[capture, rtt, depth, basket], all_result_fields_exact=True,
                exact_journal_profile_files=exact, request_trace_sha256=vh(normalized_requests), full_response_trace_sha256=vh(server.requests), fill_trace_sha256=vh(fills),
                pnl=pnl, cash=cash, positions=positions, conversions=conversions, pass_starts=server.pass_starts,
                budget_checks=active.get('budget_checks', []), fatal_errors=server.fatal_errors)
            dump(directory / 'independent-check.json', record)
            cases.append(record)
            print(json.dumps({'setting': record['setting'], 'exact_files': len(exact), 'pnl': pnl}), flush=True)
    after = {p: digest(p) for p in before}
    assert after == before and forbidden == [] and len(cases) == 7
    summary = dict(candidate_revision=REV, cases=cases, counters_for_this_resume=counts, original_source_hashes=before,
                   sources_unchanged=True, forbidden_attempts=forbidden, authorized_settings=7,
                   successful_reproductions=7, successful_cases_reused_from_previous_invocation=4,
                   prior_duplicate_execution_with_audit_hash_failure=1,
                   prior_duplicate_execution_with_audit_conversion_assertion_failure=1,
                   other_scenarios_or_variants=0, script_sha256=digest(Path(__file__)))
    dump(OUT / 'independent-reruns.json', summary)
    print(json.dumps({'cases': 7, 'exact_files': 63, 'counts': counts, 'forbidden_attempts': forbidden}), flush=True)


if __name__ == '__main__': main()
