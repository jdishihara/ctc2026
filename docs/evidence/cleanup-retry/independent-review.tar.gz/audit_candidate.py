"""Independent paired-result/profile/accounting audit; runs no strategy."""
from pathlib import Path
from collections import Counter, deque
import hashlib
import itertools
import json
import math
import statistics
import subprocess
import sys

ROOT = Path('/Users/arjunhans/Documents/ctc2026')
RUN = ROOT / 'out/cleanup-retry-window-20261024'
SOURCE = ROOT / '.worktrees/cleanup-retry-window'
OUT = Path(__file__).parent
GRID = set(itertools.product(range(241, 248), [0., .05, .25, 1.], [1., .5], [False, True]))
REV = '27ab7c4b4784c9aabc92e791b0878d387cd4cc49'
JOURNALS = ['observations.json', 'actions.jsonl', 'status.json', 'final-receipt.json', 'startup-feed.jsonl', 'result.json', 'run.lock']
EXTRA = ['cleanup-profile.json', 'mutation-profile.json']
STOP_FIELDS = ['stop_reason', 'stop_at', 'stop_phase', 'stop_market_open', 'monitor_started_at',
    'monitor_detected_at', 'cleanup_started_at', 'final_report_rounds', 'history_block_reason', 'prefix_messages', 'client_steps']
forbidden = []


def guard(event, args):
    if event.startswith('socket.'):
        forbidden.append('network'); raise RuntimeError('network forbidden')
    if event == 'open' and isinstance(args[0], (str, bytes)):
        if any(x in str(args[0]).lower() for x in ['.botkey', '/.env', '/data/history/', 'credentials', '/secrets/']):
            forbidden.append('restricted file'); raise RuntimeError('credentials/history forbidden')


sys.addaudithook(guard)


def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def vh(obj): return hashlib.sha256(json.dumps(obj, sort_keys=True, allow_nan=False).encode()).hexdigest()
def load(path): return json.loads(Path(path).read_bytes())
def key(r): return tuple(r[n] for n in ['capture', 'rtt_seconds', 'displayed_depth_fraction', 'basket_enabled'])
def name(k): return f'capture-{k[0]}-{k[1]}-{k[2]}-{int(k[3])}'
def close(a, b): assert math.isclose(a, b, rel_tol=0, abs_tol=1e-7), (a, b)


def finite(value):
    if isinstance(value, float): assert math.isfinite(value)
    elif isinstance(value, dict):
        for v in value.values(): finite(v)
    elif isinstance(value, list):
        for v in value: finite(v)


def rows(path):
    raw = Path(path).read_bytes(); assert raw.endswith(b'\n')
    return [json.loads(l) for l in raw.splitlines() if l.strip()]


def metrics(rs, summary):
    ps = [r['terminal_settlement_pnl'] for r in rs]
    loss = [r for r in rs if 'loss' in r['stop_reason']]
    return dict(positive=sum(p > 0 for p in ps), negative=sum(p < 0 for p in ps), mean=statistics.mean(ps),
        minimum=min(ps), maximum=max(ps), cleanup=dict(Counter(r['cleanup']['state'] for r in rs)),
        trial=dict(Counter(r['trial_state'] for r in rs)), loss_stops=len(loss),
        loss_cleanup_mean=statistics.mean(r['cleanup_completed_at'] - r['cleanup_started_at'] for r in loss),
        results_sha256=summary['results_sha256'], finished_at=summary['finished_at'],
        lowest_marked_pnl=min(r['lowest_marked_pnl'] for r in rs),
        maximum_marked_drawdown=max(r['maximum_marked_drawdown'] for r in rs),
        maximum_rolling_mutations=max(r['maximum_rolling_mutations'] for r in rs),
        extra_pass_mutations=sum(r['extra_pass_mutations'] for r in rs))


def description(profile, row):
    books, ages, fills, endpoints = {}, [], {}, Counter()
    posts = []
    start = row['cleanup_started_at']
    for item in profile:
        req = item['request']; path = req['path'].split('?')[0]
        endpoint = '/orderbook/*' if path.startswith('/orderbook/') else path
        endpoints[req['method'] + ' ' + endpoint] += 1
        if path.startswith('/orderbook/'): books[path.split('/')[-1]] = req['executed_at']
        if req['method'] == 'POST':
            ages.append(req['executed_at'] - books[req['body']['symbol']]); posts.append(req['executed_at'])
        if req['method'] == 'GET' and path == '/trades':
            for fill in req['response']['trades']:
                if float(fill['executed_at']) >= start:
                    if fill['trade_id'] in fills: assert fills[fill['trade_id']] == fill
                    fills[fill['trade_id']] = fill
    return dict(pnl=row['terminal_settlement_pnl'], cleanup=row['cleanup']['state'], trial=row['trial_state'],
        stop=row['stop_reason'], duration=row['cleanup_completed_at'] - start, requests=len(profile),
        request_seconds=sum(i['request']['completed_at'] - i['request']['started_at'] for i in profile),
        request_counts=dict(endpoints), closing_orders=len(posts), min_book_age=min(ages) if ages else None,
        max_book_age=max(ages) if ages else None, first_closing_order_after=min(posts) - start if posts else None,
        observed_cleanup_fills=len(fills), last_observed_cleanup_fill_after=max(float(f['executed_at']) for f in fills.values()) - start if fills else None,
        positions_after_receipt={s: q for s, q in row['server_positions_after_final_receipt'].items() if q},
        orders_after_receipt=row['server_orders_after_final_receipt'])


def full_fills(profile, row):
    found = {}
    for item in profile:
        request = item['request']
        if request['method'] == 'GET' and request['path'].split('?')[0] == '/trades':
            for fill in request['response']['trades']:
                if fill['trade_id'] in found: assert found[fill['trade_id']] == fill
                found[fill['trade_id']] = fill
    assert set(found) == {f'virtual-{i}' for i in range(row['fills'])}
    return [found[f'virtual-{i}'] for i in range(row['fills'])]


def main():
    assert subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'], text=True).strip() == REV
    before_analyzer = digest(RUN / 'analyze.py')
    assert before_analyzer == '7abc2a98b45769399ce14e5622e8dabc8fcc236c8b499d71977c9b9a1e071010'
    assert digest(RUN / 'analysis.json') == '36544315e4a3ec5b7344f003529521153e524ecb52818a2bf21bcd4cc90bb0b3'
    baseline_audit = load(OUT / 'baseline-audit.json')
    meta = {p: load(RUN / p / 'metadata.json') for p in ['baseline', 'candidate']}
    summaries = {p: load(RUN / p / 'summary.json') for p in meta}
    source_map = meta['candidate']['source_sha256']
    before = {p: digest(p) for p in source_map}
    assert source_map == meta['baseline']['source_sha256'] == baseline_audit['source_input_hashes'] == before
    assert meta['candidate']['spec'] == meta['baseline']['spec']
    assert meta['candidate']['candidate_revision'] == meta['baseline']['candidate_revision'] == REV
    assert meta['candidate']['baseline_revision'] == meta['baseline']['baseline_revision'] == 'cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026'
    assert meta['candidate']['runtime_changes'] == ['bot/practice.py']
    assert summaries['baseline']['finished_at'] <= meta['candidate']['started_at'] <= summaries['candidate']['finished_at']
    expected_base_binding = dict(baseline_audit['produced_file_hashes'])
    expected_base_binding.update({str(RUN / 'baseline' / n): digest(RUN / 'baseline' / n) for n in ['metadata.json', 'results.jsonl', 'summary.json']})
    assert meta['candidate']['baseline_artifact_sha256'] == expected_base_binding
    assert meta['candidate']['baseline_results_sha256'] == summaries['baseline']['results_sha256']
    phases, profiles, files, measured, mutation_rows = {}, {}, {}, {}, {}
    for phase in ['baseline', 'candidate']:
        summary = summaries[phase]
        data = rows(RUN / phase / 'results.jsonl')
        index = {key(r): r for r in data}
        assert len(data) == len(index) == summary['runs'] == 112 and set(index) == GRID
        assert summary['errors'] == 0 and summary['changed_sources'] == summary['forbidden_attempts'] == []
        assert summary['results_sha256'] == digest(RUN / phase / 'results.jsonl')
        finite(data); finite(summary)
        measured[phase] = metrics(data, summary)
        profiles[phase], mutation_rows[phase] = {}, {}
        for k, row in index.items():
            assert row['status'] == 'ok' and row['errors'] == []
            assert row['comparison_status'] == ('exact_archive' if phase == 'baseline' else 'identical_before_cleanup')
            directory = RUN / phase / name(k)
            assert {p.name for p in directory.iterdir() if p.is_file()} == set(JOURNALS + EXTRA)
            assert set(row['journal_sha256']) == set(JOURNALS + EXTRA)
            for filename, h in row['journal_sha256'].items():
                assert digest(directory / filename) == h
                files[str(directory / filename)] = h
            runtime_result = load(directory / 'result.json')
            for field, value in runtime_result.items(): assert row[field] == value, (phase, k, field)
            profile = load(directory / 'cleanup-profile.json')
            finite(profile)
            profiles[phase][k] = profile
            first_five = [p['request'] for p in profile if p['cleanup_attempt'] is not None and p['cleanup_attempt'] < 5]
            assert vh(first_five) == row['first_five_requests_sha256']
            starts = {}
            for p in profile:
                req, attempt = p['request'], p['cleanup_attempt']
                assert row['cleanup_started_at'] <= req['started_at'] <= req['executed_at'] <= req['completed_at'] <= row['final_client_time']
                if attempt is not None:
                    assert type(attempt) is int and 0 <= attempt < (5 if phase == 'baseline' else 62)
                    if attempt not in starts:
                        starts[attempt] = req['started_at']
                        if attempt >= 5: assert 0 <= req['started_at'] - row['cleanup_started_at'] <= 61
            mutations = load(directory / 'mutation-profile.json')
            mutation_rows[phase][k] = mutations
            assert len(mutations) == sum(n for method, n in row['request_counts'].items() if method.startswith(('POST ', 'DELETE ')))
            assert row['request_count'] == sum(row['request_counts'].values())
            window, maximum, extra, previous_index, previous_start = deque(), 0, 0, -1, -math.inf
            for m in mutations:
                finite(m)
                assert m['method'] in ('POST', 'DELETE') and previous_index < m['request_index'] < row['request_count']
                assert m['started_at'] >= previous_start
                previous_index, previous_start = m['request_index'], m['started_at']
                while window and window[0] < m['started_at'] - 60: window.popleft()
                window.append(m['started_at']); maximum = max(maximum, len(window))
                assert len(window) == m['rolling_60s'] <= 180
                if m['cleanup_attempt'] is not None and m['cleanup_attempt'] >= 5:
                    assert len(window) <= 90
                    extra += 1
            assert row['maximum_rolling_mutations'] == maximum and row['extra_pass_mutations'] == extra
            assert row['fills_after_final_receipt_requests'] == 0
            if row['cleanup']['state'] == 'flat':
                assert not any(row['server_positions_after_final_receipt'].values()) and row['server_orders_after_final_receipt'] == []
                assert row['final_receipt']['flat'] and row['final_receipt']['verified']
        phases[phase] = index
    assert len(files) == 2016
    assert summaries['candidate']['results_sha256'] == 'f716948101f1304491dcee002e815ed40b847c1e3787ae86b40beeba2199de76'
    analysis = load(RUN / 'analysis.json')
    assert measured == analysis['summaries']
    pairs, runtime_changes, residual_increases, reductions = [], [], [], []
    unchanged_journals = 0
    for k, b in phases['baseline'].items():
        c = phases['candidate'][k]
        assert b['pre_cleanup_trace'] == c['pre_cleanup_trace']
        for field in STOP_FIELDS: assert b[field] == c[field], (k, field)
        bp, cp = profiles['baseline'][k], profiles['candidate'][k]
        def first_five(profile): return [p['request'] for p in profile if p['cleanup_attempt'] is not None and p['cleanup_attempt'] < 5]
        assert first_five(bp) == first_five(cp)
        def initialization(profile):
            out = []
            for p in profile:
                if p['cleanup_attempt'] is not None: break
                out.append(p['request'])
            return out
        assert initialization(bp) == initialization(cp)
        before_desc, after_desc = description(bp, b), description(cp, c)
        pair = dict(setting=list(k), baseline=before_desc, candidate=after_desc,
                    pnl_delta=c['terminal_settlement_pnl'] - b['terminal_settlement_pnl'],
                    duration_delta=after_desc['duration'] - before_desc['duration'])
        archived_pair = next(p for p in analysis['pairs'] if tuple(p['setting']) == k)
        assert pair == archived_pair, k
        pairs.append(pair)
        base_result, cand_result = load(RUN / 'baseline' / name(k) / 'result.json'), load(RUN / 'candidate' / name(k) / 'result.json')
        if base_result != cand_result: runtime_changes.append(k)
        else:
            for journal in JOURNALS:
                assert (RUN / 'baseline' / name(k) / journal).read_bytes() == (RUN / 'candidate' / name(k) / journal).read_bytes()
                unchanged_journals += 1
        for symbol in set(b['server_positions_after_final_receipt']) | set(c['server_positions_after_final_receipt']):
            bq, cq = b['server_positions_after_final_receipt'].get(symbol, 0), c['server_positions_after_final_receipt'].get(symbol, 0)
            entry = dict(setting=list(k), symbol=symbol, before=bq, after=cq)
            if abs(cq) > abs(bq): residual_increases.append(entry)
            if b['cleanup']['state'] == 'attention' and abs(cq) < abs(bq): reductions.append(entry)
    changed_expected = {(244, 0., .5, False), (244, 0., .5, True), (247, 0., 1., False), (247, 0., .5, False), (247, 0., .5, True)}
    assert set(runtime_changes) == changed_expected and unchanged_journals == 107 * 7
    assert not residual_increases and len(reductions) == 9
    assert sorted(reductions, key=lambda x: (x['setting'], x['symbol'])) == sorted(analysis['residual_reductions'], key=lambda x: (x['setting'], x['symbol']))
    failed = []
    b, c = measured['baseline'], measured['candidate']
    if c['minimum'] < b['minimum'] - 1e-7: failed.append('worse worst terminal P&L')
    if c['negative'] > b['negative']: failed.append('more negative settings')
    if any(p['baseline']['pnl'] >= 0 > p['candidate']['pnl'] for p in pairs): failed.append('new negative setting')
    if any(p['candidate']['cleanup'] == 'attention' and p['baseline']['cleanup'] != 'attention' for p in pairs): failed.append('new attention setting')
    if residual_increases: failed.append('increased absolute residual exposure')
    if not reductions: failed.append('no improvement to residual holdings in attention outcomes')
    assert failed == analysis['failed_rules'] == []
    counts = dict(improved_pnl=sum(p['pnl_delta'] > 1e-7 for p in pairs), worsened_pnl=sum(p['pnl_delta'] < -1e-7 for p in pairs), unchanged_pnl=sum(abs(p['pnl_delta']) <= 1e-7 for p in pairs))
    assert counts == {k: analysis[k] for k in counts} == dict(improved_pnl=2, worsened_pnl=3, unchanged_pnl=107)
    assert analysis['pre_cleanup_pairs_equal'] == analysis['first_five_passes_equal'] == 112
    assert analysis['primary'] == [p for p in pairs if tuple(p['setting'][1:]) == (.25, 1., True)]
    prices = {}
    case = load(SOURCE / 'data/case.json')
    for entry in meta['candidate']['spec']['captures']:
        if entry['capture'] in {244, 247}:
            cache = load(entry['input'])
            assert cache['receipt']['clock']['state'] == cache['receipt']['end_clock']['state'] == 'ready'
            prices[entry['capture']] = cache['receipt']['prices']
    economics = []
    for k in sorted(changed_expected):
        b, c = phases['baseline'][k], phases['candidate'][k]
        assert b['conversions'] == c['conversions']
        conversions = {}
        for phase in ['baseline', 'candidate']:
            events = rows(RUN / phase / name(k) / 'actions.jsonl')
            conversions[phase] = [e for e in events if e['kind'] == 'request' and e.get('method') == 'POST'
                and e.get('path', '').startswith('/etf/') and e.get('response') is not None]
            assert len(conversions[phase]) == phases[phase][k]['conversions']
        assert conversions['baseline'] == conversions['candidate']
        fills = {p: full_fills(profiles[p][k], phases[p][k]) for p in ['baseline', 'candidate']}
        assert fills['candidate'][:len(fills['baseline'])] == fills['baseline']
        for phase, fs in fills.items():
            row = phases[phase][k]
            cash = math.fsum((-1 if f['side'] == 'buy' else 1) * f['quantity'] * f['price'] for f in fs)
            positions = {s: sum((1 if f['side'] == 'buy' else -1) * f['quantity'] for f in fs if f['symbol'] == s) for s in prices[k[0]]}
            for conversion in conversions[phase]:
                _, etf, operation = conversion['path'].strip('/').split('/')
                quantity = conversion['body']['quantity'] * (1 if operation == 'create' else -1)
                positions[etf] += quantity
                for symbol, ratio in case['etfs'][etf]['basket'].items(): positions[symbol] -= ratio * quantity
            assert positions == row['final_positions'] == row['server_positions_after_final_receipt']
            close(cash + math.fsum(q * prices[k[0]][s] for s, q in positions.items()), row['terminal_settlement_pnl'])
        extra_fills = fills['candidate'][len(fills['baseline']):]
        parts = {}
        for f in extra_fills:
            p = parts.setdefault(f['symbol'], dict(quantity=0, cash=0., contribution=0., settlement_price=prices[k[0]][f['symbol']], fills=[]))
            q = (1 if f['side'] == 'buy' else -1) * f['quantity']
            p['quantity'] += q; p['cash'] -= q * f['price']; p['contribution'] += q * (p['settlement_price'] - f['price']); p['fills'].append(f)
        for symbol, part in parts.items():
            part['vwap'] = -part['cash'] / part['quantity']
            assert part['quantity'] == -b['final_positions'][symbol]
        close(math.fsum(p['contribution'] for p in parts.values()), c['terminal_settlement_pnl'] - b['terminal_settlement_pnl'])
        extra_mutations = [m for m in mutation_rows['candidate'][k] if m['cleanup_attempt'] is not None and m['cleanup_attempt'] >= 5]
        economics.append(dict(setting=list(k), baseline_pnl=b['terminal_settlement_pnl'], candidate_pnl=c['terminal_settlement_pnl'],
            delta=c['terminal_settlement_pnl'] - b['terminal_settlement_pnl'], baseline_receipt_mark=b['final_receipt']['pnl'],
            candidate_receipt_mark=c['final_receipt']['pnl'], baseline_residual={s: q for s, q in b['final_positions'].items() if q},
            candidate_residual={s: q for s, q in c['final_positions'].items() if q}, baseline_fills=len(fills['baseline']),
            candidate_fills=len(fills['candidate']), extra_mutations=extra_mutations, by_symbol=parts,
            unchanged_cash_neutral_conversions=conversions['baseline'],
            baseline_duration=b['cleanup_completed_at'] - b['cleanup_started_at'], candidate_duration=c['cleanup_completed_at'] - c['cleanup_started_at']))
    assert sum(len(e['extra_mutations']) for e in economics) == measured['candidate']['extra_pass_mutations'] == 13
    assert {p: digest(p) for p in source_map} == before
    assert {p: digest(p) for p in expected_base_binding} == expected_base_binding
    assert digest(RUN / 'analyze.py') == before_analyzer and forbidden == []
    assert subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'], text=True).strip() == REV
    evidence = OUT / 'candidate-evidence'; evidence.mkdir(exist_ok=True)
    for filename in ['metadata.json', 'results.jsonl', 'summary.json']:
        (evidence / filename).write_bytes((RUN / 'candidate' / filename).read_bytes())
    (evidence / 'analysis.json').write_bytes((RUN / 'analysis.json').read_bytes())
    report = dict(verdict='all_declared_paired_output_gates_pass_pending_authorized_rerun_completion', candidate_revision=REV,
        settings_per_phase=112, paired_results=112, metrics=measured, pair_counts=counts,
        failed_rules=failed, residual_reductions=reductions, residual_increases=residual_increases,
        initialization_and_first_five_requests_equal=112, stopping_decisions_equal=112,
        pre_cleanup_hashes_equal=112, unchanged_runtime_result_settings=107, unchanged_original_journal_files=unchanged_journals,
        source_input_artifacts=len(source_map), source_input_hashes=before,
        baseline_bound_artifacts=len(expected_base_binding), produced_file_hashes=files,
        rolling_count_audit='All POST/DELETE starts recounted inclusively across full mutation profiles; maximum 33; each of 13 extra-pass mutations <=90.',
        pass_horizon_and_cap_verified=True, economics=economics, pairs=pairs,
        no_later_fills_in_all_rows=True, source_unchanged=True, forbidden_attempts=forbidden,
        script_sha256=digest(Path(__file__)), new_performance_runs=0,
        limitations=['Original five passes retain old rate behavior; the extra-pass admission horizon is not a hard completion deadline.',
                    'Eliminating attention portfolios here reduces residual risk, but three terminal outcomes worsen by $0.96 each.',
                    'Known training-weather overlap, recorded quote gaps and unknown live queue fills remain. No owned account trading or ownership conclusion.'])
    (OUT / 'candidate-audit.json').write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + '\n')
    print(json.dumps({k: report[k] for k in ['verdict', 'metrics', 'pair_counts', 'failed_rules', 'source_input_artifacts', 'baseline_bound_artifacts', 'unchanged_runtime_result_settings', 'forbidden_attempts']}, indent=2))


if __name__ == '__main__': main()
