# Independent analog-training overlap audit

**Confirmed: all15 complete weather tracks from closed captures241–245 are exact unique members of the frozen analog library.** This establishes overlap with the model asset. Source freeze dates remain valid but do not establish unseen-weather validation.

| Closed capture | Zero-based library rows for rounds1–3 | Ages per round | Exact matches |
| --- | --- | ---: | ---: |
| 241 | 720, 721, 722 |241 |3/3 |
| 242 | 723, 724, 725 |241 |3/3 |
| 243 | 726, 727, 728 |241 |3/3 |
| 244 | 729, 730, 731 |241 |3/3 |
| 245 | 732, 733, 734 |241 |3/3 |

Every track contains all explicit storm observations at ages0,2,…,480 for [x,y,radius,intensity]. All14,460 scalar values equal the matching float64 library values exactly; maximum absolute difference and minimum RMSE are zero. Each track has exactly one matching library row at tolerance1e−9. Snapshot trajectories were excluded. There were no duplicate storm ages or duplicate top-level news sequences in these caches, and no conflicting duplicates.

## Input and closure checks

All five cache byte hashes match immutable spec8d08de8cca753d3333f141a0a462ce2f24914ab366cc0cdcf27ed87e0845fc6f. Canonical frame and receipt hashes match cache metadata and the archived supervisor metadata. Archive metadata/results/summary hashes match the spec. Every local receipt is ready, has the correct competition ID/year and complete finite positive prices, follows the final selected frame, and follows all three final reports. All news sequences are contiguous from zero. Capture241 uses its existing single-clock live settlement receipt;242–245 also have matching end-clock checks.

## Training-selection lineage

- Library: `/Users/arjunhans/Documents/ctc2026/.worktrees/practice-history/ctc/analog_library.npz`, SHA256`22694387c3b612f5c20853feb9143e1bf8b8f5722a845da8ed584ab1b30bdf09`, tracks1350×241×4.
- `/Users/arjunhans/Documents/ctc2026/.worktrees/practice-history/scripts/build_library.py:6` selects `man["seasons"][:450]`; line7 labels these seasons1–450.
- `/Users/arjunhans/Documents/ctc2026/.worktrees/practice-history/ctc/analog.py:42` iterates selected seasons, line44 iterates storms, and lines45–54 construct/append the four-channel tracks.
- `/Users/arjunhans/Documents/ctc2026/.worktrees/practice-history/README.md:187` documents fitting1–450, tuning451–525 and reused confirmation526–600.
- Exact match rows720–734 follow `3*(capture−1)+(round−1)`, consistent with the documented build order.
- The identical NPZ bytes already exist in introduction commit`51d48f701c6877214e612533280ccff1d955e382` (Git timestamp2026-10-22T00:12:10−04:00) and frozen revision`cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026`.
- `/Users/arjunhans/Documents/ctc2026/.worktrees/practice-history/ctc/analog.py:191` takes remaining future points directly from selected library tracks. Prefix-only online matching therefore does not eliminate this training overlap.

The downloaded training manifest/feeds were deliberately not read and the library was not rebuilt. The NPZ lacks per-row season IDs or a source-manifest digest. Accordingly, complete reconstruction of all450 training seasons is outside this audit; the15 exact matching tracks and their row indices are directly verified.

## Required interpretation

These captures remain useful recorded-market execution, supervisor and cleanup diagnostics on weather trajectories already in the model library. Their chronology and reproducible request/accounting evidence remain valid. They provide no independent validation of forecast generalization to unseen weather, and no estimate of profitability without this overlap. Overlap alone does not establish any live order, account ownership or settlement-accounting error.

Suggested central notice: “The frozen analog library contains exact full tracks for all15 storms in captures241–245. Even where source and protocol freezes precede recorded events, these captures are not unseen-weather tests. Results describe execution and supervision on weather represented in training; live receipts and offline simulated outcomes retain their separate attribution.”

This audit changed no model/runtime source, ran no alternative strategy or performance comparison, accessed no network/credentials/downloaded history, and read no active246 or later capture outcomes. Full checks, hashes and numerical results are retained in audit.json.
