from __future__ import annotations
import collections, datetime, hashlib, json, math, os, subprocess, sys
from pathlib import Path
import numpy as np
ROOT=Path('/Users/arjunhans/Documents/ctc2026')
FROZEN=ROOT/'.worktrees/practice-history'
REV='cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026'
INTRO='51d48f701c6877214e612533280ccff1d955e382'
LIB=FROZEN/'ctc/analog_library.npz'
OUT=Path(sys.argv[1]); source_hashes={}; forbidden=[]
def audit(event,args):
    if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
        forbidden.append(event); raise RuntimeError('overlap audit forbids network')
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        name=os.fsdecode(args[0]).lower()
        if '.botkey' in name or '/.env' in name or '/data/history/' in name or name.endswith('/data/history') or 'credentials' in name:
            forbidden.append(name); raise RuntimeError('overlap audit forbids credentials and downloaded history')
sys.addaudithook(audit)
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):
    p=Path(p); b=p.read_bytes(); source_hashes[str(p)]=sha(b); return b
def value_sha(value):return sha(json.dumps(value,sort_keys=True,allow_nan=False).encode())
def git(*args):return subprocess.check_output(['git',*args],cwd=FROZEN)
assert git('rev-parse','HEAD').decode().strip()==REV
before_status=git('status','--porcelain','--untracked-files=normal').decode(); assert not before_status
libbytes=read(LIB); assert sha(libbytes)=='22694387c3b612f5c20853feb9143e1bf8b8f5722a845da8ed584ab1b30bdf09'
assert libbytes==git('show',REV+':ctc/analog_library.npz')==git('show',INTRO+':ctc/analog_library.npz')
build=read(FROZEN/'scripts/build_library.py'); analog=read(FROZEN/'ctc/analog.py'); readme=read(FROZEN/'README.md')
assert build==git('show',REV+':scripts/build_library.py')==git('show',INTRO+':scripts/build_library.py')
assert analog==git('show',REV+':ctc/analog.py')
assert "man['seasons'][:450]" in build.decode()
with np.load(LIB,allow_pickle=False) as z:
    array_inventory={k:{'shape':list(z[k].shape),'dtype':str(z[k].dtype)} for k in z.files}
    tracks=z['tracks'].copy()
assert tracks.shape==(1350,241,4) and np.isfinite(tracks).all()
case=json.loads(read(FROZEN/'data/case.json')); symbols=set(case['limits'])
specpath=ROOT/'out/cleanup-quotes-v1-20261024/spec.json'; specbytes=read(specpath)
assert sha(specbytes)=='8d08de8cca753d3333f141a0a462ce2f24914ab366cc0cdcf27ed87e0845fc6f'
spec=json.loads(specbytes); assert [s['capture'] for s in spec['captures']]==list(range(241,246))
results=[]; ages=list(range(0,481,2))
for item in spec['captures']:
    capture=item['capture']; p=ROOT/f'out/cleanup-quotes-v1-20261024/inputs/{capture}.json'; raw=read(p)
    assert sha(raw)==item['input_sha256']; d=json.loads(raw); meta,receipt,frames=d['meta'],d['receipt'],d['frames']
    archive=Path(item['archive'])
    for name,expected in item['archive_sha256'].items(): assert sha(read(archive/name))==expected
    archived_meta=json.loads((archive/'metadata.json').read_text()); archived_summary=json.loads((archive/'summary.json').read_text())
    assert archived_summary['errors']==archived_summary['mismatches']==0 and archived_summary['changed_sources']==[]
    assert archived_summary['results_sha256']==source_hashes[str(archive/'results.jsonl')]
    selected=next(m for m in archived_meta['captures'] if m['capture']==capture)
    receipt_hash=value_sha(receipt); frames_hash=value_sha(frames)
    assert receipt_hash==meta['receipt_sha256']==selected['receipt_sha256']
    assert frames_hash==meta['frames_sha256']==selected['frames_sha256']
    cid=receipt['competition_id']; year=str(2027-capture)
    assert meta['capture']==capture and meta['competition_id']==cid==selected['competition_id']
    assert str(meta['year'])==year and receipt['kind']=='settlement'
    assert receipt['clock']['state']=='ready' and receipt['clock']['competition_id']==cid and receipt['clock']['fictional_time'].startswith(year+'-')
    if 'end_clock' in receipt:
        assert receipt['end_clock']['state']=='ready' and receipt['end_clock']['competition_id']==cid and receipt['end_clock']['fictional_time'].startswith(year+'-')
    assert set(receipt['prices'])==symbols and all(type(v) in (int,float) and math.isfinite(v) and v>0 for v in receipt['prices'].values())
    times=[f['received_at'] for f in frames]
    assert all(type(t) in (int,float) and math.isfinite(t) for t in times) and times==sorted(times)
    assert times[0]==meta['first_at'] and times[-1]==meta['last_at'] and len(times)==meta['frame_count']
    assert type(receipt['at']) in (int,float) and math.isfinite(receipt['at']) and receipt['at']>=times[-1] and receipt['at']==meta['receipt_at']
    obs=collections.defaultdict(dict); raw_age_counts=collections.Counter(); duplicate_ages=collections.Counter(); seqmap={}; duplicate_seqs=0; final_reports={}; formed=collections.Counter(); snapshot_count=0
    for frame in frames:
        if frame['type']!='news':continue
        m=frame['message']; assert str(m['time']).startswith(year+'-')
        if m['type']=='snapshot':snapshot_count+=1
        if 'seq' in m:
            seq=m['seq']; assert type(seq) is int and seq>=0
            if seq in seqmap:
                duplicate_seqs+=1; assert m==seqmap[seq],('conflicting news',capture,seq)
            seqmap[seq]=m
        if m['type']=='storm_formed':formed[m['round']]+=1
        if m['type']=='damage_report' and m['stage']=='final':
            assert m['round'] not in final_reports; final_reports[m['round']]={'seq':m['seq'],'received_at':frame['received_at']}
        if m['type']!='storm':continue
        rnd,age=m['round'],m['age']; assert rnd in (1,2,3) and type(age) is int and age in ages
        vec=[m[k] for k in ('x','y','radius','intensity')]
        assert all(type(x) in (int,float) and math.isfinite(x) for x in vec)
        raw_age_counts[rnd]+=1
        if age in obs[rnd]:
            duplicate_ages[rnd]+=1; assert obs[rnd][age]==vec,('conflicting observation',capture,rnd,age)
        obs[rnd][age]=vec
    assert set(seqmap)==set(range(max(seqmap)+1)) and len(seqmap)==meta['coverage']['news_count']
    assert formed==collections.Counter({1:1,2:1,3:1}) and set(final_reports)=={1,2,3}
    assert max(v['received_at'] for v in final_reports.values())<=receipt['at']
    round_results=[]
    for rnd in (1,2,3):
        assert sorted(obs[rnd])==ages
        observed=np.array([obs[rnd][a] for a in ages],dtype=np.float64)
        delta=tracks-observed[None,:,:]
        maxabs=np.max(np.abs(delta),axis=(1,2)); rmse=np.sqrt(np.mean(np.square(delta),axis=(1,2)))
        matches=np.flatnonzero(maxabs<1e-9); exact=np.flatnonzero(np.all(tracks==observed,axis=(1,2)))
        assert len(matches)==len(exact)==1 and matches.tolist()==exact.tolist()
        index=int(matches[0]); assert index==3*(capture-1)+(rnd-1) and maxabs[index]==0 and rmse[index]==0
        round_results.append({'round':rnd,'observed_ages':ages,'age_count':len(ages),'raw_observation_count':raw_age_counts[rnd],'duplicate_age_count':duplicate_ages[rnd],'conflicting_duplicate_ages':0,'channels':['x','y','radius','intensity'],'track_sha256_float64':sha(observed.tobytes()),'match_rows_zero_based':matches.tolist(),'exact_equal_rows_zero_based':exact.tolist(),'unique_match_count':len(matches),'min_rmse':float(rmse.min()),'matched_max_absolute_difference':float(maxabs[index]),'second_best_rmse':float(np.partition(rmse,1)[1]),'matches_documented_season_order_index':True})
    results.append({'capture':capture,'competition_id':cid,'year':year,'input_path':str(p),'input_sha256':sha(raw),'input_matches_immutable_spec':True,'receipt_sha256':receipt_hash,'frames_sha256':frames_hash,'receipt_state':receipt['clock']['state'],'receipt_has_matching_end_clock':'end_clock' in receipt,'receipt_at':receipt['at'],'last_frame_at':times[-1],'receipt_after_last_frame_seconds':receipt['at']-times[-1],'receipt_at_utc':datetime.datetime.fromtimestamp(receipt['at'],datetime.timezone.utc).isoformat(),'frames_count':len(frames),'news_seq_count':len(seqmap),'news_seq_min':0,'news_seq_max':max(seqmap),'news_contiguous':True,'duplicate_news_seq_count':duplicate_seqs,'conflicting_news_sequences':0,'snapshots_excluded_from_track_matching':snapshot_count,'final_reports':final_reports,'rounds':round_results})
changed=[p for p,h in source_hashes.items() if sha(Path(p).read_bytes())!=h]
assert not changed and not forbidden and git('rev-parse','HEAD').decode().strip()==REV and git('status','--porcelain','--untracked-files=normal').decode()==before_status
report={'audit':'independent frozen analog library overlap check','frozen_source_revision':REV,'library_sha256':sha(libbytes),'library_arrays':array_inventory,'library_same_bytes_at_introduction_and_frozen_source':True,'library_introduction_commit':INTRO,'library_introduction_git_timestamp':git('show','-s','--format=%aI',INTRO).decode().strip(),'source_lineage':{'selection':{'path':str(FROZEN/'scripts/build_library.py'),'line':6,'expression':"build_library(root, man['seasons'][:450])"},'row_construction':{'path':str(FROZEN/'ctc/analog.py'),'line':42,'description':'iterate seasons in input order, then storms; append [x,y,radius,intensity] track'},'model_future_use':{'path':str(FROZEN/'ctc/analog.py'),'line':191,'expression':'self.tracks[sel, idx + 1:, :]'},'documented_training_split':{'path':str(FROZEN/'README.md'),'line':187,'description':'fit1–450; tune451–525; reused confirmation526–600'},'source_manifest_read':False,'full_library_rebuild_performed':False,'limitation':'NPZ does not embed source season IDs or a training-manifest digest. The source selects the first450 manifest entries; documentation calls them1–450, and all15 observed rows occur at the expected three-storm-per-season indices. No downloaded manifest/feed was read.'},'captures':results,'totals':{'captures':5,'tracks':15,'exact_unique_matches':15,'observations':sum(r['age_count'] for c in results for r in c['rounds']),'matching_scalar_values':15*241*4,'duplicate_observation_ages':sum(r['duplicate_age_count'] for c in results for r in c['rounds']),'conflicting_duplicate_observation_ages':0,'conflicting_news_sequences':0},'conclusions':{'chronological_source_freezes_remain_valid':True,'unseen_weather_validation_established':False,'exact_weather_training_overlap_established':True,'does_not_establish_live_account_error':True,'does_not_measure_counterfactual_without_overlap':True},'source_input_sha256':source_hashes,'changed_sources_inputs':changed,'forbidden_attempts':forbidden,'network_requests':0,'alternative_performance_runs':0,'active_future_captures_read':[]}
(OUT/'audit.json').write_text(json.dumps(report,indent=2)+'\n')
lines=['# Independent analog-training overlap audit','', '**Confirmed: all15 complete weather tracks from closed captures241–245 are exact unique members of the frozen analog library.** This establishes overlap with the model asset. Source freeze dates remain valid but do not establish unseen-weather validation.', '', '| Closed capture | Zero-based library rows for rounds1–3 | Ages per round | Exact matches |', '| --- | --- | ---: | ---: |']
for c in results:lines.append(f"| {c['capture']} | "+', '.join(str(r['match_rows_zero_based'][0]) for r in c['rounds'])+' |241 |3/3 |')
lines+=['','Every track contains all explicit storm observations at ages0,2,…,480 for [x,y,radius,intensity]. All14,460 scalar values equal the matching float64 library values exactly; maximum absolute difference and minimum RMSE are zero. Each track has exactly one matching library row at tolerance1e−9. Snapshot trajectories were excluded. There were no duplicate storm ages or duplicate top-level news sequences in these caches, and no conflicting duplicates.', '', '## Input and closure checks','', 'All five cache byte hashes match immutable spec8d08de8cca753d3333f141a0a462ce2f24914ab366cc0cdcf27ed87e0845fc6f. Canonical frame and receipt hashes match cache metadata and the archived supervisor metadata. Archive metadata/results/summary hashes match the spec. Every local receipt is ready, has the correct competition ID/year and complete finite positive prices, follows the final selected frame, and follows all three final reports. All news sequences are contiguous from zero. Capture241 uses its existing single-clock live settlement receipt;242–245 also have matching end-clock checks.', '', '## Training-selection lineage','', f'- Library: `{LIB}`, SHA256`{sha(libbytes)}`, tracks1350×241×4.', f'- `{FROZEN}/scripts/build_library.py:6` selects `man["seasons"][:450]`; line7 labels these seasons1–450.', f'- `{FROZEN}/ctc/analog.py:42` iterates selected seasons, line44 iterates storms, and lines45–54 construct/append the four-channel tracks.', f'- `{FROZEN}/README.md:187` documents fitting1–450, tuning451–525 and reused confirmation526–600.', f'- Exact match rows720–734 follow `3*(capture−1)+(round−1)`, consistent with the documented build order.', f'- The identical NPZ bytes already exist in introduction commit`{INTRO}` (Git timestamp2026-10-22T00:12:10−04:00) and frozen revision`{REV}`.', f'- `{FROZEN}/ctc/analog.py:191` takes remaining future points directly from selected library tracks. Prefix-only online matching therefore does not eliminate this training overlap.', '', 'The downloaded training manifest/feeds were deliberately not read and the library was not rebuilt. The NPZ lacks per-row season IDs or a source-manifest digest. Accordingly, complete reconstruction of all450 training seasons is outside this audit; the15 exact matching tracks and their row indices are directly verified.', '', '## Required interpretation','', 'These captures remain useful recorded-market execution, supervisor and cleanup diagnostics on weather trajectories already in the model library. Their chronology and reproducible request/accounting evidence remain valid. They provide no independent validation of forecast generalization to unseen weather, and no estimate of profitability without this overlap. Overlap alone does not establish any live order, account ownership or settlement-accounting error.', '', 'Suggested central notice: “The frozen analog library contains exact full tracks for all15 storms in captures241–245. Even where source and protocol freezes precede recorded events, these captures are not unseen-weather tests. Results describe execution and supervision on weather represented in training; live receipts and offline simulated outcomes retain their separate attribution.”', '', 'This audit changed no model/runtime source, ran no alternative strategy or performance comparison, accessed no network/credentials/downloaded history, and read no active246 or later capture outcomes. Full checks, hashes and numerical results are retained in audit.json.']
(OUT/'report.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'output':str(OUT),'totals':report['totals'],'library_sha256':report['library_sha256'],'receipt_checks':[(c['capture'],c['receipt_state'],c['news_seq_count']) for c in results],'changed_sources_inputs':changed,'forbidden_attempts':forbidden},indent=2))
