"""Independent scalar matcher and old-source fallback probes; synthetic weather only."""
import collections, copy, hashlib, json, math, pathlib, subprocess, tempfile, types
import numpy as np
from ctc.analog import AnalogEnsemble, GRID_AGES
from ctc.wind import PHYS
W=pathlib.Path('/Users/arjunhans/Documents/ctc2026/.worktrees/repeat-prefix')
old_source=subprocess.check_output(['git','show','cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026:ctc/analog.py'],cwd=W)
old=types.ModuleType('ctc._independent_old_analog');old.__package__='ctc';old.__file__=str(W/'ctc/analog.py');exec(compile(old_source,'<frozen-analog>','exec'),old.__dict__)
case={'islands':{'test':{}},'companies':{s:{'sites':[{'x':40,'y':500,'weight':1,'island':'test'}]} for s in PHYS}}
tracks=np.empty((4,241,4))
for row,speed in enumerate((.1,.2,-.1,-.1)):
 tracks[row,:,0]=speed*GRID_AGES;tracks[row,:,1]=500;tracks[row,:,2]=100+(row==3);tracks[row,:,3]=1
tracks[1,:21]=tracks[0,:21]
def observations(row=0,n=21):
 return [dict(age=int(GRID_AGES[i]),x=float(tracks[row,i,0]),y=float(tracks[row,i,1]),radius=float(tracks[row,i,2]),intensity=float(tracks[row,i,3]),vx=.1,vy=0.) for i in range(n)]
def oracle(obs):
 if not 21<=len(obs)<=241:return None
 for i,o in enumerate(obs):
  if o['age']!=2*i:return None
  for key in ['age','x','y','radius','intensity']:
   v=o.get(key)
   if isinstance(v,(bool,np.bool_)) or not isinstance(v,(int,float,np.integer,np.floating)) or not math.isfinite(v):return None
 matches=[]
 for r in range(4):
  if all(o[k]==tracks[r,i,j] for i,o in enumerate(obs) for j,k in enumerate(['x','y','radius','intensity'])):matches.append(r)
 return matches[0] if len(matches)==1 else None
counts=collections.Counter();rng=np.random.default_rng(10624)
with tempfile.TemporaryDirectory(prefix='repeat-runtime-synthetic-') as tmp:
 lib=pathlib.Path(tmp)/'library.npz';C=np.arange(1.,37.).reshape(6,6);C/=C.sum(axis=1,keepdims=True)
 np.savez(lib,tracks=tracks,pattern=np.array([0,1,2,5]),flip=np.array([-1,120,-1,-1]),C_off=C,C_wire=C[:,::-1])
 for config in [dict(k=0),dict(k=2,vel_w=.4,cone_w=.2,isl_w=.3,cone_center=.25,wind_condition=.5)]:
  candidate=AnalogEnsemble(case,lib=lib,repeat_prefix=True,**config)
  disabled=AnalogEnsemble(case,lib=lib,repeat_prefix=False,**config)
  baseline=old.AnalogEnsemble(case,lib=lib,**config)
  sequence=[observations(0,20),observations(0,21),observations(0,22),observations(1,22),observations(2,21),observations(3,21)]
  for i in range(360):
   row=int(rng.integers(4));n=int(rng.integers(1,242));obs=observations(row,n);fault=i%10
   if fault==1:obs[int(rng.integers(n))]['radius']+=.25
   elif fault==2:obs=obs[1:] or observations(row,1)
   elif fault==3 and n>3:obs.pop(n//2)
   elif fault==4:obs.insert(n//2,copy.deepcopy(obs[n//2]))
   elif fault==5:obs[n//2]['age']+=.25
   elif fault==6 and n>2:obs[0],obs[1]=obs[1],obs[0]
   elif fault==7:obs[n//2]['intensity']=[None,float('nan'),float('inf'),'1',True][i%5]
   elif fault==8:obs[n//2]['x']=np.nextafter(obs[n//2]['x'],np.inf)
   sequence.append(obs)
  for obs in sequence:
   age=obs[-1]['age'];official=[(age,'direct')];wire=[(age,'erratic')]
   adv={'cone':[{'age':min(age+10,480),'x':20,'y':490,'spread':20}],'hurricane_conditions':{'test':.75}}
   expected=baseline.weights(obs,official,wire,adv);off=disabled.weights(obs,official,wire,adv);got=candidate.weights(obs,official,wire,adv)
   np.testing.assert_array_equal(off,expected);counts['disabled_old_source_exact']+=1
   selected=oracle(obs);assert candidate.repeat_match==selected
   counts['scalar_selection_checks']+=1
   if selected is None:
    np.testing.assert_array_equal(got,expected);counts['fallback_old_source_exact']+=1
    if all(isinstance(obs[-1].get(k),(int,float)) and not isinstance(obs[-1].get(k),bool) and math.isfinite(obs[-1][k]) for k in ['radius','intensity']):
     actual_future,actual_sel=candidate.future_tracks(obs,got,adv);expect_future,expect_sel=baseline.future_tracks(obs,expected,adv)
     np.testing.assert_array_equal(actual_sel,expect_sel);np.testing.assert_array_equal(actual_future,expect_future);counts['fallback_future_exact']+=1
   else:
    one=np.zeros(4);one[selected]=1;np.testing.assert_array_equal(got,one);counts['recognized_one_hot']+=1
   np.testing.assert_array_equal(candidate._observed,baseline._observed);np.testing.assert_array_equal(candidate._track_error,baseline._track_error)
   np.testing.assert_array_equal(candidate.tracks,tracks)
  # Mutating a returned vector must not corrupt either cache or library.
  obs=observations(2,21);ret=candidate.weights(obs,[],[]);ret[:]=np.nan
  np.testing.assert_array_equal(candidate.weights(obs,[],[]),[0,0,1,0]);counts['returned_array_is_owned']+=1
 # Fail immediately if selection indexes a library column beyond the latest observed age.
 class BoundedLibrary(np.ndarray):
  bound=0
  def __getitem__(self,key):
   assert isinstance(key,tuple) and len(key)==3 and isinstance(key[1],slice)
   assert (key[1].stop or self.shape[1])<=self.bound,'matching read beyond current prefix'
   counts['bounded_library_reads']+=1
   return super().__getitem__(key)
 selected=AnalogEnsemble(case,lib=lib,repeat_prefix=True)
 selected.tracks=tracks.copy().view(BoundedLibrary)
 for row,n in [(0,21),(0,22),(0,24),(1,24),(2,21),(3,22),(3,241),(3,21)]:
  selected.tracks.bound=n;assert selected._repeat_index(observations(row,n))==oracle(observations(row,n));counts['bounded_selection_checks']+=1
print('RUNTIME_SUMMARY '+json.dumps(dict(counts),sort_keys=True))
