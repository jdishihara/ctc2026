"""Synthetic prerequisite review; no captured performance is evaluated.

Executes the actual candidate-prerequisite AST block with synthetic baseline
artifacts. It never calls comparison.main() or loads captured market inputs.
"""
import ast
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
ROOT = Path('/Users/arjunhans/Documents/ctc2026/.worktrees/repeat-prefix')
p = ROOT / 'scripts/compare_repeat_prefix.py'
spec = importlib.util.spec_from_file_location('cleanup_gate_review', p)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
main = next(n for n in ast.parse(p.read_text()).body if isinstance(n, ast.FunctionDef) and n.name == 'main')
node = next(n for n in main.body if isinstance(n, ast.If) and ast.unparse(n.test) == "args.phase == 'candidate'")
compiled = compile(ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[])), '<candidate-gate>', 'exec')
results = []
with tempfile.TemporaryDirectory(prefix='cleanup-gate-reproduction-') as tmp:
    out = Path(tmp)
    sources, spec = {'runtime': 'frozen'}, {'captures': 'fixed'}
    prior = dict(phase='baseline', source_sha256=sources, spec=spec, candidate_revision='rev', started_at=1.0)
    rows = []
    for capture, rtt, depth, basket in m.GRID:
        directory = out / f'capture-{capture}-{rtt}-{depth}-{int(basket)}'
        directory.mkdir()
        hashes = {}
        for name in m.JOURNALS + ['cleanup-profile.json', 'repeat-profile.json']:
            file = directory / name
            file.write_text('fixture\n')
            hashes[name] = m.digest(file)
        rows.append(dict(capture=capture, rtt_seconds=rtt, displayed_depth_fraction=depth,
                         basket_enabled=basket, status='ok', errors=[], comparison_status='exact_archive',
                         journal_sha256=hashes))
    summary = dict(runs=96, errors=0, changed_sources=[], forbidden_attempts=[], finished_at=2.0)
    def probe(name, mutate=None, artifact=None, expect_accept=False):
        pr, rr, ss = copy.deepcopy(prior), copy.deepcopy(rows), copy.deepcopy(summary)
        if mutate:
            mutate(pr, rr, ss)
        (out / 'metadata.json').write_text(json.dumps(pr))
        (out / 'results.jsonl').write_text(''.join(json.dumps(r) + '\n' for r in rr))
        ss['results_sha256'] = m.digest(out / 'results.jsonl')
        (out / 'summary.json').write_text(json.dumps(ss))
        original = artifact.read_bytes() if artifact else None
        if artifact:
            artifact.write_text('changed')
        env = dict(vars(m), args=SimpleNamespace(phase='candidate', baseline=out), source_hashes=sources,
                   spec=spec, candidate_revision='rev', baseline_hashes={}, metadata={})
        try:
            try:
                exec(compiled, env)
            except AssertionError:
                accepted = False
            else:
                accepted = True
        finally:
            if artifact:
                artifact.write_bytes(original)
        assert accepted == expect_accept, (name, accepted, expect_accept)
        result = dict(probe=name, accepted=accepted, expected_accept=expect_accept)
        results.append(result)
        print(json.dumps(result, sort_keys=True))
    probe('valid96', expect_accept=True)
    cases = [
        ('status_error', lambda p, r, s: r[0].update(status='error')),
        ('row_errors', lambda p, r, s: r[0].update(errors=['guard violation'])),
        ('comparison_mismatch', lambda p, r, s: r[0].update(comparison_status='failed')),
        ('duplicate97', lambda p, r, s: r.append(copy.deepcopy(r[0]))),
        ('duplicate_within96', lambda p, r, s: r.__setitem__(1, copy.deepcopy(r[0]))),
        ('missing95', lambda p, r, s: r.pop()),
        ('forbidden', lambda p, r, s: s.update(forbidden_attempts=['socket.connect'])),
        ('unfinished_nan', lambda p, r, s: s.update(finished_at=float('nan'))),
        ('finished_before_start', lambda p, r, s: s.update(finished_at=0.5)),
        ('changed_sources', lambda p, r, s: s.update(changed_sources=['runtime'])),
        ('wrong_sources', lambda p, r, s: p.update(source_sha256={'runtime': 'changed'})),
        ('wrong_spec', lambda p, r, s: p.update(spec={'captures': 'different'})),
        ('wrong_revision', lambda p, r, s: p.update(candidate_revision='other')),
        ('profile_hash_missing', lambda p, r, s: r[0]['journal_sha256'].pop('cleanup-profile.json')),
    ]
    for name, mutate in cases:
        probe(name, mutate)
    probe('journal_changed', artifact=next(out.glob('capture-*/actions.jsonl')))
    probe('profile_changed', artifact=next(out.glob('capture-*/cleanup-profile.json')))
    probe('repeat_profile_changed', artifact=next(out.glob('capture-*/repeat-profile.json')))
    probe('repeat_profile_missing', lambda p,r,s: r[0]['journal_sha256'].pop('repeat-profile.json'))
    probe('unexpected_capture247', lambda p,r,s: r[0].update(capture=247))
    probe('missing_capture246', lambda p,r,s: r.__setitem__(slice(None), [x for x in r if x['capture'] != 246]))
print('GATE_SUMMARY ' + json.dumps(dict(valid_accepted=sum(r['accepted'] for r in results),
                                      corruptions_rejected=sum(not r['accepted'] for r in results)), sort_keys=True))
