"""Retain the independent synthetic preflight and its reviewed source identity."""
import datetime, hashlib, importlib.util, json, pathlib, subprocess, sys, tarfile
D=pathlib.Path(__file__).resolve().parent;W=pathlib.Path('/Users/arjunhans/Documents/ctc2026/.worktrees/repeat-prefix')
PY='/Users/arjunhans/Documents/ctc2026/.venv/bin/python'
def H(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files=['ctc/analog.py','tests/test_repeat_prefix.py','scripts/compare_repeat_prefix.py','docs/repeat-prefix-plan.md']
reviewed={s:H(W/s) for s in files};runs=[]
commands=[('focused58',['pytest','-q','-p','no:cacheprovider','tests/test_repeat_prefix.py','tests/test_forecast.py']),('runtime',['script',str(D/'probe_runtime.py')]),('prerequisite',['script',str(D/'probe_gate.py')])]
for name,args in commands:
 p=subprocess.run([PY,str(D/'run_guarded.py'),*args],cwd=W,text=True,capture_output=True)
 (D/f'{name}.stdout.txt').write_text(p.stdout);(D/f'{name}.stderr.txt').write_text(p.stderr)
 guard=[json.loads(s.split(' ',1)[1]) for s in p.stdout.splitlines() if s.startswith('REVIEW_GUARD ')]
 assert p.returncode==0 and len(guard)==1 and guard[0]['forbidden_attempts']==[],(name,p.stdout,p.stderr)
 runs.append(dict(name=name,exit_code=p.returncode,guard=guard[0]))
 assert {s:H(W/s) for s in files}==reviewed,'source changed during retained verification'
spec=importlib.util.spec_from_file_location('repeat_review_driver',W/'scripts/compare_repeat_prefix.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
base='cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026';runtime={};changes=[]
for p in module.runtime_files(W):
 relative=str(p.relative_to(W));old=subprocess.check_output(['git','show',f'{base}:{relative}'],cwd=W)
 runtime[relative]={'candidate':H(p),'baseline':hashlib.sha256(old).hexdigest()}
 if p.read_bytes()!=old:changes.append(relative)
assert changes==['ctc/analog.py'] and len(runtime)==28
plan=(W/'docs/repeat-prefix-plan.md').read_text();assert 'corrections' in plan.lower() and '30-second refill' in plan
assert 'repeat_prefix_enabled' in (W/'scripts/compare_repeat_prefix.py').read_text()
for name in files:
 target=D/'reviewed'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((W/name).read_bytes());assert H(target)==reviewed[name]
metadata={'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),'reviewed_sha256':reviewed,'runtime_files':runtime,'runtime_changes':changes,'runs':runs,'captured_performance_runs':0,'forbidden_access_attempts':0,'focused_tests_passed':58,'candidate_gate_valid96_accepted':True,'candidate_gate_corruptions_rejected':20,'runtime_checks':{'scalar_selection':732,'disabled_exact_vs_cd3':732,'fallback_weights_exact':589,'fallback_future_arrays_exact':588,'recognized_one_hot':143,'bounded_selection_reads':8,'owned_output_arrays':2},'verdict':'No blocking issue found; approve freezing these bytes for the predeclared offline baseline96 then candidate96 comparison. Production enablement is outside this verdict.','scope':['Synthetic source review only; no capture performance or downloaded history read.','Corrections re-evaluate the complete current prefix; recognition may recover only for a unique corrected match.','A recognized historical prefix does not guarantee its future; ordinary fallback remains exact on tested unmatched paths.']}
(D/'review-metadata.json').write_text(json.dumps(metadata,indent=2,sort_keys=True)+'\n')
manifest={str(p.relative_to(D)):H(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name!='artifact-manifest.json'}
(D/'artifact-manifest.json').write_text(json.dumps({'files':manifest,'count':len(manifest)},indent=2,sort_keys=True)+'\n')
archive=D.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(D.rglob('*')):
  if p.is_file():t.add(p,arcname=str(p.relative_to(D)),recursive=False)
with tarfile.open(archive) as t:
 members=t.getmembers();assert len(members)==len(manifest)+1
 for member in members:assert member.isfile() and t.extractfile(member).read()==(D/member.name).read_bytes()
print(json.dumps({'directory':str(D),'archive':str(archive),'archive_sha256':H(archive),'manifest_sha256':H(D/'artifact-manifest.json'),'hashed_files':len(manifest),'reviewed_sha256':reviewed,'runs':runs,'captured_performance_runs':0,'forbidden_access_attempts':0}))
