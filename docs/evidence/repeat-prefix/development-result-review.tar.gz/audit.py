from __future__ import annotations
import ast,collections,datetime,hashlib,itertools,json,math,os,statistics,subprocess,sys
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=Path('/Users/arjunhans/Documents/ctc2026');SRC=ROOT/'.worktrees/repeat-prefix';HISTORY=ROOT/'data/history';ART=ROOT/'out/repeat-prefix-v1-20261024/development';REV='357d9986babf2b21bd3bbdcc2e69550059f16154'
ALLOWED={HISTORY.resolve()/f'season-{n:03d}'/name for n in range(451,526) for name in ('feed.jsonl','market.csv','settlement.json')}
forbidden=[];read_hashes={};input_reads=set()
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):forbidden.append(event);raise RuntimeError('independent audit forbids network')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  lexical=Path(os.fsdecode(args[0])).absolute();resolved=lexical.resolve();paths=(lexical,resolved)
  if any('.botkey' in str(p).lower() or '/.env' in str(p).lower() or 'credentials' in str(p).lower() for p in paths):forbidden.append(str(lexical));raise RuntimeError('independent audit forbids credentials')
  is_history=any(p.is_relative_to(HISTORY.resolve()) or '/data/history/' in str(p).lower() or p.name in ('feed.jsonl','market.csv','settlement.json') for p in paths)
  if is_history:
   if resolved not in ALLOWED:forbidden.append(str(lexical));raise RuntimeError('history outside451–525')
   input_reads.add(str(resolved))
sys.addaudithook(audit)
def sha(b):return hashlib.sha256(b).hexdigest()
def vh(v):return sha(json.dumps(v,sort_keys=True,allow_nan=False).encode())
def read(p):
 p=Path(p);b=p.read_bytes();read_hashes[str(p)]=sha(b);return b
def load(p):return json.loads(read(p))
def git(*a):return subprocess.check_output(['git',*a],cwd=SRC,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
assert git('rev-parse','HEAD').decode().strip()==REV
before_status=git('status','--porcelain','--untracked-files=normal').decode();assert before_status==''
m=load(ART/'metadata.json');s=load(ART/'summary.json');result_bytes=read(ART/'results.jsonl');scans=load(ART/'prefix-scan.json');rows=[json.loads(x) for x in result_bytes.splitlines()]
assert result_bytes.endswith(b'\n') and sha(result_bytes)==s['results_sha256']=='0f1b73b4368d66528659c5dd0dd4e95037b382cabc861b63d6a57f045c67c3d2'
assert read_hashes[str(ART/'prefix-scan.json')]==s['scan_sha256']=='0aa8e682f55e8b8ac4269df91faaef45206481ffee730bc0bc2d28328d4880c7'
assert m['revision']==REV and m['seasons']==list(range(451,526)) and m['fraction']==.1 and m['latency']==.25 and m['rate_limit']==90 and m['ladder_scale']==.5 and m['refill_seconds']==30
assert type(m['started_at']) in (int,float) and math.isfinite(m['started_at']) and type(s['finished_at']) in (int,float) and math.isfinite(s['finished_at']) and s['finished_at']>=m['started_at']
expected_sources=sorted([*SRC.glob('ctc/*.py'),*SRC.glob('ctc/*.json'),*SRC.glob('ctc/*.npz'),SRC/'data/case.json',SRC/'scripts/check_repeat_development.py',SRC/'docs/repeat-prefix-plan.md',SRC/'scripts/experiment_execution_costs.py'])
assert set(m['source_sha256'])=={str(p) for p in expected_sources} and len(expected_sources)==21
for p in expected_sources:
 b=read(p);assert sha(b)==m['source_sha256'][str(p)] and b==git('show',REV+':'+p.relative_to(SRC).as_posix())
assert m['source_sha256'][str(SRC/'scripts/check_repeat_development.py')]=='1823b807cf131741fd4baf35624e41d1b2f978e54c0c7f6f3fe0ad0b7f049d69'
assert set(m['input_sha256'])=={str(p) for p in ALLOWED} and len(m['input_sha256'])==225
for p,h in m['input_sha256'].items():assert sha(read(p))==h
parameters=next(n.value for n in ast.parse((SRC/'scripts/experiment_execution_costs.py').read_text()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PARAMETERS' for t in n.targets))
assert isinstance(parameters,ast.Call) and isinstance(parameters.func,ast.Name) and parameters.func.id=='dict'
parameters={kw.arg:ast.literal_eval(kw.value) for kw in parameters.keywords};assert parameters==m['parameters']
case=load(SRC/'data/case.json');caps={symbol:max(1,math.floor(n*.1)) for symbol,n in case['limits'].items()}
expected_grid=list(itertools.product(range(451,526),(False,True)));assert len(rows)==150 and [(r['season'],r['repeat_prefix']) for r in rows]==expected_grid
assert len(scans)==225 and [(r['season'],r['round']) for r in scans]==list(itertools.product(range(451,526),(1,2,3)))
assert all(type(r['repeat_prefix']) is bool and type(r['season']) is int for r in rows)
assert s['runs']==150 and s['storm_scans']==225 and all(s[k]==[] for k in ('paired_mismatches','unmatched_paired_mismatches','changed_sources_or_inputs','forbidden_attempts','guard_violations'))
row_fields={'season','repeat_prefix','pnl','fills','rejected','round_pnl','fill_trace_sha256','pnl_path_sha256','final_positions','cash'}
paired=[];independent_scores=[];groups={}
for baseline,candidate in zip(rows[::2],rows[1::2]):
 assert set(baseline)==set(candidate)==row_fields
 a={k:v for k,v in baseline.items() if k!='repeat_prefix'};b={k:v for k,v in candidate.items() if k!='repeat_prefix'}
 assert a==b and vh(a)==vh(b)
 paired.append({'season':baseline['season'],'all_fields_equal_except_enable_flag':True,'comparison_value_sha256':vh(a),'fill_trace_sha256':baseline['fill_trace_sha256'],'pnl_path_sha256':baseline['pnl_path_sha256']})
 prices=load(HISTORY/f"season-{baseline['season']:03d}"/'settlement.json')
 assert set(prices)==set(caps) and all(type(p) in (int,float) and math.isfinite(p) and p>0 for p in prices.values())
 for row in (baseline,candidate):
  assert type(row['pnl']) in (int,float) and math.isfinite(row['pnl']) and type(row['cash']) in (int,float) and math.isfinite(row['cash'])
  assert type(row['fills']) is int and row['fills']>=0 and type(row['rejected']) is int and row['rejected']>=0
  assert set(row['round_pnl'])=={'1','2','3'} and row['round_pnl']['3']==row['pnl'] and all(type(v) in (int,float) and math.isfinite(v) for v in row['round_pnl'].values())
  assert set(row['final_positions'])==set(caps) and all(type(q) is int for q in row['final_positions'].values())
  for h in ('fill_trace_sha256','pnl_path_sha256'):assert len(row[h])==64 and all(c in '0123456789abcdef' for c in row[h])
  score=row['cash']+sum(q*prices[symbol] for symbol,q in row['final_positions'].items());assert score==row['pnl']
  independent_scores.append({'season':row['season'],'repeat_prefix':row['repeat_prefix'],'cash_plus_settlement_holdings':score,'exactly_matches_reported_pnl':True})
for enabled in (False,True):
 values=[r['pnl'] for r in rows if r['repeat_prefix']==enabled]
 groups[str(enabled)]={'mean':statistics.mean(values),'worst':min(values),'best':max(values),'negative':sum(v<0 for v in values)}
assert groups==s['groups']
# Independent streaming candidate-set intersection; never call AnalogEnsemble or its helper.
import numpy as np
lib=SRC/'ctc/analog_library.npz';assert sha(read(lib))=='22694387c3b612f5c20853feb9143e1bf8b8f5722a845da8ed584ab1b30bdf09'
with np.load(lib,allow_pickle=False) as z:tracks=z['tracks'].copy()
assert tracks.shape==(1350,241,4) and np.isfinite(tracks).all()
ages=list(range(0,481,2)); independent_scans=[];details=[];total_observations=0
for season in range(451,526):
 news=[json.loads(line) for line in read(HISTORY/f'season-{season:03d}'/'feed.jsonl').splitlines()]
 storms=collections.defaultdict(list)
 for message in news:
  if message.get('type')=='storm':storms[message['round']].append(message)
 assert set(storms)=={1,2,3}
 for rnd in (1,2,3):
  obs=storms[rnd];assert len(obs)==241 and [o['age'] for o in obs]==ages
  assert all(type(o['age']) is int and all(type(o[c]) in (int,float) and math.isfinite(o[c]) for c in ('x','y','radius','intensity')) for o in obs)
  observed=np.array([[o[c] for c in ('x','y','radius','intensity')] for o in obs],dtype=np.float64)
  survivors=np.ones(len(tracks),dtype=bool);matches=[];survivor_counts=[]
  for column,current in enumerate(observed):
   survivors &= np.all(tracks[:,column,:]==current,axis=1)
   count=int(np.count_nonzero(survivors));survivor_counts.append(count)
   matches.append(int(np.flatnonzero(survivors)[0]) if column+1>=21 and count==1 else None)
  recognized=[(i+1,row) for i,row in enumerate(matches) if row is not None]
  first=recognized[0] if recognized else None
  diverged=any(row!=first[1] for row in matches[first[0]:]) if first else False
  independent_scans.append({'season':season,'round':rnd,'observations':len(obs),'recognized_prefixes':len(recognized),'first_match':list(first) if first else None,'final_match':matches[-1],'diverged_after_match':diverged})
  details.append({'season':season,'round':rnd,'age_count':len(obs),'age_grid_complete':True,'duplicate_ages':0,'float64_track_sha256':sha(observed.tobytes()),'prefix_surviving_library_rows':survivor_counts,'eligible_prefix_matches':matches,'columns_read_per_update':'only the newly observed column'});total_observations+=len(obs)
assert independent_scans==scans
assert sum(x['recognized_prefixes']>0 for x in independent_scans)==s['activated_storms']==0 and sum(x['diverged_after_match'] for x in independent_scans)==s['diverged_storms']==0
assert total_observations==225*241==54225
(OUT/'independent-prefix-scan.json').write_text(json.dumps(independent_scans,indent=2)+'\n');(OUT/'independent-prefix-details.json').write_text(json.dumps(details,indent=2)+'\n')
changed=[p for p,h in read_hashes.items() if sha(Path(p).read_bytes())!=h];assert changed==[] and forbidden==[] and set(input_reads)=={str(p) for p in ALLOWED}
assert git('rev-parse','HEAD').decode().strip()==REV and git('status','--porcelain','--untracked-files=normal').decode()==before_status
report={'audit':'independent development split result/provenance/prefix audit','source_revision':REV,'source_count':21,'input_count':225,'seasons':list(range(451,526)),'rows':150,'storm_scans':225,'explicit_weather_observations':total_observations,'all_prefixes_examined':total_observations,'eligible_prefixes_at_minimum21_points':225*(241-20),'fixed_parameters':{k:m[k] for k in ('fraction','latency','rate_limit','ladder_scale','refill_seconds','parameters')},'source_and_input_hashes_verified_before_after':True,'all_source_files_equal_frozen_git_blobs':True,'worktree_head_and_clean_status_unchanged':True,'groups_recomputed':groups,'paired_all_fields_equal_except_enable_flag':paired,'independent_terminal_score_checks':independent_scores,'independent_prefix_algorithm':'intersect1350 row candidates using exact four-channel equality for each newly observed library column; unique selection allowed only after21 complete observations','candidate_helper_used_for_independent_scan':False,'independent_scan_equals_all225_archived_records':True,'activated_storms':0,'diverged_storms':0,'library_sha256':sha(read(lib)),'negative_seasons':[r['season'] for r in rows if not r['repeat_prefix'] and r['pnl']<0],'source_input_artifact_sha256':read_hashes,'changed_sources_inputs':changed,'forbidden_attempts':forbidden,'allowed_history_files_read':sorted(input_reads),'history_outside451_525_read':False,'active_capture247_or_later_read':False,'network_requests':0,'original_results_sha256':sha(result_bytes),'original_scan_sha256':read_hashes[str(ART/'prefix-scan.json')],'started_at_utc':datetime.datetime.fromtimestamp(m['started_at'],datetime.timezone.utc).isoformat(),'finished_at_utc':datetime.datetime.fromtimestamp(s['finished_at'],datetime.timezone.utc).isoformat(),'original_elapsed_seconds':s['finished_at']-m['started_at'],'limitations':['Reused development data, not a holdout.','Zero recognition activations test unmatched fallback, not benefits or false-match handling under activation.','Historical simulator does not reproduce full production supervision or real queue competition.']}
(OUT/'audit.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:report[k] for k in ('source_revision','source_count','input_count','rows','storm_scans','explicit_weather_observations','eligible_prefixes_at_minimum21_points','groups_recomputed','independent_scan_equals_all225_archived_records','activated_storms','diverged_storms','negative_seasons','changed_sources_inputs','forbidden_attempts','original_elapsed_seconds')},indent=2))
