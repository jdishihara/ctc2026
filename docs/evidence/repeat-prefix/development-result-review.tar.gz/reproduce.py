from __future__ import annotations
import ast,contextlib,copy,hashlib,io,json,math,os,subprocess,sys
from collections.abc import Mapping
from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch
OUT=Path(__file__).resolve().parent;ROOT=Path('/Users/arjunhans/Documents/ctc2026');SRC=ROOT/'.worktrees/repeat-prefix';HISTORY=(ROOT/'data/history').resolve();ART=ROOT/'out/repeat-prefix-v1-20261024/development';REV='357d9986babf2b21bd3bbdcc2e69550059f16154'
ALLOWED={HISTORY/f'season-{n:03d}'/name for n in range(451,526) for name in ('feed.jsonl','market.csv','settlement.json')};selected=(451,488,525)
forbidden=[];violations=[];active={};history_reads=set()
def require(ok,msg):
 if not ok:violations.append(msg);raise RuntimeError(msg)
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):forbidden.append(event);raise RuntimeError('guarded reproduction forbids network')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  lexical=Path(os.fsdecode(args[0])).absolute();resolved=lexical.resolve();paths=(lexical,resolved)
  if any('.botkey' in str(p).lower() or '/.env' in str(p).lower() or 'credentials' in str(p).lower() for p in paths):forbidden.append(str(lexical));raise RuntimeError('guarded reproduction forbids credentials')
  if any(p.is_relative_to(HISTORY) or '/data/history/' in str(p).lower() or p.name in ('feed.jsonl','market.csv','settlement.json') for p in paths):
   if resolved not in ALLOWED or int(resolved.parent.name.split('-')[1]) not in selected:forbidden.append(str(lexical));raise RuntimeError('history outside selected451/488/525 reproduction')
   history_reads.add(str(resolved))
   if resolved.name=='settlement.json' and active.get('phase')=='run':
    sim=active['sim'];require(math.isfinite(sim.t) and sim.t>=2340 and not sim.market_open,'strategy attempted direct early settlement-file read')
sys.addaudithook(audit)
def sha(b):return hashlib.sha256(b).hexdigest()
def vh(v):return sha(json.dumps(v,sort_keys=True,allow_nan=False).encode())
def git(*a):return subprocess.check_output(['git',*a],cwd=SRC,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
static=json.loads((OUT/'audit.json').read_text());meta=json.loads((ART/'metadata.json').read_text());archived=[json.loads(x) for x in (ART/'results.jsonl').read_text().splitlines()]
assert git('rev-parse','HEAD').decode().strip()==REV and not git('status','--porcelain','--untracked-files=normal').strip()
source_hashes=meta['source_sha256'];input_hashes={p:h for p,h in meta['input_sha256'].items() if int(Path(p).parent.name.split('-')[1]) in selected}
for p,h in {**source_hashes,**input_hashes}.items():assert sha(Path(p).read_bytes())==h
case=json.loads((SRC/'data/case.json').read_text());case['limits']={s:max(1,math.floor(n*.1)) for s,n in case['limits'].items()};parameters=meta['parameters'];sys.path.insert(0,str(SRC))
from ctc.sim import Sim,real_time
from ctc.ladder import Ladder
from ctc.strategies import FairValueTrader
from ctc.analog import AnalogEnsemble
class TerminalPrices(Mapping):
 def __init__(self,prices,sim):self._prices=dict(prices);self._sim=sim
 def check(self):
  sim=self._sim;require(math.isfinite(sim.t) and sim.t>=2340 and not sim.market_open and active['processed_events']==active['expected_events'],'early terminal-price access')
  active['settlement_reads']+=1
 def __getitem__(self,key):self.check();return self._prices[key]
 def __iter__(self):return iter(self._prices)
 def __len__(self):return len(self._prices)
 def copy(self):self.check();return dict(self)
 def __copy__(self):return TerminalPrices(self.copy(),self._sim)
 def __deepcopy__(self,memo):return self.__copy__()
class RecordedSim(Sim):
 def _etf(self,etf,qty,sign):
  result=super()._etf(etf,qty,sign)
  if result:active['conversions'].append({'t':self.t,'etf':etf,'qty':qty,'sign':sign})
  return result
class AuditedTrader(FairValueTrader):
 def on_news(self,sim,message):
  require(real_time(message['time'],message['round'])==sim.t,'news delivered at a future or incorrect virtual time')
  active['processed_events']+=1;active['news_callbacks']+=1
  return super().on_news(sim,message)
 def on_quotes(self,sim):
  require(self.competition_id==getattr(sim,'competition_id',None),'quote callback changed simulation identity')
  model=self.model;before=(model.round,copy.deepcopy(model.last_obs),set(model.reported_rounds),model.live_history_ready)
  result=super().on_quotes(sim)
  after=(model.round,copy.deepcopy(model.last_obs),set(model.reported_rounds),model.live_history_ready)
  require(self.model is model and before==after,'quote callback mutated news history')
  active['processed_events']+=1;active['quote_callbacks']+=1
  return result
original_weights=AnalogEnsemble.weights
def checked_weights(ensemble,*a,**kw):
 result=original_weights(ensemble,*a,**kw);active['weight_calls']+=1
 if getattr(ensemble,'repeat_match',None) is not None:active['activated_weight_calls']+=1
 return result
runs=[]
for season in selected:
 for enabled in (False,True):
  active.clear();active.update(phase='construct',processed_events=0,settlement_reads=0,news_callbacks=0,quote_callbacks=0,weight_calls=0,activated_weight_calls=0,conversions=[])
  sim=RecordedSim(HISTORY/f'season-{season:03d}',copy.deepcopy(case),half_spread=.0015,latency=.25,rate_limit=90,ladder=Ladder(refill_secs=30,scale=.5))
  active['sim']=sim;active['expected_events']=sum(t<2340 for t,_,_,_ in sim.events)
  original_prices=dict(sim.settlement);sim.settlement=TerminalPrices(original_prices,sim)
  strategy=AuditedTrader(**parameters,repeat_prefix=enabled);log=io.StringIO();active['phase']='run'
  with contextlib.redirect_stdout(log),patch.object(AnalogEnsemble,'weights',checked_weights):pnl=sim.run(strategy)
  active['phase']='completed';require(sim.t==2340 and not sim.market_open and not sim.orders and not sim.pending,'terminal market not closed and cleared')
  require(active['processed_events']==active['expected_events'],'not all causal events processed')
  require(active['activated_weight_calls']==0,'unexpected recognition in independently unmatched development season')
  row={'season':season,'repeat_prefix':enabled,'pnl':pnl,'fills':len(sim.fills),'rejected':sim.rejected,'round_pnl':sim.round_pnl,'fill_trace_sha256':vh([asdict(f) for f in sim.fills]),'pnl_path_sha256':vh(sim.pnl_path),'final_positions':sim.position,'cash':sim.cash}
  row=json.loads(json.dumps(row,allow_nan=False));expected=next(r for r in archived if r['season']==season and r['repeat_prefix']==enabled)
  differences=[k for k in set(row)|set(expected) if row.get(k)!=expected.get(k)];assert differences==[],(season,enabled,differences)
  cash=0.;position=dict.fromkeys(case['limits'],0)
  for fill in sim.fills:
   q=fill.qty*(1 if fill.side=='buy' else -1);cash-=q*fill.price;position[fill.symbol]+=q
  for conversion in active['conversions']:
   etf,qty,sign=(conversion[k] for k in ('etf','qty','sign'));position[etf]+=sign*qty
   for symbol,n in case['etfs'][etf]['basket'].items():position[symbol]-=sign*qty*n
  assert cash==sim.cash and position==sim.position
  score=cash+sum(q*original_prices[s] for s,q in position.items());assert score==pnl
  directory=OUT/'reproductions'/f'{season}-{int(enabled)}';directory.mkdir(parents=True,exist_ok=True)
  (directory/'result.json').write_text(json.dumps(row,indent=2)+'\n');(directory/'fills.json').write_text(json.dumps([asdict(f) for f in sim.fills],allow_nan=False)+'\n');(directory/'pnl-path.json').write_text(json.dumps(sim.pnl_path,allow_nan=False)+'\n');(directory/'conversions.json').write_text(json.dumps(active['conversions'],allow_nan=False)+'\n');(directory/'strategy.log').write_text(log.getvalue())
  run={'season':season,'repeat_prefix':enabled,'all_result_fields_exact':True,'different_fields':differences,'pnl':pnl,'fills':len(sim.fills),'rejected':sim.rejected,'fill_trace_sha256':row['fill_trace_sha256'],'pnl_path_sha256':row['pnl_path_sha256'],'accepted_conversions':len(active['conversions']),'independent_cash':cash,'independent_positions_equal':True,'independent_settlement_score':score,'processed_events':active['processed_events'],'news_callbacks':active['news_callbacks'],'quote_callbacks':active['quote_callbacks'],'weight_calls':active['weight_calls'],'activated_weight_calls':active['activated_weight_calls'],'guarded_terminal_price_reads':active['settlement_reads'],'final_report_rounds':sorted(strategy.model.reported_rounds)}
  runs.append(run);print(json.dumps(run),flush=True)
for baseline,candidate in zip(runs[::2],runs[1::2]):assert {k:v for k,v in baseline.items() if k!='repeat_prefix'}=={k:v for k,v in candidate.items() if k!='repeat_prefix'}
changed=[p for p,h in {**source_hashes,**input_hashes}.items() if sha(Path(p).read_bytes())!=h];assert changed==[] and forbidden==[] and violations==[]
assert git('rev-parse','HEAD').decode().strip()==REV and not git('status','--porcelain','--untracked-files=normal').strip()
report={'source_revision':REV,'source_sha256':source_hashes,'selected_input_sha256':input_hashes,'settings':{k:meta[k] for k in ('fraction','latency','rate_limit','ladder_scale','refill_seconds','parameters')},'runs':runs,'all_six_results_match_archives_exactly':True,'all_three_pairs_match_exactly':True,'changed_sources_inputs':changed,'forbidden_attempts':forbidden,'guard_violations':violations,'history_files_read':sorted(history_reads),'history_read_seasons':list(selected),'active_capture247_or_later_outcomes_read':False,'network_requests':0,'alternative_performance_variants':0,'limitations':['These are repetitions of already-completed fixed development settings.','Historical simulation is not full production supervision.']}
(OUT/'reproduction.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
