from __future__ import annotations
import gzip, hashlib, io, json, subprocess, tarfile
from pathlib import Path
P=Path(__file__).resolve().parent
ROOT=Path('/Users/arjunhans/Documents/ctc2026')
ART=ROOT/'out/repeat-prefix-v1-20261024/development'
SRC=ROOT/'.worktrees/repeat-prefix'
REV='357d9986babf2b21bd3bbdcc2e69550059f16154'
def sha(b): return hashlib.sha256(b).hexdigest()
a=json.loads((P/'audit.json').read_text()); r=json.loads((P/'reproduction.json').read_text())
assert a['rows']==150 and a['storm_scans']==225 and len(a['paired_all_fields_equal_except_enable_flag'])==75
assert a['independent_scan_equals_all225_archived_records'] and a['activated_storms']==a['diverged_storms']==0
assert r['all_six_results_match_archives_exactly'] and r['all_three_pairs_match_exactly'] and len(r['runs'])==6
assert all(not obj[k] for obj,keys in [(a,['changed_sources_inputs','forbidden_attempts']),(r,['changed_sources_inputs','forbidden_attempts','guard_violations'])] for k in keys)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SRC).decode().strip()==REV
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=normal'],cwd=SRC).strip()
original=P/'original-artifacts';original.mkdir(exist_ok=True)
for name in ['metadata.json','results.jsonl','prefix-scan.json','summary.json']:
 data=(ART/name).read_bytes();assert sha(data)==a['source_input_artifact_sha256'][str(ART/name)]
 (original/name).write_bytes(data)
for path,h in r['source_sha256'].items(): assert sha(Path(path).read_bytes())==h
report='''# Independent repeat-prefix development audit

## Verdict

Verified the complete declared development comparison at frozen source
`357d9986babf2b21bd3bbdcc2e69550059f16154`. No blocker to reporting this
result under its development-only scope. No model or live promotion is inferred.

## Coverage and provenance

- All 150 rows are present in the exact 75-season by two-mode grid, seasons
  451–525 inclusive. All 225 storm scan records are present in round order 1–3.
- All 21 declared source files equal their frozen Git blobs and recorded
  SHA-256 values. All 225 declared input files match their hashes. Source,
  input and result artifacts were unchanged across the static audit; source
  and nine selected input files were unchanged across representative reruns.
  The frozen worktree remained clean at the same HEAD.
- Fixed settings match: 10% position limits; 0.25-second simulated latency;
  90 requests/minute; existing thin ladder scale 0.5 and 30-second refill;
  half-spread 0.0015. The full strategy parameter mapping is retained in
  `audit.json`, matches frozen PARAMETERS, and was used by the reruns.
- Original results SHA-256:
  `0f1b73b4368d66528659c5dd0dd4e95037b382cabc861b63d6a57f045c67c3d2`.
  Original prefix scan SHA-256:
  `0aa8e682f55e8b8ac4269df91faaef45206481ffee730bc0bc2d28328d4880c7`.

## Independent prefix scan and accounting

An independent streaming intersection over all 1,350 fitted library rows
compared only the newly observed x/y/radius/intensity column at each update.
It did not import or call the candidate recognition helper. Each storm has
all 241 ages 0, 2, …, 480 with no duplicate ages. The scan checked 54,225
prefixes, including 49,725 eligible prefixes with at least 21 observations.
All 225 independently generated records equal the archived scan: zero
recognized prefixes, activated storms or later divergences.

All 75 baseline/candidate pairs are exactly equal in every field except the
repeat-prefix enable flag, including round P&L, fills, rejections, fill-trace
hash, P&L-path hash, cash and final positions. All 150 terminal scores were
independently recomputed as cash plus marked holdings and equal their rows.

| Per-mode metric | Independently verified value |
|---|---:|
| Runs | 75 |
| Mean | 1476.4297796871826 |
| Worst | -723.1007052140435 |
| Best | 4132.793328384176 |
| Negative runs | 6 |

The negative seasons in both modes are 462, 468, 485, 489, 508 and 520.
The original summary records zero paired mismatches, unmatched mismatches,
forbidden attempts, guard violations and changed source/input hashes.

## Representative guarded reproductions

Both modes were independently rerun for each requested season using the
same frozen simulation, strategy and fixed settings. Each rerun matches
every archived result field exactly. Accepted fills and ETF conversions
independently reconstruct final cash and positions, and the terminal score.

| Season | P&L in each mode | Fills | Accepted conversions |
|---|---:|---:|---:|
| 451 | 1582.0860172301057 | 197 | 11 |
| 488 | 2979.41692023858 | 201 | 10 |
| 525 | 2566.6087709917897 | 169 | 5 |

The rerun guards block network, credential reads, history outside these three
requested seasons, direct early settlement-file reads, and terminal price
access before finite time 2340, market closure and processing of all causal
events. News callbacks verify event time; quote callbacks verify unchanged
model history and identity. All six runs processed all events, retained all
three final reports, and recorded zero actual recognition activations,
forbidden attempts or guard violations. Source files were not edited.

## Limits

These are reused development inputs, not a held-out result. Zero recognition
activations establish unchanged behavior for unmatched storms in this set;
they do not establish a benefit from recognition or behavior after an exact
match later diverges. The historical simulator does not reproduce complete
production supervision or real queue competition. Results are simulated
outcomes, not owned live profit. No active capture 247 or later data, history
outside 451–525, credentials, network calls or alternative settings were used.

## Evidence

`audit.py` and `audit.json` retain all static checks and the independent scan.
`independent-prefix-details.json` retains survivor counts for every prefix.
`reproduce.py` and `reproduction.json` retain the guarded rerun procedure and
checks. Each of the six `reproductions/` folders retains the result, accepted
fills, P&L path, conversions and strategy log. `original-artifacts/` contains
byte-identical copies of the four audited original artifacts.
`file-manifest.json` hashes every payload file. `package.json` records the
archive hash and byte-for-byte verification of every member.
'''
(P/'review.md').write_text(report)
excluded={'file-manifest.json','package.json','independent-repeat-development-results.tar.gz'}
files=sorted(p for p in P.rglob('*') if p.is_file() and p.name not in excluded)
manifest={str(p.relative_to(P)):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in files}
(P/'file-manifest.json').write_text(json.dumps({'source_revision':REV,'files':manifest},indent=2)+'\n')
files.append(P/'file-manifest.json');files.sort()
archive=P/'independent-repeat-development-results.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(mode='w',fileobj=gz,format=tarfile.PAX_FORMAT) as tar:
   for p in files:
    data=p.read_bytes();item=tarfile.TarInfo(p.relative_to(P).as_posix());item.size=len(data);item.mode=0o644;item.mtime=0
    tar.addfile(item,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(files)
 assert [m.name for m in members]==[p.relative_to(P).as_posix() for p in files]
 for member,p in zip(members,files):assert member.isfile() and tar.extractfile(member).read()==p.read_bytes()
package={'source_revision':REV,'driver_sha256':r['source_sha256'][str(SRC/'scripts/check_repeat_development.py')],'archive':str(archive),'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'archive_file_count':len(files),'payload_files_hashed':len(manifest),'all_archive_members_verified_byte_for_byte':True,'manifest_sha256':sha((P/'file-manifest.json').read_bytes()),'audit_sha256':sha((P/'audit.json').read_bytes()),'reproduction_sha256':sha((P/'reproduction.json').read_bytes()),'report_sha256':sha((P/'review.md').read_bytes())}
(P/'package.json').write_text(json.dumps(package,indent=2)+'\n')
print(json.dumps(package,indent=2))
