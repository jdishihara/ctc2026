# Independent repeat-prefix development audit

## Verdict

Verified the complete declared development comparison at frozen source
`357d9986babf2b21bd3bbdcc2e69550059f16154`. No blocker to reporting this
result under its development-only scope. No model or live promotion is inferred.

## Coverage and provenance

- All 150 rows are present in the exact 75-season by two-mode grid, seasons
  451–525 inclusive. All 225 storm scan records are present in round order 1–3.
- All 21 declared source files equal their frozen Git blobs and recorded
  SHA-256 values. All 225 declared input files match their hashes. Source,
  input and result artifacts were unchanged across the static audit; source
  and nine selected input files were unchanged across representative reruns.
  The frozen worktree remained clean at the same HEAD.
- Fixed settings match: 10% position limits; 0.25-second simulated latency;
  90 requests/minute; existing thin ladder scale 0.5 and 30-second refill;
  half-spread 0.0015. The full strategy parameter mapping is retained in
  `audit.json`, matches frozen PARAMETERS, and was used by the reruns.
- Original results SHA-256:
  `0f1b73b4368d66528659c5dd0dd4e95037b382cabc861b63d6a57f045c67c3d2`.
  Original prefix scan SHA-256:
  `0aa8e682f55e8b8ac4269df91faaef45206481ffee730bc0bc2d28328d4880c7`.

## Independent prefix scan and accounting

An independent streaming intersection over all 1,350 fitted library rows
compared only the newly observed x/y/radius/intensity column at each update.
It did not import or call the candidate recognition helper. Each storm has
all 241 ages 0, 2, …, 480 with no duplicate ages. The scan checked 54,225
prefixes, including 49,725 eligible prefixes with at least 21 observations.
All 225 independently generated records equal the archived scan: zero
recognized prefixes, activated storms or later divergences.

All 75 baseline/candidate pairs are exactly equal in every field except the
repeat-prefix enable flag, including round P&L, fills, rejections, fill-trace
hash, P&L-path hash, cash and final positions. All 150 terminal scores were
independently recomputed as cash plus marked holdings and equal their rows.

| Per-mode metric | Independently verified value |
|---|---:|
| Runs | 75 |
| Mean | 1476.4297796871826 |
| Worst | -723.1007052140435 |
| Best | 4132.793328384176 |
| Negative runs | 6 |

The negative seasons in both modes are 462, 468, 485, 489, 508 and 520.
The original summary records zero paired mismatches, unmatched mismatches,
forbidden attempts, guard violations and changed source/input hashes.

## Representative guarded reproductions

Both modes were independently rerun for each requested season using the
same frozen simulation, strategy and fixed settings. Each rerun matches
every archived result field exactly. Accepted fills and ETF conversions
independently reconstruct final cash and positions, and the terminal score.

| Season | P&L in each mode | Fills | Accepted conversions |
|---|---:|---:|---:|
| 451 | 1582.0860172301057 | 197 | 11 |
| 488 | 2979.41692023858 | 201 | 10 |
| 525 | 2566.6087709917897 | 169 | 5 |

The rerun guards block network, credential reads, history outside these three
requested seasons, direct early settlement-file reads, and terminal price
access before finite time 2340, market closure and processing of all causal
events. News callbacks verify event time; quote callbacks verify unchanged
model history and identity. All six runs processed all events, retained all
three final reports, and recorded zero actual recognition activations,
forbidden attempts or guard violations. Source files were not edited.

## Limits

These are reused development inputs, not a held-out result. Zero recognition
activations establish unchanged behavior for unmatched storms in this set;
they do not establish a benefit from recognition or behavior after an exact
match later diverges. The historical simulator does not reproduce complete
production supervision or real queue competition. Results are simulated
outcomes, not owned live profit. No active capture 247 or later data, history
outside 451–525, credentials, network calls or alternative settings were used.

## Evidence

`audit.py` and `audit.json` retain all static checks and the independent scan.
`independent-prefix-details.json` retains survivor counts for every prefix.
`reproduce.py` and `reproduction.json` retain the guarded rerun procedure and
checks. Each of the six `reproductions/` folders retains the result, accepted
fills, P&L path, conversions and strategy log. `original-artifacts/` contains
byte-identical copies of the four audited original artifacts.
`file-manifest.json` hashes every payload file. `package.json` records the
archive hash and byte-for-byte verification of every member.
