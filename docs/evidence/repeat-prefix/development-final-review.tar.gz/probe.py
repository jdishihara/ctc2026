from __future__ import annotations
import ast,contextlib,copy,hashlib,importlib.util,io,json,math,os,subprocess,sys,types
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
OUT=Path(__file__).resolve().parent; DRIVER=OUT/'reviewed-driver.py';SOURCE=DRIVER.read_text();tree=ast.parse(SOURCE)
forbidden=[]
def outer_audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):forbidden.append(event);raise RuntimeError('synthetic review forbids network')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=os.fsdecode(args[0]).lower()
  if '.botkey' in p or '/.env' in p or 'credentials' in p or '/data/history/' in p or p.endswith('/data/history'):forbidden.append(p);raise RuntimeError('synthetic review forbids credentials and real history')
sys.addaudithook(outer_audit)
spec=importlib.util.spec_from_file_location('reviewed_development_driver',DRIVER);driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
checks=[]
def record(name,**details):checks.append({'name':name,**details});print(json.dumps(checks[-1]),flush=True)
# Repeat the original terminal-price bypasses and normal Mapping operations.
accesses={'item':lambda g:g['SYNTH'],'get':lambda g:g.get('SYNTH'),'items':lambda g:list(g.items()),'values':lambda g:list(g.values()),'dict':dict,'copy_method':lambda g:g.copy(),'copy':copy.copy,'deepcopy':copy.deepcopy}
for name,access in accesses.items():
 v=[];sim=SimpleNamespace(t=0.,market_open=True);g=driver.TerminalPrices({'SYNTH':123.},sim,v)
 try:access(g)
 except RuntimeError:pass
 else:raise AssertionError('premature '+name)
 assert v==['early settlement read'];record('early '+name+' is rejected and sticky',passed=True)
for clock in (float('nan'),float('inf'),-float('inf')):
 v=[];g=driver.TerminalPrices({'SYNTH':123.},SimpleNamespace(t=clock,market_open=False),v)
 try:g['SYNTH']
 except RuntimeError:pass
 else:raise AssertionError('nonfinite clock')
 assert v==['early settlement read'];record('nonfinite terminal clock rejected',passed=True,clock=str(clock))
v=[];sim=SimpleNamespace(t=2340.,market_open=False);g=driver.TerminalPrices({'SYNTH':123.},sim,v)
assert callable(g.values) and list(g.values())==[123.]
for access in accesses.values():access(g)
assert v==[]
copied=copy.deepcopy(g);assert copied.sim is sim and copied.violations is v
sim.t=0.
try:copied['SYNTH']
except RuntimeError:pass
else:raise AssertionError('copied early read')
assert v==['early settlement read'];record('successful deepcopy retains original clock and sticky violation list',passed=True)
# Exact production input hook with synthetic paths only.
history=OUT/'synthetic-history';history.mkdir();violations=[];hook=driver.make_input_audit(history,violations)
for relative in ('season-451/feed.jsonl','season-525/settlement.json'):
 hook('open',(str(history/relative),'r',0));record('declared development input allowed',passed=True,path=relative)
for path in [history/'season-450/feed.jsonl',history/'season-526/feed.jsonl',history/'season-247/settlement.json',history/'season-451/extra.json',OUT/'outside/season-526/feed.jsonl',OUT/'synthetic-recordings/active247/feed.jsonl']:
 before=len(violations)
 try:hook('open',(str(path),'r',0))
 except RuntimeError:pass
 else:raise AssertionError('undeclared path '+str(path))
 assert len(violations)==before+1;record('undeclared input rejected and latched',passed=True,path=str(path))
for basename in ('feed.jsonl','track-data.txt'):
 mirror=OUT/('synthetic-mirror-'+basename)/'season-526'/basename;mirror.parent.mkdir(parents=True);mirror.write_text('synthetic only\n')
 link=history/('season-451' if basename=='feed.jsonl' else 'season-452')/'feed.jsonl';link.parent.mkdir(parents=True);link.symlink_to(mirror)
 before=len(violations)
 try:hook('open',(str(link),'r',0));blocked=False
 except RuntimeError:blocked=True
 if blocked:assert len(violations)==before+1
 record('declared symlink with target basename '+basename,passed=blocked,blocker=not blocked)
for event,args in [('socket.connect',()),('socket.getaddrinfo',()),('socket.bind',()),('open',(str(OUT/'.botkey'),'r',0)),('open',(str(OUT/'.env'),'r',0))]:
 before=len(violations)
 try:hook(event,args)
 except RuntimeError:pass
 else:raise AssertionError('network/credential audit event accepted')
 assert len(violations)==before+1
 record('synthetic forbidden event rejected and latched',passed=True,event=event)
# Run actual main control flow on 75 entirely synthetic seasons using stub models/simulators.
# No real model, market input or historical performance calculation is imported.
fixture=OUT/'synthetic-source';(fixture/'scripts').mkdir(parents=True);(fixture/'ctc').mkdir();(fixture/'data').mkdir();(fixture/'docs').mkdir()
(fixture/'scripts/check_repeat_development.py').write_text(SOURCE);(fixture/'scripts/experiment_execution_costs.py').write_text('PARAMETERS = {}\n');(fixture/'docs/repeat-prefix-plan.md').write_text('synthetic protocol\n');(fixture/'data/case.json').write_text('{"limits":{"SYNTH":10}}\n');(fixture/'ctc/sim.py').write_text('# synthetic import stub\n')
synthetic=OUT/'synthetic-paired-history';synthetic.mkdir()
for season in range(451,526):
 d=synthetic/f'season-{season:03d}';d.mkdir();(d/'feed.jsonl').write_text(''.join(json.dumps({'type':'storm','round':r,'age':a,'x':1.,'y':2.,'radius':3.,'intensity':4.})+'\n' for r in (1,2,3) for a in range(0,481,2)));(d/'market.csv').write_text('synthetic\n');(d/'settlement.json').write_text('{"SYNTH":123}\n')
class FakeAnalog:
 def __init__(self,*a,**kw):pass
 def _repeat_index(self,obs):return None
class FakeLadder:
 def __init__(self,**kw):assert kw=={'refill_secs':30,'scale':.5}
class FakeTrader:
 def __init__(self,**kw):self.enabled=kw['repeat_prefix']
class FakeSim:
 calls=0
 def __init__(self,folder,case,**kw):
  assert 451<=int(Path(folder).name.split('-')[-1])<=525 and case['limits']=={'SYNTH':1}
  assert kw['latency']==.25 and kw['rate_limit']==90
  self.settlement={'SYNTH':123.};self.t=0.;self.market_open=True;self.fills=[];self.rejected=0;self.position={'SYNTH':0};self.cash=0.;self.round_pnl={};self.pnl_path=[]
 def run(self,strategy):
  type(self).calls+=1;self.market_open=False;self.t=2340.;assert dict(self.settlement)=={'SYNTH':123.}
  pnl=1. if strategy.enabled else 0.;self.cash=pnl;self.round_pnl={3:pnl};self.pnl_path=[(2340.,pnl)];return pnl
mods={}
for name in ('ctc','scripts','ctc.analog','ctc.ladder','ctc.sim','ctc.strategies','scripts.experiment_execution_costs'):
 mods[name]=types.ModuleType(name)
mods['ctc.analog'].AnalogEnsemble=FakeAnalog;mods['ctc.ladder'].Ladder=FakeLadder;mods['ctc.sim'].Sim=FakeSim;mods['ctc.strategies'].FairValueTrader=FakeTrader;mods['scripts.experiment_execution_costs'].PARAMETERS={}
for name in ('ctc','scripts'):mods[name].__path__=[]
sp=importlib.util.spec_from_file_location('synthetic_main_driver',fixture/'scripts/check_repeat_development.py');module=importlib.util.module_from_spec(sp);sp.loader.exec_module(module)
def git_stub(args,**kw):
 if args[1:3]==['rev-parse','HEAD']:return 'synthetic-revision\n'
 if args[1]=='status':return b''
 if args[1]=='show':return (fixture/args[2].split(':',1)[1]).read_bytes()
 raise AssertionError(args)
log=io.StringIO(); resultdir=OUT/'synthetic-unmatched-results';exitcode=0
with patch.dict(sys.modules,mods),patch.object(module.subprocess,'check_output',git_stub),patch.object(module.sys,'argv',[str(fixture/'scripts/check_repeat_development.py'),'--history-root',str(synthetic),'--out',str(resultdir)]),contextlib.redirect_stdout(log):
 try:module.main()
 except SystemExit as exc:exitcode=exc.code
(OUT/'synthetic-main.stdout.log').write_text(log.getvalue());summary=json.loads((resultdir/'summary.json').read_text())
assert FakeSim.calls==150 and summary['runs']==150 and summary['storm_scans']==225 and summary['activated_storms']==0 and summary['paired_mismatches']==list(range(451,526)) and summary['unmatched_paired_mismatches']==list(range(451,526)) and exitcode==1
record('actual main rejects75 unmatched output differences after retaining diagnostics',passed=True,exit_code=exitcode,runs=summary['runs'],storm_scans=summary['storm_scans'],activated_storms=summary['activated_storms'],paired_mismatch_count=len(summary['paired_mismatches']),real_performance_runs=0)
# Check the exact divergence indexing independently with synthetic match streams.
main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
scan_assign=next(n for n in ast.walk(main) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='divergence' for t in n.targets))
code=compile(ast.Expression(scan_assign.value),str(DRIVER),'eval')
for name,matches,expected in [('never', [None]*30,False),('stable',[None]*20+[7]*10,False),('later_divergence',[None]*20+[7]*4+[None]*6,True),('recovered',[None]*20+[7]*4+[None]+[7]*5,True),('last_prefix',[None]*29+[7],False)]:
 recognized=[(n+1,row) for n,row in enumerate(matches) if row is not None];first=recognized[0] if recognized else None
 got=eval(code,{'first':first,'matches':matches});assert got==expected
 record('prefix divergence accounting '+name,passed=True,diverged=got)
report={'driver_sha256':hashlib.sha256(SOURCE.encode()).hexdigest(),'checks':checks,'real_history_reads':0,'actual_performance_runs':0,'network_requests':0,'forbidden_outer_attempts':forbidden,'synthetic_output':str(resultdir)}
assert forbidden==[];(OUT/'review.json').write_text(json.dumps(report,indent=2)+'\n');print('EVIDENCE',OUT)
