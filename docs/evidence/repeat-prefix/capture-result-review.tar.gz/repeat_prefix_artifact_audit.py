"""Independent read-only audit of the complete frozen cleanup comparison."""
import collections, hashlib, itertools, json, math, os, pathlib, statistics, subprocess, sys, tempfile
ROOT=pathlib.Path('/Users/arjunhans/Documents/ctc2026'); O=ROOT/'out/repeat-prefix-v1-20261024'
C=ROOT/'.worktrees/repeat-prefix'; B=ROOT/'.worktrees/practice-history'
REVS={C:'357d9986babf2b21bd3bbdcc2e69550059f16154',B:'cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026'}
forbidden=[]
def guard(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
  forbidden.append(event);raise RuntimeError('network forbidden')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  name=os.fsdecode(args[0]).lower()
  if '.botkey' in name or '/.env' in name or '/data/history/' in name or 'credentials' in name:
   forbidden.append(name);raise RuntimeError('sensitive/downloaded-history read forbidden')
sys.addaudithook(guard)
def J(p):return json.loads(pathlib.Path(p).read_text())
def R(p):return [json.loads(x) for x in pathlib.Path(p).read_text().splitlines()]
def H(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def VH(x):return hashlib.sha256(json.dumps(x,sort_keys=True,allow_nan=False).encode()).hexdigest()
def K(r):return r['capture'],r['rtt_seconds'],r['displayed_depth_fraction'],r['basket_enabled']
def near(a,b):assert math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-6),(a,b)
def directory(base,k):return base/f'capture-{k[0]}-{k[1]}-{k[2]}-{int(k[3])}'
JOURNALS=['observations.json','actions.jsonl','status.json','final-receipt.json','startup-feed.jsonl','result.json','run.lock']
grid=list(itertools.product(range(241,247),[0.,.05,.25,1.],[1.,.5],[False,True]))
phases={};source_hashes={};git_paths={}
for root,rev in REVS.items():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==rev
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root,text=True)
for phase in ('baseline','candidate'):
 d=O/phase;m=J(d/'metadata.json');s=J(d/'summary.json');rows=R(d/'results.jsonl');index={K(r):r for r in rows}
 assert len(rows)==len(index)==96 and [K(r) for r in rows]==grid
 assert m['phase']==phase and m['grid']==[list(k) for k in grid] and m['runtime_changes']==['ctc/analog.py']
 assert m['candidate_revision']==REVS[C] and m['baseline_revision']==REVS[B]
 assert s['runs']==96 and s['errors']==0 and not s['changed_sources'] and not s['forbidden_attempts']
 assert math.isfinite(s['finished_at']) and s['finished_at']>=m['started_at']
 assert s['results_sha256']==H(d/'results.jsonl')
 for name,expected in m['source_sha256'].items():
  p=pathlib.Path(name);assert H(p)==expected,p;source_hashes[name]=expected
  for root,rev in REVS.items():
   if p.is_relative_to(root):
    blob=subprocess.check_output(['git','show',f'{rev}:{p.relative_to(root)}'],cwd=root)
    assert hashlib.sha256(blob).hexdigest()==expected,p
    git_paths[name]=expected
 for r in rows: assert r['status']=='ok' and not r['errors'] and r['comparison_status']==('exact_archive' if phase=='baseline' else 'candidate_evaluated')
 phases[phase]=(m,s,index)
bm,bs,br=phases['baseline'];cm,cs,cr=phases['candidate']
assert bm['spec']==cm['spec']==J(O/'spec.json') and bm['source_sha256']==cm['source_sha256']
assert bs['finished_at']<=cm['started_at']<=cs['finished_at']
assert cm['baseline_results_sha256']==H(O/'baseline/results.jsonl')
for name,expected in cm['baseline_artifact_sha256'].items():assert H(name)==expected,name
case=J(C/'data/case.json');caps={s:max(1,math.floor(q*.1)) for s,q in case['limits'].items()}
inputs={};metas={};archive_rows={};archive_dirs={}
for item in bm['spec']['captures']:
 c=item['capture'];a=pathlib.Path(item['archive']);data=J(item['input']);am=J(a/'metadata.json');sm=J(a/'summary.json')
 assert H(item['input'])==item['input_sha256']
 if (O/'inputs'/f'{c}.json').exists():assert H(O/'inputs'/f'{c}.json')==item['input_sha256']
 for name,expected in item['archive_sha256'].items():assert H(a/name)==expected
 assert sm['errors']==sm['mismatches']==0 and not sm['changed_sources'] and sm['results_sha256']==H(a/'results.jsonl')
 selected=next(x for x in am['captures'] if x['capture']==c)
 assert VH(data['frames'])==selected['frames_sha256'] and VH(data['receipt'])==selected['receipt_sha256']
 assert data['receipt']['competition_id']==selected['competition_id']
 assert selected['year']==str(2027-c) and data['receipt']['clock']['state']=='ready'
 assert data['receipt']['clock']['competition_id']==selected['competition_id']
 assert str(data['receipt']['clock']['fictional_time']).startswith(selected['year']+'-')
 assert len(data['frames'])==selected['frame_count'] and data['frames'][0]['received_at']==selected['first_at'] and data['frames'][-1]['received_at']==selected['last_at']
 assert selected['last_at']<=data['receipt']['at']==selected['receipt_at']
 assert set(data['receipt']['prices'])==set(caps) and all(type(p) in (int,float) and math.isfinite(p) and p>0 for p in data['receipt']['prices'].values())
 seqs={f['message']['seq'] for f in data['frames'] if f.get('type')=='news' and 'seq' in f['message']}
 assert seqs==set(range(len(seqs))) and len(seqs)==selected['coverage']['news_count']
 inputs[c]=data;metas[c]=selected;archive_dirs[c]=a
 for r in R(a/'results.jsonl'):
  if r['capture']==c:assert K(r) not in archive_rows;archive_rows[K(r)]=r
assert set(archive_rows)==set(grid)
extra={'capture','comparison_status','pre_cleanup_trace','journal_sha256','repeat_profile'}
fixed=['stop_reason','stop_at','stop_phase','stop_market_open','monitor_started_at','monitor_detected_at','cleanup_started_at','final_report_rounds','history_block_reason','prefix_messages','client_steps']
for k in grid:
 a,b=br[k],cr[k]
 assert a['journal_sha256']['startup-feed.jsonl']==b['journal_sha256']['startup-feed.jsonl']
 assert {f:v for f,v in a.items() if f not in extra}=={f:v for f,v in archive_rows[k].items() if f not in ('capture','comparison_status')},k
 for name in JOURNALS:assert (directory(O/'baseline',k)/name).read_bytes()==(directory(archive_dirs[k[0]],k)/name).read_bytes(),(k,name)
# Independently verify each recorded row against observed weather prefixes only.
import numpy as np
with np.load(C/'ctc/analog_library.npz') as lib:library=lib['tracks']
prefix_oracles={};recognition_evidence=[]
for capture,data in inputs.items():
 for rnd in (1,2,3):
  weather={}
  for f in data['frames']:
   msg=f.get('message',{})
   if f.get('type')=='news' and msg.get('type')=='storm' and msg['round']==rnd:
    row=tuple(msg[k] for k in ('x','y','radius','intensity'))
    if msg['age'] in weather:assert weather[msg['age']]==row
    weather[msg['age']]=row
  assert sorted(weather)==list(range(0,482,2)),(capture,rnd,'weather ages')
  observations=np.asarray([weather[a] for a in range(0,482,2)])
  prefix_matches={}
  for n in range(21,242):
   matches=np.flatnonzero(np.all(library[:,:n,:]==observations[None,:n,:],axis=(1,2)))
   prefix_matches[(n-1)*2]=int(matches[0]) if len(matches)==1 else None
  prefix_oracles[(capture,rnd)]=prefix_matches
  recognition_evidence.append(dict(capture=capture,round=rnd,first_unique_age=next((age for age,row in prefix_matches.items() if row is not None),None),rows=sorted({r for r in prefix_matches.values() if r is not None})))
for phase,(metadata,summary,rows) in phases.items():
 assert metadata['repeat_prefix_enabled']==(phase=='candidate')
 for setting,row in rows.items():
  profile=row['repeat_profile'];assert profile['recognized']==sum(x['calls'] for x in profile['rows'].values())<=profile['calls']
  if phase=='baseline':assert profile['recognized']==0 and profile['rows']=={}
  for label,counts in profile['rows'].items():
   analog=int(label);assert 40<=counts['first_age']<=counts['last_age']<=480 and counts['calls']>0
   matched=[r for r in (1,2,3) if prefix_oracles[(setting[0],r)].get(counts['first_age'])==analog]
   assert len(matched)==1,(setting,label,counts)
   for age in range(counts['first_age'],counts['last_age']+1,2):assert prefix_oracles[(setting[0],matched[0])][age]==analog
profiles=[];stops=[];attention=[];post_receipt_tails=[];journal_files=0
for phase,(_,_,rows) in phases.items():
 for k,r in rows.items():
  c,rtt,depth,basket=k;d=directory(O/phase,k);meta=metas[c];cid=meta['competition_id']
  assert set(r['journal_sha256'])==set(JOURNALS+['cleanup-profile.json','repeat-profile.json'])
  for name,sha in r['journal_sha256'].items():assert H(d/name)==sha,(phase,k,name);journal_files+=1
  assert J(d/'repeat-profile.json')==r['repeat_profile']
  assert J(d/'result.json')=={f:v for f,v in r.items() if f not in extra}
  status=J(d/'status.json');receipt=J(d/'final-receipt.json');obs=J(d/'observations.json');actions=R(d/'actions.jsonl')
  assert r['observed_final_receipt']==receipt and r['final_receipt']==status['latest']['final_receipt'] and r['cleanup']==status['latest']['cleanup']
  assert r['trial']==status['trials'][cid] and r['stop_reason']==status['stop_reason']
  assert (status['fraction'],status['loss_trigger'],status['target_seasons'])==(.1,250.,1)
  assert not status['ownership_blocks'] and status['owned_order_count']==r['orders'] and r['orders']<500
  assert r['terminal_closed'] and r['history_block_reason'] is None
  if not r['fills_after_final_receipt_requests']:
   assert not r['server_orders_after_final_receipt']
   assert r['server_positions_after_final_receipt']==r['final_positions']
  assert r['request_count']==sum(r['request_counts'].values())
  assert r['stop_at']<=r['monitor_detected_at']<=r['cleanup_started_at']<=r['cleanup_completed_at']==r['final_client_time']
  near((r['monitor_detected_at']-r['monitor_started_at'])/.5,round((r['monitor_detected_at']-r['monitor_started_at'])/.5))
  near(r['cutoff_seconds'],meta['last_at']-meta['first_at']);near(r['settlement_available_at'],meta['receipt_at']-meta['first_at'])
  assert all(abs(r['final_positions'][s])<=limit and r['maximum_absolute_positions'][s]<=limit for s,limit in caps.items())
  assert all(receipt[f] for f in ('identity_verified','history_ownership_clear','account_valid','verified')) and receipt['account_error'] is None
  assert receipt['clock']['competition_id']==receipt['end_clock']['competition_id']==cid
  rr=receipt['positions']['positions'];assert {p['symbol']:p['quantity'] for p in rr}==r['server_positions_after_final_receipt']
  near(sum(p['realized_pnl']+p['unrealized_pnl'] for p in rr),r['final_receipt']['pnl'])
  cash=sum(p['realized_pnl']-(p['quantity']*p['average_price'] if p['quantity'] else 0) for p in rr)
  terminal_positions=r['server_positions_after_final_receipt'].copy()
  if r['fills_after_final_receipt_requests']:
   assert phase=='candidate' and k[:3]==(244,0.,1.) and r['fills_after_final_receipt_requests']==1
   assert len(r['server_orders_after_final_receipt'])==1
   order=r['server_orders_after_final_receipt'][0];assert order['order_id']==19 and order['symbol']=='REIN' and order['side']=='buy'
   remain=order['quantity']-order['filled_quantity'];assert remain==1 and terminal_positions['REIN']==-1
   crossing=next(f for f in inputs[c]['frames'] if f.get('type')=='quote' and f.get('symbol')=='REIN' and f['received_at']-meta['first_at']>r['cleanup_completed_at'] and f['ask']<=order['price'] and f['ask_size']*depth>=remain)
   near(crossing['received_at']-meta['first_at'],262.24383783340454)
   cash-=remain*order['price'];terminal_positions['REIN']+=remain
   post_receipt_tails.append(dict(setting=k,remaining_order=order,first_eligible_quote=crossing,receipt_mark=r['final_receipt']['pnl'],post_receipt_fill_price=order['price'],terminal_pnl=r['terminal_settlement_pnl']))
  assert terminal_positions==r['final_positions']
  terminal=cash+sum(q*inputs[c]['receipt']['prices'][symbol] for symbol,q in terminal_positions.items())
  near(terminal,r['terminal_settlement_pnl'])
  assert r['final_receipt']['flat']==all(p['quantity']==0 for p in rr)
  assert len(r['final_receipt_requests'])==5
  for request in r['final_receipt_requests']:
   assert request['method']=='GET' and r['cleanup_started_at']<=request['started_at']<=request['executed_at']<=request['completed_at']<=r['cleanup_completed_at']
   near(request['executed_at']-request['started_at'],rtt/2);near(request['completed_at']-request['started_at'],rtt)
  assert [o['observed_at'] for o in obs]==sorted(o['observed_at'] for o in obs)
  for o in obs:
   assert o['positions_started_at']<=o['positions_executed_at']<=o['positions_completed_at']<=o['observed_at']
   near(o['positions_executed_at']-o['positions_started_at'],rtt/2)
  for a in actions:
   if a['kind']=='request_attempt':assert a['at']-meta['first_at']<=r['stop_at']+1e-6
  assert r['trial']['attempt_count']==sum(a['kind']=='request_attempt' for a in actions)
  settlements=[a for a in actions if a['kind']=='settlement']
  if r['trial_state']=='completed':
   assert r['trial']['completed'] and r['cleanup']['state']=='settled' and len(settlements)==1 and r['final_report_rounds']==[1,2,3]
   assert settlements[0]['at']>=meta['receipt_at'] and r['stop_at']>=r['settlement_available_at']
   near(settlements[0]['pnl'],terminal);near(r['trial']['settlement_pnl'],terminal)
  else:
   assert r['trial_state']=='incomplete_trial' and not r['trial']['completed'] and not settlements
   assert r['stop_reason'].startswith('cumulative simulated P&L reached loss trigger')
   atstop=[o for o in obs if abs(o['observed_at']-r['stop_at'])<1e-7];assert atstop and atstop[0]['pnl']<=-250
   stops.append(dict(phase=phase,setting=k,stop_sample=atstop[0],pnl=r['terminal_settlement_pnl']))
  if r['cleanup']['state']=='flat':assert receipt['flat'] and not any(r['final_positions'].values())
  if r['cleanup']['state']=='attention':
   assert not receipt['flat'] and r['cleanup']['reason']=='cleanup retry limit'
   attention.append(dict(phase=phase,setting=k,positions_after_receipt={s:q for s,q in r['server_positions_after_final_receipt'].items() if q},positions_terminal={s:q for s,q in r['final_positions'].items() if q},pnl=terminal))
  prof=J(d/'cleanup-profile.json');previous=r['cleanup_started_at'];books={};position=None;orders=None;lastclock=None;ages=[];posts=[];direct_checks=0
  assert prof and prof[0]['request']['started_at']==r['cleanup_started_at']
  for i,entry in enumerate(prof):
   req=entry['request'];method,path=req['method'],req['path'];start,mid,end=(req[x] for x in ('started_at','executed_at','completed_at'))
   assert previous-1e-7<=start<=mid<=end<=r['cleanup_completed_at']+1e-7
   near(mid-start,rtt/2);near(end-start,rtt);previous=end
   if method=='GET' and path=='/positions?include_zero=true':position={p['symbol']:p['quantity'] for p in req['response']['positions']}
   if method=='GET' and path=='/orders/open':orders=req['response']['orders']
   if method=='GET' and path=='/competitions/time':lastclock=req['response']
   if method=='GET' and path.startswith('/orderbook/'):
    symbol=path.split('/')[2].split('?')[0];books[symbol]=req
    expected_paths=['/competitions/time','/orders/open','/positions?include_zero=true','/trades','/orders?limit=500','/competitions/time']
    actual_sequence=[(x['request']['method'],x['request']['path']) for x in prof[i+1:i+7]]
    assert actual_sequence==[('GET',p) for p in expected_paths],(phase,k,'post-book reconciliation sequence',actual_sequence)
    direct_checks+=1
   if method=='POST':
    assert path=='/orders' and not orders and lastclock['competition_id']==cid and lastclock['state']=='running'
    body=req['body'];symbol=body['symbol'];q=position[symbol]
    assert q and body['side']==('sell' if q>0 else 'buy') and 0<body['quantity']<=abs(q)
    book=books[symbol];age=mid-book['executed_at'];near(age,rtt*9);ages.append(age)
    levels=book['response']['bids' if q>0 else 'asks'];raw=max(.01,levels[0]['price']*(.99 if q>0 else 1.01))
    expected=round((math.ceil(raw/.01-1e-9) if q>0 else math.floor(raw/.01+1e-9))*.01,2);near(body['price'],expected)
    posts.append(dict(symbol=symbol,quantity=body['quantity'],side=body['side'],price=body['price'],executed_at=mid,quote_age=age))
  near(prof[-1]['request']['completed_at'],r['cleanup_completed_at'])
  profiles.append(dict(phase=phase,setting=k,duration=r['cleanup_completed_at']-r['cleanup_started_at'],requests=len(prof),request_seconds=len(prof)*rtt,closing_posts=posts,quote_ages=ages,postbook_checks=direct_checks))
metrics={}
for phase,(_,_,rows) in phases.items():
 vals=[r['terminal_settlement_pnl'] for r in rows.values()]
 metrics[phase]=dict(count=len(vals),sum=sum(vals),mean=statistics.mean(vals),min=min(vals),max=max(vals),positive=sum(v>0 for v in vals),negative=sum(v<0 for v in vals),cleanup=dict(collections.Counter(r['cleanup']['state'] for r in rows.values())),trial=dict(collections.Counter(r['trial_state'] for r in rows.values())))
pairs=[]
for k in grid:
 a,b=br[k],cr[k];delta=b['terminal_settlement_pnl']-a['terminal_settlement_pnl']
 pairs.append(dict(setting=k,baseline_pnl=a['terminal_settlement_pnl'],candidate_pnl=b['terminal_settlement_pnl'],delta=delta,baseline_duration=a['cleanup_completed_at']-a['cleanup_started_at'],candidate_duration=b['cleanup_completed_at']-b['cleanup_started_at'],baseline_receipt_pnl=a['final_receipt']['pnl'],candidate_receipt_pnl=b['final_receipt']['pnl'],changed_fields=[f for f in a if f not in extra and a[f]!=b[f]]))
assert sum(p['delta']>1e-7 for p in pairs)==80 and sum(p['delta']< -1e-7 for p in pairs)==16
per_capture_pairs={c:dict(improved=sum(p['delta']>1e-7 for p in pairs if p['setting'][0]==c),worsened=sum(p['delta']< -1e-7 for p in pairs if p['setting'][0]==c)) for c in range(241,247)}
assert per_capture_pairs[242]==dict(improved=14,worsened=2) and per_capture_pairs[244]==dict(improved=2,worsened=14)
assert all(per_capture_pairs[c]==dict(improved=16,worsened=0) for c in (241,243,245,246))

import ast, contextlib, io
analysis_hash=H(O/'analysis.json'); tree=ast.parse((O/'analyze.py').read_text())
tree.body=[node for node in tree.body if not (isinstance(node,ast.Expr) and isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and node.value.func.attr=='write_text')]
ns={'__file__':str(O/'analyze.py'),'__name__':'independent_retained_analysis'}
with contextlib.redirect_stdout(io.StringIO()):exec(compile(tree,str(O/'analyze.py'),'exec'),ns)
assert (json.dumps(ns['report'],indent=2,allow_nan=False)+'\n').encode()==(O/'analysis.json').read_bytes() and H(O/'analysis.json')==analysis_hash
assert ns['report']['decision']=='reject'
assert ns['report']['failed_rules']==['new_attention_outcome','increased_residual_exposure','more_negative_capture_settings','worse_worst_capture_result']
for phase in ('baseline','candidate'):
 a=ns['report']['aggregate'][phase];m=metrics[phase]
 for af,mf in [('mean','mean'),('worst','min'),('best','max'),('positive','positive'),('negative','negative'),('cleanup_states','cleanup'),('trial_states','trial')]:assert a[af]==m[mf]
assert all(H(name)==sha for name,sha in source_hashes.items()) and not forbidden
out=pathlib.Path(tempfile.mkdtemp(prefix='repeat-prefix-artifact-audit-'))
result=dict(startup_feed_identical_pairs=96,analysis_exact=True,analysis_sha256=analysis_hash,pair_counts=dict(pnl_improved=sum(p['delta']>1e-7 for p in pairs),pnl_declined=sum(p['delta']< -1e-7 for p in pairs),pnl_unchanged=sum(abs(p['delta'])<=1e-7 for p in pairs),cleanup_faster=sum(p['candidate_duration']<p['baseline_duration']-1e-7 for p in pairs),cleanup_slower=sum(p['candidate_duration']>p['baseline_duration']+1e-7 for p in pairs),all_result_fields_unchanged=sum(not p['changed_fields'] for p in pairs)),source_files_verified=len(source_hashes),git_source_files_verified=len(git_paths),baseline_bound_artifacts=len(cm['baseline_artifact_sha256']),model_overlap_limitation='Observed prefixes are compared with the fixed fitted library; these reused paths are execution diagnostics, not unfamiliar-weather evidence.',journal_profile_hashes_verified=journal_files,baseline_journals_byte_exact=96*len(JOURNALS),pairs=pairs,metrics=metrics,profiles=profiles,stops=stops,attention=attention,per_capture_pairs=per_capture_pairs,post_receipt_tails=post_receipt_tails,recognition_evidence=recognition_evidence,source_hashes=source_hashes,results_sha256={p:s['results_sha256'] for p,(_,s,_) in phases.items()},forbidden_attempts=forbidden)
(out/'audit.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(path=str(out/'audit.json'),metrics=metrics,source_files_verified=len(source_hashes),git_source_files_verified=len(git_paths),bound_baseline_artifacts=len(cm['baseline_artifact_sha256']),journal_profile_hashes=journal_files,baseline_journals_byte_exact=672,pair_counts=result['pair_counts'],attention=attention,forbidden_attempts=forbidden),indent=2))
