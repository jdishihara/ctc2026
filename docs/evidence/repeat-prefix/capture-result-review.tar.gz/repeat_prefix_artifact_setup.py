from pathlib import Path
s=Path('/tmp/cleanup_refresh_artifact_audit.py').read_text()
s=s.replace('cleanup-refresh-v1-20261024','repeat-prefix-v1-20261024').replace("C=ROOT/'.worktrees/cleanup-empty-cancel'","C=ROOT/'.worktrees/repeat-prefix'").replace('74c81f4d288f72e1248a6956ffcb15fea3970005','357d9986babf2b21bd3bbdcc2e69550059f16154')
s=s.replace('range(241,246)','range(241,247)').replace('==80','==96').replace("['bot/practice.py']","['ctc/analog.py']").replace("else 'identical_before_cleanup'","else 'candidate_evaluated'")
s=s.replace("'pre_cleanup_trace','journal_sha256'}","'pre_cleanup_trace','journal_sha256','repeat_profile'}")
s=s.replace("JOURNALS+['cleanup-profile.json']","JOURNALS+['cleanup-profile.json','repeat-profile.json']")
s=s.replace(" assert a['journal_sha256']['observations.json']==b['journal_sha256']['observations.json']\n",'')
s=s.replace(" assert a['pre_cleanup_trace']==b['pre_cleanup_trace'] and all(a[f]==b[f] for f in fixed),k\n",'')
s=s.replace("assert sum(abs(p['delta'])>1e-7 for p in pairs)==4","assert sum(p['delta']>1e-7 for p in pairs)==80 and sum(p['delta']< -1e-7 for p in pairs)==16\nassert all((p['delta']<0)==(p['setting'][0]==244) for p in pairs)")
s=s.replace("assert (O/'baseline/results.jsonl').read_bytes()==(ROOT/'out/cleanup-quotes-v1-20261024/baseline/results.jsonl').read_bytes()",'')
s=s.replace("precleanup_observations_identical_pairs=80,startup_feed_identical_pairs=80,","startup_feed_identical_pairs=96,")
s=s.replace('baseline_journals_byte_exact=80*len(JOURNALS)','baseline_journals_byte_exact=96*len(JOURNALS)').replace('baseline_journals_byte_exact=560','baseline_journals_byte_exact=672')
s=s.replace("All 15 weather tracks are reported to overlap the fitted library; this is execution evidence only.","Observed prefixes are compared with the fixed fitted library; these reused paths are execution diagnostics, not unfamiliar-weather evidence.")
s=s.replace("prefix='cleanup-refresh-artifact-audit-'","prefix='repeat-prefix-artifact-audit-'")
s=s.replace("pnl_changes=[p for p in pairs if abs(p['delta'])>1e-7]","pair_counts=result['pair_counts']")
insert=s.index('profiles=[];stops=[];attention=[];journal_files=0')
s=s[:insert]+'''# Independently verify each recorded row against observed weather prefixes only.
import numpy as np
with np.load(C/'ctc/analog_library.npz') as lib:library=lib['tracks']
prefix_oracles={};recognition_evidence=[]
for capture,data in inputs.items():
 for rnd in (1,2,3):
  weather={}
  for f in data['frames']:
   msg=f.get('message',{})
   if f.get('type')=='news' and msg.get('type')=='storm' and msg['round']==rnd:
    row=tuple(msg[k] for k in ('x','y','radius','intensity'))
    if msg['age'] in weather:assert weather[msg['age']]==row
    weather[msg['age']]=row
  assert sorted(weather)==list(range(0,482,2)),(capture,rnd,'weather ages')
  observations=np.asarray([weather[a] for a in range(0,482,2)])
  prefix_matches={}
  for n in range(21,242):
   matches=np.flatnonzero(np.all(library[:,:n,:]==observations[None,:n,:],axis=(1,2)))
   prefix_matches[(n-1)*2]=int(matches[0]) if len(matches)==1 else None
  prefix_oracles[(capture,rnd)]=prefix_matches
  recognition_evidence.append(dict(capture=capture,round=rnd,first_unique_age=next((age for age,row in prefix_matches.items() if row is not None),None),rows=sorted({r for r in prefix_matches.values() if r is not None})))
for phase,(metadata,summary,rows) in phases.items():
 assert metadata['repeat_prefix_enabled']==(phase=='candidate')
 for setting,row in rows.items():
  profile=row['repeat_profile'];assert profile['recognized']==sum(x['calls'] for x in profile['rows'].values())<=profile['calls']
  if phase=='baseline':assert profile['recognized']==0 and profile['rows']=={}
  for label,counts in profile['rows'].items():
   analog=int(label);assert 40<=counts['first_age']<=counts['last_age']<=480 and counts['calls']>0
   matched=[r for r in (1,2,3) if prefix_oracles[(setting[0],r)].get(counts['first_age'])==analog]
   assert len(matched)==1,(setting,label,counts)
   for age in range(counts['first_age'],counts['last_age']+1,2):assert prefix_oracles[(setting[0],matched[0])][age]==analog
''' +s[insert:]
s=s.replace("  assert J(d/'result.json')==", "  assert J(d/'repeat-profile.json')==r['repeat_profile']\n  assert J(d/'result.json')==")
s=s.replace("source_hashes=source_hashes,results_sha256", "recognition_evidence=recognition_evidence,source_hashes=source_hashes,results_sha256")
# Verify the retained full analysis without permitting its write back to the experiment directory.
insert=s.index("assert all(H(name)==sha for name,sha in source_hashes.items()) and not forbidden")
s=s[:insert]+'''import ast, contextlib, io
analysis_hash=H(O/'analysis.json'); tree=ast.parse((O/'analyze.py').read_text())
tree.body=[node for node in tree.body if not (isinstance(node,ast.Expr) and isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and node.value.func.attr=='write_text')]
ns={'__file__':str(O/'analyze.py'),'__name__':'independent_retained_analysis'}
with contextlib.redirect_stdout(io.StringIO()):exec(compile(tree,str(O/'analyze.py'),'exec'),ns)
assert ns['report']==J(O/'analysis.json') and H(O/'analysis.json')==analysis_hash
assert ns['report']['decision']=='reject'
assert ns['report']['failed_rules']==['new_attention_outcome','increased_residual_exposure','more_negative_capture_settings','worse_worst_capture_result']
for phase in ('baseline','candidate'):
 a=ns['report']['aggregate'][phase];m=metrics[phase]
 for af,mf in [('mean','mean'),('worst','min'),('best','max'),('positive','positive'),('negative','negative'),('cleanup_states','cleanup'),('trial_states','trial')]:assert a[af]==m[mf]
''' +s[insert:]
s=s.replace("startup_feed_identical_pairs=96,","startup_feed_identical_pairs=96,analysis_exact=True,analysis_sha256=analysis_hash,")
Path('/tmp/repeat_prefix_artifact_audit.py').write_text(s)
