"""Independent paired representative reruns; only already closed captures 241-245."""
import collections, copy, hashlib, json, os, pathlib, subprocess, sys, tempfile
from collections.abc import Mapping
from dataclasses import asdict
from unittest.mock import patch
ROOT=pathlib.Path('/Users/arjunhans/Documents/ctc2026');O=ROOT/'out/repeat-prefix-v1-20261024'
PHASE=sys.argv[1];assert PHASE in ('baseline','candidate')
W=ROOT/'.worktrees'/('practice-history' if PHASE=='baseline' else 'repeat-prefix')
REV='cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026' if PHASE=='baseline' else '357d9986babf2b21bd3bbdcc2e69550059f16154'
violations=[]
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
  violations.append(event);raise RuntimeError('network forbidden')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  name=os.fsdecode(args[0]).lower()
  if '.botkey' in name or '/.env' in name or '/data/history/' in name or 'credentials' in name:
   violations.append(name);raise RuntimeError('credentials/downloaded-history forbidden')
sys.addaudithook(audit)
def J(p):return json.loads(pathlib.Path(p).read_text())
def H(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def VH(v):return hashlib.sha256(json.dumps(v,sort_keys=True,allow_nan=False).encode()).hexdigest()
def K(r):return r['capture'],r['rtt_seconds'],r['displayed_depth_fraction'],r['basket_enabled']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==REV
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=W,text=True)
m=J(O/PHASE/'metadata.json');source_hashes=m['source_sha256']
assert all(H(p)==sha for p,sha in source_hashes.items())
expected={K(r):r for line in (O/PHASE/'results.jsonl').read_text().splitlines() if (r:=json.loads(line))}
items={i['capture']:i for i in m['spec']['captures']}
sys.path.insert(0,str(W))
from scripts import replay_practice_supervisor as replay
from bot import practice
from ctc.strategies import FairValueTrader
from ctc.analog import AnalogEnsemble
import numpy as np
assert pathlib.Path(replay.__file__).resolve().is_relative_to(W.resolve())
case=J(W/'data/case.json');out=pathlib.Path(tempfile.mkdtemp(prefix='repeat-prefix-independent-'+PHASE+'-'))
cases=[(244,.25,1.,True),(244,.25,.5,True),(244,.05,.5,True),(241,.25,1.,True),(246,.25,1.,True)]
active={};counts=collections.Counter();results=[]
OServer=replay.PracticeReplayServer;OSession=practice.PracticeSession
old_finish=practice.finish;old_quotes=FairValueTrader.on_quotes;old_send=replay.ServerTransport.send;old_weights=AnalogEnsemble.weights

def enforce(condition,message):
 if not condition:
  exc=AssertionError(message)
  if 'server' in active:active['server'].latch(exc)
  raise exc
class RecordingServer(OServer):
 def __init__(self,*a,**kw):
  super().__init__(*a,**kw);active['server']=self;self.cleanup_profile=[]
 def request(self,*a,**kw):
  stack=[]
  if 'cleanup_request_index' in active:
   frame=sys._getframe(1)
   while frame:
    if frame.f_code.co_filename.endswith(('/bot/practice.py','/bot/live.py')):
     stack.append(dict(file=pathlib.Path(frame.f_code.co_filename).name,function=frame.f_code.co_name,line=frame.f_lineno))
    frame=frame.f_back
  response=super().request(*a,**kw)
  if 'cleanup_request_index' in active:
   self.cleanup_profile.append(dict(request=copy.deepcopy(self.requests[-1]),stack=stack))
  return response
class RecordingSession(OSession):
 def __init__(self,*a,**kw):
  super().__init__(*a,**kw);active['session']=self
class GuardedSettlement(Mapping):
 def __init__(self,values):self._prices=dict(values)
 def _check(self):
  s=active['server'];counts['settlement_reads']+=1
  enforce(s.terminal and not s.market.market_open and s.now>=s.settlement_available_at,'premature settlement access')
 def __getitem__(self,key):self._check();return self._prices[key]
 def __iter__(self):return iter(self._prices)
 def __len__(self):return len(self._prices)
 def copy(self):self._check();return dict(self)
 def __copy__(self):return self.copy()
 def __deepcopy__(self,memo):self._check();return GuardedSettlement(dict(self))
def finish(journal):
 s=active['server'];active['cleanup_request_index']=len(s.requests);active['cleanup_fill_index']=len(s.market.fills)
 return old_finish(journal)
def cached_state(trader,exchange):
 model=trader.model
 return dict(at=active['server'].now,exchange_t=exchange.t,round=model.round,last_observed_age=model.obs[-1]['age'] if model.obs else None,positions=exchange.position.copy(),fair=copy.deepcopy(trader.fair),fair_sd=copy.deepcopy(model.fair_sd),future_sd=copy.deepcopy(model.future_sd),repeat_match=getattr(model.ensemble,'repeat_match',None),history_ready=model.live_history_ready)
def quotes(trader,exchange):
 before=cached_state(trader,exchange)
 counts['quote_callbacks']+=1
 enforce(trader.competition_id==exchange.competition_id and isinstance(trader.competition_id,str) and bool(trader.competition_id.strip()),'identity mismatch')
 model=trader.model;reports=set(model.reported_rounds);ready=model.live_history_ready
 result=old_quotes(trader,exchange)
 enforce(trader.model is model and model.reported_rounds==reports and model.live_history_ready==ready,'quotes changed model history')
 active.setdefault('quote_observations',collections.deque(maxlen=100)).append(dict(before=before,after=cached_state(trader,exchange)))
 return result
def weights(ensemble,obs,official,wire,adv=None):
 counts['weight_calls']+=1
 key=tuple(tuple(o.get(k) for k in ('age','x','y','radius','intensity')) for o in obs)
 for o in obs:
  weather=(o.get('round',active['session'].strat.model.round),o['age'],o['x'],o['y'],o['radius'],o['intensity'])
  enforce(weather in active['weather_received'],'model weather absent from captured news')
  enforce(active['weather_received'][weather]<=active['origin']+active['server'].now+1e-7,'model observed future weather')
 counts['causal_weather_points']+=len(obs)
 cache=active.setdefault('oracle_cache',{})
 if key not in cache:
  v=np.asarray(key,dtype=float);n=len(v);oracle=None
  if 21<=n<=241 and np.isfinite(v).all() and np.array_equal(v[:,0],np.arange(n)*2):
   matches=np.flatnonzero(np.all(ensemble.tracks[:,:n,:]==v[None,:,1:],axis=(1,2)))
   if len(matches)==1:oracle=int(matches[0])
  cache[key]=oracle
  counts['independent_prefix_scans']+=1
 oracle=cache[key]
 result=old_weights(ensemble,obs,official,wire,adv)
 match=getattr(ensemble,'repeat_match',None)
 enforce(match==(oracle if PHASE=='candidate' else None),'recognition differs from independent prefix oracle')
 if match is not None:
  exact=np.zeros(len(result));exact[match]=1
  enforce(np.array_equal(result,exact),'recognition did not return exact one-hot')
  counts['recognized_prefix_calls']+=1
 profile=active.setdefault('recognition',dict(calls=0,recognized=0,rows={}))
 profile['calls']+=1
 if match is not None:
  profile['recognized']+=1
  item=profile['rows'].setdefault(str(match),dict(calls=0,first_age=obs[-1]['age'],last_age=obs[-1]['age']))
  item['calls']+=1;item['last_age']=obs[-1]['age']
 return result
def send(exchange,method,path,body=None):
 if method=='POST' and isinstance(exchange,replay.OfflinePracticeExchange):
  counts['strategy_posts']+=1;session=active['session']
  enforce(not session._valid_weather_wait() and session.strat.model.live_history_ready,'strategy POST without ready news')
  enforce(session.competition_id==exchange.competition_id==session.strat.competition_id,'strategy POST identity mismatch')
 if method=='POST' and isinstance(exchange,replay.OfflineCleanupExchange):
  counts['cleanup_posts']+=1;q=exchange.position[body['symbol']]
  enforce(exchange.state_ready and exchange.market_open and not exchange.open_orders,'unsafe cached cleanup state')
  enforce(exchange.competition_id==exchange.expected_id,'cleanup identity mismatch')
  enforce(q and body['side']==('sell' if q>0 else 'buy') and 0<body['quantity']<=abs(q),'cleanup not reducing cached exposure')
  actual=active['server'].market.position[body['symbol']]
  enforce(actual and body['side']==('sell' if actual>0 else 'buy') and 0<body['quantity']<=abs(actual),'cleanup not reducing actual server exposure at request start')
 return old_send(exchange,method,path,body)
with patch.object(replay,'PracticeReplayServer',RecordingServer),patch.object(practice,'PracticeSession',RecordingSession),patch.object(practice,'finish',finish),patch.object(FairValueTrader,'on_quotes',quotes),patch.object(replay.ServerTransport,'send',send),patch.object(AnalogEnsemble,'weights',weights),patch.dict(replay.PARAMETERS,{'repeat_prefix':True} if PHASE=='candidate' else {}):
 for k in cases:
  active.clear();c,rtt,depth,basket=k;item=items[c];assert H(item['input'])==item['input_sha256']
  data=J(item['input']);receipt=data['receipt'];meta=next(x for x in J(pathlib.Path(item['archive'])/'metadata.json')['captures'] if x['capture']==c)
  assert VH(data['frames'])==meta['frames_sha256'] and VH(receipt)==meta['receipt_sha256']
  assert receipt['clock']['state']=='ready' and meta['year']==str(2027-c)
  active['origin']=data['frames'][0]['received_at'];active['weather_received']={}
  for f in data['frames']:
   msg=f.get('message',{})
   if f.get('type')=='news' and msg.get('type')=='storm':
    weather=tuple(msg[k] for k in ('round','age','x','y','radius','intensity'))
    active['weather_received'].setdefault(weather,f['received_at'])
  d=out/f'capture-{c}-{rtt}-{depth}-{int(basket)}'
  result=replay.replay_supervised(case,data['frames'],str(2027-c),receipt['competition_id'],GuardedSettlement(receipt['prices']),receipt_at=receipt['at'],out=d,rtt=rtt,depth_scale=depth,basket=basket)
  want={f:v for f,v in expected[k].items() if f not in ('capture','comparison_status','pre_cleanup_trace','journal_sha256','repeat_profile')}
  assert result==want,(k,[f for f in set(result)|set(want) if result.get(f)!=want.get(f)])
  server=active['server'];assert not server.fatal_errors
  prefix=dict(requests_sha256=VH(server.requests[:active['cleanup_request_index']]),fills_sha256=VH([asdict(f) for f in server.market.fills[:active['cleanup_fill_index']]]))
  assert prefix==expected[k]['pre_cleanup_trace']
  (d/'cleanup-profile.json').write_text(json.dumps(server.cleanup_profile,indent=2)+'\n')
  profile=active.get('recognition',dict(calls=0,recognized=0,rows={}))
  assert profile==expected[k]['repeat_profile']
  (d/'repeat-profile.json').write_text(json.dumps(profile,indent=2)+'\n')
  for name,sha in expected[k]['journal_sha256'].items():assert H(d/name)==sha,(k,name)
  (d/'request-trace.json').write_text(json.dumps(server.requests,indent=2,allow_nan=False)+'\n')
  (d/'fill-trace.json').write_text(json.dumps([asdict(f) for f in server.market.fills],indent=2,allow_nan=False)+'\n')
  around=[q for q in active.get('quote_observations',[]) if q['before']['at']<=result['stop_at']+1e-7][-5:]
  (d/'last-quote-observations.json').write_text(json.dumps(dict(note='Cached fields observed without recalculating valuation; callbacks can span the stop time.',stop_at=result['stop_at'],cleanup_started_at=result['cleanup_started_at'],callbacks=around),indent=2,allow_nan=False)+'\n')
  result_entry=dict(setting=k,pnl=result['terminal_settlement_pnl'],cleanup=result['cleanup'],duration=result['cleanup_completed_at']-result['cleanup_started_at'],files_exact=9,pre_cleanup_trace=prefix)
  results.append(result_entry);print(json.dumps(dict(phase=PHASE,setting=k,pnl=result_entry['pnl'],cleanup=result['cleanup']['state'],duration=result_entry['duration'],verified='all result fields, pre-cleanup traces and nine files exact')),flush=True)
assert not violations and all(H(p)==sha for p,sha in source_hashes.items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==REV
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=W,text=True)
proof=dict(phase=PHASE,revision=REV,cases=results,counts=dict(counts),forbidden_attempts=violations,sources_unchanged=True,source_hashes=source_hashes)
(out/'independent-audit.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(audit_path=str(out/'independent-audit.json'),phase=PHASE,cases=len(results),counts=dict(counts),forbidden_attempts=violations)),flush=True)
