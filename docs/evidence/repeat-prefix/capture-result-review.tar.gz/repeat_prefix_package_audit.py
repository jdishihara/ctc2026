"""Package reviewed v1 results and the authorized ten guarded reruns."""
import collections, hashlib, json, os, pathlib, shutil, sys, tarfile, tempfile
T=pathlib.Path('/var/folders/5_/4_9w4ch971l2mm9c6fqtg5400000gn/T');forbidden=[]
def guard(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):
  forbidden.append(event);raise RuntimeError('network forbidden')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=os.fsdecode(args[0]).lower()
  if '.botkey' in p or '/.env' in p or '/data/history/' in p or 'credentials' in p:
   forbidden.append(p);raise RuntimeError('credential/history access forbidden')
sys.addaudithook(guard)
def H(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def J(p):return json.loads(p.read_text())
out=pathlib.Path(tempfile.mkdtemp(prefix='repeat-prefix-independent-evidence-'))
for phase,folder in [('baseline','repeat-prefix-independent-baseline-ihx0dkmp'),('candidate','repeat-prefix-independent-candidate-tvc8zp_t')]:shutil.copytree(T/folder,out/phase)
shutil.copyfile(T/'repeat-prefix-artifact-audit-b6i6xjnl/audit.json',out/'artifact-audit.json')
for name in ['repeat_prefix_guarded_rerun.py','repeat_prefix_rerun_setup.py','repeat_prefix_artifact_audit.py','repeat_prefix_artifact_setup.py','repeat_prefix_package_audit.py']:
 shutil.copyfile(pathlib.Path('/tmp')/name,out/name)
for name in ['repeat_prefix_baseline_rerun','repeat_prefix_candidate_rerun','repeat_prefix_artifact_audit']:
 for suffix in ['stdout.log','stderr.log']:shutil.copyfile(pathlib.Path('/tmp')/f'{name}.{suffix}',out/f'{name}.{suffix}')
a=J(out/'artifact-audit.json');b=J(out/'baseline/independent-audit.json');c=J(out/'candidate/independent-audit.json');counts=collections.Counter(b['counts']);counts.update(c['counts'])
assert len(b['cases'])==len(c['cases'])==5 and all(r['files_exact']==9 for phase in [b,c] for r in phase['cases'])
assert a['journal_profile_hashes_verified']==1728 and a['baseline_journals_byte_exact']==672 and a['analysis_exact']
assert not a['forbidden_attempts'] and not b['forbidden_attempts'] and not c['forbidden_attempts']
callback_proof={}
for phase in ['baseline','candidate']:
 v=J(out/phase/'capture-244-0.25-1.0-1/last-quote-observations.json');last=v['callbacks'][-1]
 assert last['before']['round']==last['after']['round']==1
 callback_proof[phase]={'stop_at':v['stop_at'],'cleanup_started_at':v['cleanup_started_at'],'last_callback_before':last['before'],'last_callback_after':last['after']}
verdict=dict(verdict='Approve the negative v1 evidence; reject production promotion under the declared worst-loss, negative-count, new-attention and residual-exposure rules.',candidate_revision=c['revision'],baseline_revision=b['revision'],all_pairs=96,paired_reruns=10,exact_rerun_files=90,extra_request_fill_quote_observation_files=30,source_files_verified=a['source_files_verified'],git_source_files_verified=a['git_source_files_verified'],baseline_bound_artifacts=a['baseline_bound_artifacts'],journal_profile_hashes_verified=1728,baseline_journals_byte_exact=672,metrics=a['metrics'],per_capture_pairs=a['per_capture_pairs'],recognition_evidence=a['recognition_evidence'],guard_counts=dict(counts),post_receipt_tails=a['post_receipt_tails'],primary_round_one_callback_observations=callback_proof,forbidden_attempts=[],sources_unchanged=b['sources_unchanged'] and c['sources_unchanged'],limitations=['Captures use repeated fitted weather; these are correlated execution diagnostics, not unfamiliar-weather or live-profitability evidence.','All 96 rows and artifacts were audited; only the requested five paired settings were rerun.','Full analysis was reproduced from retained outputs, including development summaries; this audit did not read or rerun downloaded development history.','Recorded cached fair/SD states are at different times and may predate the most recent observation; they are not a same-time causal model ablation.','Two zero-RTT/full-depth attention cases have one post-receipt residual-order fill; cleanup status, receipt mark, and terminal P&L remain distinct.'],audit_notes=['The all-row auditor was adapted to account for two reported post-receipt fills, rather than applying the earlier cleanup experiment assumption of zero such fills.','An internal tuple/list comparison was corrected to exact JSON-byte comparison when reproducing the analysis helper.','Initial descriptive attribution was corrected from the actual pairs: capture242 has 2 regressions and capture244 has 14; the latter also has 2 improvements.'])
(out/'verdict.json').write_text(json.dumps(verdict,indent=2,sort_keys=True)+'\n')
manifest={str(p.relative_to(out)):H(p) for p in sorted(out.rglob('*')) if p.is_file()}
(out/'artifact-manifest.json').write_text(json.dumps({'count':len(manifest),'files':manifest},indent=2,sort_keys=True)+'\n')
archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(out.rglob('*')):
  if p.is_file():t.add(p,arcname=str(p.relative_to(out)),recursive=False)
with tarfile.open(archive) as t:
 members=t.getmembers();assert len(members)==len(manifest)+1
 for member in members:assert member.isfile() and t.extractfile(member).read()==(out/member.name).read_bytes()
assert not forbidden
print(json.dumps({'directory':str(out),'archive':str(archive),'archive_sha256':H(archive),'manifest_sha256':H(out/'artifact-manifest.json'),'hashed_files':len(manifest),'archive_files':len(manifest)+1,'archive_bytes':archive.stat().st_size,'counts':dict(counts),'forbidden_attempts':forbidden}))
