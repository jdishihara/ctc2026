from pathlib import Path
p=Path('/tmp/cleanup_refresh_guarded_rerun.py')
s=p.read_text().replace('cleanup-refresh-v1-20261024','repeat-prefix-v1-20261024').replace("else 'cleanup-empty-cancel'","else 'repeat-prefix'").replace('74c81f4d288f72e1248a6956ffcb15fea3970005','357d9986babf2b21bd3bbdcc2e69550059f16154').replace("prefix='cleanup-refresh-independent-'","prefix='repeat-prefix-independent-'")
s=s.replace('from ctc.strategies import FairValueTrader','from ctc.strategies import FairValueTrader\nfrom ctc.analog import AnalogEnsemble\nimport numpy as np')
s=s.replace('cases=[(243,1.,.5,True),(245,1.,1.,False),(243,1.,.5,False),(243,1.,1.,True),(242,.25,1.,True),(244,0.,.5,True)]','cases=[(244,.25,1.,True),(244,.25,.5,True),(244,.05,.5,True),(241,.25,1.,True),(246,.25,1.,True)]')
s=s.replace('old_finish=practice.finish;old_quotes=FairValueTrader.on_quotes;old_send=replay.ServerTransport.send','old_finish=practice.finish;old_quotes=FairValueTrader.on_quotes;old_send=replay.ServerTransport.send;old_weights=AnalogEnsemble.weights')
s=s.replace("def quotes(trader,exchange):\n counts['quote_callbacks']+=1", """def cached_state(trader,exchange):
 model=trader.model
 return dict(at=active['server'].now,exchange_t=exchange.t,round=model.round,last_observed_age=model.obs[-1]['age'] if model.obs else None,positions=exchange.position.copy(),fair=copy.deepcopy(trader.fair),fair_sd=copy.deepcopy(model.fair_sd),future_sd=copy.deepcopy(model.future_sd),repeat_match=getattr(model.ensemble,'repeat_match',None),history_ready=model.live_history_ready)
def quotes(trader,exchange):
 before=cached_state(trader,exchange)
 counts['quote_callbacks']+=1""")
s=s.replace("enforce(trader.model is model and model.reported_rounds==reports and model.live_history_ready==ready,'quotes changed model history')\n return result", "enforce(trader.model is model and model.reported_rounds==reports and model.live_history_ready==ready,'quotes changed model history')\n active.setdefault('quote_observations',collections.deque(maxlen=100)).append(dict(before=before,after=cached_state(trader,exchange)))\n return result")
start=s.index('def send(exchange,method,path,body=None):')
s=s[:start]+'''def weights(ensemble,obs,official,wire,adv=None):
 counts['weight_calls']+=1
 key=tuple(tuple(o.get(k) for k in ('age','x','y','radius','intensity')) for o in obs)
 for o in obs:
  weather=(o.get('round',active['session'].strat.model.round),o['age'],o['x'],o['y'],o['radius'],o['intensity'])
  enforce(weather in active['weather_received'],'model weather absent from captured news')
  enforce(active['weather_received'][weather]<=active['origin']+active['server'].now+1e-7,'model observed future weather')
 counts['causal_weather_points']+=len(obs)
 cache=active.setdefault('oracle_cache',{})
 if key not in cache:
  v=np.asarray(key,dtype=float);n=len(v);oracle=None
  if 21<=n<=241 and np.isfinite(v).all() and np.array_equal(v[:,0],np.arange(n)*2):
   matches=np.flatnonzero(np.all(ensemble.tracks[:,:n,:]==v[None,:,1:],axis=(1,2)))
   if len(matches)==1:oracle=int(matches[0])
  cache[key]=oracle
  counts['independent_prefix_scans']+=1
 oracle=cache[key]
 result=old_weights(ensemble,obs,official,wire,adv)
 match=getattr(ensemble,'repeat_match',None)
 enforce(match==(oracle if PHASE=='candidate' else None),'recognition differs from independent prefix oracle')
 if match is not None:
  exact=np.zeros(len(result));exact[match]=1
  enforce(np.array_equal(result,exact),'recognition did not return exact one-hot')
  counts['recognized_prefix_calls']+=1
 profile=active.setdefault('recognition',dict(calls=0,recognized=0,rows={}))
 profile['calls']+=1
 if match is not None:
  profile['recognized']+=1
  item=profile['rows'].setdefault(str(match),dict(calls=0,first_age=obs[-1]['age'],last_age=obs[-1]['age']))
  item['calls']+=1;item['last_age']=obs[-1]['age']
 return result
''' + s[start:]
s=s.replace("patch.object(replay.ServerTransport,'send',send):", "patch.object(replay.ServerTransport,'send',send),patch.object(AnalogEnsemble,'weights',weights),patch.dict(replay.PARAMETERS,{'repeat_prefix':True} if PHASE=='candidate' else {}):")
s=s.replace("assert receipt['clock']['state']=='ready' and meta['year']==str(2027-c)","""assert receipt['clock']['state']=='ready' and meta['year']==str(2027-c)
  active['origin']=data['frames'][0]['received_at'];active['weather_received']={}
  for f in data['frames']:
   msg=f.get('message',{})
   if f.get('type')=='news' and msg.get('type')=='storm':
    weather=tuple(msg[k] for k in ('round','age','x','y','radius','intensity'))
    active['weather_received'].setdefault(weather,f['received_at'])""")
s=s.replace("('capture','comparison_status','pre_cleanup_trace','journal_sha256')","('capture','comparison_status','pre_cleanup_trace','journal_sha256','repeat_profile')")
s=s.replace("(d/'cleanup-profile.json').write_text(json.dumps(server.cleanup_profile,indent=2)+'\\n')", """(d/'cleanup-profile.json').write_text(json.dumps(server.cleanup_profile,indent=2)+'\\n')
  profile=active.get('recognition',dict(calls=0,recognized=0,rows={}))
  assert profile==expected[k]['repeat_profile']
  (d/'repeat-profile.json').write_text(json.dumps(profile,indent=2)+'\\n')""")
s=s.replace("result_entry=dict(setting=k,pnl=result['terminal_settlement_pnl']", """(d/'request-trace.json').write_text(json.dumps(server.requests,indent=2,allow_nan=False)+'\\n')
  (d/'fill-trace.json').write_text(json.dumps([asdict(f) for f in server.market.fills],indent=2,allow_nan=False)+'\\n')
  around=[q for q in active.get('quote_observations',[]) if q['before']['at']<=result['stop_at']+1e-7][-5:]
  (d/'last-quote-observations.json').write_text(json.dumps(dict(note='Cached fields observed without recalculating valuation; callbacks can span the stop time.',stop_at=result['stop_at'],cleanup_started_at=result['cleanup_started_at'],callbacks=around),indent=2,allow_nan=False)+'\\n')
  result_entry=dict(setting=k,pnl=result['terminal_settlement_pnl']""")
s=s.replace('files_exact=8','files_exact=9').replace('and eight files exact','and nine files exact')
Path('/tmp/repeat_prefix_guarded_rerun.py').write_text(s)
