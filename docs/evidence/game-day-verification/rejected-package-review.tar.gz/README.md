# Game-day integration review at 87ff281

**Changes required. Do not approve** `87ff281491bf6187694e90b7053b7c70d396334b`.

## Strengths and completed checks

All six evidence artifacts match their recorded copies; all 130 archive members match source directories. Internal manifests verify 79 member hashes, including original failure evidence. All 97 source/test/config bindings match frozen `4cc4324`. Python and Mario sources are unchanged from `f8fda59`. Production ZIP has exactly three verified files, only `storage` permission, Cornell-only content-script matches, no localhost URL, and no dynamic eval. All 55 report links and three additional derivatives README links resolve.

Retained evidence supports 152 full unit tests, typecheck, 11 timezone tests per zone, three Chromium passes with zero skips, 26 independent focused tests and 11 retained assertions. Initial skips, two initial browser failures, all red/failed-green logs, original 45 hashed failure files plus manifest, and packaging notes are preserved. Mario logs show 46 contracts/eight races/no orders; base Python log reports 713 passes. No new tests or browser runs were made.

## Important findings

1. **Development build crosses the live boundary.** `derivatives-overlay/README.md:48` says both builds may remain loaded, while `scripts/build.mjs:35` adds localhost to the real Cornell match. `src/content/index.ts:40,149` restores/persists auto-submit; new store pause is false (`src/state/store.ts:274`) and that flag drives arming (`:1381`). Mock arming can therefore survive navigation to the live exchange, or coexist with an armed production overlay. Isolate development matches to localhost and test both manifests. Require explicitly checking/disarming saved auto-submit before a manual dry run, and disabling any older development build that still matches Cornell.

2. **Packaged submission claims are false as unconditional statements.** `manifest.base.json:5` says “never submits orders”; `README.md:5` says the user always clicks Buy/Sell. The package includes persistent opt-in automatic submission. Correct the description/introduction to state the default and optional armed capability, then regenerate/rebind the ZIP and source receipt.

No Critical or Minor findings. These are handoff/package findings in existing behavior, not regressions introduced by the converter correction.

## Declined to judge

- Actual account ownership, live compatibility or activation: no live access.
- Competitive returns or broader pricing quality: no performance evaluation.
- Active capture 249 or later outcomes: not read.
- Re-review of all frozen runtime behavior: approved converter review reused; this review checks integration and handoff.

## Review-harness note

An initial read-only comparison overlooked the nested original archive's `initial-3bdc5cd/` prefix. After normalizing that prefix, all 46 nested members match the separately packaged original failure archive. The failed comparison script/log is retained. No artifact changed and no policy/test/browser run occurred.

`package-audit.json`, `source-hashes.json`, `archive-member-hashes.json` and the audit script preserve the checks. `review.json` records the findings.
