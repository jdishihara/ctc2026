"""Read-only source/package audit. No browser, network or test execution."""
from pathlib import Path,PurePosixPath
import hashlib,io,json,re,subprocess,tarfile,zipfile
ROOT=Path('/Users/arjunhans/Documents/ctc2026/.worktrees/derivatives-browser-checks')
OUT=Path(__file__).resolve().parent
HEAD='87ff281491bf6187694e90b7053b7c70d396334b'
RUNTIME='4cc43247152264971b1d194647d91729113d38e7'
BASE='f8fda59f196aa61d107b28f0c565cf46d07aea63'
E=ROOT/'docs/evidence/game-day-verification'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def save(n,v):(OUT/n).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert not git('status','--porcelain')
manifest=load(E/'artifact-manifest.json');receipt=load(E/'source-build-receipt.json');summary=load(E/'verification-summary.json')
assert manifest['runtime_revision']==receipt['source_revision']==summary['runtime_source']==RUNTIME
assert manifest['python_sources_unchanged_from']==summary['base_main']==BASE
assert not git('diff',BASE,HEAD,'--','bot','ctc','mario','scripts','tests')
source_checks={}
for name,m in receipt['source_files'].items():
 b=(ROOT/name).read_bytes();assert len(b)==m['bytes'] and sha(b)==m['sha256'],name
 assert b==git('show',f'{RUNTIME}:{name}'),name
 source_checks[name]=m
assert len(source_checks)==97
# Runtime/test/config tree is exactly the frozen tree, apart from permitted prose.
changed_runtime=git('diff','--name-only',RUNTIME,HEAD,'--','derivatives-overlay').decode().splitlines()
assert changed_runtime==['derivatives-overlay/GAMEDAY.md'],changed_runtime
archives={};artifact_checks=[];member_checks={};inner_hashes=0
for name,m in manifest['files'].items():
 b=(E/name).read_bytes();assert len(b)==m['bytes'] and sha(b)==m['sha256'],name
 if m.get('source'):assert Path(m['source']).read_bytes()==b
 if name.endswith('.tar.gz'):
  ar={}
  with tarfile.open(E/name) as t:
   for member in t:
    p=PurePosixPath(member.name);assert not p.is_absolute() and '..' not in p.parts
    assert member.isfile() or member.isdir()
    if member.isfile():
     n=str(p);assert n not in ar
     ar[n]=t.extractfile(member).read()
  assert len(ar)==m['regular_files']
  d=Path(m['source_directory'])
  for n,data in ar.items():assert (d/n).read_bytes()==data,(name,n)
  member_checks[name]={n:{'sha256':sha(b),'bytes':len(b)} for n,b in ar.items()}
  for mn in [n for n in ar if PurePosixPath(n).name=='manifest.json']:
   md=json.loads(ar[mn]);prefix=PurePosixPath(mn).parent
   for fn,info in md['files'].items():
    key=str(prefix/fn);assert sha(ar[key])==info['sha256'],(name,key)
    if 'bytes' in info:assert len(ar[key])==info['bytes']
    inner_hashes+=1
  archives[name]=ar
 artifact_checks.append({'path':name,'sha256':sha(b),'bytes':len(b),'members':m.get('regular_files')})
assert len(artifact_checks)==6 and sum(len(a) for a in archives.values())==130
final=archives['independent-review.tar.gz'];initial=archives['initial-review.tar.gz'];local=archives['local-checks.tar.gz']
prefix='final-4cc4324/'
r=json.loads(final[prefix+'review-receipt.json'])
assert r['head']==RUNTIME and r['focused_unit_tests']['passed']==26
assert r['retained_assertions']['passed']==5 and r['retained_assertions']['failed']==0
assert len(r['ownership_and_stability'])==6 and all(r['ownership_and_stability'].values())
assert r['network_attempts']==0 and r['all_imported_working_files_and_reviewed_tests_match_frozen_git']
with tarfile.open(fileobj=io.BytesIO(final[prefix+'initial-failures.tar.gz'])) as t:
 nested={str(PurePosixPath(m.name)):t.extractfile(m).read() for m in t if m.isfile()}
assert nested==initial
assert r['initial_failures']['hashed_files_verified']==45 and len(initial)==46
assert final[prefix+'packaging-initial-attempt.log']
for n,b in final.items():
 if n.startswith(prefix+'source/'):
  rel=n[len(prefix+'source/'):];assert b==(ROOT/rel).read_bytes()==git('show',f'{RUNTIME}:{rel}')
assert json.loads(local['verification-summary.json'])==summary and json.loads(local['source-build-receipt.json'])==receipt
assert b'152 passed' in local['derivatives-fix-unit-02.log']
assert local['derivatives-fix-timezones-02.log'].count(b'11 passed')==2
assert b'713 passed' in local['competition-pr29-python.log']
e2e=json.loads(local['derivatives-e2e-05.json']);assert e2e['stats']==summary['derivatives']['browser']
assert e2e['stats']['expected']==3 and all(e2e['stats'][k]==0 for k in ['skipped','unexpected','flaky'])
assert json.loads(local['derivatives-e2e-02.json'])['stats']['unexpected']==2
assert '3 skipped' in local['derivatives-e2e.log'].decode()
assert summary['mario']['contracts']==46 and summary['mario']['races_ingested']==8
assert not summary['mario']['auto_execute'] and summary['mario']['trades']=={'trades':[]} and summary['mario']['unmapped']==[]
assert json.loads(local['mario-smoke-receipt.json'])==summary['mario']
zip_bytes=(E/'derivatives-overlay.zip').read_bytes();assert zip_bytes==local['derivatives-overlay.zip']
assert zip_bytes==Path(receipt['production_package']['path']).read_bytes()
assert sha(zip_bytes)==receipt['production_package']['sha256']==summary['derivatives']['package_sha256']
with zipfile.ZipFile(io.BytesIO(zip_bytes)) as z:
 assert set(z.namelist())=={'main.js','overlay.js','manifest.json'}
 zfiles={n:z.read(n) for n in z.namelist()}
 for n,b in zfiles.items():assert sha(b)==receipt['production_package']['files'][n]
 prod=json.loads(zfiles['manifest.json']);assert prod==load(ROOT/'derivatives-overlay/manifest.base.json')
 assert prod['permissions']==['storage'] and not prod.get('host_permissions')
 assert all(c['matches']==['https://cornelltradingcompetition.org/*'] for c in prod['content_scripts'])
 assert all(c['all_frames'] is False for c in prod['content_scripts'])
 for n in ['main.js','overlay.js']:
  assert b'localhost:5317' not in zfiles[n]
  assert not re.search(rb'(^|[^.\w$])eval\s*\(|new\s+Function\s*\(',zfiles[n])
links=[];by_doc={}
for rel in ['docs/game-day-verification.md','docs/competition-readiness.md','docs/overnight-run.md','derivatives-overlay/README.md','derivatives-overlay/GAMEDAY.md','mario/README.md']:
 p=ROOT/rel;count=0
 for dest in re.findall(r'\[[^\]]+\]\(([^)]+)\)',p.read_text()):
  if '://' in dest or dest.startswith('#'):continue
  target=dest.split('#')[0].split(' "')[0]
  assert (p.parent/target).resolve().exists(),(rel,target)
  links.append({'document':rel,'target':target});count+=1
 by_doc[rel]=count
assert not git('status','--porcelain') and git('rev-parse','HEAD').decode().strip()==HEAD
save('archive-member-hashes.json',member_checks)
save('source-hashes.json',source_checks)
report={'head':HEAD,'base':BASE,'runtime_revision':RUNTIME,'artifact_checks':artifact_checks,
 'archive_regular_files':130,'internal_hash_entries_checked':inner_hashes,'source_files_bound':97,
 'frozen_runtime_test_config_exact':True,'python_and_mario_unchanged':True,
 'production_zip_sha256':sha(zip_bytes),'production_manifest':prod,'production_zip_file_sha256':receipt['production_package']['files'],
 'retained_test_evidence':summary,'retained_independent_review':r,'relative_links':links,'relative_link_count':len(links),'links_by_document':by_doc,
 'new_test_or_browser_runs':0,'performance_replays':0,'network_or_credential_access':False,
 'claims_qualification':'Test pass counts refer to retained logs independently bound to frozen source, not fresh reruns by this reviewer.',
 'finding_evidence':{'development_build_keeps_real_exchange_match':True,'auto_submit_persisted_and_restored':True,'new_store_paused_default':False,'production_description_claims_never_submits':True}}
save('package-audit.json',report)
print(json.dumps({k:report[k] for k in ['head','source_files_bound','archive_regular_files','internal_hash_entries_checked','relative_link_count','links_by_document','production_zip_sha256','new_test_or_browser_runs']},indent=2))
