// ../ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/engine/normal.ts
var SQRT2PI = 2.5066282746310002;
function normPdf(x) {
  return Math.exp(-0.5 * x * x) / SQRT2PI;
}
function normCdf(x) {
  if (Number.isNaN(x)) return NaN;
  const ax = Math.abs(x);
  let c;
  if (ax > 37) {
    c = 0;
  } else {
    const e = Math.exp(-ax * ax / 2);
    if (ax < 7.07106781186547) {
      let b = 0.0352624965998911 * ax + 0.700383064443688;
      b = b * ax + 6.37396220353165;
      b = b * ax + 33.912866078383;
      b = b * ax + 112.079291497871;
      b = b * ax + 221.213596169931;
      b = b * ax + 220.206867912376;
      c = e * b;
      b = 0.0883883476483184 * ax + 1.75566716318264;
      b = b * ax + 16.064177579207;
      b = b * ax + 86.7807322029461;
      b = b * ax + 296.564248779674;
      b = b * ax + 637.333633378831;
      b = b * ax + 793.826512519948;
      b = b * ax + 440.413735824752;
      c = c / b;
    } else {
      let b = ax + 0.65;
      b = ax + 4 / b;
      b = ax + 3 / b;
      b = ax + 2 / b;
      b = ax + 1 / b;
      c = e / b / SQRT2PI;
    }
  }
  return x > 0 ? 1 - c : c;
}
var A = [-39.69683028665376, 220.9460984245205, -275.9285104469687, 138.357751867269, -30.66479806614716, 2.506628277459239];
var B = [-54.47609879822406, 161.5858368580409, -155.6989798598866, 66.80131188771972, -13.28068155288572];
var C = [-0.007784894002430293, -0.3223964580411365, -2.400758277161838, -2.549732539343734, 4.374664141464968, 2.938163982698783];
var D = [0.007784695709041462, 0.3224671290700398, 2.445134137142996, 3.754408661907416];
function normInv(p) {
  if (!(p > 0 && p < 1)) {
    if (p === 0) return -Infinity;
    if (p === 1) return Infinity;
    return NaN;
  }
  const pLow = 0.02425;
  let x;
  if (p < pLow) {
    const q = Math.sqrt(-2 * Math.log(p));
    x = (((((C[0] * q + C[1]) * q + C[2]) * q + C[3]) * q + C[4]) * q + C[5]) / ((((D[0] * q + D[1]) * q + D[2]) * q + D[3]) * q + 1);
  } else if (p <= 1 - pLow) {
    const q = p - 0.5;
    const r = q * q;
    x = (((((A[0] * r + A[1]) * r + A[2]) * r + A[3]) * r + A[4]) * r + A[5]) * q / (((((B[0] * r + B[1]) * r + B[2]) * r + B[3]) * r + B[4]) * r + 1);
  } else {
    const q = Math.sqrt(-2 * Math.log(1 - p));
    x = -(((((C[0] * q + C[1]) * q + C[2]) * q + C[3]) * q + C[4]) * q + C[5]) / ((((D[0] * q + D[1]) * q + D[2]) * q + D[3]) * q + 1);
  }
  const e = normCdf(x) - p;
  const u = e * SQRT2PI * Math.exp(x * x / 2);
  return x - u / (1 + x * u / 2);
}

// ../ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/engine/blackScholes.ts
function intrinsic(kind, S, K) {
  return kind === "C" ? Math.max(S - K, 0) : Math.max(K - S, 0);
}
function degenerate(S, K, sigma, T) {
  return !(T > 0) || !(sigma > 0) || !(S > 0) || !(K > 0);
}
function d1d2(S, K, sigma, T) {
  const sd = sigma * Math.sqrt(T);
  const d1 = (Math.log(S / K) + 0.5 * sd * sd) / sd;
  return [d1, d1 - sd];
}
function price(kind, S, K, sigma, T) {
  if (degenerate(S, K, sigma, T)) return intrinsic(kind, Math.max(S, 0), Math.max(K, 0));
  const [d1, d2] = d1d2(S, K, sigma, T);
  return kind === "C" ? S * normCdf(d1) - K * normCdf(d2) : K * normCdf(-d2) - S * normCdf(-d1);
}
function delta(kind, S, K, sigma, T) {
  if (degenerate(S, K, sigma, T)) {
    if (kind === "C") return S > K ? 1 : 0;
    return S < K ? -1 : 0;
  }
  const [d1] = d1d2(S, K, sigma, T);
  return kind === "C" ? normCdf(d1) : normCdf(d1) - 1;
}
function gamma(S, K, sigma, T) {
  if (degenerate(S, K, sigma, T)) return 0;
  const [d1] = d1d2(S, K, sigma, T);
  return normPdf(d1) / (S * sigma * Math.sqrt(T));
}
function vegaPerPoint(S, K, sigma, T) {
  if (degenerate(S, K, sigma, T)) return 0;
  const [d1] = d1d2(S, K, sigma, T);
  return S * normPdf(d1) * Math.sqrt(T) / 100;
}
function thetaPerDay(S, K, sigma, T) {
  if (degenerate(S, K, sigma, T)) return 0;
  const [d1] = d1d2(S, K, sigma, T);
  return -(S * normPdf(d1) * sigma) / (2 * Math.sqrt(T)) / 252;
}
function greeks(kind, S, K, sigma, T) {
  return {
    price: price(kind, S, K, sigma, T),
    delta: delta(kind, S, K, sigma, T),
    gamma: gamma(S, K, sigma, T),
    vegaPerPoint: vegaPerPoint(S, K, sigma, T),
    thetaPerDay: thetaPerDay(S, K, sigma, T)
  };
}
function probItm(kind, S, K, sigma, T) {
  if (degenerate(S, K, sigma, T)) return intrinsic(kind, S, K) > 0 ? 1 : 0;
  const [, d2] = d1d2(S, K, sigma, T);
  return kind === "C" ? normCdf(d2) : normCdf(-d2);
}

// ../ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/engine/impliedVol.ts
var IV_LO = 1e-4;
var IV_HI = 10;
function impliedVol(kind, px, S, K, T, tol = 1e-8) {
  if (!Number.isFinite(px) || !(S > 0) || !(K > 0) || !(T > 0)) return null;
  const intr = intrinsic(kind, S, K);
  const upper = kind === "C" ? S : K;
  if (px < intr - 1e-9 || px > upper + 1e-9) return null;
  let lo = IV_LO;
  let hi = IV_HI;
  const fLo = price(kind, S, K, lo, T) - px;
  const fHi = price(kind, S, K, hi, T) - px;
  if (fLo >= 0) return lo;
  if (fHi < 0) return null;
  let x = Math.min(Math.max(Math.sqrt(2 * Math.PI / T) * px / S, 0.05), 3);
  for (let i = 0; i < 100; i++) {
    const f = price(kind, S, K, x, T) - px;
    if (Math.abs(f) < tol) return x;
    if (f > 0) hi = x;
    else lo = x;
    const v = vegaPerPoint(S, K, x, T) * 100;
    let next = v > 1e-12 ? x - f / v : NaN;
    if (!(next > lo && next < hi)) next = 0.5 * (lo + hi);
    if (hi - lo < 1e-14) return next;
    x = next;
  }
  return x;
}

// ../ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/engine/safeExpr.ts
var VARIABLES = ["x", "S", "T", "K"];
var CONSTANTS = { pi: Math.PI, e: Math.E };
var FUNCS = {
  sqrt: { arity: [1, 1], f: Math.sqrt },
  ln: { arity: [1, 1], f: Math.log },
  log: { arity: [1, 1], f: Math.log10 },
  exp: { arity: [1, 1], f: Math.exp },
  abs: { arity: [1, 1], f: Math.abs },
  min: { arity: [1, 16], f: Math.min },
  max: { arity: [1, 16], f: Math.max },
  normcdf: { arity: [1, 1], f: normCdf },
  norminv: { arity: [1, 1], f: normInv }
};
var ExprError = class extends Error {
};
function tokenize(src) {
  if (src.length > 500) throw new ExprError("expression too long");
  const out = [];
  let i = 0;
  while (i < src.length) {
    const ch = src[i];
    if (/\s/.test(ch)) {
      i++;
      continue;
    }
    const num = /^(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/.exec(src.slice(i));
    if (num) {
      out.push({ t: "num", v: Number(num[0]) });
      i += num[0].length;
      continue;
    }
    const id = /^[A-Za-z_][A-Za-z0-9_]*/.exec(src.slice(i));
    if (id) {
      out.push({ t: "id", v: id[0] });
      i += id[0].length;
      continue;
    }
    if ("+-*/^(),".includes(ch)) {
      out.push({ t: "op", v: ch });
      i++;
      continue;
    }
    if (ch === "\u2212") {
      out.push({ t: "op", v: "-" });
      i++;
      continue;
    }
    throw new ExprError(`unexpected character '${ch}'`);
  }
  out.push({ t: "end" });
  return out;
}
var BP = { "+": 10, "-": 10, "*": 20, "/": 20, "^": 30 };
function parseExpr(src) {
  const toks = tokenize(src);
  let p = 0;
  const peek = () => toks[p];
  const next = () => toks[p++];
  const expectOp = (v) => {
    const t = next();
    if (t.t !== "op" || t.v !== v) throw new ExprError(`expected '${v}'`);
  };
  function nud(t) {
    if (t.t === "num") return { k: "num", v: t.v };
    if (t.t === "op" && t.v === "-") return { k: "neg", a: expr(25) };
    if (t.t === "op" && t.v === "+") return expr(25);
    if (t.t === "op" && t.v === "(") {
      const e = expr(0);
      expectOp(")");
      return e;
    }
    if (t.t === "id") {
      const nt = peek();
      if (nt.t === "op" && nt.v === "(") {
        const fn = t.v.toLowerCase();
        if (!Object.prototype.hasOwnProperty.call(FUNCS, fn)) throw new ExprError(`unknown function '${t.v}'`);
        next();
        const args = [];
        const close = peek();
        if (!(close.t === "op" && close.v === ")")) {
          for (; ; ) {
            args.push(expr(0));
            const s = next();
            if (s.t === "op" && s.v === ",") continue;
            if (s.t === "op" && s.v === ")") break;
            throw new ExprError("expected ',' or ')'");
          }
        } else next();
        const [lo, hi] = FUNCS[fn].arity;
        if (args.length < lo || args.length > hi) throw new ExprError(`${fn} takes ${lo === hi ? lo : `${lo}-${hi}`} argument(s)`);
        return { k: "call", fn, args };
      }
      if (VARIABLES.includes(t.v)) return { k: "var", name: t.v };
      if (Object.prototype.hasOwnProperty.call(CONSTANTS, t.v)) return { k: "num", v: CONSTANTS[t.v] };
      throw new ExprError(`unknown identifier '${t.v}'`);
    }
    throw new ExprError("unexpected token");
  }
  function expr(rbp) {
    let left = nud(next());
    for (; ; ) {
      const t = peek();
      if (t.t !== "op" || !(t.v in BP)) break;
      const bp = BP[t.v];
      if (bp <= rbp) break;
      next();
      const right = expr(t.v === "^" ? bp - 1 : bp);
      left = { k: "bin", op: t.v, a: left, b: right };
    }
    return left;
  }
  const root = expr(0);
  if (peek().t !== "end") throw new ExprError("unexpected trailing input");
  return root;
}
function evalNode(n, vars) {
  switch (n.k) {
    case "num":
      return n.v;
    case "var": {
      const v = vars[n.name];
      if (v == null) throw new ExprError(`variable ${n.name} has no value`);
      return v;
    }
    case "neg":
      return -evalNode(n.a, vars);
    case "bin": {
      const a = evalNode(n.a, vars);
      const b = evalNode(n.b, vars);
      switch (n.op) {
        case "+":
          return a + b;
        case "-":
          return a - b;
        case "*":
          return a * b;
        case "/":
          return a / b;
        case "^":
          return Math.pow(a, b);
      }
      throw new ExprError("bad operator");
    }
    case "call":
      return FUNCS[n.fn].f(...n.args.map((x) => evalNode(x, vars)));
  }
}
function compileExpr(src) {
  try {
    const node = parseExpr(src);
    return { ok: true, run: (v) => evalNode(node, v) };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : String(e) };
  }
}

// ../ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/engine/converters.ts
var CONVERTERS = [
  { id: "iv", label: "IV (%, or decimal)" },
  { id: "variance", label: "Annual variance (decimal or %\xB2)" },
  { id: "dailyMoveAbs", label: "Daily move $" },
  { id: "dailyMovePct", label: "Daily move %" },
  { id: "expiryMovePct", label: "Move to expiry %" },
  { id: "atmStraddle", label: "ATM straddle $" },
  { id: "callPrice", label: "Call price @K", needsK: true },
  { id: "putPrice", label: "Put price @K", needsK: true },
  { id: "probItmCall", label: "P(call ITM) @K", needsK: true },
  { id: "probItmPut", label: "P(put ITM) @K", needsK: true },
  { id: "vegaPerPoint", label: "Vega per vol pt @K", needsK: true },
  { id: "custom", label: "Custom formula (x S T K)" }
];
function normalizeVol(value, hasPct = false) {
  return hasPct || value > 3 ? value / 100 : value;
}
function nearestStrike(S, strikes2) {
  if (!strikes2?.length) return S;
  return strikes2.reduce((b, k) => Math.abs(k - S) < Math.abs(b - S) ? k : b, strikes2[0]);
}
function bisect(f, target, lo, hi) {
  let flo = f(lo) - target;
  const fhi = f(hi) - target;
  if (!Number.isFinite(flo) || !Number.isFinite(fhi) || flo * fhi > 0) return null;
  for (let i = 0; i < 200; i++) {
    const m = 0.5 * (lo + hi);
    const fm = f(m) - target;
    if (Math.abs(fm) < 1e-13 || hi - lo < 1e-13) return m;
    if (fm * flo > 0) {
      lo = m;
      flo = fm;
    } else hi = m;
  }
  return 0.5 * (lo + hi);
}
function convertToSigma(id, x, ctx) {
  const { S, T } = ctx;
  if (!Number.isFinite(x)) return { sigma: null, note: "no value" };
  const K = ctx.K ?? nearestStrike(S, ctx.strikes);
  switch (id) {
    case "iv":
      return { sigma: normalizeVol(x) };
    case "variance": {
      const unit = ctx.varianceUnit ?? "auto";
      const pct2 = unit === "pct2" || unit === "auto" && x > 9;
      if (x < 0) return { sigma: null, note: "negative variance" };
      return { sigma: pct2 ? Math.sqrt(x) / 100 : Math.sqrt(x), note: pct2 ? "read as %\xB2" : "read as decimal" };
    }
    case "dailyMoveAbs":
      return S > 0 ? { sigma: x / S * Math.sqrt(252) } : { sigma: null };
    case "dailyMovePct":
      return { sigma: x / 100 * Math.sqrt(252) };
    case "expiryMovePct":
      return T > 0 ? { sigma: x / 100 / Math.sqrt(T) } : { sigma: null };
    case "atmStraddle": {
      if (!(T > 0) || !(S > 0)) return { sigma: null };
      const f = (s) => price("C", S, K, s, T) + price("P", S, K, s, T);
      const sigma = bisect(f, x, IV_LO, IV_HI);
      return { sigma, approx: x / (0.8 * S * Math.sqrt(T)), note: `exact BS straddle at K=${K}` };
    }
    case "callPrice":
      return { sigma: impliedVol("C", x, S, K, T) };
    case "putPrice":
      return { sigma: impliedVol("P", x, S, K, T) };
    case "probItmCall":
    case "probItmPut": {
      if (!(T > 0) || !(x > 0 && x < 1)) return { sigma: null, note: "probability must be in (0,1)" };
      const kind = id === "probItmCall" ? "C" : "P";
      const a = Math.log(S / K);
      const hi = a < 0 ? Math.min(Math.sqrt(2 * -a) / Math.sqrt(T), IV_HI) : IV_HI;
      const sigma = bisect((s) => probItm(kind, S, K, s, T), x, IV_LO, hi);
      return { sigma, note: sigma == null ? "no solution on the low-vol branch" : void 0 };
    }
    case "vegaPerPoint": {
      if (!(T > 0) || !(x > 0)) return { sigma: null };
      const a = Math.abs(Math.log(S / K));
      const peak = Math.min(Math.max(Math.sqrt(2 * a) / Math.sqrt(T), IV_LO * 2), IV_HI);
      const f = (s) => vegaPerPoint(S, K, s, T);
      const roots = [bisect(f, x, IV_LO, peak), bisect(f, x, peak, IV_HI)].filter((r) => r != null);
      if (!roots.length) return { sigma: null, note: "vega out of range" };
      const prior = ctx.prior ?? 0.5;
      const sigma = roots.reduce((b, r) => Math.abs(r - prior) < Math.abs(b - prior) ? r : b, roots[0]);
      return { sigma, note: roots.length > 1 ? `two roots (${roots.map((r) => (r * 100).toFixed(1)).join("%, ")}%); picked nearest ${(prior * 100).toFixed(0)}%` : void 0 };
    }
    case "custom": {
      const c = compileExpr(ctx.formula ?? "x");
      if (!c.ok) return { sigma: null, note: c.error };
      try {
        const v = c.run({ x, S, T, K });
        return Number.isFinite(v) ? { sigma: v } : { sigma: null, note: "formula gave a non-finite value" };
      } catch (e) {
        return { sigma: null, note: e instanceof Error ? e.message : String(e) };
      }
    }
  }
}

// ../ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/engine/autoConverter.ts
var KEYWORDS = {
  variance: /\bvarian/i,
  dailyMoveAbs: /\b(daily|one[- ]day|1[- ]day)\b[^.%]{0,30}\$|\$[^.]{0,20}\b(daily|per day|a day)\b|dollar (move|range)/i,
  dailyMovePct: /\b(daily|one[- ]day|1[- ]day)\b[^.$]{0,30}(%|percent|move|range|vol)|\bper[- ]day\b/i,
  expiryMovePct: /(expected|implied|typical)?\s*move\b[^.]{0,30}\b(to|by|at|through|until)\s+expir|\bexpiry move|\bmove to expiry|\bterminal\b/i,
  atmStraddle: /\bstraddle/i,
  callPrice: /\bcall\b[^.]{0,20}\b(price|premium|worth|trades?|quoted?)|\b(price|premium) of (the|a) call/i,
  putPrice: /\bput\b[^.]{0,20}\b(price|premium|worth|trades?|quoted?)|\b(price|premium) of (the|a) put/i,
  probItmCall: /\b(probab|chance|likelihood|odds)[^.]{0,40}\b(above|over|exceed|finish(es|ing)? above|call)|\bcall\b[^.]{0,20}\b(in[- ]the[- ]money|ITM)/i,
  probItmPut: /\b(probab|chance|likelihood|odds)[^.]{0,40}\b(below|under|finish(es|ing)? below|put)|\bput\b[^.]{0,20}\b(in[- ]the[- ]money|ITM)/i,
  vegaPerPoint: /\bvega\b/i,
  iv: /\b(implied vol(atility)?|IV|sigma|σ|volatility)\b/i
};
var MONEY_IDS = ["dailyMoveAbs", "atmStraddle", "callPrice", "putPrice", "vegaPerPoint"];
var PCT_IDS = ["iv", "dailyMovePct", "expiryMovePct", "variance"];
function mentionedConverters(text) {
  return CONVERTERS.filter(({ id }) => KEYWORDS[id]?.test(text)).map(({ id }) => id);
}
var median = (xs) => {
  const a = [...xs].sort((x, y) => x - y);
  return a.length ? a.length % 2 ? a[(a.length - 1) / 2] : (a[a.length / 2 - 1] + a[a.length / 2]) / 2 : NaN;
};
function identifyConverter(inp) {
  const text = inp.text ?? "";
  const anyDollar = inp.samples.some((s) => /\$/.test(s.rawStr ?? ""));
  const anyPct = inp.samples.some((s) => /%/.test(s.rawStr ?? ""));
  const ranked = [];
  for (const { id } of CONVERTERS) {
    if (id === "custom") continue;
    if (anyDollar && !MONEY_IDS.includes(id)) continue;
    if (anyPct && !PCT_IDS.includes(id)) continue;
    const errs = [];
    const sigmas = [];
    for (const smp of inp.samples) {
      const S = inp.spot[smp.underlying];
      const iv = inp.marketIV[smp.underlying];
      if (S == null || iv == null || !(S > 0) || !(iv > 0)) continue;
      const r = convertToSigma(id, smp.raw, { S, T: inp.T, strikes: inp.strikes?.[smp.underlying], prior: iv });
      if (r.sigma == null || !Number.isFinite(r.sigma) || r.sigma <= 0) continue;
      sigmas.push(r.sigma);
      errs.push(Math.abs(r.sigma - iv) * 100);
    }
    if (!errs.length) continue;
    ranked.push({ id, errPts: median(errs), sigma: median(sigmas), keyword: !!KEYWORDS[id]?.test(text) });
  }
  ranked.sort((a, b) => a.errPts - b.errPts);
  if (!ranked.length) return { id: null, reason: "no converter could be evaluated (need a spot and a market IV)", ranked };
  const within = ranked.filter((c) => c.errPts <= inp.tolPts);
  const fmt = (c) => `${c.id} (\u03C3 ${(c.sigma * 100).toFixed(1)}%, off ${c.errPts.toFixed(1)} pts)`;
  if (!within.length) {
    return { id: null, reason: `nothing within ${inp.tolPts} vol pts of the market IV; closest ${fmt(ranked[0])}. Pick the converter by hand.`, ranked };
  }
  const named = within.filter((c) => c.keyword);
  const mentioned = mentionedConverters(text);
  if (mentioned.length && !named.length) {
    return { id: null, reason: `message names ${mentioned.join(", ")}, but no named converter is within ${inp.tolPts} vol pts of the market IV. Pick the converter by hand.`, ranked };
  }
  if (named.length === 1) return { id: named[0].id, reason: `message names it and it matches the market IV: ${fmt(named[0])}`, ranked };
  if (named.length > 1 && named[1].errPts - named[0].errPts >= inp.tieMarginPts) {
    return { id: named[0].id, reason: `several named, nearest market IV: ${fmt(named[0])} vs ${fmt(named[1])}`, ranked };
  }
  if (named.length > 1) {
    return { id: null, reason: `ambiguous named converters: ${fmt(named[0])} vs ${fmt(named[1])}. Pick the converter by hand.`, ranked };
  }
  const best = within[0];
  const second2 = ranked[1];
  if (second2 && second2.errPts - best.errPts < inp.tieMarginPts) {
    return { id: null, reason: `ambiguous: ${fmt(best)} vs ${fmt(second2)}. Pick the converter by hand.`, ranked };
  }
  return { id: best.id, reason: `nearest the market IV: ${fmt(best)}${second2 ? `; next ${fmt(second2)}` : ""}`, ranked };
}

// ../ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/engine/chain.ts
var DEFAULT_OPTION_REGEX = "^(OIL|PLANE)_(\\d{4})_([CP])(\\d+(?:\\.\\d+)?)$";
function compileSymbolRegex(src) {
  try {
    return new RegExp(src);
  } catch {
    return new RegExp(DEFAULT_OPTION_REGEX);
  }
}
function parseOptionSymbol(symbol, re = new RegExp(DEFAULT_OPTION_REGEX)) {
  const m = re.exec(symbol);
  if (!m || m.length < 5) return null;
  const kind = m[3].toUpperCase().startsWith("C") ? "C" : m[3].toUpperCase().startsWith("P") ? "P" : null;
  const strike = Number(m[4]);
  if (!kind || !Number.isFinite(strike)) return null;
  return { symbol, underlying: m[1].toUpperCase(), expiry: m[2], kind, strike };
}
function metaFromSymbolEntry(entry, re) {
  if (typeof entry === "string") return parseOptionSymbol(entry, re);
  if (!entry || typeof entry !== "object") return null;
  const o = entry;
  const symbol = String(o.symbol ?? o.ticker ?? o.name ?? o.id ?? "");
  const fromName = symbol ? parseOptionSymbol(symbol, re) : null;
  const kindRaw = String(o.option_type ?? o.optionType ?? o.right ?? o.put_call ?? o.kind ?? o.type ?? "").toUpperCase();
  const kind = /^(C|CALL)/.test(kindRaw) ? "C" : /^(P|PUT)/.test(kindRaw) ? "P" : null;
  const strike = Number(o.strike ?? o.strike_price ?? o.strikePrice);
  const underlying = String(o.underlying ?? o.underlying_symbol ?? o.underlyingSymbol ?? o.root ?? "").toUpperCase();
  if (symbol && kind && Number.isFinite(strike) && strike > 0 && underlying) {
    return { symbol, underlying, kind, strike, expiry: String(o.expiry ?? o.expiration ?? fromName?.expiry ?? "") };
  }
  return fromName;
}
function mid(c) {
  if (c.bid != null && c.ask != null && c.bid > 0 && c.ask > 0 && c.ask >= c.bid) return (c.bid + c.ask) / 2;
  return null;
}
function buildChains(metas, quotes) {
  const out = {};
  for (const m of metas) {
    const q = quotes[m.symbol];
    const c = {
      ...m,
      bid: q?.bid ?? null,
      ask: q?.ask ?? null,
      bidSize: q?.bidSize ?? null,
      askSize: q?.askSize ?? null,
      t: q?.t ?? null,
      src: q?.src ?? null
    };
    const ch = out[m.underlying] ??= { underlying: m.underlying, strikes: [], rows: [], contracts: [] };
    ch.contracts.push(c);
    let row = ch.rows.find((r) => r.strike === m.strike);
    if (!row) {
      row = { strike: m.strike };
      ch.rows.push(row);
    }
    if (m.kind === "C") row.call = c;
    else row.put = c;
  }
  for (const ch of Object.values(out)) {
    ch.rows.sort((a, b) => a.strike - b.strike);
    ch.strikes = ch.rows.map((r) => r.strike);
    ch.contracts.sort((a, b) => a.strike - b.strike || a.kind.localeCompare(b.kind));
  }
  return out;
}
function contractIV(c, S, T) {
  const m = mid(c);
  const ivMid = m != null ? impliedVol(c.kind, m, S, c.strike, T) : null;
  const ivBid = c.bid != null && c.bid > 0 ? impliedVol(c.kind, c.bid, S, c.strike, T) : null;
  const ivAsk = c.ask != null && c.ask > 0 ? impliedVol(c.kind, c.ask, S, c.strike, T) : null;
  return { mid: ivMid, bid: ivBid, ask: ivAsk, vegaAtMid: ivMid != null ? vegaPerPoint(S, c.strike, ivMid, T) : 0 };
}
function median2(xs) {
  const a = xs.filter((x) => Number.isFinite(x)).sort((x, y) => x - y);
  if (!a.length) return null;
  const k = Math.floor(a.length / 2);
  return a.length % 2 ? a[k] : (a[k - 1] + a[k]) / 2;
}
function marketIV(chain, S, T, minVega = 0.02) {
  if (!(S > 0) || !(T > 0)) return null;
  const ivs = [];
  for (const c of chain.contracts) {
    const iv = contractIV(c, S, T);
    if (iv.mid != null && iv.mid > 2e-4 && iv.vegaAtMid >= minVega) ivs.push(iv.mid);
  }
  return median2(ivs);
}
function parityImpliedSpot(chain) {
  const xs = [];
  for (const r of chain.rows) {
    if (!r.call || !r.put) continue;
    const mc = mid(r.call);
    const mp = mid(r.put);
    if (mc != null && mp != null) xs.push(r.strike + mc - mp);
  }
  return median2(xs);
}
function inferTick(prices, fallback = 0.01) {
  let dec = 0;
  let seen = false;
  for (const p of prices) {
    if (!Number.isFinite(p)) continue;
    seen = true;
    const s = String(p);
    const i = s.indexOf(".");
    if (i >= 0) dec = Math.max(dec, Math.min(s.length - i - 1, 4));
  }
  if (!seen) return fallback;
  return dec === 0 ? Math.min(fallback, 1) : Math.pow(10, -dec);
}
function roundToTick(px, tick2, mode = "nearest") {
  if (!(tick2 > 0)) return px;
  const n = px / tick2;
  const r = mode === "down" ? Math.floor(n + 1e-9) : mode === "up" ? Math.ceil(n - 1e-9) : Math.round(n);
  const dec = Math.max(0, Math.ceil(-Math.log10(tick2) - 1e-9));
  return Number((r * tick2).toFixed(dec));
}

// ../ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/engine/headline.ts
var DEFAULT_HEADLINE_CONFIG = {
  aliases: {
    OIL: ["\\boil\\b", "\\bcrude\\b", "\\bbrent\\b", "\\bOIL\\b", "\\bbarrel"],
    PLANE: ["\\bPLANE\\b", "\\bNew\\s?Air\\b", "\\bairline", "\\bplane\\b"]
  }
};
var VOL_RE = /\b(?:implied\s+vol(?:atilit(?:y|ies)|s)?|IVs?|vol(?:atilit(?:y|ies)|s)?|sigma|σ)\b/i;
var SPOT_NEAR_RE = /\b(?:price|spot|px|level|trades?\s+at|settles?\s+at|closes?\s+at)\s*:?\s*(?:of\s*)?\$?\s*$/i;
var FOR_RE = /^\s*(?:%|percent)?\s*(?:for|on|in|of)\s+$/i;
var ANALYST_RE = /\banalyst\s*#?\s*(1|2|3|one|two|three)\b/i;
var WORD_NUM = { "1": 1, "2": 2, "3": 3, one: 1, two: 2, three: 3 };
var UP_RE = /\b(?:rise[sn]?|rose|jump(?:s|ed)?|climb(?:s|ed)?|gain(?:s|ed)?|up|soar(?:s|ed)?|rall(?:y|ies|ied)|surge[sd]?|spike[sd]?)\b/i;
var DOWN_RE = /\b(?:fall(?:s|en)?|fell|drop(?:s|ped)?|down|plunge[sd]?|slide[sd]?|slid|sink(?:s)?|sank|decline[sd]?|tumble[sd]?|crash(?:es|ed)?|slump(?:s|ed)?)\b/i;
function parseHeadline(text, cfg = DEFAULT_HEADLINE_CONFIG) {
  const res = { underlyings: {}, analysts: [], mentions: [] };
  if (!text || typeof text !== "string") return res;
  const markers = [];
  for (const [und, pats] of Object.entries(cfg.aliases)) {
    for (const p of pats) {
      let re;
      try {
        re = new RegExp(p, "gi");
      } catch {
        continue;
      }
      for (const m of text.matchAll(re)) markers.push({ i: m.index ?? 0, end: (m.index ?? 0) + m[0].length, kind: "und", und });
    }
  }
  for (const m of text.matchAll(new RegExp(ANALYST_RE.source, "gi"))) {
    markers.push({ i: m.index ?? 0, end: (m.index ?? 0) + m[0].length, kind: "analyst", analyst: WORD_NUM[m[1].toLowerCase()] });
  }
  const numRe = /(\$\s?)?(?<![\w.:\-/])(\d+(?:,\d{3})*(?:\.\d+)?|\.\d+)(?![\w:]|\.\d|-\d)(\s?%)?/g;
  for (const m of text.matchAll(numRe)) {
    const i = m.index ?? 0;
    const inside = markers.some((k) => k.kind === "analyst" && i >= k.i && i < k.end);
    if (inside) continue;
    const value = Number(m[2].replace(/,/g, ""));
    if (!Number.isFinite(value)) continue;
    markers.push({ i, end: i + m[0].length, kind: "num", value, raw: m[0].trim(), pct: !!m[3], dollar: !!m[1] });
  }
  markers.sort((a, b) => a.i - b.i || (a.kind === "num" ? 1 : -1));
  const ms = [];
  for (const m of markers) {
    const prev = ms[ms.length - 1];
    if (prev && m.kind === "und" && prev.kind === "und" && m.i < prev.end) continue;
    ms.push(m);
  }
  let curUnd = null;
  let curAnalyst = null;
  let lastIdx = 0;
  const mentions = /* @__PURE__ */ new Set();
  for (const m of ms) {
    if (m.kind === "und") {
      curUnd = m.und;
      mentions.add(curUnd);
      lastIdx = m.end;
      continue;
    }
    if (m.kind === "analyst") {
      curAnalyst = m.analyst;
      lastIdx = m.end;
      continue;
    }
    const gap = text.slice(lastIdx, m.i);
    if (/[.;!?]\s|\n|\|/.test(gap) && !/\banalyst/i.test(gap)) curAnalyst = null;
    let before = text.slice(Math.max(0, m.i - 28), m.i);
    const boundary = /^[\s\S]*(?:[.;!?]\s+|\|\s*)/.exec(before);
    if (boundary) before = before.slice(boundary[0].length);
    const after = text.slice(m.end, m.end + 16);
    lastIdx = m.end;
    const nextUnd = ms.find((k) => k.kind === "und" && k.i >= m.end);
    const undHere = nextUnd && FOR_RE.test(text.slice(m.end, nextUnd.i)) ? nextUnd.und : curUnd;
    if (!undHere) continue;
    if (/\btariff|\bpercent of\b|\bday|\bweek|\bmonth|\byear|\bround|\bevent|\bdeaths?|\bkilled|\bpassengers?|\bflights?/i.test(before.slice(-16) + " " + after)) {
      if (!VOL_RE.test(before) && !/\b(move|range|straddle|varian|premium|probab|chance)/i.test(before)) continue;
    }
    const volCue = VOL_RE.test(before) && !SPOT_NEAR_RE.test(before) || /^\s*%?\s*(?:implied\s+)?vol/i.test(after);
    const value = m.value;
    if (curAnalyst != null) {
      res.analysts.push({
        analyst: curAnalyst,
        underlying: undHere,
        raw: m.raw,
        hasPct: !!m.pct,
        isVol: volCue,
        value: normalizeVol(value, m.pct),
        rawValue: value
      });
      if (undHere !== curUnd) mentions.add(undHere);
      continue;
    }
    const u = res.underlyings[undHere] ??= {};
    if (undHere !== curUnd) mentions.add(undHere);
    if (volCue) {
      if (u.iv == null) {
        u.iv = normalizeVol(value, m.pct);
        u.ivRaw = m.raw;
      }
    } else if (m.pct) {
      const ctx = text.slice(Math.max(0, m.i - 40), m.i);
      const sign = DOWN_RE.test(ctx) ? -1 : UP_RE.test(ctx) ? 1 : 0;
      if (sign && u.changePct == null) u.changePct = sign * value;
    } else if (u.spot == null && value > 0) {
      u.spot = value;
      u.spotRaw = m.raw;
    }
  }
  for (const [k, v] of Object.entries(res.underlyings)) if (!Object.keys(v).length) delete res.underlyings[k];
  res.mentions = [...mentions];
  return res;
}
function extractStructured(msg, underlyings) {
  const out = {};
  const seen = /* @__PURE__ */ new Set();
  const SPOT_KEYS = /^(spot|price|new_price|newprice|underlying_price|px|level|value)$/i;
  const IV_KEYS = /^(iv|vol|volatility|implied_vol|impliedvol|new_iv|sigma)$/i;
  const SPOT_GROUP = /^(spots?|prices?|new_prices?|underlying_prices?|underlyings?|levels?)$/i;
  const IV_GROUP = /^(ivs?|vols?|volatilit(y|ies)|implied_vols?|new_ivs?|estimates?|values?|sigmas?)$/i;
  const top = msg && typeof msg === "object" ? msg : {};
  const analystMsg = top.analyst != null || /analyst/i.test(String(top.type ?? top.kind ?? ""));
  const visit = (o, ctxUnd, depth, hint) => {
    if (!o || typeof o !== "object" || depth > 5 || seen.has(o)) return;
    seen.add(o);
    const rec = o;
    let und = ctxUnd;
    const symField = rec.symbol ?? rec.underlying ?? rec.asset;
    if (typeof symField === "string" && underlyings.includes(symField.toUpperCase())) und = symField.toUpperCase();
    for (const [k, v] of Object.entries(rec)) {
      const ku = k.toUpperCase();
      if (underlyings.includes(ku)) {
        if (typeof v === "number") {
          const field = analystMsg || hint === "iv" ? "iv" : "spot";
          (out[ku] ??= {})[field] = field === "iv" && !analystMsg ? normalizeVol(v) : v;
        } else visit(v, ku, depth + 1, hint);
        continue;
      }
      const m = /^(OIL|PLANE)_(.+)$/i.exec(k);
      if (m && typeof v === "number" && underlyings.includes(m[1].toUpperCase())) {
        const u = out[m[1].toUpperCase()] ??= {};
        if (IV_KEYS.test(m[2])) u.iv = normalizeVol(v);
        else if (SPOT_KEYS.test(m[2])) u.spot = v;
        continue;
      }
      if (und && typeof v === "number") {
        const u = out[und] ??= {};
        if (IV_KEYS.test(k)) u.iv = analystMsg ? v : normalizeVol(v);
        else if (SPOT_KEYS.test(k) && !analystMsg) u.spot = v;
      } else if (typeof v === "object") visit(v, und, depth + 1, IV_GROUP.test(k) ? "iv" : SPOT_GROUP.test(k) ? "spot" : hint);
    }
  };
  visit(msg, null, 0, null);
  return out;
}

// ../ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/engine/tradingTime.ts
function parseNaive(s) {
  const m = /^\s*(\d{4})-(\d{2})-(\d{2})[T ](\d{1,2}):(\d{2})(?::(\d{2})(?:\.(\d+))?)?/.exec(s ?? "");
  if (!m) return null;
  const frac = m[7] ? Number("0." + m[7]) : 0;
  return { y: +m[1], m: +m[2], d: +m[3], hh: +m[4], mm: +m[5], ss: (m[6] ? +m[6] : 0) + frac };
}
function toSec(t) {
  return Date.UTC(t.y, t.m - 1, t.d, t.hh, t.mm, 0) / 1e3 + t.ss;
}
function fromSec(sec) {
  const whole = Math.floor(sec);
  const dt = new Date(whole * 1e3);
  return {
    y: dt.getUTCFullYear(),
    m: dt.getUTCMonth() + 1,
    d: dt.getUTCDate(),
    hh: dt.getUTCHours(),
    mm: dt.getUTCMinutes(),
    ss: dt.getUTCSeconds() + (sec - whole)
  };
}
function parseNaiveSec(s) {
  const t = parseNaive(s);
  return t ? toSec(t) : null;
}
var pad = (n) => String(Math.floor(n)).padStart(2, "0");
function fmtDate(sec) {
  const t = fromSec(sec);
  return `${t.y}-${pad(t.m)}-${pad(t.d)}`;
}
function dayStart(sec) {
  return Math.floor(sec / 86400) * 86400;
}
function secOfDay(sec) {
  return sec - dayStart(sec);
}
function hmsToSec(s) {
  const [h, m, x] = s.split(":").map(Number);
  return h * 3600 + m * 60 + (x || 0);
}
function isWeekday(sec) {
  const wd = new Date(dayStart(sec) * 1e3).getUTCDay();
  return wd >= 1 && wd <= 5;
}
var DEFAULT_SESSION = { expiry: "2026-06-26T16:00:00", open: "09:30", close: "16:00", holidays: [] };
function tradingDaysRemaining(nowSec, spec = DEFAULT_SESSION) {
  const exp = parseNaiveSec(spec.expiry);
  if (exp == null || nowSec >= exp) return 0;
  const open = hmsToSec(spec.open);
  const close = hmsToSec(spec.close);
  const len = close - open;
  const hol = new Set(spec.holidays ?? []);
  const isSession = (daySec) => isWeekday(daySec) && !hol.has(fmtDate(daySec));
  const today = dayStart(nowSec);
  const expDay = dayStart(exp);
  let days = 0;
  if (isSession(today)) {
    const endToday = today === expDay ? Math.min(close, secOfDay(exp)) : close;
    const t = Math.min(Math.max(secOfDay(nowSec), open), endToday);
    days += Math.max(endToday - t, 0) / len;
  }
  for (let d = today + 86400; d <= expDay; d += 86400) {
    if (!isSession(d)) continue;
    days += d === expDay ? Math.max(Math.min(secOfDay(exp), close) - open, 0) / len : 1;
  }
  return days;
}

// ../ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/engine/schedule.ts
var DEFAULT_SCHEDULE = [
  { n: 1, date: "2026-06-01", news: "09:30:00", move: "10:22:00", snap: "11:14:00", round: 1 },
  { n: 2, date: "2026-06-01", news: "11:40:00", move: "12:32:00", snap: "13:24:00", round: 1 },
  { n: 3, date: "2026-06-01", news: "13:50:00", move: "14:42:00", snap: "15:34:00", round: 1 },
  { n: 4, date: "2026-06-02", news: "09:30:00", move: "10:22:00", snap: "11:14:00", round: 2 },
  { n: 5, date: "2026-06-02", news: "11:40:00", move: "12:32:00", snap: "13:24:00", round: 2 },
  { n: 6, date: "2026-06-02", news: "13:50:00", move: "14:42:00", snap: "15:34:00", round: 2 },
  { n: 7, date: "2026-06-03", news: "09:30:00", move: "10:09:00", snap: "10:48:00", round: 3 },
  { n: 8, date: "2026-06-03", news: "11:07:30", move: "11:46:30", snap: "12:25:30", round: 3 },
  { n: 9, date: "2026-06-03", news: "12:45:00", move: "13:24:00", snap: "14:03:00", round: 3 },
  { n: 10, date: "2026-06-03", news: "14:22:30", move: "15:01:30", snap: "15:40:30", round: 3 }
];
function phaseAt(nowSec, schedule = DEFAULT_SCHEDULE, opts = {}) {
  const open = hmsToSec(opts.open ?? "09:30");
  const close = hmsToSec(opts.close ?? "16:00");
  const dates = [...new Set(schedule.map((e2) => e2.date))].sort();
  const date = fmtDate(nowSec);
  const tod = secOfDay(nowSec);
  let replay = false;
  let dayEvents = schedule.filter((e2) => e2.date === date);
  if (!dayEvents.length) {
    const first2 = dates[0];
    const last = dates[dates.length - 1];
    if (first2 && date > first2 && date <= last) {
      return { event: null, phase: "CLOSED", nextPhase: null, simSecondsToNext: null, replay, simSecondsInPhase: null };
    }
    if (first2 && date > last && date < "2100-01-01" && date >= "2026-01-01") {
      return { event: schedule[schedule.length - 1] ?? null, phase: "ENDED", nextPhase: null, simSecondsToNext: null, replay, simSecondsInPhase: null };
    }
    if (first2 && date < first2 && date >= "2026-01-01") {
      return { event: null, phase: "CLOSED", nextPhase: "NEWS", simSecondsToNext: null, replay, simSecondsInPhase: null };
    }
    replay = true;
    dayEvents = schedule.filter((e2) => e2.date === first2);
  }
  const ev = [...dayEvents].sort((a, b) => hmsToSec(a.news) - hmsToSec(b.news));
  const isLastDay = !replay && date === dates[dates.length - 1];
  if (!ev.length) return { event: null, phase: "CLOSED", nextPhase: null, simSecondsToNext: null, replay, simSecondsInPhase: null };
  const firstNews = hmsToSec(ev[0].news);
  if (tod < Math.min(open, firstNews)) {
    return { event: ev[0], phase: "CLOSED", nextPhase: "NEWS", simSecondsToNext: firstNews - tod, replay, simSecondsInPhase: null };
  }
  if (tod >= close) {
    const lastEv = ev[ev.length - 1];
    const ended = isLastDay || !replay && lastEv.n === Math.max(...schedule.map((e2) => e2.n));
    return { event: lastEv, phase: ended ? "ENDED" : "CLOSED", nextPhase: ended ? null : "NEWS", simSecondsToNext: null, replay, simSecondsInPhase: tod - close };
  }
  if (tod < firstNews) {
    return { event: ev[0], phase: "WAITING", nextPhase: "NEWS", simSecondsToNext: firstNews - tod, replay, simSecondsInPhase: tod - open };
  }
  let i = 0;
  while (i + 1 < ev.length && hmsToSec(ev[i + 1].news) <= tod) i++;
  const e = ev[i];
  const news2 = hmsToSec(e.news);
  const move = hmsToSec(e.move);
  const snap = hmsToSec(e.snap);
  if (tod < move) return { event: e, phase: "NEWS", nextPhase: "UNDERLYING_MOVED", simSecondsToNext: move - tod, replay, simSecondsInPhase: tod - news2 };
  if (tod < snap) return { event: e, phase: "UNDERLYING_MOVED", nextPhase: "SNAPPED", simSecondsToNext: snap - tod, replay, simSecondsInPhase: tod - move };
  const next = ev[i + 1];
  if (next) return { event: e, phase: "SNAPPED", nextPhase: "NEWS", simSecondsToNext: hmsToSec(next.news) - tod, replay, simSecondsInPhase: tod - snap };
  return { event: e, phase: "SNAPPED", nextPhase: isLastDay ? "ENDED" : "CLOSED", simSecondsToNext: close - tod, replay, simSecondsInPhase: tod - snap };
}
function realSecondsToNext(info, clockRate) {
  if (info.simSecondsToNext == null || !(clockRate > 0)) return null;
  return info.simSecondsToNext / clockRate;
}

// ../ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/core/config.ts
var DEFAULT_CONFIG = {
  mode: "auto",
  underlyings: ["OIL", "PLANE"],
  symbolRegex: DEFAULT_OPTION_REGEX,
  caseNameRegex: "euleria|newtonia|derivativ|option",
  fields: {
    quote: { symbol: ["symbol", "sym", "ticker"], bid: ["bid", "bid_price", "best_bid"], ask: ["ask", "ask_price", "best_ask"], bidSize: ["bid_size", "bidSize", "bid_qty"], askSize: ["ask_size", "askSize", "ask_qty"], last: ["last", "price", "last_price"] },
    positions: { list: ["positions", "data", "items", "results"], symbol: ["symbol", "sym", "ticker", "instrument"], qty: ["quantity", "net_quantity", "position", "qty", "net_position", "size"] },
    orders: { list: ["orders", "data", "items", "results"], symbol: ["symbol", "sym", "ticker"], side: ["side", "direction"], remaining: ["remaining_quantity", "remaining", "leaves_quantity", "open_quantity", "quantity", "qty"], status: ["status", "state"] },
    clock: { fictionalTime: ["fictional_time", "fictionalTime", "sim_time"], clockRate: ["clock_rate", "clockRate", "rate"], state: ["state", "status"], name: ["name", "case", "title"], id: ["competition_id", "id"] }
  },
  dom: {
    qtyLabel: "QTY",
    priceLabel: "PRICE",
    buyText: "BUY",
    sellText: "SELL",
    limitText: "Limit",
    marketText: "Market",
    strikeHeader: "STRIKE",
    callsHeader: "CALLS",
    putsHeader: "PUTS",
    latestLabel: "LATEST",
    positionsLabel: "Positions",
    spotPattern: "Spot\\s*\\$?\\s*([0-9]+(?:\\.[0-9]+)?)",
    tPattern: "T[^0-9]{0,8}([0-9]*\\.?[0-9]+)\\s*yr\\s*\\(\\s*([0-9]*\\.?[0-9]+)\\s*trading\\s*days?\\s*\\)",
    clockPattern: "^\\s*(\\d{1,2}):(\\d{2}):(\\d{2})\\s*$"
  },
  schedule: DEFAULT_SCHEDULE,
  session: DEFAULT_SESSION,
  T_mode: "dom",
  manualTDays: null,
  fallbackClockRate: { rounds12: 52, round3: 39 },
  thresholds: {
    minEdge: 0.05,
    ivOutlierPts: 1.5,
    arbEps: 0.02,
    positionLimit: 300,
    perTicketCap: 300,
    maxAbsDeltaPerUnderlying: 300,
    maxAbsVegaPts: 150,
    staleQuoteSec: 3,
    staleClockSec: 3,
    minVegaForIV: 0.02,
    flattenWarnFraction: 0.1,
    flattenWarnRealSec: 30,
    flattenThroughPct: 2,
    flattenThroughTicks: 5,
    learnDelayRealSec: 5
  },
  blend: { mode: "median", lambda: 25e-4, k: 1, bandMode: "auto" },
  rate: { limit: 40, amberAt: 30, redAt: 36 },
  headline: DEFAULT_HEADLINE_CONFIG,
  multiplier: 1,
  tick: null,
  priceMode: "touch",
  preferSynthForSpot: true,
  prefillEnabled: true,
  focus: null,
  auto: {
    confirm: true,
    converter: true,
    converterTolPts: 8,
    converterTieMarginPts: 2,
    submit: false,
    submitRateCap: 36,
    submitIntervalMs: 1500,
    resubmitAfterMs: 2e4,
    flattenResubmitMs: 6e3,
    flattenReserve: 12,
    flattenIntervalMs: 1500,
    spotBoundPct: 40,
    volMin: 0.05,
    volMax: 3,
    switchTabs: true
  }
};
var isObj = (x) => !!x && typeof x === "object" && !Array.isArray(x);
function cloneDefaults() {
  return JSON.parse(JSON.stringify(DEFAULT_CONFIG));
}
function pick(o, names) {
  if (!isObj(o)) return void 0;
  for (const n of names) if (o[n] !== void 0 && o[n] !== null) return o[n];
  return void 0;
}
function pickNum(o, names) {
  const v = pick(o, names);
  const n = typeof v === "string" ? Number(v) : v;
  return typeof n === "number" && Number.isFinite(n) ? n : null;
}

// ../ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/engine/analysts.ts
var ANALYSTS = [1, 2, 3];
var DEFAULT_BLEND = { mode: "median", lambda: 25e-4, k: 1, bandMode: "auto" };
function statsOf(errs) {
  if (!errs.length) return { n: 0, mse: null, rmse: null, bias: null, lastErr: null };
  const mse = errs.reduce((s, e) => s + e * e, 0) / errs.length;
  return { n: errs.length, mse, rmse: Math.sqrt(mse), bias: errs.reduce((s, e) => s + e, 0) / errs.length, lastErr: errs[errs.length - 1] };
}
function analystStats(history, underlying) {
  const out = {};
  for (const a of ANALYSTS) {
    const errs = history.filter((r) => underlying == null || r.underlying === underlying).sort((x, y) => x.event - y.event || x.t - y.t).map((r) => r.estimates[a] != null ? r.estimates[a] - r.trueVol : null).filter((e) => e != null && Number.isFinite(e));
    out[a] = statsOf(errs);
  }
  return out;
}
function effectiveMse(history, underlying, a) {
  const u = analystStats(history, underlying)[a];
  const p = analystStats(history)[a];
  if (u.mse == null && p.mse == null) return null;
  if (u.mse == null) return p.mse;
  if (p.mse == null) return u.mse;
  return (u.n * u.mse + p.mse) / (u.n + 1);
}
function analystWeights(history, underlying, present, lambda) {
  const raw = {};
  let sum = 0;
  for (const a of present) {
    const m = effectiveMse(history, underlying, a) ?? lambda;
    const w = 1 / (m + lambda);
    raw[a] = w;
    sum += w;
  }
  for (const a of present) raw[a] = raw[a] / sum;
  return raw;
}
function blendAnalysts(estimates, underlying, history, opts = DEFAULT_BLEND) {
  const present = ANALYSTS.filter((a) => estimates[a] != null && Number.isFinite(estimates[a]) && estimates[a] > 0);
  const vals = present.map((a) => estimates[a]);
  if (!present.length) return { vol: null, low: null, high: null, weights: {}, mode: opts.mode, note: "no analyst values" };
  const weights = analystWeights(history, underlying, present, opts.lambda);
  let vol;
  let mode = opts.mode;
  if (mode.startsWith("single:")) {
    const a = Number(mode.slice(7));
    if (estimates[a] != null) vol = estimates[a];
    else {
      mode = "median";
      vol = median2(vals);
    }
  } else if (mode === "weighted") {
    vol = present.reduce((s, a) => s + weights[a] * estimates[a], 0);
  } else {
    vol = median2(vals);
  }
  const hasHistory = history.some((r) => r.underlying === underlying) || history.length > 0;
  const bandMode = opts.bandMode === "auto" ? hasHistory && mode !== "median" ? "dispersion" : "minmax" : opts.bandMode;
  let low;
  let high;
  let note;
  if (bandMode === "minmax") {
    const disp = hasHistory ? Math.sqrt(present.reduce((s, a) => s + weights[a] * (effectiveMse(history, underlying, a) ?? 0), 0)) : 0;
    low = Math.min(...vals, vol - opts.k * disp);
    high = Math.max(...vals, vol + opts.k * disp);
    note = `band = analyst min/max${disp ? ` widened by ${opts.k}\xD7${(disp * 100).toFixed(1)}pts` : ""}`;
  } else {
    let disp;
    if (mode.startsWith("single:")) {
      const a = Number(mode.slice(7));
      disp = Math.sqrt(effectiveMse(history, underlying, a) ?? opts.lambda);
    } else {
      disp = Math.sqrt(present.reduce((s, a) => s + weights[a] * (effectiveMse(history, underlying, a) ?? opts.lambda), 0));
    }
    low = vol - opts.k * disp;
    high = vol + opts.k * disp;
    note = `band = blend \xB1 ${opts.k}\xD7${(disp * 100).toFixed(1)}pts`;
  }
  return { vol, low: Math.max(low, 1e-4), high, weights, mode, note };
}

// ../ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/engine/arbitrage.ts
var DEFAULT_ARB_OPTS = { eps: 0.02, ivOutlierPts: 1.5, minVega: 0.02, cap: 300 };
var has = (x) => x != null && Number.isFinite(x) && x > 0;
var touch = (c, side, cap) => {
  const s = side === "BUY" ? c.askSize : c.bidSize;
  return s != null && s > 0 ? Math.min(s, cap) : cap;
};
var leg = (c, side, ratio = 1) => ({ symbol: c.symbol, side, price: side === "BUY" ? c.ask : c.bid, ratio });
var sizeOf = (legs, cs, cap) => Math.max(0, Math.floor(Math.min(cap, ...legs.map((l, i) => touch(cs[i], l.side, cap) / l.ratio))));
function flag(kind, ch, description, legs, cs, edge, cap, spotDependent, riskless) {
  const maxSize = sizeOf(legs, cs, cap);
  return { kind, underlying: ch.underlying, description, legs, edgePerUnit: edge, maxSize, expectedPnL: edge * maxSize, spotDependent, riskless };
}
function gcd(a, b) {
  a = Math.abs(Math.round(a));
  b = Math.abs(Math.round(b));
  while (b) [a, b] = [b, a % b];
  return a || 1;
}
function findArbs(ch, spot, T, opts = DEFAULT_ARB_OPTS) {
  const out = [];
  const { eps, cap } = opts;
  const rows = ch.rows;
  if (spot != null && spot > 0) {
    for (const r of rows) {
      const c = r.call;
      const p = r.put;
      if (!c || !p) continue;
      const fwd = spot - r.strike;
      if (has(c.ask) && has(p.bid) && c.ask - p.bid < fwd - eps) {
        const legs = [leg(c, "BUY"), leg(p, "SELL")];
        out.push(flag("parity", ch, `Buy synthetic K=${r.strike}: costs ${(c.ask - p.bid).toFixed(2)} vs S\u2212K ${fwd.toFixed(2)}`, legs, [c, p], fwd - (c.ask - p.bid), cap, true, false));
      }
      if (has(c.bid) && has(p.ask) && c.bid - p.ask > fwd + eps) {
        const legs = [leg(c, "SELL"), leg(p, "BUY")];
        out.push(flag("parity", ch, `Sell synthetic K=${r.strike}: receives ${(c.bid - p.ask).toFixed(2)} vs S\u2212K ${fwd.toFixed(2)}`, legs, [c, p], c.bid - p.ask - fwd, cap, true, false));
      }
    }
  }
  for (let i = 0; i < rows.length; i++) {
    for (let j = i + 1; j < rows.length; j++) {
      const r1 = rows[i];
      const r2 = rows[j];
      const width = r2.strike - r1.strike;
      const c1 = r1.call, c2 = r2.call, p1 = r1.put, p2 = r2.put;
      if (c1 && c2 && p1 && p2) {
        if (has(c1.ask) && has(p1.bid) && has(c2.bid) && has(p2.ask)) {
          const cost = c1.ask - p1.bid - c2.bid + p2.ask;
          if (width - cost > eps) {
            const legs = [leg(c1, "BUY"), leg(p1, "SELL"), leg(c2, "SELL"), leg(p2, "BUY")];
            out.push(flag("box", ch, `Buy box ${r1.strike}/${r2.strike}: cost ${cost.toFixed(2)} < width ${width}`, legs, [c1, p1, c2, p2], width - cost, cap, false, true));
          }
        }
        if (has(c1.bid) && has(p1.ask) && has(c2.ask) && has(p2.bid)) {
          const recv = c1.bid - p1.ask - c2.ask + p2.bid;
          if (recv - width > eps) {
            const legs = [leg(c1, "SELL"), leg(p1, "BUY"), leg(c2, "BUY"), leg(p2, "SELL")];
            out.push(flag("box", ch, `Sell box ${r1.strike}/${r2.strike}: receive ${recv.toFixed(2)} > width ${width}`, legs, [c1, p1, c2, p2], recv - width, cap, false, true));
          }
        }
      }
      if (c1 && c2 && has(c1.ask) && has(c2.bid) && c2.bid - c1.ask > eps) {
        out.push(flag("monotonicity", ch, `Call ${r1.strike} ask ${c1.ask} < call ${r2.strike} bid ${c2.bid}`, [leg(c1, "BUY"), leg(c2, "SELL")], [c1, c2], c2.bid - c1.ask, cap, false, true));
      }
      if (p1 && p2 && has(p2.ask) && has(p1.bid) && p1.bid - p2.ask > eps) {
        out.push(flag("monotonicity", ch, `Put ${r2.strike} ask ${p2.ask} < put ${r1.strike} bid ${p1.bid}`, [leg(p2, "BUY"), leg(p1, "SELL")], [p2, p1], p1.bid - p2.ask, cap, false, true));
      }
      if (c1 && c2 && has(c1.bid) && has(c2.ask) && c1.bid - c2.ask - width > eps) {
        out.push(flag("vertical", ch, `Call spread ${r1.strike}/${r2.strike} bid ${(c1.bid - c2.ask).toFixed(2)} > width ${width}`, [leg(c1, "SELL"), leg(c2, "BUY")], [c1, c2], c1.bid - c2.ask - width, cap, false, true));
      }
      if (p1 && p2 && has(p2.bid) && has(p1.ask) && p2.bid - p1.ask - width > eps) {
        out.push(flag("vertical", ch, `Put spread ${r1.strike}/${r2.strike} bid ${(p2.bid - p1.ask).toFixed(2)} > width ${width}`, [leg(p2, "SELL"), leg(p1, "BUY")], [p2, p1], p2.bid - p1.ask - width, cap, false, true));
      }
    }
  }
  for (let i = 0; i + 2 < rows.length; i++) {
    for (let j = i + 1; j + 1 < rows.length; j++) {
      for (let k = j + 1; k < rows.length; k++) {
        const [a, b, c] = [rows[i], rows[j], rows[k]];
        let w1 = c.strike - b.strike;
        let w3 = b.strike - a.strike;
        let w2 = c.strike - a.strike;
        const s = 100;
        w1 = Math.round(w1 * s);
        w2 = Math.round(w2 * s);
        w3 = Math.round(w3 * s);
        const g = gcd(gcd(w1, w2), w3);
        w1 /= g;
        w2 /= g;
        w3 /= g;
        for (const kind of ["C", "P"]) {
          const x1 = kind === "C" ? a.call : a.put;
          const x2 = kind === "C" ? b.call : b.put;
          const x3 = kind === "C" ? c.call : c.put;
          if (!x1 || !x2 || !x3 || !has(x1.ask) || !has(x2.bid) || !has(x3.ask)) continue;
          const cost = w1 * x1.ask - w2 * x2.bid + w3 * x3.ask;
          if (cost < -eps) {
            const legs = [leg(x1, "BUY", w1), leg(x2, "SELL", w2), leg(x3, "BUY", w3)];
            const name = kind === "C" ? "Call" : "Put";
            out.push(flag("convexity", ch, `${name} butterfly ${a.strike}/${b.strike}/${c.strike} (${w1}:-${w2}:${w3}) for a credit of ${(-cost).toFixed(2)}`, legs, [x1, x2, x3], -cost, cap, false, true));
          }
        }
      }
    }
  }
  if (spot != null && spot > 0 && T > 0) {
    const ivs = ch.contracts.map((c) => ({ c, iv: contractIV(c, spot, T) }));
    const med = median2(ivs.filter((x) => x.iv.mid != null && x.iv.vegaAtMid >= opts.minVega).map((x) => x.iv.mid));
    if (med != null) {
      for (const { c, iv } of ivs) {
        if (iv.mid == null || iv.vegaAtMid < opts.minVega) continue;
        const dev = (iv.mid - med) * 100;
        if (Math.abs(dev) <= opts.ivOutlierPts) continue;
        const fairAtMed = price(c.kind, spot, c.strike, med, T);
        if (dev > 0 && iv.bid != null && iv.bid > med && has(c.bid)) {
          out.push(flag("ivOutlier", ch, `${c.symbol} rich: mid IV ${(iv.mid * 100).toFixed(1)}% vs median ${(med * 100).toFixed(1)}% \u2192 sell`, [leg(c, "SELL")], [c], c.bid - fairAtMed, cap, true, false));
        } else if (dev < 0 && iv.ask != null && iv.ask < med && has(c.ask)) {
          out.push(flag("ivOutlier", ch, `${c.symbol} cheap: mid IV ${(iv.mid * 100).toFixed(1)}% vs median ${(med * 100).toFixed(1)}% \u2192 buy`, [leg(c, "BUY")], [c], fairAtMed - c.ask, cap, true, false));
        }
      }
    }
  }
  return out.sort((x, y) => Number(y.riskless) - Number(x.riskless) || y.expectedPnL - x.expectedPnL);
}

// ../ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/engine/fairValue.ts
var DEFAULT_EDGE_OPTS = { positionLimit: 300, perTicketCap: 300, minEdge: 0.05, multiplier: 1, tick: 0.01 };
function roomFor(side, position, resting, limit) {
  const rb = resting?.buy ?? 0;
  const rs = resting?.sell ?? 0;
  const r = side === "BUY" ? limit - (position + rb) : limit + (position - rs);
  return Math.max(0, Math.floor(r));
}
function sizeAtTouch(c, side, fallback) {
  const s = side === "BUY" ? c.askSize : c.bidSize;
  return s != null && s > 0 ? s : fallback;
}
function computeEdges(chain, target, baseline, T, positions, resting, opts = DEFAULT_EDGE_OPTS) {
  const rows = [];
  for (const c of chain.contracts) {
    const K = c.strike;
    const fair = price(c.kind, target.spot, K, target.vol, T);
    const fLo = price(c.kind, target.spot, K, target.volLow, T);
    const fHi = price(c.kind, target.spot, K, target.volHigh, T);
    const fairs = [fLo, fair, fHi];
    const buyEdge = c.ask != null && c.ask > 0 ? fair - c.ask : null;
    const sellEdge = c.bid != null && c.bid > 0 ? c.bid - fair : null;
    const robustBuy = c.ask != null && c.ask > 0 ? Math.min(...fairs) - c.ask : null;
    const robustSell = c.bid != null && c.bid > 0 ? c.bid - Math.max(...fairs) : null;
    let side = null;
    let edge = 0;
    if (buyEdge != null && (sellEdge == null || buyEdge >= sellEdge)) {
      side = "BUY";
      edge = buyEdge;
    } else if (sellEdge != null) {
      side = "SELL";
      edge = sellEdge;
    }
    let robustSide = null;
    let robustEdge = -Infinity;
    if (robustBuy != null && robustBuy > robustEdge) {
      robustSide = "BUY";
      robustEdge = robustBuy;
    }
    if (robustSell != null && robustSell > robustEdge) {
      robustSide = "SELL";
      robustEdge = robustSell;
    }
    if (!Number.isFinite(robustEdge)) robustEdge = 0;
    const tradeSide = robustSide ?? side;
    const pos = positions[c.symbol] ?? 0;
    const room = tradeSide ? roomFor(tradeSide, pos, resting[c.symbol], opts.positionLimit) : 0;
    const touch2 = tradeSide ? sizeAtTouch(c, tradeSide, opts.perTicketCap) : 0;
    const qty = Math.max(0, Math.min(touch2, room, opts.perTicketCap));
    let spotComponent = null;
    let volComponent = null;
    if (baseline && baseline.oldSpot > 0 && baseline.oldVol > 0) {
      const base = price(c.kind, baseline.oldSpot, K, baseline.oldVol, T);
      const atNewSpot = price(c.kind, target.spot, K, baseline.oldVol, T);
      spotComponent = atNewSpot - base;
      volComponent = fair - atNewSpot;
    }
    rows.push({
      contract: c,
      fair,
      fairLow: Math.min(...fairs),
      fairHigh: Math.max(...fairs),
      buyEdge,
      sellEdge,
      side,
      edge,
      robustSide,
      robustEdge,
      qty,
      room,
      expectedPnL: edge * qty * opts.multiplier,
      robustPnL: Math.max(robustEdge, 0) * qty * opts.multiplier,
      spotComponent,
      volComponent,
      greeks: greeks(c.kind, target.spot, K, target.vol, T),
      edgeTicks: opts.tick > 0 ? edge / opts.tick : 0,
      passes: robustEdge >= opts.minEdge && qty > 0
    });
  }
  return rows;
}

// ../ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/engine/risk.ts
var DEFAULT_CAPS = { maxAbsDeltaPerUnderlying: 300, maxAbsVegaPts: 150 };
var emptyBook = () => ({ delta: 0, gamma: 0, vega: 0, theta: 0, dollarDeltaUp: 0, dollarDeltaDown: 0, vega5: 0, value: 0 });
function contractsBySymbol(chains) {
  const out = {};
  for (const ch of Object.values(chains)) for (const c of ch.contracts) out[c.symbol] = c;
  return out;
}
function portfolio(chains, positions, inputs, T, multiplier = 1) {
  const bySym = contractsBySymbol(chains);
  const rows = [];
  const perUnderlying = {};
  const total = emptyBook();
  for (const [sym, qty] of Object.entries(positions)) {
    const c = bySym[sym];
    if (!c || !qty) continue;
    const inp = inputs[c.underlying];
    if (!inp || !(inp.spot > 0) || !(inp.vol > 0)) continue;
    const g = greeks(c.kind, inp.spot, c.strike, inp.vol, T);
    const row = {
      symbol: sym,
      underlying: c.underlying,
      qty,
      fair: g.price,
      mark: mid(c),
      delta: g.delta * qty * multiplier,
      gamma: g.gamma * qty * multiplier,
      vega: g.vegaPerPoint * qty * multiplier,
      theta: g.thetaPerDay * qty * multiplier
    };
    rows.push(row);
    const b = perUnderlying[c.underlying] ??= emptyBook();
    for (const bk of [b, total]) {
      bk.delta += row.delta;
      bk.gamma += row.gamma;
      bk.vega += row.vega;
      bk.theta += row.theta;
      bk.dollarDeltaUp += row.delta + 0.5 * row.gamma;
      bk.dollarDeltaDown += -row.delta + 0.5 * row.gamma;
      bk.vega5 += row.vega * 5;
      bk.value += g.price * qty * multiplier;
    }
  }
  return { rows, perUnderlying, total };
}
function capBreaches(p, caps) {
  const out = [];
  for (const [u, b] of Object.entries(p.perUnderlying)) {
    if (Math.abs(b.delta) > caps.maxAbsDeltaPerUnderlying) out.push({ underlying: u, what: "delta", value: b.delta, cap: caps.maxAbsDeltaPerUnderlying });
    if (Math.abs(b.vega) > caps.maxAbsVegaPts) out.push({ underlying: u, what: "vega", value: b.vega, cap: caps.maxAbsVegaPts });
  }
  return out;
}
function needsFlatten(p, caps, fraction = 0.1) {
  return Object.values(p.perUnderlying).some(
    (b) => Math.abs(b.delta) > fraction * caps.maxAbsDeltaPerUnderlying || Math.abs(b.vega) > fraction * caps.maxAbsVegaPts
  );
}
function flattenOrders(chains, positions, inputs, T, caps = DEFAULT_CAPS, perTicketCap = 300, through = { pct: 0, ticks: 0, tick: 0.01 }, resting = {}) {
  const p = portfolio(chains, positions, inputs, T);
  const bySym = contractsBySymbol(chains);
  const orders = [];
  const pairOf = {};
  for (const ch of Object.values(chains)) {
    for (const r of ch.rows) {
      if (!r.call || !r.put) continue;
      const qc = positions[r.call.symbol] ?? 0;
      const qp = positions[r.put.symbol] ?? 0;
      if (qc && qp && Math.sign(qc) === -Math.sign(qp)) {
        const gid = `flat-syn-${r.call.symbol}`;
        pairOf[r.call.symbol] = gid;
        pairOf[r.put.symbol] = gid;
      }
    }
  }
  for (const row of p.rows) {
    const c = bySym[row.symbol];
    const side = row.qty > 0 ? "SELL" : "BUY";
    const touch2 = side === "SELL" ? c.bid : c.ask;
    const ref = mid(c) ?? row.fair;
    const dist = Math.max(through.pct / 100 * (ref ?? 0), through.ticks * through.tick);
    const px = touch2 == null ? null : side === "SELL" ? Math.max(through.tick, touch2 - dist) : touch2 + dist;
    const working = side === "SELL" ? resting[row.symbol]?.sell ?? 0 : resting[row.symbol]?.buy ?? 0;
    let remaining = Math.max(0, Math.abs(row.qty) - working);
    if (remaining === 0) continue;
    const b = p.perUnderlying[row.underlying];
    const dRed = b && Math.sign(b.delta) === Math.sign(row.delta) ? Math.abs(row.delta) / caps.maxAbsDeltaPerUnderlying : -Math.abs(row.delta) / caps.maxAbsDeltaPerUnderlying;
    const vRed = b && Math.sign(b.vega) === Math.sign(row.vega) ? Math.abs(row.vega) / caps.maxAbsVegaPts : -Math.abs(row.vega) / caps.maxAbsVegaPts;
    while (remaining > 0) {
      const q = Math.min(remaining, perTicketCap);
      remaining -= q;
      orders.push({
        symbol: row.symbol,
        underlying: row.underlying,
        side,
        qty: q,
        price: px,
        spreadCost: touch2 != null ? Math.abs(ref - touch2) * q : 0,
        riskScore: (dRed + vRed) * (q / Math.abs(row.qty)),
        groupId: pairOf[row.symbol],
        reason: `close ${row.qty > 0 ? "long" : "short"} ${Math.abs(row.qty)} (\u0394 ${row.delta.toFixed(1)}, vega ${row.vega.toFixed(1)})`
      });
    }
  }
  orders.sort((a, b) => b.riskScore - a.riskScore);
  const out = [];
  const used = /* @__PURE__ */ new Set();
  for (const o of orders) {
    if (used.has(o)) continue;
    out.push(o);
    used.add(o);
    if (o.groupId) {
      for (const m of orders) if (!used.has(m) && m.groupId === o.groupId) {
        out.push(m);
        used.add(m);
      }
    }
  }
  return { orders: out, totalSpreadCost: out.reduce((s, o) => s + o.spreadCost, 0) };
}

// ../ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/engine/rateLimit.ts
var RateMeter = class {
  constructor(windowMs = 6e4, limit = 40, amberAt = 30, redAt = 36) {
    this.windowMs = windowMs;
    this.limit = limit;
    this.amberAt = amberAt;
    this.redAt = redAt;
  }
  times = [];
  add(t = Date.now(), n = 1) {
    for (let i = 0; i < n; i++) this.times.push(t);
    if (this.times.length > 5e3) this.times.splice(0, this.times.length - 5e3);
  }
  count(now = Date.now()) {
    const cut = now - this.windowMs;
    while (this.times.length && this.times[0] <= cut) this.times.shift();
    return this.times.length;
  }
  status(now = Date.now()) {
    const used = this.count(now);
    return {
      used,
      limit: this.limit,
      remaining: Math.max(0, this.limit - used),
      level: used >= this.redAt ? "red" : used >= this.amberAt ? "amber" : "ok"
    };
  }
  /** ms until the oldest action ages out (0 when there is spare capacity) */
  msUntilFree(now = Date.now()) {
    if (this.count(now) < this.limit) return 0;
    return Math.max(0, this.times[0] + this.windowMs - now);
  }
};
function isOrderAction(method, url) {
  const m = (method || "GET").toUpperCase();
  if (m === "GET" || m === "HEAD" || m === "OPTIONS") return false;
  return /\/api\/v\d+\/(orders|etf|create|redeem)/i.test(url) || /\/orders(\/|\?|$)/i.test(url);
}

// ../ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/engine/structures.ts
function legRoom(sym, side, positions, resting, limit) {
  return roomFor(side, positions[sym] ?? 0, resting[sym], limit);
}
function syntheticForwards(chain, targetSpot, T, vol, positions = {}, resting = {}, opts = { positionLimit: 300, perTicketCap: 300 }) {
  const out = [];
  for (const r of chain.rows) {
    const c = r.call;
    const p = r.put;
    if (!c || !p) continue;
    const K = r.strike;
    const fwd = targetSpot - K;
    const vC = vegaPerPoint(targetSpot, K, vol, T);
    const vP = vegaPerPoint(targetSpot, K, vol, T);
    const dC = delta("C", targetSpot, K, vol, T);
    const dP = delta("P", targetSpot, K, vol, T);
    if (c.ask != null && p.bid != null && c.ask > 0 && p.bid > 0) {
      const cost = c.ask - p.bid;
      const size = Math.min(
        sizeAtTouch(c, "BUY", opts.perTicketCap),
        sizeAtTouch(p, "SELL", opts.perTicketCap),
        legRoom(c.symbol, "BUY", positions, resting, opts.positionLimit),
        legRoom(p.symbol, "SELL", positions, resting, opts.positionLimit),
        opts.perTicketCap
      );
      const edge = fwd - cost;
      out.push({
        kind: "synthLong",
        underlying: chain.underlying,
        strike: K,
        legs: [{ symbol: c.symbol, side: "BUY", price: c.ask, ratio: 1 }, { symbol: p.symbol, side: "SELL", price: p.bid, ratio: 1 }],
        cost,
        fair: fwd,
        edge,
        size,
        expectedPnL: edge * size,
        vega: vC - vP,
        delta: dC - dP
      });
    }
    if (c.bid != null && p.ask != null && c.bid > 0 && p.ask > 0) {
      const cost = p.ask - c.bid;
      const size = Math.min(
        sizeAtTouch(c, "SELL", opts.perTicketCap),
        sizeAtTouch(p, "BUY", opts.perTicketCap),
        legRoom(c.symbol, "SELL", positions, resting, opts.positionLimit),
        legRoom(p.symbol, "BUY", positions, resting, opts.positionLimit),
        opts.perTicketCap
      );
      const edge = c.bid - p.ask - fwd;
      out.push({
        kind: "synthShort",
        underlying: chain.underlying,
        strike: K,
        legs: [{ symbol: c.symbol, side: "SELL", price: c.bid, ratio: 1 }, { symbol: p.symbol, side: "BUY", price: p.ask, ratio: 1 }],
        cost,
        fair: -fwd,
        edge,
        size,
        expectedPnL: edge * size,
        vega: vP - vC,
        delta: dP - dC
      });
    }
  }
  return out.sort((a, b) => b.edge - a.edge);
}
function straddles(chain, targetSpot, targetVol, T, positions = {}, resting = {}, opts = { positionLimit: 300, perTicketCap: 300 }) {
  const out = [];
  for (const r of chain.rows) {
    const c = r.call;
    const p = r.put;
    if (!c || !p) continue;
    const K = r.strike;
    const fair = price("C", targetSpot, K, targetVol, T) + price("P", targetSpot, K, targetVol, T);
    const vega = 2 * vegaPerPoint(targetSpot, K, targetVol, T);
    const delta2 = delta("C", targetSpot, K, targetVol, T) + delta("P", targetSpot, K, targetVol, T);
    if (c.ask != null && p.ask != null && c.ask > 0 && p.ask > 0) {
      const cost = c.ask + p.ask;
      const size = Math.min(
        sizeAtTouch(c, "BUY", opts.perTicketCap),
        sizeAtTouch(p, "BUY", opts.perTicketCap),
        legRoom(c.symbol, "BUY", positions, resting, opts.positionLimit),
        legRoom(p.symbol, "BUY", positions, resting, opts.positionLimit),
        opts.perTicketCap
      );
      out.push({
        kind: "straddleBuy",
        underlying: chain.underlying,
        strike: K,
        legs: [{ symbol: c.symbol, side: "BUY", price: c.ask, ratio: 1 }, { symbol: p.symbol, side: "BUY", price: p.ask, ratio: 1 }],
        cost,
        fair,
        edge: fair - cost,
        size,
        expectedPnL: (fair - cost) * size,
        vega,
        delta: delta2
      });
    }
    if (c.bid != null && p.bid != null && c.bid > 0 && p.bid > 0) {
      const credit = c.bid + p.bid;
      const size = Math.min(
        sizeAtTouch(c, "SELL", opts.perTicketCap),
        sizeAtTouch(p, "SELL", opts.perTicketCap),
        legRoom(c.symbol, "SELL", positions, resting, opts.positionLimit),
        legRoom(p.symbol, "SELL", positions, resting, opts.positionLimit),
        opts.perTicketCap
      );
      out.push({
        kind: "straddleSell",
        underlying: chain.underlying,
        strike: K,
        legs: [{ symbol: c.symbol, side: "SELL", price: c.bid, ratio: 1 }, { symbol: p.symbol, side: "SELL", price: p.bid, ratio: 1 }],
        cost: -credit,
        fair: -fair,
        edge: credit - fair,
        size,
        expectedPnL: (credit - fair) * size,
        vega: -vega,
        delta: -delta2
      });
    }
  }
  return out.sort((a, b) => b.edge - a.edge);
}

// ../ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/engine/tickets.ts
var seq = 0;
var nextId = (p) => `${p}-${++seq}`;
function legGreeks(inp, symbol, side, qty) {
  const c = inp.contracts[symbol];
  const t = c && inp.targets[c.underlying];
  if (!c || !t) return { d: 0, v: 0 };
  const sgn = side === "BUY" ? 1 : -1;
  return { d: sgn * qty * delta(c.kind, t.spot, c.strike, t.vol, inp.T), v: sgn * qty * vegaPerPoint(t.spot, c.strike, t.vol, inp.T) };
}
function priceFor(inp, c, side, fair) {
  const touch2 = side === "BUY" ? c.ask : c.bid;
  if (touch2 == null) return null;
  if (inp.priceMode === "passive" && fair != null) {
    if (side === "BUY") {
      const p2 = Math.min((c.bid ?? touch2 - inp.tick) + inp.tick, fair - inp.minEdge, touch2);
      return roundToTick(p2, inp.tick, "down");
    }
    const p = Math.max((c.ask ?? touch2 + inp.tick) - inp.tick, fair + inp.minEdge, touch2);
    return roundToTick(p, inp.tick, "up");
  }
  return roundToTick(touch2, inp.tick, side === "BUY" ? "up" : "down");
}
function planTickets(inp) {
  const pos = { ...inp.positions };
  const greeksNow = {};
  for (const [u, g] of Object.entries(inp.bookGreeks)) if (g) greeksNow[u] = { ...g };
  const room = (sym, side) => {
    const r = inp.resting[sym];
    const p = pos[sym] ?? 0;
    return Math.max(0, side === "BUY" ? inp.positionLimit - (p + (r?.buy ?? 0)) : inp.positionLimit + (p - (r?.sell ?? 0)));
  };
  const inFocus = (u) => !inp.focus || inp.focus === u;
  const mult = inp.multiplier ?? 1;
  const cands = [];
  const synths = (inp.structures ?? []).filter((s) => (s.kind === "synthLong" || s.kind === "synthShort") && s.edge >= inp.minEdge && s.size > 0 && inFocus(s.underlying));
  const useSynth = inp.preferSynthForSpot && (inp.round === 2 || inp.round === 3);
  for (const s of useSynth ? synths : []) {
    cands.push({
      pnl: s.edge * s.size * mult,
      size: s.size,
      underlying: s.underlying,
      source: "struct",
      reason: `${s.kind === "synthLong" ? "Buy" : "Sell"} synthetic K=${s.strike}: edge ${s.edge.toFixed(2)} (vega-neutral spot trade)`,
      legs: s.legs.map((l) => ({ symbol: l.symbol, side: l.side, ratio: l.ratio, fair: null, edge: s.edge / 2 }))
    });
  }
  for (const e of inp.edges) {
    const c = e.contract;
    if (!e.passes || !e.robustSide || !inFocus(c.underlying)) continue;
    if (useSynth && e.spotComponent != null && e.volComponent != null && Math.abs(e.spotComponent) > 2 * Math.abs(e.volComponent)) {
      const dirLong = e.robustSide === "BUY" === (c.kind === "C");
      if (synths.some((s) => s.underlying === c.underlying && s.kind === "synthLong" === dirLong)) continue;
    }
    cands.push({
      pnl: e.robustEdge * e.qty * mult,
      size: e.qty,
      underlying: c.underlying,
      source: "edge",
      reason: `${e.robustSide === "BUY" ? "Buy" : "Sell"} ${c.symbol}: fair ${e.fair.toFixed(2)}, robust edge ${e.robustEdge.toFixed(2)}`,
      legs: [{ symbol: c.symbol, side: e.robustSide, ratio: 1, fair: e.fair, edge: e.robustEdge }]
    });
  }
  cands.sort((a, b) => b.pnl - a.pnl);
  const ok = [];
  const red = [];
  for (const cand of cands) {
    let size = Math.min(cand.size, inp.perTicketCap, ...cand.legs.map((l) => Math.floor(room(l.symbol, l.side) / l.ratio)));
    if (!(size > 0)) continue;
    const gid = cand.legs.length > 1 ? nextId("grp") : void 0;
    const g = greeksNow[cand.underlying] ?? { delta: 0, vega: 0 };
    let dd = 0;
    let dv = 0;
    for (const l of cand.legs) {
      const lg = legGreeks(inp, l.symbol, l.side, size * l.ratio);
      dd += lg.d;
      dv += lg.v;
    }
    const breach = [];
    if (Math.abs(g.delta + dd) > inp.caps.maxAbsDeltaPerUnderlying && Math.abs(g.delta + dd) > Math.abs(g.delta)) breach.push(`delta \u2192 ${(g.delta + dd).toFixed(0)}`);
    if (Math.abs(g.vega + dv) > inp.caps.maxAbsVegaPts && Math.abs(g.vega + dv) > Math.abs(g.vega)) breach.push(`vega \u2192 ${(g.vega + dv).toFixed(0)}`);
    const tickets = [];
    for (const l of cand.legs) {
      const c = inp.contracts[l.symbol];
      if (!c) continue;
      const px = priceFor(inp, c, l.side, l.fair);
      if (px == null) continue;
      tickets.push({
        id: nextId("t"),
        symbol: l.symbol,
        underlying: cand.underlying,
        side: l.side,
        type: "limit",
        qty: size * l.ratio,
        price: px,
        reason: cand.reason,
        expectedPnL: cand.pnl * (size / cand.size) / cand.legs.length,
        edgePerUnit: l.edge,
        groupId: gid,
        source: cand.source,
        breach,
        withinRateBudget: true
      });
    }
    if (tickets.length !== cand.legs.length) continue;
    if (breach.length) {
      red.push(...tickets);
      continue;
    }
    for (const t of tickets) pos[t.symbol] = (pos[t.symbol] ?? 0) + (t.side === "BUY" ? t.qty : -t.qty);
    greeksNow[cand.underlying] = { delta: g.delta + dd, vega: g.vega + dv };
    ok.push(...tickets);
    size = 0;
  }
  const all = [...ok, ...red];
  all.forEach((t, i) => t.withinRateBudget = i < inp.rateRemaining);
  return all;
}
function ticketsFromArb(f, contracts, perTicketCap, tick2) {
  const units = Math.max(0, Math.min(f.maxSize, Math.floor(perTicketCap / Math.max(...f.legs.map((l) => l.ratio)))));
  const gid = nextId("arb");
  return f.legs.map((l) => ({
    id: nextId("t"),
    symbol: l.symbol,
    underlying: contracts[l.symbol]?.underlying ?? f.underlying,
    side: l.side,
    type: "limit",
    qty: units * l.ratio,
    price: roundToTick(l.price, tick2, l.side === "BUY" ? "up" : "down"),
    reason: `${f.kind}: ${f.description}`,
    expectedPnL: f.edgePerUnit * units / f.legs.length,
    edgePerUnit: f.edgePerUnit,
    groupId: f.legs.length > 1 ? gid : void 0,
    source: "arb",
    breach: [],
    withinRateBudget: true
  })).filter((t) => t.qty > 0);
}
function ticketsFromFlatten(orders, tick2, rateRemaining, focus) {
  return orders.filter((o) => o.price != null && (!focus || o.underlying === focus)).map((o, i) => ({
    id: nextId("t"),
    symbol: o.symbol,
    underlying: o.underlying,
    side: o.side,
    type: "limit",
    qty: o.qty,
    price: roundToTick(o.price, tick2, o.side === "BUY" ? "up" : "down"),
    reason: o.reason,
    expectedPnL: -o.spreadCost,
    edgePerUnit: 0,
    groupId: o.groupId,
    source: "flatten",
    breach: [],
    withinRateBudget: i < rateRemaining
  }));
}

// ../ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/core/classify.ts
var KNOWN_WS_TYPES = /* @__PURE__ */ new Set(["quote", "trade", "subscription_ack", "news", "orderbook", "book", "snapshot", "error", "heartbeat", "pong"]);
var BOOK_KEYS = /^(bids|asks|levels|book|depth)$/i;
var VOL_WORDS = /\b(analyst|implied[ _]?vol|volatility|vol|iv|sigma)\b/i;
function urlPath(url) {
  try {
    return new URL(url, "http://x").pathname;
  } catch {
    return String(url).split("?")[0];
  }
}
function hasKeyDeep(o, re, depth = 0) {
  if (!o || typeof o !== "object" || depth > 4) return false;
  for (const [k, v] of Object.entries(o)) {
    if (re.test(k)) return true;
    if (v && typeof v === "object" && hasKeyDeep(v, re, depth + 1)) return true;
  }
  return false;
}
function mentionsVol(raw) {
  return VOL_WORDS.test(raw);
}
var FrameClassifier = class {
  seqs = /* @__PURE__ */ new Set();
  seqOrder = [];
  knownTypes = new Set(KNOWN_WS_TYPES);
  classifyWs(dir, data, json) {
    try {
      if (data && typeof data === "object" && data.binary) {
        return { key: `ws-${dir}:binary`, dir, type: "binary", highlights: [] };
      }
      const raw = typeof data === "string" ? data : "";
      let j = json;
      if (j === void 0) {
        try {
          j = JSON.parse(raw);
        } catch {
          return { key: dir === "in" ? "ws:malformed" : "ws-out:malformed", dir, type: "malformed", highlights: ["malformed"] };
        }
      }
      if (dir === "out") {
        const action = j && typeof j === "object" ? String(j.action ?? j.type ?? "frame") : "frame";
        return { key: `ws-out:${action}`, dir, type: action, json: j, highlights: [] };
      }
      const o = j && typeof j === "object" ? j : {};
      const type = typeof o.type === "string" ? o.type : Array.isArray(j) ? "array" : "untyped";
      const highlights = [];
      if (!this.knownTypes.has(type)) highlights.push("new-type");
      if (type !== "quote" && type !== "trade" && hasKeyDeep(j, BOOK_KEYS)) highlights.push("orderbook-like");
      if (type !== "quote" && type !== "trade" && mentionsVol(raw)) highlights.push("vol/analyst");
      if (type === "news") {
        const msg = o.message && typeof o.message === "object" ? o.message : o;
        const sub = typeof msg.type === "string" ? msg.type : typeof msg.headline === "string" ? "headline" : "untyped";
        const seq2 = typeof msg.seq === "number" ? msg.seq : typeof o.seq === "number" ? o.seq : void 0;
        let dup = false;
        if (seq2 != null) {
          dup = this.seqs.has(seq2);
          if (!dup) {
            this.seqs.add(seq2);
            this.seqOrder.push(seq2);
            if (this.seqOrder.length > 5e3) this.seqs.delete(this.seqOrder.shift());
          }
        }
        return { key: `ws:news:${sub}`, dir, type, json: j, dup, seq: seq2, highlights };
      }
      return { key: `ws:${type}`, dir, type, json: j, highlights };
    } catch {
      return { key: "ws:malformed", dir, type: "malformed", highlights: ["malformed"] };
    }
  }
  classifyHttp(method, url, json, raw, isReq = false) {
    const key = `${isReq ? "req" : "http"}:${(method || "GET").toUpperCase()} ${urlPath(url)}`;
    const highlights = [];
    try {
      if (hasKeyDeep(json, BOOK_KEYS)) highlights.push("orderbook-like");
      if (raw && /news|headline|analyst/i.test(url + " " + raw.slice(0, 4e3)) && mentionsVol(raw.slice(0, 4e3))) highlights.push("vol/analyst");
    } catch {
    }
    return { key, dir: isReq ? "req" : "http", type: "http", json, highlights };
  }
};

// ../ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/core/capture.ts
var MAX_RAW = 2e4;
var Capture = class {
  constructor(capacity = 5e3) {
    this.capacity = capacity;
    this.buf = new Array(capacity);
  }
  buf;
  head = 0;
  size = 0;
  kinds = /* @__PURE__ */ new Map();
  version = 0;
  add(e) {
    const raw = e.raw.length > MAX_RAW ? e.raw.slice(0, MAX_RAW) + "\u2026[truncated]" : e.raw;
    const entry = { ...e, raw };
    this.buf[this.head] = entry;
    this.head = (this.head + 1) % this.capacity;
    this.size = Math.min(this.size + 1, this.capacity);
    let k = this.kinds.get(e.key);
    if (!k) {
      k = { key: e.key, count: 0, first: e.t, last: e.t, recent: [], example: raw, highlights: /* @__PURE__ */ new Set() };
      this.kinds.set(e.key, k);
    }
    k.count++;
    k.last = e.t;
    k.example = raw;
    k.recent.push(e.t);
    while (k.recent.length && k.recent[0] < e.t - 1e4) k.recent.shift();
    for (const h of e.highlights) k.highlights.add(h);
    this.version++;
  }
  entries() {
    const out = [];
    for (let i = 0; i < this.size; i++) {
      const e = this.buf[(this.head - this.size + i + this.capacity) % this.capacity];
      if (e) out.push(e);
    }
    return out;
  }
  get length() {
    return this.size;
  }
  ratePerSec(key, now = Date.now()) {
    const k = this.kinds.get(key);
    if (!k) return 0;
    return k.recent.filter((t) => t > now - 1e4).length / 10;
  }
  clear() {
    this.buf.fill(void 0);
    this.head = 0;
    this.size = 0;
    this.kinds.clear();
    this.version++;
  }
  toJSON(meta = {}) {
    return JSON.stringify(
      {
        meta: { ...meta, exportedAt: (/* @__PURE__ */ new Date()).toISOString(), count: this.size },
        kinds: [...this.kinds.values()].map((k) => ({ key: k.key, count: k.count, first: k.first, last: k.last, example: k.example, highlights: [...k.highlights] })),
        entries: this.entries()
      },
      null,
      1
    );
  }
  /** Trigger a local download via Blob + <a download>. Must be called from a user click. */
  download(caseName, doc = document) {
    const stamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
    const safe = (caseName || "unknown").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "unknown";
    const name = `ctc-capture-${safe}-${stamp}.json`;
    const blob = new Blob([this.toJSON({ case: caseName })], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = doc.createElement("a");
    a.href = url;
    a.download = name;
    a.style.display = "none";
    (doc.body || doc.documentElement).appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5e3);
    return name;
  }
};

// ../ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/state/store.ts
var emptyTarget = () => ({
  spot: { value: null, src: "\u2014", confirmed: false, suggestion: null },
  vol: { value: null, src: "\u2014", confirmed: false, suggestion: null },
  volLow: null,
  volHigh: null,
  bandNote: ""
});
function defaultUi() {
  return { tab: "Edge", pinned: false, collapsed: false, hidden: false, x: null, y: null, showCheat: false, focusField: null, focusUnd: "OIL", captureOpen: false };
}
var Store = class {
  constructor(cfg, nowFn = () => Date.now()) {
    this.nowFn = nowFn;
    this.cfg = cfg;
    this.symbolRe = compileSymbolRegex(cfg.symbolRegex);
    this.rate = new RateMeter(6e4, cfg.rate.limit, cfg.rate.amberAt, cfg.rate.redAt);
    this.s = {
      caseName: null,
      competitionId: null,
      clock: { fictionalSec: null, receivedAt: 0, rate: null, state: null },
      lastClockPollAt: 0,
      domClock: null,
      domSpot: null,
      domT: null,
      domChain: null,
      quotes: {},
      undQuotes: {},
      metas: {},
      symbolsSeen: [],
      positions: {},
      positionsSrc: null,
      positionsAt: 0,
      restPositionsAt: 0,
      manualPositions: null,
      resting: {},
      news: [],
      lastLatestText: null,
      targets: Object.fromEntries(cfg.underlyings.map((u) => [u, emptyTarget()])),
      baselines: {},
      preNews: {},
      analystInputs: {},
      converter: { id: "variance", K: null, formula: "sqrt(x)" },
      history: [],
      timeline: {},
      manualQueue: [],
      loaded: null,
      recentLoads: [],
      fills: [],
      seenTradeIds: [],
      ws: { open: false, url: null, lastMsgAt: 0, subscribeSeen: null },
      panelProbe: null,
      ui: defaultUi(),
      toast: null,
      phaseKey: null,
      learnAt: null,
      auto: { targets: {}, converter: { status: "idle", id: null, reason: "", event: null, ranked: [] }, paused: false, log: [], lastSubmitAt: 0 }
    };
    this.d = this.compute();
  }
  s;
  d;
  cfg;
  capture = new Capture(5e3);
  classifier = new FrameClassifier();
  rate;
  listeners = /* @__PURE__ */ new Set();
  recomputeTimer = null;
  lastAutoJudgeAt = 0;
  symbolRe;
  version = 0;
  /** persistence hook, set by the content script */
  persist = () => void 0;
  // ---------------- subscription ----------------
  subscribe(fn) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }
  emit() {
    this.version++;
    for (const f of this.listeners) {
      try {
        f();
      } catch {
      }
    }
  }
  /** Debounced recompute (100 ms) followed by emit. */
  changed(immediate = false) {
    if (immediate) {
      if (this.recomputeTimer) clearTimeout(this.recomputeTimer);
      this.recomputeTimer = null;
      this.d = this.compute();
      this.emit();
      return;
    }
    if (this.recomputeTimer) return;
    this.recomputeTimer = setTimeout(() => {
      this.recomputeTimer = null;
      try {
        this.d = this.compute();
      } catch (e) {
        console.warn("[deriv-overlay] compute failed", e);
      }
      this.emit();
    }, 100);
  }
  setConfig(cfg) {
    this.cfg = cfg;
    this.symbolRe = compileSymbolRegex(cfg.symbolRegex);
    this.rate.limit = cfg.rate.limit;
    this.rate.amberAt = cfg.rate.amberAt;
    this.rate.redAt = cfg.rate.redAt;
    for (const u of cfg.underlyings) this.s.targets[u] ??= emptyTarget();
    for (const sym of this.s.symbolsSeen) this.noteSymbol(sym);
    this.changed(true);
  }
  toast(text, level = "info") {
    this.s.toast = { text, level, t: this.nowFn() };
    this.changed();
  }
  // ---------------- ingestion ----------------
  noteSymbol(sym) {
    if (typeof sym !== "string" || !sym) return;
    if (!this.s.symbolsSeen.includes(sym)) this.s.symbolsSeen.push(sym);
    const m = parseOptionSymbol(sym, this.symbolRe);
    if (m && !this.s.metas[sym]) this.s.metas[sym] = m;
  }
  isUnderlying(sym) {
    return this.cfg.underlyings.includes(sym.toUpperCase());
  }
  handleBridge(kind, p) {
    const now = this.nowFn();
    try {
      if (kind === "ws-in") {
        const c = this.classifier.classifyWs("in", p.data, p.json);
        this.capture.add({ t: now, key: c.key, dir: "in", url: p.url, raw: typeof p.data === "string" ? p.data : JSON.stringify(p.data), highlights: c.highlights });
        this.s.ws.lastMsgAt = now;
        this.s.ws.open = true;
        if (!c.dup && c.json !== void 0) this.handleWsJson(c.json, now);
      } else if (kind === "ws-out") {
        const c = this.classifier.classifyWs("out", p.data, p.json);
        this.capture.add({ t: now, key: c.key, dir: "out", url: p.url, raw: typeof p.data === "string" ? p.data : JSON.stringify(p.data), highlights: c.highlights });
        const j = c.json;
        if (j && Array.isArray(j.symbols)) {
          this.s.ws.subscribeSeen = j;
          for (const s of j.symbols) this.noteSymbol(String(s));
        }
      } else if (kind === "ws-open") {
        this.s.ws.open = true;
        this.s.ws.url = p.url ?? null;
        this.capture.add({ t: now, key: "ws:open", dir: "meta", url: p.url, raw: p.url ?? "", highlights: [] });
      } else if (kind === "ws-close") {
        this.s.ws.open = false;
        this.capture.add({ t: now, key: "ws:close", dir: "meta", url: p.url, raw: p.url ?? "", highlights: [] });
      } else if (kind === "http") {
        const c = this.classifier.classifyHttp(p.method ?? "GET", p.url ?? "", p.json, p.body ?? "");
        this.capture.add({ t: now, key: c.key, dir: "http", url: p.url, raw: p.body ?? "", highlights: c.highlights });
        if ((p.method ?? "GET").toUpperCase() === "POST" && /\/orders(\?|$)/.test(p.url ?? "")) this.noteOrderResponse(p.status ?? 200, p.json, now);
        if ((p.status ?? 200) < 400 && p.json !== void 0) this.handleHttp(p.method ?? "GET", p.url ?? "", p.json, now);
      } else if (kind === "http-req") {
        const c = this.classifier.classifyHttp(p.method ?? "POST", p.url ?? "", p.json, p.body ?? "", true);
        this.capture.add({ t: now, key: c.key, dir: "req", url: p.url, raw: p.body ?? "", highlights: c.highlights });
        if (isOrderAction(p.method ?? "POST", p.url ?? "")) this.rate.add(now);
      } else if (kind === "hooks-ready") {
        this.capture.add({ t: now, key: "meta:hooks-ready", dir: "meta", raw: p.url ?? "", highlights: [] });
      }
    } catch (e) {
      console.warn("[deriv-overlay] ingest failed", e);
    }
    this.changed();
  }
  handleWsJson(j, now = this.nowFn()) {
    if (!j || typeof j !== "object") return;
    const o = j;
    const type = String(o.type ?? "");
    const F = this.cfg.fields.quote;
    if (type === "quote" || type === "book" || type === "orderbook") {
      const sym = String(pick(o, F.symbol) ?? "");
      if (!sym) return;
      this.noteSymbol(sym);
      let bid = pickNum(o, F.bid);
      let ask = pickNum(o, F.ask);
      let bidSize = pickNum(o, F.bidSize);
      let askSize = pickNum(o, F.askSize);
      if (type !== "quote") {
        const lvl = (x) => Array.isArray(x) && x.length ? x[0] : null;
        const b = lvl(o.bids);
        const a = lvl(o.asks);
        const px = (l) => Array.isArray(l) ? Number(l[0]) : l && typeof l === "object" ? pickNum(l, ["price", "px"]) : null;
        const sz = (l) => Array.isArray(l) ? Number(l[1]) : l && typeof l === "object" ? pickNum(l, ["size", "quantity", "qty"]) : null;
        bid ??= px(b);
        ask ??= px(a);
        bidSize ??= sz(b);
        askSize ??= sz(a);
      }
      if (this.isUnderlying(sym)) {
        const prev = this.s.undQuotes[sym.toUpperCase()];
        this.s.undQuotes[sym.toUpperCase()] = { bid, ask, last: pickNum(o, F.last) ?? prev?.last ?? null, t: now };
      } else {
        this.s.quotes[sym] = { symbol: sym, bid, ask, bidSize, askSize, t: now, src: type === "quote" ? "WS" : "BOOK" };
      }
    } else if (type === "trade") {
      const sym = String(o.symbol ?? "");
      const px = pickNum(o, ["price", "px"]);
      if (sym && px != null && this.isUnderlying(sym)) {
        const u = sym.toUpperCase();
        const prev = this.s.undQuotes[u];
        this.s.undQuotes[u] = { bid: prev?.bid ?? null, ask: prev?.ask ?? null, last: px, t: now };
      } else if (sym) this.noteSymbol(sym);
    } else if (type === "news") {
      const msg = o.message && typeof o.message === "object" ? o.message : o;
      const text = [msg.headline, msg.text, msg.title, msg.body, msg.message].find((x) => typeof x === "string");
      const seq2 = typeof msg.seq === "number" ? msg.seq : null;
      const kind = String(msg.type ?? "news");
      const structured = extractStructured(msg, this.cfg.underlyings);
      if (text || Object.keys(structured).length) {
        this.ingestNews(text ?? "", "WS", seq2, kind, msg, structured, now);
      }
    } else if (type === "subscription_ack") {
      if (Array.isArray(o.symbols)) for (const s of o.symbols) this.noteSymbol(String(s));
    }
  }
  handleHttp(method, url, j, now = this.nowFn()) {
    let path = url;
    let params = new URLSearchParams();
    try {
      const u = new URL(url, "http://x");
      path = u.pathname;
      params = u.searchParams;
    } catch {
    }
    if (method !== "GET") return;
    const C2 = this.cfg.fields.clock;
    if (/\/competitions\/current$/.test(path)) {
      const ft = pick(j, C2.fictionalTime);
      const sec = typeof ft === "string" ? parseNaiveSec(ft) : null;
      const rate = pickNum(j, C2.clockRate);
      const state = pick(j, C2.state);
      const name = pick(j, C2.name);
      const id = pick(j, C2.id);
      if (typeof name === "string") this.s.caseName = name;
      if (typeof id === "string" && id !== this.s.competitionId) {
        this.s.competitionId = id;
        this.onCompetition?.(id);
      }
      if (sec != null) this.s.clock = { fictionalSec: sec, receivedAt: now, rate, state: typeof state === "string" ? state : null };
      this.s.lastClockPollAt = now;
      return;
    }
    if (/\/symbols$/.test(path)) {
      const list = Array.isArray(j) ? j : pick(j, ["symbols", "data", "items", "instruments"]);
      if (Array.isArray(list)) {
        for (const e of list) {
          const m = metaFromSymbolEntry(e, this.symbolRe);
          const sym = typeof e === "string" ? e : String(e?.symbol ?? "");
          if (sym && !this.s.symbolsSeen.includes(sym)) this.s.symbolsSeen.push(sym);
          if (m) this.s.metas[m.symbol] = m;
        }
      }
      return;
    }
    if (/\/positions$/.test(path)) {
      const P = this.cfg.fields.positions;
      const out = {};
      const list = Array.isArray(j) ? j : pick(j, P.list);
      if (Array.isArray(list)) {
        for (const it of list) {
          const sym = pick(it, P.symbol);
          const q = pickNum(it, P.qty);
          if (typeof sym === "string" && q != null) out[sym] = q;
        }
      } else if (j && typeof j === "object") {
        for (const [k, v] of Object.entries(j)) {
          if (typeof v === "number") out[k] = v;
          else if (v && typeof v === "object") {
            const q = pickNum(v, P.qty);
            if (q != null) out[k] = q;
          }
        }
      }
      this.s.positions = out;
      this.s.positionsSrc = "REST";
      this.s.positionsAt = now;
      this.s.restPositionsAt = now;
      return;
    }
    if (/\/orders\/open$/.test(path) || /\/orders$/.test(path)) {
      const O = this.cfg.fields.orders;
      const list = Array.isArray(j) ? j : pick(j, O.list);
      if (!Array.isArray(list)) return;
      const symParam = params.get("symbol");
      const fresh = {};
      if (symParam) fresh[symParam] = { buy: 0, sell: 0 };
      for (const it of list) {
        const sym = pick(it, O.symbol);
        if (typeof sym !== "string") continue;
        const status = String(pick(it, O.status) ?? "open").toLowerCase();
        if (/fill|cancel|reject|done|closed/.test(status) && !/partial/.test(status)) continue;
        const side = String(pick(it, O.side) ?? "").toLowerCase();
        const rem = pickNum(it, O.remaining) ?? 0;
        const r = fresh[sym] ??= { buy: 0, sell: 0 };
        if (side.startsWith("b")) r.buy += rem;
        else if (side.startsWith("s")) r.sell += rem;
      }
      if (symParam) Object.assign(this.s.resting, fresh);
      else this.s.resting = fresh;
      return;
    }
    if (/\/trades$/.test(path)) {
      const list = Array.isArray(j) ? j : pick(j, ["trades", "data", "items"]);
      if (!Array.isArray(list)) return;
      for (const it of list) {
        const id = String(pick(it, ["trade_id", "id", "fill_id"]) ?? "");
        if (!id || this.s.seenTradeIds.includes(id)) continue;
        this.s.seenTradeIds.push(id);
        if (this.s.seenTradeIds.length > 2e3) this.s.seenTradeIds.shift();
        const symbol = String(pick(it, ["symbol"]) ?? "");
        const px = pickNum(it, ["price", "px", "fill_price"]);
        const qty = pickNum(it, ["quantity", "qty", "size"]) ?? 0;
        if (!symbol || px == null) continue;
        const q = this.s.quotes[symbol];
        const m = q ? mid(q) : null;
        this.s.fills.push({
          id,
          symbol,
          side: String(pick(it, ["side", "direction"]) ?? ""),
          qty,
          price: px,
          bid: q?.bid ?? null,
          ask: q?.ask ?? null,
          atMid: m != null ? Math.abs(px - m) < 51e-4 : null,
          event: this.d?.phase?.event?.n ?? null,
          t: now
        });
        if (this.s.fills.length > 500) this.s.fills.shift();
      }
    }
  }
  onCompetition;
  /** DOM fallbacks pushed by the content script. */
  handleDom(r) {
    const now = this.nowFn();
    if (r.clockSec != null) this.s.domClock = { sec: r.clockSec, t: now };
    if (r.spot != null) this.s.domSpot = { value: r.spot, t: now };
    if (r.T) this.s.domT = { ...r.T, t: now };
    if (r.chain?.length) {
      const strikes2 = [...new Set(r.chain.map((x) => x.strike))].sort((a, b) => a - b);
      this.s.domChain = { strikes: strikes2, t: now };
      const und = this.domChainUnderlying(strikes2);
      if (und) {
        for (const row of r.chain) {
          const meta = Object.values(this.s.metas).find((m) => m.underlying === und && m.kind === row.kind && Math.abs(m.strike - row.strike) < 1e-9);
          if (!meta) continue;
          const ws = this.s.quotes[meta.symbol];
          const wsFresh = ws && ws.src !== "DOM" && now - ws.t < this.cfg.thresholds.staleQuoteSec * 1e3;
          if (!wsFresh && (row.bid != null || row.ask != null)) {
            this.s.quotes[meta.symbol] = { symbol: meta.symbol, bid: row.bid, ask: row.ask, bidSize: row.bidSize, askSize: row.askSize, t: now, src: "DOM" };
          }
        }
      }
    }
    if (r.latest && r.latest !== this.s.lastLatestText) {
      this.s.lastLatestText = r.latest;
      this.ingestNews(r.latest, "DOM", null, "latest", null, {}, now);
    }
    if (r.positions && now - this.s.restPositionsAt > 1e4 && !this.s.manualPositions) {
      this.s.positions = r.positions;
      this.s.positionsSrc = "DOM";
      this.s.positionsAt = now;
    }
    this.changed();
  }
  /** Which underlying does the visible DOM chain show? Match strikes, then spot proximity. */
  domChainUnderlying(strikes2) {
    const chains = buildChains(Object.values(this.s.metas), {});
    const cands = Object.values(chains).filter((c) => strikes2.every((k) => c.strikes.some((x) => Math.abs(x - k) < 1e-9)));
    if (cands.length === 1) return cands[0].underlying;
    if (cands.length > 1 && this.s.domSpot) {
      const ds = this.s.domSpot.value;
      let best = null;
      let bestErr = Infinity;
      for (const c of cands) {
        const ref = this.d?.spot?.[c.underlying]?.value;
        if (ref != null && Math.abs(ref - ds) / ref < bestErr) {
          bestErr = Math.abs(ref - ds) / ref;
          best = c.underlying;
        }
      }
      return best;
    }
    return null;
  }
  // ---------------- news / targets ----------------
  newsEvent(msg) {
    const n = Number(msg?.event);
    if (Number.isInteger(n) && this.cfg.schedule.some((e) => e.n === n)) return n;
    const d = this.d;
    const ph = d?.phase;
    if (!ph) return null;
    if (ph.phase === "NEWS" || ph.phase === "UNDERLYING_MOVED") return ph.event?.n ?? null;
    if (ph.nextPhase === "NEWS" && d.realToNext != null && d.realToNext < 15) {
      const cur = ph.event;
      if (ph.phase === "CLOSED" || ph.phase === "WAITING") return cur?.n ?? null;
      const sorted = [...this.cfg.schedule].sort((a, b) => a.n - b.n);
      const idx = sorted.findIndex((e) => e.n === cur?.n);
      return sorted[idx + 1]?.n ?? null;
    }
    if (ph.phase === "SNAPPED") return ph.event?.n ?? null;
    return null;
  }
  ingestNews(text, src, seq2, kind, msg, structured, now = this.nowFn()) {
    const clean = text.replace(/\s+/g, " ").trim();
    if (clean && this.s.news.some((n) => n.text === clean && now - n.t < 10 * 6e4)) return;
    if (kind === "snapshot" && !clean) return;
    const event = this.newsEvent(msg);
    const parse = parseHeadline(clean, { aliases: this.cfg.headline.aliases });
    for (const [u, v] of Object.entries(structured)) parse.underlyings[u] = { ...v, ...parse.underlyings[u] };
    const aField = Number(msg?.analyst);
    if (!parse.analysts.length && [1, 2, 3].includes(aField)) {
      for (const [u, v] of Object.entries(parse.underlyings)) {
        const val = v.iv ?? null;
        if (val != null) parse.analysts.push({ analyst: aField, underlying: u, value: normalizeVol(val), rawValue: val, raw: String(val), hasPct: false, isVol: true });
      }
      parse.underlyings = {};
    }
    const item = { seq: seq2, text: clean, t: now, src, event, parse, kind };
    this.s.news.unshift(item);
    if (this.s.news.length > 200) this.s.news.pop();
    if (event == null) return;
    const tl = this.timelineFor(event);
    if (!tl.headline && clean && !parse.analysts.length) tl.headline = clean;
    if (!this.s.baselines[event]) this.snapshotBaseline(event);
    const round = this.cfg.schedule.find((e) => e.n === event)?.round ?? null;
    for (const [u, v] of Object.entries(parse.underlyings)) {
      if (!this.s.targets[u]) continue;
      if (v.spot != null) this.suggest(u, "spot", v.spot, `headline ("${v.spotRaw ?? v.spot}")`, event);
      else if (v.changePct != null) {
        const base = this.s.baselines[event]?.[u]?.oldSpot;
        if (base) this.suggest(u, "spot", base * (1 + v.changePct / 100), `headline ${v.changePct > 0 ? "+" : ""}${v.changePct}%`, event);
      }
      if (v.iv != null) {
        this.suggest(u, "vol", v.iv, `announced IV (read "${v.ivRaw ?? v.iv}")`, event);
        const t = this.s.targets[u];
        t.volLow = v.iv;
        t.volHigh = v.iv;
        t.bandNote = "announced: band is a point";
      }
    }
    for (const a of parse.analysts) {
      if (!this.s.targets[a.underlying]) continue;
      const raw = round === 3 ? a.rawValue : a.value;
      this.setAnalyst(event, a.underlying, a.analyst, raw, "parsed", false);
    }
    if (parse.analysts.length) {
      if (round === 3) this.tryAutoConverter(event, clean, parse);
      this.refreshBlend(event);
    }
    this.autoConfirm(event);
  }
  // ---------------- auto-pilot: targets ----------------
  /** Why a target cannot be auto-confirmed yet, or ok with a description of what will be accepted. */
  autoCheck(u, event) {
    const t = this.s.targets[u];
    if (!t) return { ok: false, reason: "unknown underlying" };
    const a = this.cfg.auto;
    const round = this.roundOf(event);
    const cand = (f) => f.suggestion ? f.suggestion : f.event === event && f.value != null && f.src !== "pre-news" ? { value: f.value, src: f.src } : null;
    const spot = cand(t.spot);
    const vol = cand(t.vol);
    if (!t.spot.suggestion && !t.vol.suggestion && t.spot.confirmed && t.vol.confirmed && t.spot.event === event && t.vol.event === event) {
      return { ok: false, reason: "confirmed", done: true };
    }
    if (!spot) return { ok: false, reason: "waiting for the spot in the news" };
    if (round === 1) {
      if (!vol || !vol.src.startsWith("announced")) return { ok: false, reason: "waiting for the announced IV" };
    } else {
      const row = this.s.analystInputs[event]?.[u];
      const have = ANALYSTS.filter((x) => row?.[x]?.sigma != null);
      if (round === 3 && a.converter && this.s.auto.converter.status === "idle") {
        return { ok: false, reason: `Round 3 quantity not identified yet (${this.s.auto.converter.reason || "waiting for an analyst message"})` };
      }
      if (have.length < ANALYSTS.length) {
        const missing = ANALYSTS.filter((x) => !have.includes(x)).map((x) => `A${x}`).join(", ");
        return { ok: false, reason: `waiting for analyst${have.length === 2 ? "" : "s"} ${missing} (${have.length}/3)` };
      }
      if (!vol) return { ok: false, reason: "no blended vol yet" };
    }
    const ref = this.d?.spot[u]?.value ?? this.s.baselines[event]?.[u]?.oldSpot ?? null;
    if (ref != null && ref > 0) {
      const dev = Math.abs(spot.value - ref) / ref * 100;
      if (dev > a.spotBoundPct) return { ok: false, reason: `spot ${spot.value.toFixed(2)} is ${dev.toFixed(0)}% from live ${ref.toFixed(2)} (bound ${a.spotBoundPct}%): confirm by hand` };
    }
    if (!(spot.value > 0)) return { ok: false, reason: `spot ${spot.value} is not positive: confirm by hand` };
    if (vol.value < a.volMin || vol.value > a.volMax) {
      return { ok: false, reason: `vol ${(vol.value * 100).toFixed(1)}% outside ${(a.volMin * 100).toFixed(0)}\u2013${(a.volMax * 100).toFixed(0)}%: confirm by hand` };
    }
    return { ok: true, reason: `spot ${spot.value.toFixed(2)} (${spot.src}) \xB7 vol ${(vol.value * 100).toFixed(1)}% (${vol.src})` };
  }
  /** Accept complete, sane targets for this event without Alt+A. Records why when it cannot. */
  autoConfirm(event) {
    if (!this.cfg.auto.confirm || event == null) return;
    const ph = this.d?.phase;
    if (!ph?.event || ph.event.n !== event || !(ph.phase === "NEWS" || ph.phase === "UNDERLYING_MOVED")) return;
    const now = this.nowFn();
    let accepted = false;
    for (const u of this.cfg.underlyings) {
      if (!this.s.targets[u]) continue;
      const chk = this.autoCheck(u, event);
      if (chk.done) continue;
      if (chk.ok) {
        this.confirmTargets(u);
        this.s.auto.targets[u] = { status: "confirmed", reason: chk.reason, event, t: now };
        accepted = true;
      } else {
        const prev = this.s.auto.targets[u];
        if (prev?.status === "confirmed" && prev.event === event && !this.s.targets[u].spot.suggestion && !this.s.targets[u].vol.suggestion) continue;
        this.s.auto.targets[u] = { status: "manual", reason: chk.reason, event, t: now };
      }
    }
    if (accepted) {
      this.recordTargets(event);
      this.changed(true);
    }
  }
  confirmTargets(u) {
    const t = this.s.targets[u];
    if (!t) return;
    for (const field of ["spot", "vol"]) {
      const f = t[field];
      if (f.suggestion) {
        f.value = f.suggestion.value;
        f.src = f.suggestion.src;
        f.suggestion = null;
      }
      if (f.value != null) f.confirmed = true;
    }
  }
  recordTargets(ev) {
    const tl = this.timelineFor(ev);
    tl.targets = Object.fromEntries(this.cfg.underlyings.map((u) => [u, { spot: this.s.targets[u]?.spot.value ?? null, vol: this.s.targets[u]?.vol.value ?? null, src: `${this.s.targets[u]?.spot.src} / ${this.s.targets[u]?.vol.src}` }]));
  }
  // ---------------- auto-pilot: Round 3 converter ----------------
  tryAutoConverter(event, text, parse) {
    const ac = this.s.auto.converter;
    if (!this.cfg.auto.converter || ac.status === "manual") return;
    const evidenceText = this.s.news.filter((n) => n.event === event && n.parse.analysts.length).map((n) => n.text).join(" ") || text;
    const named = mentionedConverters(evidenceText);
    if (ac.status === "chosen" && (!named.length || named.every((id) => id === ac.id))) return;
    const samples = parse.analysts.filter((a) => this.s.targets[a.underlying]).map((a) => ({ underlying: a.underlying, raw: a.rawValue, rawStr: a.raw }));
    for (const [u, row] of Object.entries(this.s.analystInputs[event] ?? {})) {
      for (const a of ANALYSTS) {
        const raw = row[a]?.raw;
        if (raw != null && !samples.some((x) => x.underlying === u && x.raw === raw)) samples.push({ underlying: u, raw });
      }
    }
    if (!samples.length) return;
    const spot = {};
    const strikes2 = {};
    for (const u of this.cfg.underlyings) {
      spot[u] = this.d?.spot[u]?.value ?? this.s.baselines[event]?.[u]?.oldSpot ?? null;
      strikes2[u] = this.d?.chains[u]?.strikes;
    }
    const res = identifyConverter({ samples, text: evidenceText, marketIV: this.d?.marketIV ?? {}, spot, T: this.d?.T.years ?? 20 / 252, strikes: strikes2, tolPts: this.cfg.auto.converterTolPts, tieMarginPts: this.cfg.auto.converterTieMarginPts });
    ac.ranked = res.ranked;
    ac.event = event;
    ac.reason = res.reason;
    if (res.id) {
      ac.status = "chosen";
      ac.id = res.id;
      this.setConverter({ id: res.id, K: null }, "auto");
      this.toast(`Round 3 quantity identified: ${CONVERTERS.find((c) => c.id === res.id)?.label ?? res.id} (${res.reason})`, "info");
    } else {
      ac.status = "idle";
      ac.id = null;
      for (const [u, target] of Object.entries(this.s.targets)) {
        if (target.vol.event === event && target.vol.src.startsWith("analysts")) {
          target.vol.confirmed = false;
          this.s.auto.targets[u] = { status: "manual", reason: res.reason, event, t: this.nowFn() };
        }
      }
      this.toast(`Round 3 converter not identified: ${res.reason}`, "warn");
      this.changed(true);
    }
  }
  /** Forget an automatic or manual pick so the next analyst message re-runs the identification. */
  resetAutoConverter() {
    this.s.auto.converter = { status: "idle", id: null, reason: "", event: null, ranked: [] };
    const ev = this.d.phase?.event?.n;
    if (ev != null && this.roundOf(ev) === 3) {
      const text = this.s.news.filter((n) => n.event === ev && n.parse.analysts.length).map((n) => n.text).join(" ");
      const parse = { underlyings: {}, analysts: this.s.news.filter((n) => n.event === ev).flatMap((n) => n.parse.analysts), mentions: [] };
      if (parse.analysts.length) this.tryAutoConverter(ev, text, parse);
    }
    this.changed(true);
  }
  // ---------------- auto-pilot: submissions ----------------
  setAutoPaused(paused) {
    this.s.auto.paused = paused;
    this.changed(true);
  }
  logAutoSubmit(t, result) {
    const now = this.nowFn();
    this.s.auto.log.push({ t: now, symbol: t.symbol, side: t.side, qty: t.qty, price: t.price, source: t.source, event: this.d.phase?.event?.n ?? null, result });
    if (this.s.auto.log.length > 300) this.s.auto.log.shift();
    this.s.auto.lastSubmitAt = now;
    this.capture.add({ t: now, key: "auto:submit", dir: "meta", raw: JSON.stringify({ symbol: t.symbol, side: t.side, qty: t.qty, price: t.price, result }), highlights: [] });
    this.changed(true);
  }
  /** The page's POST /orders response that follows an auto click: attach the exchange's answer to the log line. */
  noteOrderResponse(status, json, now) {
    const pending = [...this.s.auto.log].reverse().find((l) => l.result === "clicked" && now - l.t < 8e3);
    if (!pending) return;
    const j = json && typeof json === "object" ? json : {};
    const detail = [j.status, j.filled_quantity != null && j.quantity != null ? `${j.filled_quantity}/${j.quantity} filled` : null, j.detail].filter(Boolean).join(", ");
    pending.result = status < 400 ? `sent \xB7 HTTP ${status}${detail ? ` ${detail}` : ""}` : `REJECTED \xB7 HTTP ${status}${detail ? ` ${detail}` : ""}`;
    this.capture.add({ t: now, key: "auto:result", dir: "meta", raw: JSON.stringify({ symbol: pending.symbol, side: pending.side, qty: pending.qty, price: pending.price, result: pending.result }), highlights: status >= 400 ? ["rejected"] : [] });
  }
  suggest(u, field, value, src, event = this.d?.phase?.event?.n ?? null) {
    const t = this.s.targets[u];
    if (!t || !Number.isFinite(value)) return;
    const f = t[field];
    if (f.confirmed && f.event === event) f.suggestion = { value, src };
    else {
      t[field] = { value, src, confirmed: false, suggestion: null, event };
    }
  }
  /** Type a target. Typed values are confirmed immediately. */
  setTarget(u, field, value) {
    const t = this.s.targets[u];
    if (!t) return;
    if (value == null || !Number.isFinite(value)) {
      t[field] = { value: null, src: "\u2014", confirmed: false, suggestion: null };
    } else {
      const v = field === "vol" ? normalizeVol(value) : value;
      t[field] = { value: v, src: "typed", confirmed: true, suggestion: null, event: this.d?.phase?.event?.n ?? null };
      if (field === "vol") {
        const lo = t.volLow;
        const hi = t.volHigh;
        if (lo == null || hi == null || v < lo || v > hi) {
          t.volLow = v;
          t.volHigh = v;
          t.bandNote = "typed: band is a point";
        }
      }
    }
    this.changed(true);
  }
  acceptSuggestions() {
    for (const u of this.cfg.underlyings) {
      const t = this.s.targets[u];
      if (!t) continue;
      const d = this.d.effTargets[u];
      for (const field of ["spot", "vol"]) {
        const f = t[field];
        if (f.suggestion) {
          f.value = f.suggestion.value;
          f.src = f.suggestion.src;
          f.suggestion = null;
        }
        if (f.value == null && d) {
          f.value = field === "spot" ? d.spot : d.vol;
          f.src = field === "spot" ? `live (${this.d.spot[u]?.src})` : "market IV";
        }
        if (f.value != null) f.confirmed = true;
      }
    }
    const ev = this.d.phase?.event?.n;
    if (ev != null) {
      this.recordTargets(ev);
      for (const u of this.cfg.underlyings) this.s.auto.targets[u] = { status: "confirmed", reason: "accepted by hand (Alt+A)", event: ev, t: this.nowFn() };
    }
    this.changed(true);
  }
  setAnalyst(event, u, a, raw, src, recompute = true) {
    const ev = this.s.analystInputs[event] ??= {};
    const row = ev[u] ??= {};
    const cell = row[a];
    if (src === "parsed" && cell?.src === "typed") return;
    const round = this.cfg.schedule.find((e) => e.n === event)?.round ?? 2;
    const conv = this.convert(round, u, raw);
    row[a] = { raw, sigma: conv.sigma, src, note: conv.note };
    if (recompute) {
      this.refreshBlend(event);
      this.autoConfirm(event);
      this.changed(true);
    }
  }
  convert(round, u, raw) {
    if (raw == null || !Number.isFinite(raw)) return { sigma: null };
    if (round !== 3) return { sigma: normalizeVol(raw), note: raw > 3 ? `read ${raw} as ${raw}%` : `read ${raw} as ${(raw * 100).toFixed(1)}%` };
    const S = this.d?.effTargets[u]?.spot ?? this.d?.spot[u]?.value ?? null;
    const T = this.d?.T.years ?? 20 / 252;
    if (S == null) return { sigma: null, note: "no spot" };
    const r = convertToSigma(this.s.converter.id, raw, {
      S,
      T,
      K: this.s.converter.K ?? void 0,
      strikes: this.d?.chains[u]?.strikes,
      formula: this.s.converter.formula,
      prior: this.d?.marketIV[u] ?? 0.5
    });
    return { sigma: r.sigma, note: r.note };
  }
  setConverter(c, by = "manual") {
    Object.assign(this.s.converter, c);
    if (by === "manual") {
      const ac = this.s.auto.converter;
      ac.status = "manual";
      ac.id = this.s.converter.id;
      ac.reason = 'picked by hand; automatic identification is off until "re-run"';
    }
    for (const [evS, byU] of Object.entries(this.s.analystInputs)) {
      const ev = Number(evS);
      const round = this.cfg.schedule.find((e) => e.n === ev)?.round;
      if (round !== 3) continue;
      for (const [u, row] of Object.entries(byU)) {
        for (const a of ANALYSTS) {
          const cell = row[a];
          if (!cell) continue;
          const conv = this.convert(3, u, cell.raw);
          cell.sigma = conv.sigma;
          cell.note = conv.note;
        }
      }
      this.refreshBlend(ev);
    }
    const cur = this.d?.phase?.event?.n;
    if (cur != null && this.roundOf(cur) === 3) this.autoConfirm(cur);
    this.changed(true);
  }
  refreshBlend(event) {
    const ev = this.s.analystInputs[event];
    if (!ev) return;
    for (const [u, row] of Object.entries(ev)) {
      const est = {};
      for (const a of ANALYSTS) if (row[a]?.sigma != null) est[a] = row[a]?.sigma;
      const b = blendAnalysts(est, u, this.s.history, this.cfg.blend);
      const t = this.s.targets[u];
      if (!t || b.vol == null) continue;
      if (t.vol.src.startsWith("announced") && !t.vol.confirmed) continue;
      this.suggest(u, "vol", b.vol, `analysts ${b.mode}`, event);
      if (!(t.vol.confirmed && t.vol.src === "typed")) {
        t.volLow = b.low;
        t.volHigh = b.high;
        t.bandNote = b.note;
      }
    }
  }
  snapshotBaseline(event) {
    const b = {};
    for (const u of this.cfg.underlyings) {
      const pn = this.s.preNews[u];
      const spot = pn?.spot ?? this.d?.spot[u]?.value ?? null;
      const vol = pn?.vol ?? this.d?.marketIV[u] ?? null;
      if (spot != null && vol != null) b[u] = { oldSpot: spot, oldVol: vol };
    }
    this.s.baselines[event] = b;
    this.timelineFor(event).baseline = b;
  }
  timelineFor(n) {
    const round = this.cfg.schedule.find((e) => e.n === n)?.round ?? 0;
    return this.s.timeline[n] ??= { n, round };
  }
  // ---------------- clock / phases (called every ~200 ms) ----------------
  tick() {
    const now = this.nowFn();
    const d = this.compute();
    this.d = d;
    const ph = d.phase;
    if (ph && !(ph.phase === "NEWS" || ph.phase === "UNDERLYING_MOVED")) {
      for (const u of this.cfg.underlyings) {
        const sp = d.spot[u]?.value ?? null;
        const iv = d.marketIV[u] ?? null;
        if (sp != null || iv != null) this.s.preNews[u] = { spot: sp ?? this.s.preNews[u]?.spot ?? null, vol: iv ?? this.s.preNews[u]?.vol ?? null, t: now };
      }
    }
    const key = ph?.event ? `${ph.event.n}:${ph.phase}` : ph?.phase ?? null;
    if (key !== this.s.phaseKey) {
      const prev = this.s.phaseKey;
      this.s.phaseKey = key;
      if (prev !== null && ph?.event) this.onPhaseChange(ph, d);
      else if (prev === null && ph?.event && (ph.phase === "NEWS" || ph.phase === "UNDERLYING_MOVED") && !this.s.baselines[ph.event.n]) {
        this.snapshotBaseline(ph.event.n);
      }
    }
    if (ph?.event && (ph.phase === "NEWS" || ph.phase === "UNDERLYING_MOVED") && !d.targetsConfirmed && this.cfg.auto.confirm && now - this.lastAutoJudgeAt > 1e3) {
      this.lastAutoJudgeAt = now;
      this.autoConfirm(ph.event.n);
    }
    if (this.s.learnAt && now >= this.s.learnAt.at) {
      const ev = this.s.learnAt.event;
      this.s.learnAt = null;
      this.learn(ev);
    }
    this.s.recentLoads = this.s.recentLoads.filter((r) => now - r.t < 6e3);
    if (this.s.toast && now - this.s.toast.t > 6e3) this.s.toast = null;
    this.emit();
  }
  onPhaseChange(ph, d) {
    const ev = ph.event;
    if (ph.phase === "NEWS") {
      if (!this.s.baselines[ev.n]) this.snapshotBaseline(ev.n);
      for (const u of this.cfg.underlyings) {
        const t = this.s.targets[u];
        const b = this.s.baselines[ev.n]?.[u];
        if (!t) continue;
        if (t.spot.event !== ev.n) t.spot = { value: b?.oldSpot ?? null, src: "pre-news", confirmed: false, suggestion: null, event: null };
        if (t.vol.event !== ev.n) {
          t.vol = { value: b?.oldVol ?? null, src: "pre-news", confirmed: false, suggestion: null, event: null };
          t.volLow = b?.oldVol ?? null;
          t.volHigh = b?.oldVol ?? null;
          t.bandNote = "no news yet";
        }
      }
      this.s.manualQueue = [];
      this.timelineFor(ev.n);
      for (const u of this.cfg.underlyings) this.s.auto.targets[u] = { status: "idle", reason: "waiting for the news", event: ev.n, t: this.nowFn() };
      if (!this.s.ui.pinned) this.s.ui.tab = "Edge";
      this.autoConfirm(ev.n);
    } else if (ph.phase === "UNDERLYING_MOVED") {
      for (const u of this.cfg.underlyings) {
        const t = this.s.targets[u];
        const live = d.spot[u]?.value;
        if (!t || live == null) continue;
        if (t.spot.src === "pre-news" || t.spot.value == null) this.suggest(u, "spot", live, "live after move", ev.n);
        else if (t.spot.value && Math.abs(live - t.spot.value) / t.spot.value > 5e-3) {
          this.toast(`${u} moved to ${live.toFixed(2)} vs target ${t.spot.value.toFixed(2)}: check the target spot`, "warn");
          t.spot.suggestion = { value: live, src: "live after move" };
        }
      }
      this.autoConfirm(ev.n);
    } else if (ph.phase === "SNAPPED") {
      this.s.learnAt = { event: ev.n, at: this.nowFn() + this.cfg.thresholds.learnDelayRealSec * 1e3 };
      this.s.manualQueue = [];
      if (!this.s.ui.pinned) this.s.ui.tab = "Risk";
    }
  }
  /** Post-snap: record true vol per underlying, score analysts, estimate edge captured. */
  learn(event) {
    const d = this.compute();
    const tl = this.timelineFor(event);
    tl.trueVol = {};
    tl.trueSpot = {};
    tl.analystErrors = {};
    for (const u of this.cfg.underlyings) {
      const tv = d.marketIV[u] ?? null;
      tl.trueVol[u] = tv;
      tl.trueSpot[u] = d.spot[u]?.value ?? null;
      const row = this.s.analystInputs[event]?.[u];
      if (tv == null || !row) continue;
      const estimates = {};
      const errs = {};
      for (const a of ANALYSTS) {
        const sg = row[a]?.sigma;
        if (sg != null) {
          estimates[a] = sg;
          errs[a] = sg - tv;
        }
      }
      tl.analystErrors[u] = errs;
      if (Object.keys(estimates).length) {
        this.s.history = this.s.history.filter((r) => !(r.event === event && r.underlying === u));
        this.s.history.push({ event, underlying: u, estimates, trueVol: tv, t: this.nowFn() });
      }
    }
    const fills = this.s.fills.filter((f) => f.event === event);
    if (fills.length) {
      let cap = 0;
      for (const f of fills) {
        const c = d.contracts[f.symbol];
        const sp = c ? tl.trueSpot[c.underlying] : null;
        const vol = c ? tl.trueVol[c.underlying] : null;
        if (!c || sp == null || vol == null) continue;
        const fair = price(c.kind, sp, c.strike, vol, d.T.years);
        cap += (f.side.toLowerCase().startsWith("b") ? 1 : -1) * (fair - f.price) * f.qty * this.cfg.multiplier;
      }
      tl.captured = cap;
    }
    this.persistHistory();
    this.changed(true);
  }
  persistHistory() {
    if (this.s.competitionId) this.persist(`history:${this.s.competitionId}`, { history: this.s.history, timeline: this.s.timeline });
  }
  resetHistory() {
    this.s.history = [];
    this.s.timeline = {};
    this.persistHistory();
    this.changed(true);
  }
  // ---------------- tickets ----------------
  /** Next ticket from the manual (arb) queue, else the live plan; skips what was just loaded. */
  pickNext(kind, opts = {}) {
    const say = (text, level) => {
      if (!opts.quiet) this.toast(text, level);
    };
    if (kind === "edge" && !this.d.targetsConfirmed && !this.s.manualQueue.length) {
      say("Targets not confirmed: press Alt+A (or Accept) first", "warn");
      return null;
    }
    if (kind === "edge" && this.s.manualQueue.length) {
      if (!opts.exclude) return this.s.manualQueue.shift() ?? null;
      const i = this.s.manualQueue.findIndex((t2) => !opts.exclude?.(t2));
      if (i >= 0) return this.s.manualQueue.splice(i, 1)[0];
      return null;
    }
    let list = kind === "edge" ? this.d.plan.filter((t2) => !t2.breach.length) : this.d.flatten;
    if (opts.exclude) list = list.filter((t2) => !opts.exclude?.(t2));
    if (!list.length) {
      say(kind === "edge" ? "No tickets clear the robust edge threshold" : "Nothing to flatten", "info");
      return null;
    }
    const recent = new Set(this.s.recentLoads.map((r) => r.sig));
    const t = list.find((x) => !recent.has(`${x.symbol}:${x.side}`)) ?? (opts.exclude ? null : list[0]);
    if (t && !t.withinRateBudget) say("Order-rate budget is exhausted for this minute", "warn");
    return t;
  }
  markLoaded(t, ok, message) {
    this.s.loaded = { ticket: t, t: this.nowFn(), ok, message };
    this.s.recentLoads.push({ sig: `${t.symbol}:${t.side}`, t: this.nowFn() });
    this.changed(true);
  }
  queueArb(f) {
    const tick2 = this.d.tick;
    this.s.manualQueue = ticketsFromArb(f, this.d.contracts, this.cfg.thresholds.perTicketCap, tick2);
    this.toast(`${this.s.manualQueue.length} linked tickets queued: Alt+N loads them in order`, "info");
    this.changed(true);
  }
  setManualPositions(p) {
    this.s.manualPositions = p;
    if (p) {
      this.s.positions = { ...p };
      this.s.positionsSrc = "manual";
      this.s.positionsAt = this.nowFn();
    }
    this.changed(true);
  }
  // ---------------- derived ----------------
  compute() {
    const now = this.nowFn();
    const cfg = this.cfg;
    const s = this.s;
    const th = cfg.thresholds;
    let mode = "capture-only";
    let modeReason = "no derivatives signals yet";
    if (cfg.mode === "derivatives") {
      mode = "derivatives";
      modeReason = "forced in Config";
    } else if (cfg.mode === "auto") {
      let caseRe = null;
      try {
        caseRe = new RegExp(cfg.caseNameRegex, "i");
      } catch {
        caseRe = null;
      }
      if (s.caseName && caseRe?.test(s.caseName)) {
        mode = "derivatives";
        modeReason = `case "${s.caseName}"`;
      } else if (cfg.underlyings.every((u) => s.symbolsSeen.some((x) => x.toUpperCase() === u))) {
        mode = "derivatives";
        modeReason = `symbols include ${cfg.underlyings.join(" & ")}`;
      } else if (Object.keys(s.metas).length) {
        mode = "derivatives";
        modeReason = "option symbols seen";
      }
    }
    let simNow = null;
    let clockSrc = "none";
    const c = s.clock;
    const clockStale = !s.lastClockPollAt || now - s.lastClockPollAt > th.staleClockSec * 1e3;
    let clockRate = c.rate ?? 0;
    if (c.fictionalSec != null && !clockStale) {
      const running = !c.state || /run|open|active|live/i.test(c.state);
      simNow = c.fictionalSec + (running ? (now - c.receivedAt) * (c.rate ?? 0) / 1e3 : 0);
      clockSrc = "REST";
    } else if (s.domClock && now - s.domClock.t < 5e3) {
      const baseDate = c.fictionalSec != null ? dayStart(c.fictionalSec) : parseNaiveSec(`${cfg.schedule[0]?.date ?? "2026-06-01"}T00:00:00`) ?? 0;
      const ev2 = cfg.schedule.find((e) => e.date === fmtDate(baseDate));
      clockRate = c.rate ?? (ev2?.round === 3 ? cfg.fallbackClockRate.round3 : cfg.fallbackClockRate.rounds12);
      simNow = baseDate + s.domClock.sec + (now - s.domClock.t) * clockRate / 1e3;
      clockSrc = "DOM";
    } else if (c.fictionalSec != null) {
      simNow = c.fictionalSec;
      clockSrc = "REST";
    }
    const phase = simNow != null ? phaseAt(simNow, cfg.schedule, { open: cfg.session.open, close: cfg.session.close }) : null;
    const realToNext = phase ? realSecondsToNext(phase, clockRate) : null;
    const round = phase?.event?.round ?? null;
    let T;
    const computed = () => {
      if (simNow == null) return { days: 20, src: "computed (no clock: 20d)" };
      let t = simNow;
      if (phase?.replay) {
        const first2 = parseNaiveSec(`${cfg.schedule[0]?.date ?? "2026-06-01"}T00:00:00`) ?? 0;
        t = first2 + secOfDay(simNow);
      }
      return { days: tradingDaysRemaining(t, cfg.session), src: phase?.replay ? "computed (replay)" : "computed" };
    };
    if (cfg.T_mode === "manual" && cfg.manualTDays != null) T = { days: cfg.manualTDays, years: cfg.manualTDays / 252, src: "manual" };
    else if (cfg.T_mode === "fixed20") T = { days: 20, years: 20 / 252, src: "fixed 20d" };
    else if (cfg.T_mode === "dom" && s.domT && now - s.domT.t < 5e3 && s.domT.days > 0) T = { days: s.domT.days, years: s.domT.days / 252, src: "DOM Fair tab" };
    else {
      const x = computed();
      T = { days: x.days, years: x.days / 252, src: x.src };
    }
    const chains = buildChains(Object.values(s.metas), s.quotes);
    const contracts = contractsBySymbol(chains);
    const spot = {};
    const mIV = {};
    const domUnd = s.domChain && s.domSpot && now - s.domSpot.t < 5e3 ? this.domChainUnderlying(s.domChain.strikes) : null;
    for (const u of cfg.underlyings) {
      const q = s.undQuotes[u];
      const qMid = q ? q.bid != null && q.ask != null ? (q.bid + q.ask) / 2 : q.last ?? q.bid ?? q.ask : null;
      const ch = chains[u];
      const par = ch ? parityImpliedSpot(ch) : null;
      if (q && qMid != null && now - q.t < 3e4) spot[u] = { value: qMid, src: "WS", age: (now - q.t) / 1e3 };
      else if (domUnd === u && s.domSpot) spot[u] = { value: s.domSpot.value, src: "DOM", age: (now - s.domSpot.t) / 1e3 };
      else if (par != null) spot[u] = { value: par, src: "parity", age: null };
      else if (qMid != null) spot[u] = { value: qMid, src: "WS (stale)", age: q ? (now - q.t) / 1e3 : null };
      else spot[u] = { value: null, src: "none", age: null };
      const sv = spot[u].value;
      mIV[u] = ch && sv != null ? marketIV(ch, sv, T.years, th.minVegaForIV) : null;
    }
    const prices = [];
    for (const q of Object.values(s.quotes)) {
      if (q.bid != null) prices.push(q.bid);
      if (q.ask != null) prices.push(q.ask);
    }
    const tick2 = cfg.tick ?? inferTick(prices.slice(0, 200), 0.01);
    const effTargets = {};
    const blends = {};
    let targetsConfirmed = true;
    for (const u of cfg.underlyings) {
      const t = s.targets[u];
      const sp = t?.spot.value ?? spot[u]?.value ?? null;
      const vol = t?.vol.value ?? mIV[u] ?? null;
      if (t && (!t.spot.confirmed || !t.vol.confirmed) && (!cfg.focus || cfg.focus === u)) targetsConfirmed = false;
      if (sp != null && vol != null && sp > 0 && vol > 0) {
        let lo = t?.volLow ?? vol;
        let hi = t?.volHigh ?? vol;
        if (lo > vol) lo = vol;
        if (hi < vol) hi = vol;
        effTargets[u] = { spot: sp, vol, volLow: lo, volHigh: hi };
      }
      const ev2 = phase?.event?.n;
      const row = ev2 != null ? s.analystInputs[ev2]?.[u] : void 0;
      if (row) {
        const est = {};
        for (const a of ANALYSTS) if (row[a]?.sigma != null) est[a] = row[a]?.sigma;
        blends[u] = blendAnalysts(est, u, s.history, cfg.blend);
      } else blends[u] = null;
    }
    const positions = s.manualPositions ?? s.positions;
    const edges = {};
    const synths = {};
    const strads = {};
    const arbs = [];
    const ev = phase?.event?.n;
    const edgeOpts = { positionLimit: th.positionLimit, perTicketCap: th.perTicketCap, minEdge: th.minEdge, multiplier: cfg.multiplier, tick: tick2 };
    const structOpts = { positionLimit: th.positionLimit, perTicketCap: th.perTicketCap };
    for (const u of cfg.underlyings) {
      const ch = chains[u];
      const tg = effTargets[u];
      if (!ch) continue;
      if (tg) {
        const base = ev != null ? s.baselines[ev]?.[u] ?? null : null;
        edges[u] = computeEdges(ch, tg, base, T.years, positions, s.resting, edgeOpts);
        synths[u] = syntheticForwards(ch, tg.spot, T.years, tg.vol, positions, s.resting, structOpts);
        strads[u] = straddles(ch, tg.spot, tg.vol, T.years, positions, s.resting, structOpts);
      }
      arbs.push(...findArbs(ch, spot[u]?.value ?? null, T.years, { eps: th.arbEps, ivOutlierPts: th.ivOutlierPts, minVega: th.minVegaForIV, cap: th.perTicketCap }));
    }
    const riskInputs = {};
    for (const u of cfg.underlyings) {
      const tg = effTargets[u];
      if (tg) riskInputs[u] = { spot: tg.spot, vol: tg.vol };
    }
    const pf = portfolio(chains, positions, riskInputs, T.years, cfg.multiplier);
    const caps = { maxAbsDeltaPerUnderlying: th.maxAbsDeltaPerUnderlying, maxAbsVegaPts: th.maxAbsVegaPts };
    const breaches = capBreaches(pf, caps);
    const flattenNow = phase?.nextPhase === "NEWS" && realToNext != null && realToNext <= th.flattenWarnRealSec && needsFlatten(pf, caps, th.flattenWarnFraction);
    const rate = this.rate.status(now);
    const allEdges = Object.values(edges).flat();
    const allSynths = Object.values(synths).flat();
    const plan = planTickets({
      edges: allEdges,
      structures: allSynths,
      contracts,
      targets: riskInputs,
      T: T.years,
      positions,
      resting: s.resting,
      bookGreeks: Object.fromEntries(Object.entries(pf.perUnderlying).map(([u, b]) => [u, { delta: b.delta, vega: b.vega }])),
      caps,
      positionLimit: th.positionLimit,
      perTicketCap: th.perTicketCap,
      minEdge: th.minEdge,
      rateRemaining: rate.remaining,
      round,
      preferSynthForSpot: cfg.preferSynthForSpot,
      priceMode: cfg.priceMode,
      tick: tick2,
      focus: cfg.focus,
      multiplier: cfg.multiplier
    });
    const fl = flattenOrders(chains, positions, riskInputs, T.years, caps, th.perTicketCap, { pct: th.flattenThroughPct ?? 0, ticks: th.flattenThroughTicks ?? 0, tick: tick2 }, s.resting);
    const flatten = ticketsFromFlatten(fl.orders, tick2, rate.remaining, cfg.focus);
    let quoteAge = null;
    for (const q of Object.values(s.quotes)) {
      const age = (now - q.t) / 1e3;
      if (quoteAge == null || age < quoteAge) quoteAge = age;
    }
    return {
      now,
      mode,
      modeReason,
      simNow,
      clockSrc,
      clockStale,
      clockRate,
      replay: !!phase?.replay,
      phase,
      realToNext,
      round,
      T,
      chains,
      contracts,
      spot,
      marketIV: mIV,
      effTargets,
      blends,
      edges,
      synths,
      straddles: strads,
      arbs,
      portfolio: pf,
      breaches,
      flattenNow,
      plan,
      flatten,
      flattenCost: fl.totalSpreadCost,
      rate,
      quoteAge,
      tick: tick2,
      targetsConfirmed,
      autoArmed: cfg.auto.submit && !s.auto.paused && mode === "derivatives"
    };
  }
  analystTable(u) {
    return analystStats(this.s.history, u);
  }
  roundOf(event) {
    return this.cfg.schedule.find((e) => e.n === event)?.round ?? null;
  }
  sessionOpenSec() {
    return hmsToSec(this.cfg.session.open);
  }
};

// ../ctc2026/out/derivatives-converter-review-20261024/final-4cc4324/probe.ts
var strikes = { OIL: [60, 100, 140], PLANE: [30, 40, 50] };
function quoteAll(st2, spots, vols, T) {
  for (const [u, ks] of Object.entries(strikes)) {
    st2.handleWsJson({ type: "quote", symbol: u, bid: spots[u] - 0.01, ask: spots[u] + 0.01, bid_size: 5, ask_size: 5 });
    for (const K of ks) {
      for (const k of ["C", "P"]) {
        const f = price(k, spots[u], K, vols[u], T);
        const r = (x) => Math.round(x * 100) / 100;
        st2.handleWsJson({ type: "quote", symbol: `${u}_0626_${k}${K}`, bid: Math.max(0.01, r(f - 0.05)), ask: r(f + 0.05), bid_size: 40, ask_size: 40 });
      }
    }
  }
}
function clock(st2, t, now, rate = 52) {
  st2.handleHttp("GET", "/api/v1/competitions/current", { competition_id: "c1", name: "Newtonia vs Euleria", state: "running", fictional_time: t, clock_rate: rate }, now);
}
function news(st2, seq2, headline, extra = {}) {
  st2.handleWsJson({ type: "news", message: { type: "headline", seq: seq2, headline, ...extra } });
}
function setup(opts = {}) {
  let now = 1e6;
  const cfg = cloneDefaults();
  if (opts.confirm != null) cfg.auto.confirm = opts.confirm;
  if (opts.converter != null) cfg.auto.converter = opts.converter;
  const st2 = new Store(cfg, () => now);
  st2.handleHttp("GET", "/api/v1/symbols", Object.entries(strikes).flatMap(([u, ks]) => [u, ...ks.flatMap((K) => [`${u}_0626_C${K}`, `${u}_0626_P${K}`])]));
  const tick2 = (ms) => {
    now += ms;
    st2.s.lastClockPollAt = now;
    st2.tick();
  };
  const at2 = (t, advanceMs = 0) => {
    now += advanceMs;
    clock(st2, t, now);
  };
  return { st: st2, tick: tick2, at: at2 };
}
var multiple = identifyConverter({ samples: [{ underlying: "PLANE", raw: 1 }], text: "Analyst 1: PLANE call price 1.00 and put price 1.00", marketIV: { PLANE: 0.16 }, spot: { PLANE: 40 }, T: 18 / 252, strikes: { PLANE: [40] }, tolPts: 8, tieMarginPts: 2 });
console.log(JSON.stringify({ probe: "multiple_named_fallthrough", result: multiple }, null, 2));
var { st, tick, at } = setup();
at("2026-06-03T09:29:00");
quoteAll(st, { OIL: 100, PLANE: 40 }, { OIL: 0.55, PLANE: 1.21 }, 18 / 252);
tick(100);
at("2026-06-03T09:30:02");
tick(100);
news(st, 1, "Oiler nationalises a refinery. OIL rises to 103.00. PLANE falls to 38.50.");
st.s.converter.id = "iv";
news(st, 2, "Analyst 1: OIL variance 0.5625, PLANE variance 1.21", { type: "analyst" });
var first = JSON.parse(JSON.stringify({ converter: st.s.auto.converter, targets: st.s.targets, cells: st.s.analystInputs[7] }));
news(st, 3, "Analyst 2: OIL 0.5625, PLANE 1.21", { type: "analyst" });
var second = JSON.parse(JSON.stringify({ converter: st.s.auto.converter, targets: st.s.targets, cells: st.s.analystInputs[7] }));
news(st, 4, "Analyst 3: OIL 0.5625, PLANE 1.21", { type: "analyst" });
var third = JSON.parse(JSON.stringify({ converter: st.s.auto.converter, targets: st.s.targets, cells: st.s.analystInputs[7], targetsConfirmed: st.d.targetsConfirmed }));
console.log(JSON.stringify({ probe: "later_unnamed_message", first, second, third }, null, 2));
