import { identifyConverter } from '/Users/arjunhans/Documents/ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/engine/autoConverter';
import { cloneDefaults } from '/Users/arjunhans/Documents/ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/core/config';
import { price } from '/Users/arjunhans/Documents/ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/engine/blackScholes';
import { Store } from '/Users/arjunhans/Documents/ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/state/store';
const strikes: Record<string, number[]> = { OIL: [60, 100, 140], PLANE: [30, 40, 50] };

function quoteAll(st: Store, spots: Record<string, number>, vols: Record<string, number>, T: number) {
  for (const [u, ks] of Object.entries(strikes)) {
    st.handleWsJson({ type: 'quote', symbol: u, bid: spots[u] - 0.01, ask: spots[u] + 0.01, bid_size: 5, ask_size: 5 });
    for (const K of ks) {
      for (const k of ['C', 'P'] as const) {
        const f = price(k, spots[u], K, vols[u], T);
        const r = (x: number) => Math.round(x * 100) / 100;
        st.handleWsJson({ type: 'quote', symbol: `${u}_0626_${k}${K}`, bid: Math.max(0.01, r(f - 0.05)), ask: r(f + 0.05), bid_size: 40, ask_size: 40 });
      }
    }
  }
}
function clock(st: Store, t: string, now: number, rate = 52) {
  st.handleHttp('GET', '/api/v1/competitions/current', { competition_id: 'c1', name: 'Newtonia vs Euleria', state: 'running', fictional_time: t, clock_rate: rate }, now);
}
function news(st: Store, seq: number, headline: string, extra: Record<string, unknown> = {}) {
  st.handleWsJson({ type: 'news', message: { type: 'headline', seq, headline, ...extra } });
}

function setup(opts: { confirm?: boolean; converter?: boolean } = {}) {
  let now = 1_000_000;
  const cfg = cloneDefaults();
  if (opts.confirm != null) cfg.auto.confirm = opts.confirm;
  if (opts.converter != null) cfg.auto.converter = opts.converter;
  const st = new Store(cfg, () => now);
  st.handleHttp('GET', '/api/v1/symbols', Object.entries(strikes).flatMap(([u, ks]) => [u, ...ks.flatMap((K) => [`${u}_0626_C${K}`, `${u}_0626_P${K}`])]));
  const tick = (ms: number) => { now += ms; st.s.lastClockPollAt = now; st.tick(); };
  /** advance the wall clock, then poll the exchange clock at the new time */
  const at = (t: string, advanceMs = 0) => { now += advanceMs; clock(st, t, now); };
  return { st, tick, at };
}


const multiple = identifyConverter({samples:[{underlying:'PLANE',raw:1}],text:'Analyst 1: PLANE call price 1.00 and put price 1.00',marketIV:{PLANE:0.16},spot:{PLANE:40},T:18/252,strikes:{PLANE:[40]},tolPts:8,tieMarginPts:2});
console.log(JSON.stringify({probe:'multiple_named_fallthrough',result:multiple},null,2));
const {st,tick,at}=setup();
at('2026-06-03T09:29:00');
quoteAll(st,{OIL:100,PLANE:40},{OIL:0.55,PLANE:1.21},18/252);tick(100);
at('2026-06-03T09:30:02');tick(100);
news(st,1,'Oiler nationalises a refinery. OIL rises to 103.00. PLANE falls to 38.50.');
st.s.converter.id='iv';
news(st,2,'Analyst 1: OIL variance 0.5625, PLANE variance 1.21',{type:'analyst'});
const first=JSON.parse(JSON.stringify({converter:st.s.auto.converter,targets:st.s.targets,cells:st.s.analystInputs[7]}));
news(st,3,'Analyst 2: OIL 0.5625, PLANE 1.21',{type:'analyst'});
const second=JSON.parse(JSON.stringify({converter:st.s.auto.converter,targets:st.s.targets,cells:st.s.analystInputs[7]}));
news(st,4,'Analyst 3: OIL 0.5625, PLANE 1.21',{type:'analyst'});
const third=JSON.parse(JSON.stringify({converter:st.s.auto.converter,targets:st.s.targets,cells:st.s.analystInputs[7],targetsConfirmed:st.d.targetsConfirmed}));
console.log(JSON.stringify({probe:'later_unnamed_message',first,second,third},null,2));
