let attempts=0;
const deny=(...a)=>{attempts++;throw new Error('OFFLINE_REVIEW_NETWORK_DENIED')};
globalThis.fetch=deny;
require('node:net').Socket.prototype.connect=deny;
require('node:tls').connect=deny;
for(const n of ['node:http','node:https']){const h=require(n);h.request=deny;h.get=deny;}
const dns=require('node:dns');dns.lookup=deny;dns.resolve=deny;
process.on('exit',()=>{process.stderr.write(JSON.stringify({network_guard_attempts:attempts})+'\n');if(attempts)process.exitCode=1;});
