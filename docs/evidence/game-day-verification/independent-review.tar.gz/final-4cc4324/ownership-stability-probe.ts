import { identifyConverter } from '/Users/arjunhans/Documents/ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/engine/autoConverter';
import { cloneDefaults } from '/Users/arjunhans/Documents/ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/core/config';
import { price } from '/Users/arjunhans/Documents/ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/engine/blackScholes';
import { Store } from '/Users/arjunhans/Documents/ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/src/state/store';
const strikes: Record<string, number[]> = { OIL: [60, 100, 140], PLANE: [30, 40, 50] };

function quoteAll(st: Store, spots: Record<string, number>, vols: Record<string, number>, T: number) {
  for (const [u, ks] of Object.entries(strikes)) {
    st.handleWsJson({ type: 'quote', symbol: u, bid: spots[u] - 0.01, ask: spots[u] + 0.01, bid_size: 5, ask_size: 5 });
    for (const K of ks) {
      for (const k of ['C', 'P'] as const) {
        const f = price(k, spots[u], K, vols[u], T);
        const r = (x: number) => Math.round(x * 100) / 100;
        st.handleWsJson({ type: 'quote', symbol: `${u}_0626_${k}${K}`, bid: Math.max(0.01, r(f - 0.05)), ask: r(f + 0.05), bid_size: 40, ask_size: 40 });
      }
    }
  }
}
function clock(st: Store, t: string, now: number, rate = 52) {
  st.handleHttp('GET', '/api/v1/competitions/current', { competition_id: 'c1', name: 'Newtonia vs Euleria', state: 'running', fictional_time: t, clock_rate: rate }, now);
}
function news(st: Store, seq: number, headline: string, extra: Record<string, unknown> = {}) {
  st.handleWsJson({ type: 'news', message: { type: 'headline', seq, headline, ...extra } });
}

function setup(opts: { confirm?: boolean; converter?: boolean } = {}) {
  let now = 1_000_000;
  const cfg = cloneDefaults();
  if (opts.confirm != null) cfg.auto.confirm = opts.confirm;
  if (opts.converter != null) cfg.auto.converter = opts.converter;
  const st = new Store(cfg, () => now);
  st.handleHttp('GET', '/api/v1/symbols', Object.entries(strikes).flatMap(([u, ks]) => [u, ...ks.flatMap((K) => [`${u}_0626_C${K}`, `${u}_0626_P${K}`])]));
  const tick = (ms: number) => { now += ms; st.s.lastClockPollAt = now; st.tick(); };
  /** advance the wall clock, then poll the exchange clock at the new time */
  const at = (t: string, advanceMs = 0) => { now += advanceMs; clock(st, t, now); };
  return { st, tick, at };
}



function ready() {
 const {st,tick,at}=setup();
 at('2026-06-03T09:29:00');quoteAll(st,{OIL:100,PLANE:40},{OIL:.55,PLANE:1.21},18/252);tick(100);
 at('2026-06-03T09:30:02');tick(100);
 news(st,1,'Oiler nationalises a refinery. OIL rises to 103.00. PLANE falls to 38.50.');
 return {st,tick};
}
const {st,tick}=ready();
let calls=0;
const actual=st.tryAutoConverter.bind(st);
st.tryAutoConverter=(...args)=>{calls++;return actual(...args);};
news(st,2,'Analyst 1: OIL 0.5625, PLANE 1.21',{type:'analyst'});
const selected=JSON.stringify(st.s.auto.converter);
const beforeQuoteCalls=calls;
quoteAll(st,{OIL:100,PLANE:40},{OIL:.75,PLANE:1.1},18/252);tick(100);
const afterQuoteCalls=calls;
const afterQuotes=JSON.stringify(st.s.auto.converter);
news(st,3,'Analyst 2: OIL 0.5625, PLANE 1.21',{type:'analyst'});
const afterUnitless=JSON.stringify(st.s.auto.converter);
const typed=ready().st;
for(let a=1;a<=3;a++)news(typed,a+1,`Analyst ${a}: OIL 0.5625, PLANE 1.21`,{type:'analyst'});
typed.setTarget('OIL','vol',.8);typed.setTarget('PLANE','vol',1.2);
news(typed,5,'Analyst 1: OIL variance 0.5625, PLANE variance 1.21',{type:'analyst'});
const assertions={
 quotes_do_not_call_identifier:beforeQuoteCalls===afterQuoteCalls,
 quotes_do_not_change_inference:selected===afterQuotes,
 later_unitless_message_keeps_uncontradicted_inference:selected===afterUnitless,
 typed_oil_preserved:typed.s.targets.OIL.vol.src==='typed' && typed.s.targets.OIL.vol.confirmed && typed.s.targets.OIL.vol.value===.8,
 typed_plane_preserved:typed.s.targets.PLANE.vol.src==='typed' && typed.s.targets.PLANE.vol.confirmed && typed.s.targets.PLANE.vol.value===1.2,
 typed_targets_remain_usable:typed.s.auto.converter.status==='idle' && typed.d.targetsConfirmed,
};
console.log(JSON.stringify({assertions,beforeQuoteCalls,afterQuoteCalls,selected:JSON.parse(selected),afterQuotes:JSON.parse(afterQuotes),afterUnitless:JSON.parse(afterUnitless),typed:{converter:typed.s.auto.converter,targets:typed.s.targets,targetsConfirmed:typed.d.targetsConfirmed}},null,2));
if(Object.values(assertions).some(x=>!x))throw new Error('OWNERSHIP_STABILITY_ASSERTION_FAILED');
