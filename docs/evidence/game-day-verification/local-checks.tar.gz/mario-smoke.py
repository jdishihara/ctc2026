"""Bounded local-only Mario startup, full-race ingestion and manual-default check."""
import json
from pathlib import Path
import socket
import subprocess
import sys
import time
import traceback
import urllib.request

ROOT = Path('/Users/arjunhans/Documents/ctc2026-competition')
OUT = Path('/Users/arjunhans/Documents/ctc2026/out/game-day-verification-20261024')
PYTHON = '/Users/arjunhans/Documents/ctc2026/.venv/bin/python'
processes = []
logs = []
receipt = dict(started_at=time.time(), mode='local mock only', auto_execute=False)


def get(url):
    assert url.startswith(('http://127.0.0.1:8790/', 'http://127.0.0.1:18787/'))
    with urllib.request.urlopen(url, timeout=3) as response:
        return json.load(response)


try:
    for port in (8790, 18787):
        with socket.socket() as connection:
            connection.settimeout(.2)
            assert connection.connect_ex(('127.0.0.1', port)) != 0, f'port {port} already in use'
    for name, command in [
        ('mario-mock', [PYTHON, '-u', 'mario/mock_exchange.py', '--race-every', '4']),
        ('mario-desk', [PYTHON, '-u', 'mario/desk.py', '--mock', '--tap', 'http',
                        '--auto-results', '--no-repl', '--port', '18787']),
    ]:
        log = (OUT / f'{name}.log').open('x')
        logs.append(log)
        processes.append(subprocess.Popen(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT))
    deadline = time.monotonic() + 55
    samples = 0
    with (OUT / 'mario-snapshots.jsonl').open('x') as snapshots:
        while time.monotonic() < deadline:
            assert all(p.poll() is None for p in processes), 'owned mock/desk process exited early'
            try:
                state = get('http://127.0.0.1:18787/state.json')
            except (OSError, ValueError):
                time.sleep(.5)
                continue
            snapshots.write(json.dumps(dict(at=time.time(), state=state)) + '\n')
            snapshots.flush()
            samples += 1
            assert state['auto'] is None, 'default desk unexpectedly enabled execution'
            if state['status'] == 'connected' and state['n_done'] == 8 and len(state['rows']) == 46:
                break
            time.sleep(1)
        else:
            raise AssertionError('desk did not ingest all eight mock races before deadline')
    assert state['unmapped'] == [] and state['age'] < 5
    assert all(row.get('pos', 0) == 0 for row in state['rows'])
    trades = get('http://127.0.0.1:8790/api/v1/trades')
    assert (trades if isinstance(trades, list) else trades['trades']) == []
    (OUT / 'mario-final-state.json').write_text(json.dumps(state, indent=2) + '\n')
    receipt.update(status='passed', samples=samples, contracts=len(state['rows']),
                   races_ingested=state['n_done'], unmapped=state['unmapped'], trades=trades)
except BaseException as exc:
    receipt.update(status='failed', error=repr(exc), traceback=traceback.format_exc())
finally:
    for process in reversed(processes):
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)
    for log in logs:
        log.close()
    receipt.update(finished_at=time.time(), process_returncodes=[p.returncode for p in processes])
    (OUT / 'mario-smoke-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))
sys.exit(0 if receipt['status'] == 'passed' else 1)
