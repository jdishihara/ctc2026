# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: rounds.spec.ts >> arb flags, Round 2 analyst learning, Round 3 variance converter
- Location: tests/e2e/rounds.spec.ts:53:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('[data-deriv-overlay]').locator('.box').filter({ hasText: 'Analysts · event 7' }).locator('tbody tr').filter({ hasText: /^A2/ })
Expected substring: "70.0%"
Received string:    "A2 49.0% 100.0%"
Timeout: 15000ms

Call log:
  - Expect "toContainText" locator('[data-deriv-overlay]').locator('.box').filter({ hasText: 'Analysts · event 7' }).locator('tbody tr').filter({ hasText: /^A2/ }) with timeout 15000ms
  - waiting for locator('[data-deriv-overlay]').locator('.box').filter({ hasText: 'Analysts · event 7' }).locator('tbody tr').filter({ hasText: /^A2/ })
    12 × locator resolved to <tr>…</tr>
       - unexpected value "A2 — —"
    22 × locator resolved to <tr>…</tr>
       - unexpected value "A2 49.0% 100.0%"

```

```yaml
- row "A2 0.49 49.0% 1 100.0%":
  - cell "A2"
  - cell "0.49 49.0%":
    - textbox "raw": "0.49"
    - text: 49.0%
  - cell "1 100.0%":
    - textbox "raw": "1"
    - text: 100.0%
```

# Test source

```ts
  1   | // End-to-end through Rounds 2 and 3 on the mock: arb flags, analyst learning across events 4-6, Round 3 converter.
  2   | import { test, expect, chromium, BrowserContext } from '@playwright/test';
  3   | import { spawn, ChildProcess } from 'node:child_process';
  4   | import { mkdtempSync } from 'node:fs';
  5   | import { tmpdir } from 'node:os';
  6   | import { dirname, join } from 'node:path';
  7   | import { fileURLToPath } from 'node:url';
  8   | 
  9   | const ROOT = join(dirname(fileURLToPath(import.meta.url)), '../..');
  10  | const EXT = join(ROOT, 'dist-dev');
  11  | const BASE = 'http://localhost:5317';
  12  | 
  13  | let server: ChildProcess;
  14  | let ctx: BrowserContext | null = null;
  15  | let skipReason: string | null = null;
  16  | 
  17  | test.beforeAll(async () => {
  18  |   // wait for a previous spec's mock exchange to release the port
  19  |   for (let i = 0; i < 50; i++) {
  20  |     try {
  21  |       await fetch(`${BASE}/__mock/stats`);
  22  |       await new Promise((r) => setTimeout(r, 200));
  23  |     } catch {
  24  |       break;
  25  |     }
  26  |   }
  27  |   server = spawn(process.execPath, [join(ROOT, 'mock-exchange/server.mjs'), '--port', '5317', '--fast', '6', '--preroll', '4', '--start-event', '4', '--glitch', '--quiet'], { stdio: 'inherit' });
  28  |   for (let i = 0; i < 50; i++) {
  29  |     try {
  30  |       if ((await fetch(`${BASE}/api/v1/competitions/current`)).ok) break;
  31  |     } catch {
  32  |       /* not up yet */
  33  |     }
  34  |     await new Promise((r) => setTimeout(r, 100));
  35  |   }
  36  |   try {
  37  |     ctx = await chromium.launchPersistentContext(mkdtempSync(join(tmpdir(), 'deriv-rounds-')), {
  38  |       headless: true, channel: 'chromium', args: [`--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`],
  39  |     });
  40  |   } catch (e) {
  41  |     skipReason = `could not launch Chromium with the extension: ${e}`;
  42  |   }
  43  | });
  44  | test.afterAll(async () => {
  45  |   await ctx?.close();
  46  |   if (server) {
  47  |     const gone = new Promise<void>((r) => server.once('exit', () => r()));
  48  |     server.kill();
  49  |     await Promise.race([gone, new Promise((r) => setTimeout(r, 3000))]);
  50  |   }
  51  | });
  52  | 
  53  | test('arb flags, Round 2 analyst learning, Round 3 variance converter', async () => {
  54  |   test.skip(!!skipReason, skipReason ?? '');
  55  |   test.setTimeout(240_000);
  56  |   const page = await ctx!.newPage();
  57  |   await page.goto(`${BASE}/trading`);
  58  |   const ov = page.locator('[data-deriv-overlay]');
  59  |   await expect(ov.getByText('DERIVATIVES')).toBeVisible({ timeout: 15_000 });
  60  |   await ov.getByRole('button', { name: '📌' }).click(); // pin tabs: no auto-switching during this test
  61  | 
  62  |   // Arb tab: the --glitch monotonicity violation is flagged with its legs and can be queued
  63  |   await ov.getByRole('button', { name: 'Arb', exact: true }).click();
  64  |   await expect(ov.getByText('monotonicity', { exact: true }).first()).toBeVisible({ timeout: 10_000 });
  65  |   await expect(ov.getByText(/BUY OIL_0626_C100@.*SELL OIL_0626_C140@/).first()).toBeVisible();
  66  |   await ov.getByRole('button', { name: 'Queue tickets' }).first().click();
  67  |   await expect(ov.getByText(/linked tickets queued/)).toBeVisible();
  68  | 
  69  |   // Round 2: the analyst grid fills from the news; learning accumulates over events 4-6
  70  |   await ov.getByRole('button', { name: 'Vol', exact: true }).click();
  71  |   await expect(ov.getByText('Analysts · event 4 (IV)')).toBeVisible({ timeout: 15_000 });
  72  |   const accRow = (a: string) => ov.locator('.box', { hasText: 'Analyst accuracy' }).locator('tbody tr').filter({ has: page.locator('td:first-child', { hasText: new RegExp(`^${a}$`) }) });
  73  |   // n counts (event, underlying) records: 2 per event
  74  |   await expect(accRow('A2').locator('td').nth(1)).toHaveText(/^[2-9]$/, { timeout: 60_000 });
  75  |   await expect(ov.getByText(/Analysts · event [56] \(IV\)/)).toBeVisible({ timeout: 60_000 });
  76  |   await expect(accRow('A2').locator('td').nth(1)).toHaveText(/^[4-9]$/, { timeout: 60_000 });
  77  |   const rmse = async (a: string) => Number(await accRow(a).locator('td').nth(2).textContent());
  78  |   expect(await rmse('A2')).toBeLessThan(2); // accurate analyst: < 2 vol points
  79  |   expect(await rmse('A1')).toBeGreaterThan(5); // biased analyst
  80  |   // the learned blend trusts Analyst 2
  81  |   await ov.locator('select', { has: page.locator('option[value="weighted"]') }).selectOption('weighted');
  82  |   const wText = (await ov.getByText(/A1 \d+% A2 \d+% A3 \d+%/).first().textContent()) ?? '';
  83  |   const w2 = Number(/A2 (\d+)%/.exec(wText)?.[1]);
  84  |   expect(w2, wText).toBeGreaterThan(60);
  85  | 
  86  |   // Round 3 (after the day-2 close and break): variance quotes converted to sigma
  87  |   await expect(ov.getByText(/Analysts · event 7 \(raw → σ via Annual variance/)).toBeVisible({ timeout: 120_000 });
  88  |   const grid = ov.locator('.box', { hasText: 'Analysts · event 7' });
  89  |   // Analyst 2 quotes OIL variance 0.49 → 70.0%, PLANE 1.0 → 100.0%
> 90  |   await expect(grid.locator('tbody tr').filter({ hasText: /^A2/ })).toContainText('70.0%', { timeout: 15_000 });
      |                                                                     ^ Error: expect(locator).toContainText(expected) failed
  91  |   await expect(grid.locator('tbody tr').filter({ hasText: /^A2/ })).toContainText('100.0%');
  92  |   // switching the converter re-converts the same raw numbers
  93  |   await ov.locator('select', { has: page.locator('option[value="custom"]') }).selectOption('dailyMovePct'); // 0.49 read as a 0.49% daily move → 7.8%
  94  |   await expect(grid.locator('tbody tr').filter({ hasText: /^A2/ })).not.toContainText('70.0%');
  95  |   await ov.locator('select', { has: page.locator('option[value="custom"]') }).selectOption('variance');
  96  |   await expect(grid.locator('tbody tr').filter({ hasText: /^A2/ })).toContainText('70.0%');
  97  | 
  98  |   const stats = await (await fetch(`${BASE}/__mock/stats`)).json();
  99  |   expect(stats.orderPosts).toBe(0);
  100 |   expect(stats.wsExtraFrames).toBe(0);
  101 | });
  102 | 
```