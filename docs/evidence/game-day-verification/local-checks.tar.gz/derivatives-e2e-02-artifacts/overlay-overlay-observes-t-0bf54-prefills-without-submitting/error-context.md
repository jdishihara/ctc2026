# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: overlay.spec.ts >> overlay observes the mock exchange, suggests targets, prefills without submitting
- Location: tests/e2e/overlay.spec.ts:63:1

# Error details

```
Error: expect(locator).toHaveClass(expected) failed

Locator: locator('[data-deriv-overlay]').locator('[data-field="spot-OIL"]')
Expected pattern: /amber/
Received string:  "num"
Timeout: 5000ms

Call log:
  - Expect "toHaveClass" locator('[data-deriv-overlay]').locator('[data-field="spot-OIL"]') with timeout 5000ms
  - waiting for locator('[data-deriv-overlay]').locator('[data-field="spot-OIL"]')
    14 × locator resolved to <input class="num" placeholder="spot" data-field="spot-OIL" title="headline ("108.50") (confirmed)"/>
       - unexpected value "num"

```

```yaml
- textbox "headline (\"108.50\") (confirmed)":
  - /placeholder: spot
  - text: "108.50"
```

# Test source

```ts
  1   | // End-to-end: real Chromium + the dev build of the extension + the mock exchange.
  2   | import { test, expect, chromium, BrowserContext, Page } from '@playwright/test';
  3   | import { spawn, ChildProcess } from 'node:child_process';
  4   | import { existsSync, mkdtempSync } from 'node:fs';
  5   | import { tmpdir } from 'node:os';
  6   | import { dirname, join } from 'node:path';
  7   | import { fileURLToPath } from 'node:url';
  8   | 
  9   | const ROOT = join(dirname(fileURLToPath(import.meta.url)), '../..');
  10  | const EXT = join(ROOT, 'dist-dev');
  11  | const PORT = 5317; // the dev manifest matches this origin
  12  | const BASE = `http://localhost:${PORT}`;
  13  | 
  14  | let server: ChildProcess;
  15  | let ctx: BrowserContext;
  16  | let page: Page;
  17  | let skipReason: string | null = null;
  18  | 
  19  | const stats = async () => (await (await fetch(`${BASE}/__mock/stats`)).json()) as { orderPosts: number; wsSubscribeFrames: number; wsExtraFrames: number; positions: { symbol: string; quantity: number }[] };
  20  | 
  21  | test.beforeAll(async () => {
  22  |   if (!existsSync(join(EXT, 'manifest.json'))) throw new Error('run npm run build:dev first');
  23  |   // wait for a previous spec's mock exchange to release the port
  24  |   for (let i = 0; i < 50; i++) {
  25  |     try {
  26  |       await fetch(`${BASE}/__mock/stats`);
  27  |       await new Promise((r) => setTimeout(r, 200));
  28  |     } catch {
  29  |       break;
  30  |     }
  31  |   }
  32  |   server = spawn(process.execPath, [join(ROOT, 'mock-exchange/server.mjs'), '--port', String(PORT), '--fast', '4', '--preroll', '10', '--quiet'], { stdio: 'inherit' });
  33  |   for (let i = 0; i < 50; i++) {
  34  |     try {
  35  |       if ((await fetch(`${BASE}/api/v1/competitions/current`)).ok) break;
  36  |     } catch {
  37  |       /* not up yet */
  38  |     }
  39  |     await new Promise((r) => setTimeout(r, 100));
  40  |   }
  41  |   const userDataDir = mkdtempSync(join(tmpdir(), 'deriv-overlay-e2e-'));
  42  |   const args = [`--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`];
  43  |   try {
  44  |     ctx = await chromium.launchPersistentContext(userDataDir, { headless: true, channel: 'chromium', args });
  45  |   } catch (e) {
  46  |     try {
  47  |       ctx = await chromium.launchPersistentContext(userDataDir, { headless: false, args });
  48  |     } catch (e2) {
  49  |       skipReason = `could not launch Chromium with the extension: ${e} / ${e2}`;
  50  |     }
  51  |   }
  52  | });
  53  | 
  54  | test.afterAll(async () => {
  55  |   await ctx?.close();
  56  |   if (server) {
  57  |     const gone = new Promise<void>((r) => server.once('exit', () => r()));
  58  |     server.kill();
  59  |     await Promise.race([gone, new Promise((r) => setTimeout(r, 3000))]);
  60  |   }
  61  | });
  62  | 
  63  | test('overlay observes the mock exchange, suggests targets, prefills without submitting', async () => {
  64  |   test.skip(!!skipReason, skipReason ?? '');
  65  |   page = await ctx.newPage();
  66  |   const errors: string[] = [];
  67  |   page.on('pageerror', (e) => errors.push(String(e)));
  68  |   await page.goto(`${BASE}/trading`);
  69  | 
  70  |   // 1. overlay mounts (shadow DOM is open, Playwright locators pierce it)
  71  |   const overlay = page.locator('[data-deriv-overlay]');
  72  |   await expect(overlay).toHaveCount(1, { timeout: 10_000 });
  73  |   await expect(overlay.getByText('DERIVATIVES')).toBeVisible({ timeout: 10_000 });
  74  | 
  75  |   // 2. capture shows quotes and the clock poll
  76  |   await overlay.getByRole('button', { name: 'Capture', exact: true }).click();
  77  |   await expect(overlay.getByText('ws:quote', { exact: true })).toBeVisible({ timeout: 10_000 });
  78  |   await expect(overlay.getByText('http:GET /api/v1/competitions/current', { exact: true })).toBeVisible();
  79  | 
  80  |   // 3. the countdown advances
  81  |   const countdown = overlay.locator('.count');
  82  |   const c1 = await countdown.textContent();
  83  |   await page.waitForTimeout(2200);
  84  |   const c2 = await countdown.textContent();
  85  |   expect(c1).not.toEqual(c2);
  86  | 
  87  |   // 4. event 1 headline → targets suggested (amber) on the Edge tab
  88  |   await overlay.getByRole('button', { name: 'Edge', exact: true }).click();
  89  |   const spotIn = overlay.locator('[data-field="spot-OIL"]');
  90  |   const volIn = overlay.locator('[data-field="vol-OIL"]');
  91  |   await expect(spotIn).toHaveValue('108.50', { timeout: 20_000 });
  92  |   await expect(volIn).toHaveValue('65.0');
> 93  |   await expect(spotIn).toHaveClass(/amber/);
      |                        ^ Error: expect(locator).toHaveClass(expected) failed
  94  |   await expect(overlay.locator('[data-field="vol-PLANE"]')).toHaveValue('85.0');
  95  | 
  96  |   // 5. Alt+A accepts, Alt+N prefills the order form
  97  |   await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur());
  98  |   await page.keyboard.press('Alt+KeyA');
  99  |   await expect(spotIn).not.toHaveClass(/amber/);
  100 |   await page.keyboard.press('Alt+KeyN');
  101 |   await expect(overlay.locator('.ticket')).toContainText('Ready: review and click', { timeout: 5000 });
  102 |   const card = (await overlay.locator('.ticket .row').first().textContent()) ?? '';
  103 |   const m = /(BUY|SELL)(\d+)((?:OIL|PLANE)_0626_[CP]\d+)@([\d.]+)/.exec(card.replace(/\s+/g, ''));
  104 |   expect(m, card).not.toBeNull();
  105 |   const [, side, qty, sym, px] = m as RegExpExecArray;
  106 |   await expect(page.locator('.osym')).toHaveText(sym);
  107 |   await expect(page.locator('input.qty')).toHaveValue(qty);
  108 |   expect(Number(await page.locator('input.price').inputValue())).toBeCloseTo(Number(px), 6);
  109 |   await expect(page.locator('.sidebtn.active')).toHaveText(side);
  110 |   await expect(page.locator('.typebtn.active')).toHaveText('Limit');
  111 | 
  112 |   // 6. automation sent zero orders and did not touch the socket
  113 |   let s = await stats();
  114 |   expect(s.orderPosts).toBe(0);
  115 |   expect(s.wsSubscribeFrames).toBe(1);
  116 |   expect(s.wsExtraFrames).toBe(0);
  117 | 
  118 |   // 7. a human submit: positions update, the Risk tab reflects it
  119 |   await page.locator('button.submit').click();
  120 |   await expect.poll(async () => (await stats()).orderPosts).toBe(1);
  121 |   await expect.poll(async () => (await stats()).positions.find((p) => p.symbol === sym)?.quantity ?? 0, { timeout: 5000 }).not.toBe(0);
  122 |   await overlay.getByRole('button', { name: 'Risk', exact: true }).click();
  123 |   await expect(overlay.locator('td', { hasText: sym }).first()).toBeVisible({ timeout: 5000 });
  124 |   s = await stats();
  125 |   expect(s.orderPosts).toBe(1);
  126 |   expect(errors).toEqual([]);
  127 | });
  128 | 
```