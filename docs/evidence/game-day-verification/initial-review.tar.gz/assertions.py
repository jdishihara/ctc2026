import json,sys
from pathlib import Path
p=Path(__file__).parent
prior=json.loads((p/'probe-results.json').read_text())
new=json.loads((p/'contradictory-units-results.json').read_text())
checks=[
('unresolved_named_tie_must_not_pick_unnamed',prior[0]['result']['id'] is None),
('earlier_named_units_must_survive_later_unitless_messages',prior[1]['third']['converter']['id'] is None and not prior[1]['third']['targetsConfirmed']),
('contradictory_later_named_units_must_invalidate_automatic_pick',new[0]['third']['converter']['id'] is None and not new[0]['third']['targetsConfirmed']),
('explicit_manual_pick_stays_manual',new[1]['third']['converter']['status']=='manual'),
]
for name,ok in checks: print(('PASS ' if ok else 'FAIL ')+name)
print(json.dumps({'checks':len(checks),'passed':sum(ok for _,ok in checks),'failed':sum(not ok for _,ok in checks)}))
sys.exit(1 if any(not ok for _,ok in checks) else 0)
