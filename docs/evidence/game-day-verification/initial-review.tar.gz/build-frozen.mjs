import {build} from '/Users/arjunhans/Documents/ctc2026/.worktrees/derivatives-browser-checks/derivatives-overlay/node_modules/esbuild/lib/main.js';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {dirname,join} from 'node:path';
const dir=dirname(fileURLToPath(import.meta.url));
const wt='/Users/arjunhans/Documents/ctc2026/.worktrees/derivatives-browser-checks';
const head='3bdc5cd81c3016cd9954e27efb56d0ae429ea922';
const sources={};
const plugin={name:'exact-git-source',setup(build){
  build.onLoad({filter:/\.ts$/},args=>{
    if(!args.path.startsWith(wt+'/derivatives-overlay/src/'))return;
    const rel=args.path.slice(wt.length+1);
    const contents=execFileSync('git',['show',head+':'+rel],{cwd:wt,encoding:'utf8'});
    sources[rel]=createHash('sha256').update(contents).digest('hex');
    return {contents,loader:'ts'};
  });
}};
for(const name of ['probe','contradictory-units-probe','post-confirmation-probe']){
  await build({entryPoints:[join(dir,name+'.ts')],bundle:true,platform:'node',format:'cjs',define:{__DEV__:'true'},outfile:join(dir,name+'-frozen.cjs'),plugins:[plugin]});
}
writeFileSync(join(dir,'frozen-imports.json'),JSON.stringify({head,sources},null,2)+'\n');
