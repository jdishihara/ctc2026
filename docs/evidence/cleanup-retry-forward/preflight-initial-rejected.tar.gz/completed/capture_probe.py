from __future__ import annotations
import contextlib,copy,hashlib,importlib.util,io,json,os,sys,types
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
OUT=Path(__file__).resolve().parent;SRC=Path('/Users/arjunhans/Documents/ctc2026/.worktrees/cleanup-retry-forward');forbidden=[]
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):forbidden.append(event);raise RuntimeError('synthetic preflight forbids network')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).absolute();q=p.resolve()
  if any('/data/history' in str(x).lower() or '/recordings/' in str(x).lower() or '/ctc2026/out/' in str(x).lower() or '.botkey' in str(x).lower() or '/.env' in str(x).lower() or 'credentials' in str(x).lower() for x in (p,q)):
   forbidden.append(str(p));raise RuntimeError('synthetic preflight forbids real inputs/credentials')
sys.addaudithook(audit)
fixture=OUT/'capture-synthetic-source';frozen=OUT/'capture-synthetic-frozen'
for p in (fixture,frozen):
 for name in ('scripts','ctc','data','docs','bot'):(p/name).mkdir(parents=True,exist_ok=True)
 (p/'data/case.json').write_text('{"limits":{"SYNTH":1}}\n')
 (p/'ctc/analog.py').write_text('# identical synthetic runtime\n')
 (p/'bot/practice.py').write_text('def reconcile_stop(server):\n for attempt in range('+('5' if p==frozen else '6')+'):\n  server.request("GET", "/positions", {"changed": True} if attempt==1 and server.attack=="first_five_changed" else None)\n  if attempt==4 and server.attack in ("extra_91","extra_91_inclusive","extra_90_expired"):\n   for i in range(90):server.request("DELETE", "/orders/synthetic")\n   if server.attack=="extra_91_inclusive":server.now += 60\n   if server.attack=="extra_90_expired":server.now += 60.00001\n  if attempt==5:\n   server.request("POST", "/orders", {"quantity":1})\n   server.request("DELETE", "/orders/synthetic")\n  if attempt==0 and server.attack=="whole_181":\n   for i in range(181):server.request("POST", "/orders", {"quantity":1})\n server.request("GET", "/post-loop-final-receipt")\n')
source=(SRC/'scripts/compare_cleanup_retry_forward.py').read_bytes();path=fixture/'scripts/compare_cleanup_retry_forward.py';path.write_bytes(source);(fixture/'docs/cleanup-retry-window-plan.md').write_text('synthetic plan only\n')
spec=importlib.util.spec_from_file_location('capture_blend_under_test',path);driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
CAPTURE=248;driver.GRID=driver.forward_grid(CAPTURE)
(fixture/'docs/cleanup-retry-forward-plan.md').write_text('synthetic forward plan only\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def vh(v):return hashlib.sha256(json.dumps(v,sort_keys=True,allow_nan=False).encode()).hexdigest()
def result(rtt,depth,basket):return dict(status='ok',errors=[],rtt_seconds=rtt,displayed_depth_fraction=depth,basket_enabled=basket,synthetic_result=True,**{key:None for key in ['stop_reason','stop_at','stop_phase','stop_market_open','monitor_started_at','monitor_detected_at','cleanup_started_at','final_report_rounds','history_block_reason','prefix_messages','client_steps']})
items=[]
for capture in [CAPTURE]:
 data={'frames':[],'receipt':{'competition_id':f'synthetic-{capture}','prices':{'SYNTH':1},'at':1792837800.,'kind':'settlement','source':'read_only_market_observer','year':str(2027-capture),'clock':{'competition_id':f'synthetic-{capture}','state':'ready','fictional_time':str(2027-capture)+'-01-01'},'end_clock':{'competition_id':f'synthetic-{capture}','state':'ready','fictional_time':str(2027-capture)+'-01-01'},'coverage':{'contiguous':True,'final_rounds':[1,2,3]}}}
 cached=OUT/f'capture-{capture}-synthetic-input.json';cached.write_text(json.dumps(data))
 archive=OUT/f'capture-{capture}-synthetic-archive';archive.mkdir()
 rows=[]
 for cap,rtt,depth,basket in driver.GRID:
  if cap!=capture:continue
  rows.append(dict(capture=capture,comparison_status='synthetic_archive',**result(rtt,depth,basket)))
  d=archive/f'capture-{capture}-{rtt}-{depth}-{int(basket)}';d.mkdir()
  for name in driver.JOURNALS:(d/name).write_text('synthetic journal '+name+'\n')
 (archive/'metadata.json').write_text(json.dumps({'captures':[dict(capture=capture,competition_id=data['receipt']['competition_id'],frames_sha256=vh(data['frames']),receipt_sha256=vh(data['receipt']))]}))
 (archive/'results.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
 (archive/'summary.json').write_text(json.dumps(dict(errors=0,mismatches=0,changed_sources=[],results_sha256=sha(archive/'results.jsonl'))))
 items.append(dict(capture=capture,input=str(cached),input_sha256=sha(cached),archive=str(archive),archive_sha256={n:sha(archive/n) for n in ('metadata.json','results.jsonl','summary.json')}))
specpath=OUT/'capture-synthetic-spec.json';specpath.write_text(json.dumps(dict(baseline_root=str(frozen),captures=items)))
parameters={'unchanged_parameter':'sentinel'};seen=[];server_refs=[];attack=None
class FakeServer:
 def __init__(self,*a,**kw):
  self.attack=attack if calls==1 else None;self.requests=[];self.market=SimpleNamespace(fills=[],market_open=True);self.terminal=False;self.now=0.;self.settlement_available_at=10.;self.fatal_errors=[];server_refs.append(self)
 def request(self,method,path,body=None):
  self.requests.append(dict(method=method,path=path,body=copy.deepcopy(body),started_at=self.now,executed_at=self.now,completed_at=self.now,response={}))
  return {}
 def latch(self,exc):self.fatal_errors.append(str(exc))
class FakeSession:
 def __init__(self,*a,**kw):pass
class FakeAnalog:
 def __init__(self,enabled):self.repeat_match=0 if enabled else None
 def weights(self,obs,official,wire,adv=None):return [1.]
class FakeTrader:
 def __init__(self,**kw):
  seen.append(copy.deepcopy(kw));self.kw=kw;self.competition_id='synthetic';self.model=SimpleNamespace(reported_rounds=set(),live_history_ready=True);self.ensemble=None
 def on_quotes(self,exchange):
  if calls==1 and attack=='quote_history':self.model.live_history_ready=False
  return None
class FakeTransport:
 def send(self,*a,**kw):return None
mods={n:types.ModuleType(n) for n in ('scripts','scripts.replay_practice_supervisor','bot','bot.practice','ctc','ctc.strategies','ctc.analog')}
for n in ('scripts','bot','ctc'):mods[n].__path__=[]
replay=mods['scripts.replay_practice_supervisor'];practice=mods['bot.practice'];mods['ctc.strategies'].FairValueTrader=FakeTrader;mods['ctc.analog'].AnalogEnsemble=FakeAnalog
replay.PARAMETERS=parameters;replay.PracticeReplayServer=FakeServer;replay.ServerTransport=FakeTransport;replay.OfflinePracticeExchange=type('SyntheticPractice',(FakeTransport,),{});replay.OfflineCleanupExchange=type('SyntheticCleanup',(FakeTransport,),{})
practice.PracticeSession=FakeSession;current_server=None;practice.finish=lambda journal:practice.reconcile_stop(current_server)
calls=0

def run_stub(case,frames,year,cid,settlement,*,receipt_at,out,rtt,depth_scale,basket):
 global calls,current_server
 calls+=1
 assert case=={'limits':{'SYNTH':1}} and frames==[] and year==str(2027-CAPTURE)
 server=replay.PracticeReplayServer();current_server=server;server.request('GET','/before-cleanup');session=practice.PracticeSession();trader=FakeTrader(**{**replay.PARAMETERS,'basket_edge':.01 if basket else 0})
 session.strat=trader;session.competition_id='synthetic';session._valid_weather_wait=lambda:False
 def reject(fn):
  try:fn()
  except AssertionError:pass
  else:raise AssertionError('guard '+str(attack)+' did not fail')
 if calls==1 and attack in ('quote_identity','quote_history'):
  reject(lambda:trader.on_quotes(SimpleNamespace(competition_id='wrong' if attack=='quote_identity' else 'synthetic')))
  trader.model.live_history_ready=True
 else:trader.on_quotes(SimpleNamespace(competition_id='synthetic'))
 if attack and calls==1:
  if attack in ('settlement_open','settlement_before_receipt','settlement_copy','settlement_shallow_copy','settlement_deep_copy'):
   if attack=='settlement_before_receipt':server.terminal=True;server.market.market_open=False;server.now=9.
   fn={'settlement_open':lambda:settlement['SYNTH'],'settlement_before_receipt':lambda:settlement['SYNTH'],'settlement_copy':settlement.copy,'settlement_shallow_copy':lambda:copy.copy(settlement),'settlement_deep_copy':lambda:copy.deepcopy(settlement)}[attack]
   reject(fn)
  elif attack.startswith('strategy_'):
   exchange=replay.OfflinePracticeExchange();exchange.competition_id='synthetic'
   if attack=='strategy_history':trader.model.live_history_ready=False
   if attack=='strategy_weather_wait':session._valid_weather_wait=lambda:True
   if attack=='strategy_identity':exchange.competition_id='wrong'
   reject(lambda:exchange.send('POST','/orders',{'symbol':'SYNTH','quantity':1,'side':'buy'}))
   trader.model.live_history_ready=True;session._valid_weather_wait=lambda:False
  elif attack.startswith('cleanup_'):
   exchange=replay.OfflineCleanupExchange();exchange.position={'SYNTH':1};exchange.state_ready=True;exchange.market_open=True;exchange.open_orders=[];exchange.expected_id=exchange.competition_id='synthetic'
   body={'symbol':'SYNTH','side':'sell','quantity':1}
   if attack=='cleanup_unready':exchange.state_ready=False
   if attack=='cleanup_closed':exchange.market_open=False
   if attack=='cleanup_working_order':exchange.open_orders=[{}]
   if attack=='cleanup_identity':exchange.expected_id='wrong'
   if attack=='cleanup_side':body['side']='buy'
   if attack=='cleanup_quantity':body['quantity']=2
   if attack=='cleanup_zero':body['quantity']=0
   reject(lambda:exchange.send('POST','/orders',body))
 try:practice.finish(None)
 except AssertionError:pass
 server.terminal=True;server.market.market_open=False;server.now=receipt_at
 assert dict(settlement)=={'SYNTH':1}
 out.mkdir()
 for name in driver.JOURNALS:(out/name).write_text('synthetic journal '+name+'\n')
 return result(rtt,depth_scale,basket)
replay.replay_supervised=run_stub

def fake_git(args,**kw):
 root=Path(kw.get('cwd'))
 if args[1:3]==['rev-parse','HEAD']:return (driver.FROZEN if root==frozen else 'synthetic-candidate-revision')+'\n'
 if args[1]=='status':return b''
 if args[1]=='show':return (root/args[2].split(':',1)[1]).read_bytes()
 raise AssertionError(args)

def phase(name,out,baseline=None,guard_attack=None):
 global calls,attack
 calls=0;seen.clear();server_refs.clear();attack=guard_attack
 runtime=frozen if name=='baseline' else fixture
 replay.__file__=str(runtime/'scripts/replay_practice_supervisor.py')
 namespace={};exec(compile((runtime/'bot/practice.py').read_text(),str(runtime/'bot/practice.py'),'exec'),namespace);practice.reconcile_stop=namespace['reconcile_stop']
 argv=[str(path),'--phase',name,'--spec',str(specpath),'--out',str(out),'--capture',str(CAPTURE)]
 if baseline:argv+=['--baseline',str(baseline)]
 code=0;log=io.StringIO()
 with patch.dict(sys.modules,mods),patch.object(driver.subprocess,'check_output',fake_git),patch.object(driver,'runtime_files',lambda root:sorted([root/'data/case.json',root/'bot/practice.py'])),patch.object(driver.sys,'argv',argv),patch.object(driver.time,'time',lambda:1792843201.),contextlib.redirect_stdout(log):
  try:driver.main()
  except SystemExit as exc:code=exc.code
 (OUT/(out.name+'.stdout.log')).write_text(log.getvalue())
 assert calls==16 and len(seen)==16 and parameters=={'unchanged_parameter':'sentinel'}
 for (_,_,_,basket),kw in zip(driver.GRID,seen):
  expected={'unchanged_parameter':'sentinel','basket_edge':.01 if basket else 0}
  assert kw==expected
 metadata=json.loads((out/'metadata.json').read_text());summary=json.loads((out/'summary.json').read_text());rows=[json.loads(x) for x in (out/'results.jsonl').read_text().splitlines()]
 assert summary['runs']==len(rows)==16 and not summary['forbidden_attempts'] and not summary['changed_sources']
 assert summary['errors']==int(bool(guard_attack and guard_attack!='extra_90_expired')) and code==int(bool(guard_attack and guard_attack!='extra_90_expired')), (summary['errors'],code,guard_attack)
 if guard_attack and guard_attack != 'extra_90_expired':assert len(server_refs[0].fatal_errors)==(0 if guard_attack=='first_five_changed' else 1) and rows[0]['status']=='error'
 if not guard_attack:
  for row in rows:
   d=out/f"capture-{row['capture']}-{row['rtt_seconds']}-{row['displayed_depth_fraction']}-{int(row['basket_enabled'])}"
   pp=json.loads((d/'cleanup-profile.json').read_text());mm=json.loads((d/'mutation-profile.json').read_text())
   assert [x['cleanup_attempt'] for x in pp]==([0,1,2,3,4,None] if name=='baseline' else [0,1,2,3,4,5,5,5,None])
   assert row['first_five_requests_sha256']==vh([x['request'] for x in pp[:5]])
   assert row['extra_pass_mutations']==(0 if name=='baseline' else 2)
   assert all(x['cleanup_attempt']==5 for x in mm)
 return dict(phase=name,synthetic_guard_attack=guard_attack,rows=16,exit_code=code,errors=summary['errors'],parameters_restored=True,parameter_plumbing_exact=True,first_five_tagging_checked=not guard_attack)
base=OUT/'capture-baseline-synthetic-results';cand=OUT/'capture-candidate-synthetic-results'
checks=[phase('baseline',base),phase('candidate',cand,base)]
for mode in ['settlement_before_receipt','whole_181','extra_91_inclusive','first_five_changed']:
 checks.append(phase('candidate',OUT/('capture-guard-'+mode),base,mode))
main_rejections=[]
original_spec=specpath.read_bytes()
def prerequisite(name,mutate,restore):
 global calls
 calls=0;target=OUT/('prerequisite-'+name)
 mutate()
 argv=[str(path),'--phase','baseline','--spec',str(specpath),'--out',str(target),'--capture',str(CAPTURE)]
 replay.__file__=str(frozen/'scripts/replay_practice_supervisor.py')
 try:
  with patch.dict(sys.modules,mods),patch.object(driver.subprocess,'check_output',fake_git),patch.object(driver,'runtime_files',lambda root:sorted([root/'data/case.json',root/'bot/practice.py'])),patch.object(driver.sys,'argv',argv),patch.object(driver.time,'time',lambda:1792843201.),contextlib.redirect_stdout(io.StringIO()):
   try:driver.main()
   except AssertionError:pass
   else:raise RuntimeError('invalid prerequisite accepted '+name)
  assert calls==0 and not target.exists() and parameters=={'unchanged_parameter':'sentinel'}
 finally:restore()
 main_rejections.append(dict(probe=name,rejected_before_replay_and_output=True))
def wrongcapture():
 v=json.loads(original_spec);v['captures'][0]['capture']=247;specpath.write_text(json.dumps(v))
prerequisite('wrong_capture247',wrongcapture,lambda:specpath.write_bytes(original_spec))
archive=Path(items[0]['archive']);original_rows=(archive/'results.jsonl').read_bytes();original_summary=(archive/'summary.json').read_bytes()
def missinggrid():
 rr=[json.loads(x) for x in original_rows.splitlines()];rr.pop();(archive/'results.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in rr))
 ss=json.loads(original_summary);ss['results_sha256']=sha(archive/'results.jsonl');(archive/'summary.json').write_text(json.dumps(ss))
 v=json.loads(original_spec);v['captures'][0]['archive_sha256']={n:sha(archive/n) for n in ('metadata.json','results.jsonl','summary.json')};specpath.write_text(json.dumps(v))
def restoregrid():
 (archive/'results.jsonl').write_bytes(original_rows);(archive/'summary.json').write_bytes(original_summary);specpath.write_bytes(original_spec)
prerequisite('missing_archive_setting',missinggrid,restoregrid)

# Receipt semantic eligibility counterexample, with all declared hashes updated.
original_input=Path(items[0]['input']).read_bytes();original_metadata=(archive/'metadata.json').read_bytes()
def refresh_spec_hashes():
 value=json.loads(original_spec);value['captures'][0]['input_sha256']=sha(Path(items[0]['input']));value['captures'][0]['archive_sha256']={n:sha(archive/n) for n in ('metadata.json','results.jsonl','summary.json')};specpath.write_text(json.dumps(value))
def restore_eligibility():
 Path(items[0]['input']).write_bytes(original_input);(archive/'metadata.json').write_bytes(original_metadata);specpath.write_bytes(original_spec)
def invalid_receipt(kind):
 data=json.loads(original_input)
 if kind=='running_clock':data['receipt']['clock']['state']='running';data['receipt']['end_clock']['state']='running'
 if kind=='wrong_year':data['receipt']['year']='9999'
 if kind=='no_official_source':data['receipt']['source']='not_an_observer'
 Path(items[0]['input']).write_text(json.dumps(data));meta=json.loads(original_metadata);meta['captures'][0]['receipt_sha256']=vh(data['receipt']);(archive/'metadata.json').write_text(json.dumps(meta));refresh_spec_hashes()
def invalid_provenance():
 meta=json.loads(original_metadata);meta.update(phase='reference',source_revision='unreviewed',source_sha256={},forward=False);(archive/'metadata.json').write_text(json.dumps(meta));refresh_spec_hashes()
accepted_invalid=[]
for problem in ('running_clock','wrong_year','no_official_source','wrong_archive_phase_source'):
 try:
  if problem=='wrong_archive_phase_source':invalid_provenance()
  else:invalid_receipt(problem)
  observed=phase('baseline',OUT/('invalid-accepted-'+problem))
  accepted_invalid.append(dict(problem=problem,expected='reject before replay',observed=observed))
 finally:restore_eligibility()
(OUT/'eligibility-counterexamples.json').write_text(json.dumps(dict(accepted_invalid=accepted_invalid,forbidden_attempts=forbidden,actual_capture_runs=0),indent=2)+'\n')

assert not forbidden
report=dict(driver_sha256=hashlib.sha256(source).hexdigest(),checks=checks,main_prerequisite_rejections=main_rejections,forbidden_outer_attempts=forbidden,actual_history_reads=0,actual_performance_runs=0,synthetic_success_rows=32,synthetic_fault_rows=4*16,notes=['Only synthetic inputs and deterministic replay stubs; no captured-market simulations.','The actual main executes all16 settings and restores parameters on success and latched-guard failure.','Three selected swallowed guard failures remain fatal; first-five drift also fails its row; all other15 rows are retained. Other unchanged safety guards are covered by the original exact-body preflight.'])
(OUT/'capture-probe.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
