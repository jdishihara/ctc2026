from __future__ import annotations
import contextlib,copy,hashlib,importlib.util,io,json,os,sys,types
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
OUT=Path(__file__).resolve().parent;SRC=Path('/Users/arjunhans/Documents/ctc2026/.worktrees/cleanup-retry-forward');forbidden=[]
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):forbidden.append(event);raise RuntimeError('synthetic preflight forbids network')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).absolute();q=p.resolve()
  if any('/data/history' in str(x).lower() or '/recordings/' in str(x).lower() or '/ctc2026/out/' in str(x).lower() or '.botkey' in str(x).lower() or '/.env' in str(x).lower() or 'credentials' in str(x).lower() for x in (p,q)):
   forbidden.append(str(p));raise RuntimeError('synthetic preflight forbids real inputs/credentials')
sys.addaudithook(audit)
sys.path.insert(0,str(SRC))
from scripts import evaluate_observed_season as real_observed,observe_market_seasons as real_observer
from scripts import replay_serialized_client as real_core
REAL_CASE=json.loads((SRC/'data/case.json').read_text())
fixture=OUT/'capture-synthetic-source';frozen=OUT/'capture-synthetic-frozen'
for p in (fixture,frozen):
 for name in ('scripts','ctc','data','docs','bot'):(p/name).mkdir(parents=True,exist_ok=True)
 (p/'data/case.json').write_text(json.dumps(REAL_CASE))
 (p/'ctc/analog.py').write_text('# identical synthetic runtime\n')
 (p/'bot/practice.py').write_text('def reconcile_stop(server):\n for attempt in range('+('5' if p==frozen else '6')+'):\n  server.request("GET", "/positions", {"changed": True} if attempt==1 and server.attack=="first_five_changed" else None)\n  if attempt==4 and server.attack in ("extra_91","extra_91_inclusive","extra_90_expired"):\n   for i in range(90):server.request("DELETE", "/orders/synthetic")\n   if server.attack=="extra_91_inclusive":server.now += 60\n   if server.attack=="extra_90_expired":server.now += 60.00001\n  if attempt==5:\n   server.request("POST", "/orders", {"quantity":1})\n   server.request("DELETE", "/orders/synthetic")\n  if attempt==0 and server.attack=="whole_181":\n   for i in range(181):server.request("POST", "/orders", {"quantity":1})\n server.request("GET", "/post-loop-final-receipt")\n')
source=(SRC/'scripts/compare_cleanup_retry_forward.py').read_bytes();path=fixture/'scripts/compare_cleanup_retry_forward.py';path.write_bytes(source);(fixture/'docs/cleanup-retry-window-plan.md').write_text('synthetic plan only\n')
spec=importlib.util.spec_from_file_location('capture_blend_under_test',path);driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
CAPTURE=int(os.environ.get("REVIEW_CAPTURE","248"));driver.GRID=driver.forward_grid(CAPTURE)
(fixture/'docs/cleanup-retry-forward-plan.md').write_text('synthetic forward plan only\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def vh(v):return hashlib.sha256(json.dumps(v,sort_keys=True,allow_nan=False).encode()).hexdigest()
def result(rtt,depth,basket):return dict(status='ok',errors=[],rtt_seconds=rtt,displayed_depth_fraction=depth,basket_enabled=basket,synthetic_result=True,**{key:None for key in ['stop_reason','stop_at','stop_phase','stop_market_open','monitor_started_at','monitor_detected_at','cleanup_started_at','final_report_rounds','history_block_reason','prefix_messages','client_steps']})
items=[]
for capture in [CAPTURE]:
 data={'frames':[],'receipt':{'competition_id':f'synthetic-{capture}','prices':{'SYNTH':1},'at':1792837800.,'kind':'settlement','source':'read_only_market_observer','year':str(2027-capture),'clock':{'competition_id':f'synthetic-{capture}','state':'ready','fictional_time':str(2027-capture)+'-01-01'},'end_clock':{'competition_id':f'synthetic-{capture}','state':'ready','fictional_time':str(2027-capture)+'-01-01'},'coverage':{'contiguous':True,'final_rounds':[1,2,3]}}}
 cached=OUT/f'capture-{capture}-synthetic-input.json';cached.write_text(json.dumps(data))
 archive=OUT/f'capture-{capture}-synthetic-archive';archive.mkdir()
 rows=[]
 for cap,rtt,depth,basket in driver.GRID:
  if cap!=capture:continue
  rows.append(dict(capture=capture,comparison_status='synthetic_archive',**result(rtt,depth,basket)))
  d=archive/f'capture-{capture}-{rtt}-{depth}-{int(basket)}';d.mkdir()
  for name in driver.JOURNALS:(d/name).write_text('synthetic journal '+name+'\n')
 (archive/'metadata.json').write_text(json.dumps({'captures':[dict(capture=capture,competition_id=data['receipt']['competition_id'],frames_sha256=vh(data['frames']),receipt_sha256=vh(data['receipt']))]}))
 (archive/'results.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
 (archive/'summary.json').write_text(json.dumps(dict(errors=0,mismatches=0,changed_sources=[],results_sha256=sha(archive/'results.jsonl'))))
 items.append(dict(capture=capture,input=str(cached),input_sha256=sha(cached),archive=str(archive),archive_sha256={n:sha(archive/n) for n in ('metadata.json','results.jsonl','summary.json')}))
specpath=OUT/'capture-synthetic-spec.json';specpath.write_text(json.dumps(dict(baseline_root=str(frozen),captures=items)))
parameters={'unchanged_parameter':'sentinel'};seen=[];server_refs=[];attack=None
class FakeServer:
 def __init__(self,*a,**kw):
  self.attack=attack if calls==1 else None;self.requests=[];self.market=SimpleNamespace(fills=[],market_open=True);self.terminal=False;self.now=0.;self.settlement_available_at=10.;self.fatal_errors=[];server_refs.append(self)
 def request(self,method,path,body=None):
  self.requests.append(dict(method=method,path=path,body=copy.deepcopy(body),started_at=self.now,executed_at=self.now,completed_at=self.now,response={}))
  return {}
 def latch(self,exc):self.fatal_errors.append(str(exc))
class FakeSession:
 def __init__(self,*a,**kw):pass
class FakeAnalog:
 def __init__(self,enabled):self.repeat_match=0 if enabled else None
 def weights(self,obs,official,wire,adv=None):return [1.]
class FakeTrader:
 def __init__(self,**kw):
  seen.append(copy.deepcopy(kw));self.kw=kw;self.competition_id='synthetic';self.model=SimpleNamespace(reported_rounds=set(),live_history_ready=True);self.ensemble=None
 def on_quotes(self,exchange):
  if calls==1 and attack=='quote_history':self.model.live_history_ready=False
  return None
class FakeTransport:
 def send(self,*a,**kw):return None
mods={n:types.ModuleType(n) for n in ('scripts','scripts.replay_practice_supervisor','bot','bot.practice','ctc','ctc.strategies','ctc.analog')}
for n in ('scripts','bot','ctc'):mods[n].__path__=[]
replay=mods['scripts.replay_practice_supervisor'];practice=mods['bot.practice'];mods['ctc.strategies'].FairValueTrader=FakeTrader;mods['ctc.analog'].AnalogEnsemble=FakeAnalog
mods['scripts.evaluate_observed_season']=real_observed;mods['scripts.observe_market_seasons']=real_observer;mods['scripts.replay_serialized_client']=real_core
replay.PARAMETERS=parameters;replay.PracticeReplayServer=FakeServer;replay.ServerTransport=FakeTransport;replay.OfflinePracticeExchange=type('SyntheticPractice',(FakeTransport,),{});replay.OfflineCleanupExchange=type('SyntheticCleanup',(FakeTransport,),{})
practice.PracticeSession=FakeSession;current_server=None;practice.finish=lambda journal:practice.reconcile_stop(current_server)
calls=0

def run_stub(case,frames,year,cid,settlement,*,receipt_at,out,rtt,depth_scale,basket):
 global calls,current_server
 calls+=1
 assert case==REAL_CASE and frames==FRAME_FIXTURE and year==str(2027-CAPTURE)
 server=replay.PracticeReplayServer();current_server=server;server.request('GET','/before-cleanup');session=practice.PracticeSession();trader=FakeTrader(**{**replay.PARAMETERS,'basket_edge':.01 if basket else 0})
 session.strat=trader;session.competition_id='synthetic';session._valid_weather_wait=lambda:False
 def reject(fn):
  try:fn()
  except AssertionError:pass
  else:raise AssertionError('guard '+str(attack)+' did not fail')
 if calls==1 and attack in ('quote_identity','quote_history'):
  reject(lambda:trader.on_quotes(SimpleNamespace(competition_id='wrong' if attack=='quote_identity' else 'synthetic')))
  trader.model.live_history_ready=True
 else:trader.on_quotes(SimpleNamespace(competition_id='synthetic'))
 if attack and calls==1:
  if attack in ('settlement_open','settlement_before_receipt','settlement_copy','settlement_shallow_copy','settlement_deep_copy'):
   if attack=='settlement_before_receipt':server.terminal=True;server.market.market_open=False;server.now=9.
   fn={'settlement_open':lambda:settlement['SYNTH'],'settlement_before_receipt':lambda:settlement['SYNTH'],'settlement_copy':settlement.copy,'settlement_shallow_copy':lambda:copy.copy(settlement),'settlement_deep_copy':lambda:copy.deepcopy(settlement)}[attack]
   reject(fn)
  elif attack.startswith('strategy_'):
   exchange=replay.OfflinePracticeExchange();exchange.competition_id='synthetic'
   if attack=='strategy_history':trader.model.live_history_ready=False
   if attack=='strategy_weather_wait':session._valid_weather_wait=lambda:True
   if attack=='strategy_identity':exchange.competition_id='wrong'
   reject(lambda:exchange.send('POST','/orders',{'symbol':'SYNTH','quantity':1,'side':'buy'}))
   trader.model.live_history_ready=True;session._valid_weather_wait=lambda:False
  elif attack.startswith('cleanup_'):
   exchange=replay.OfflineCleanupExchange();exchange.position={'SYNTH':1};exchange.state_ready=True;exchange.market_open=True;exchange.open_orders=[];exchange.expected_id=exchange.competition_id='synthetic'
   body={'symbol':'SYNTH','side':'sell','quantity':1}
   if attack=='cleanup_unready':exchange.state_ready=False
   if attack=='cleanup_closed':exchange.market_open=False
   if attack=='cleanup_working_order':exchange.open_orders=[{}]
   if attack=='cleanup_identity':exchange.expected_id='wrong'
   if attack=='cleanup_side':body['side']='buy'
   if attack=='cleanup_quantity':body['quantity']=2
   if attack=='cleanup_zero':body['quantity']=0
   reject(lambda:exchange.send('POST','/orders',body))
 try:practice.finish(None)
 except AssertionError:pass
 server.terminal=True;server.market.market_open=False;server.now=receipt_at
 assert dict(settlement)==PRICE_FIXTURE
 out.mkdir()
 for name in driver.JOURNALS:(out/name).write_text('synthetic journal '+name+'\n')
 return result(rtt,depth_scale,basket)
replay.replay_supervised=run_stub

def fake_git(args,**kw):
 root=Path(kw.get('cwd'))
 if args[1:3]==['rev-parse','HEAD']:return ({frozen:driver.FROZEN,forward:driver.FORWARD_DRIVER,reference:fwd.FORWARD_REFERENCE_REVISION}.get(root,'synthetic-candidate-revision'))+'\n'
 if args[1]=='status':return b''
 if args[1]=='show':return (root/args[2].split(':',1)[1]).read_bytes()
 raise AssertionError(args)

def phase(name,out,baseline=None,guard_attack=None):
 global calls,attack
 calls=0;seen.clear();server_refs.clear();attack=guard_attack
 runtime=frozen if name=='baseline' else fixture
 replay.__file__=str(runtime/'scripts/replay_practice_supervisor.py')
 namespace={};exec(compile((runtime/'bot/practice.py').read_text(),str(runtime/'bot/practice.py'),'exec'),namespace);practice.reconcile_stop=namespace['reconcile_stop']
 argv=[str(path),'--phase',name,'--spec',str(specpath),'--out',str(out),'--capture',str(CAPTURE)]
 if baseline:argv+=['--baseline',str(baseline)]
 code=0;log=io.StringIO()
 with patch.dict(sys.modules,mods),patch.object(driver.subprocess,'check_output',fake_git),patch.object(driver,'runtime_files',lambda root:sorted([root/'data/case.json',root/'bot/practice.py'])),patch.object(driver.sys,'argv',argv),patch.object(driver.time,'time',lambda:1792843201.),contextlib.redirect_stdout(log):
  try:driver.main()
  except SystemExit as exc:code=exc.code
 (OUT/(out.name+'.stdout.log')).write_text(log.getvalue())
 assert calls==16 and len(seen)==16 and parameters=={'unchanged_parameter':'sentinel'}
 for (_,_,_,basket),kw in zip(driver.GRID,seen):
  expected={'unchanged_parameter':'sentinel','basket_edge':.01 if basket else 0}
  assert kw==expected
 metadata=json.loads((out/'metadata.json').read_text());summary=json.loads((out/'summary.json').read_text());rows=[json.loads(x) for x in (out/'results.jsonl').read_text().splitlines()]
 assert summary['runs']==len(rows)==16 and not summary['forbidden_attempts'] and not summary['changed_sources']
 assert summary['errors']==int(bool(guard_attack and guard_attack!='extra_90_expired')) and code==int(bool(guard_attack and guard_attack!='extra_90_expired')), (summary['errors'],code,guard_attack)
 if guard_attack and guard_attack != 'extra_90_expired':assert len(server_refs[0].fatal_errors)==(0 if guard_attack=='first_five_changed' else 1) and rows[0]['status']=='error'
 if not guard_attack:
  for row in rows:
   d=out/f"capture-{row['capture']}-{row['rtt_seconds']}-{row['displayed_depth_fraction']}-{int(row['basket_enabled'])}"
   pp=json.loads((d/'cleanup-profile.json').read_text());mm=json.loads((d/'mutation-profile.json').read_text())
   assert [x['cleanup_attempt'] for x in pp]==([0,1,2,3,4,None] if name=='baseline' else [0,1,2,3,4,5,5,5,None])
   assert row['first_five_requests_sha256']==vh([x['request'] for x in pp[:5]])
   assert row['extra_pass_mutations']==(0 if name=='baseline' else 2)
   assert all(x['cleanup_attempt']==5 for x in mm)
 return dict(phase=name,synthetic_guard_attack=guard_attack,rows=16,exit_code=code,errors=summary['errors'],parameters_restored=True,parameter_plumbing_exact=True,first_five_tagging_checked=not guard_attack)

# Real official receipt reconstruction and frozen upstream driver/source gate;
# generated frames only, no observed market inputs.
import shutil
forward=OUT/'forward-source';reference=OUT/'reference-source'
loader=importlib.util.spec_from_file_location('original_forward_driver',Path('/Users/arjunhans/Documents/ctc2026/.worktrees/supervised-forward/scripts/compare_practice_supervisor.py'))
fwd=importlib.util.module_from_spec(loader);loader.loader.exec_module(fwd)
actual_forward=Path('/Users/arjunhans/Documents/ctc2026/.worktrees/supervised-forward')
actual_reference=Path('/Users/arjunhans/Documents/ctc2026/.worktrees/serialized-forward')
for actual,copyroot in [(actual_forward,forward),(actual_reference,reference)]:
 names=[p.relative_to(actual) for p in fwd.source_files(actual)]
 if actual==actual_forward:names += [Path(x) for x in ['bot/practice.py','scripts/replay_practice_supervisor.py','scripts/compare_practice_supervisor.py','docs/supervised-replay-plan.md','docs/practice-round-transition-plan.md','docs/supervised-forward-plan.md']]
 for name in names:
  p=copyroot/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(actual/name,p)
year=str(2027-CAPTURE);cid=f'synthetic-{CAPTURE}';t=1792837740.;FRAME_FIXTURE=[]
for rnd in [1,2,3]:
 start=t+(rnd-1)*20
 def news(at,message):FRAME_FIXTURE.append(dict(type='news',received_at=at,message=dict(time=year+'-06-01T00:00:00',round=rnd,**message)))
 news(start,dict(type='snapshot',phase='pre_storm',last_seq=rnd-2))
 for symbol in REAL_CASE['limits']:FRAME_FIXTURE.append(dict(type='quote',received_at=start+1,symbol=symbol,bid=99.,ask=101.,bid_size=10,ask_size=10))
 news(start+2,dict(type='damage_report',stage='final',seq=rnd-1))
 news(start+3,dict(type='snapshot',phase='closed',last_seq=rnd-1))
PRICE_FIXTURE={s:100. for s in REAL_CASE['limits']}
receipt=dict(kind='settlement',at=1792838000.,source='read_only_market_observer',competition_id=cid,year=year,clock=dict(competition_id=cid,state='ready',fictional_time=year+'-06-01T00:00:00'),prices=PRICE_FIXTURE,coverage=dict(contiguous=True,conflicting_sequences=False,final_rounds=[1,2,3],seq_count=3,last_seq=2,advertised_last_seq=2,first_at=t,last_at=FRAME_FIXTURE[-1]['received_at']))
receipt['end_clock']=copy.deepcopy(receipt['clock'])
obs=OUT/'sealed-observations.jsonl';feed=OUT/'sealed-feed.jsonl'
obs.write_text(json.dumps(receipt)+'\n');feed.write_text(''.join(json.dumps(f)+'\n' for f in FRAME_FIXTURE))
validated_receipt,validated_frames,coverage=real_observed.observed_capture(obs,feed,cid,REAL_CASE['limits'])
assert validated_receipt==receipt and validated_frames==FRAME_FIXTURE
corearchive=OUT/'core-archive';corearchive.mkdir();core_results=corearchive/'results.jsonl'
core_results.write_text(''.join(json.dumps(dict(status='ok',rtt_seconds=rtt,displayed_depth_fraction=depth,basket_enabled=basket))+'\n' for _,rtt,depth,basket in driver.GRID))
reference_sources={str(p.relative_to(reference)):sha(p) for p in fwd.source_files(reference)}
core_meta=dict(mode='observed',competition_id=cid,year=year,source_revision=fwd.FORWARD_REFERENCE_REVISION,source_sha256=reference_sources,receipt_sha256=vh(receipt),frames_sha256=vh(FRAME_FIXTURE),official_receipt=receipt,frame_count=len(FRAME_FIXTURE),first_at=FRAME_FIXTURE[0]['received_at'],last_at=FRAME_FIXTURE[-1]['received_at'],receipt_at=receipt['at'],fraction=.1,parameters=real_core.PARAMETERS,rtts=[0.,.05,.25,1.],depths=[1.,.5],baskets=[False,True])
(corearchive/'metadata.json').write_text(json.dumps(core_meta));(corearchive/'summary.json').write_text(json.dumps(dict(runs=16,errors=0,elapsed_seconds=1.)))
original=dict(capture=CAPTURE,mode='observed',competition_id=cid,archive_results=str(core_results),archive_results_sha256=sha(core_results),archive_metadata_sha256=sha(corearchive/'metadata.json'),archive_summary_sha256=sha(corearchive/'summary.json'),observations=str(obs),observations_bytes=obs.stat().st_size,observations_sha256=sha(obs),feed=str(feed),feed_bytes=feed.stat().st_size,feed_sha256=sha(feed))
upstream_spec_path=OUT/'forward-spec.json';upstream_spec=dict(reference_root=str(reference),reference_revision=fwd.FORWARD_REFERENCE_REVISION,captures=[original]);upstream_spec_path.write_text(json.dumps(upstream_spec))
runtime={str(p):sha(p) for p in [p for p in fwd.source_files(forward) if p.relative_to(forward).parts[0]!='docs']+[forward/'bot/practice.py',forward/'scripts/replay_practice_supervisor.py']}
dependencies=fwd.source_files(forward)+[forward/'bot/practice.py',forward/'scripts/replay_practice_supervisor.py',forward/'scripts/compare_practice_supervisor.py',forward/'docs/supervised-replay-plan.md',forward/'docs/practice-round-transition-plan.md',upstream_spec_path,forward/'docs/supervised-forward-plan.md',obs,feed,core_results,corearchive/'metadata.json',corearchive/'summary.json',*[Path(p) for p in runtime]]
metadata=dict(phase='supervised',source_revision=driver.FORWARD_DRIVER,source_sha256={str(p):sha(p) for p in dependencies},spec=upstream_spec,grid=[list(x) for x in fwd.GRID],fraction=.1,loss_trigger=250.,prior_pnl=0.,forward=True,driver_revision=driver.FORWARD_DRIVER,driver_sha256=sha(forward/'scripts/compare_practice_supervisor.py'),runtime_revision=driver.FROZEN,runtime_sha256=runtime,forward_plan_sha256=sha(forward/'docs/supervised-forward-plan.md'),forward_plan_revision=driver.FORWARD_DRIVER,started_at=1792838100.,captures=[dict(capture=CAPTURE,competition_id=cid,year=year,coverage=coverage,receipt_sha256=vh(receipt),frames_sha256=vh(FRAME_FIXTURE),archive_sha256=sha(core_results),receipt_at=receipt['at'],first_at=FRAME_FIXTURE[0]['received_at'],last_at=FRAME_FIXTURE[-1]['received_at'],frame_count=len(FRAME_FIXTURE))])
archive=Path(items[0]['archive']);cached=Path(items[0]['input'])
cached.write_text(json.dumps(dict(frames=FRAME_FIXTURE,receipt=receipt)))
(archive/'metadata.json').write_text(json.dumps(metadata))
rr=[json.loads(x) for x in (archive/'results.jsonl').read_text().splitlines()]
for row in rr:row['comparison_status']='supervised_after_verified_baseline'
(archive/'results.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rr))
summary=dict(runs=16,errors=0,mismatches=0,changed_sources=[],finished_at=1792838200.,results_sha256=sha(archive/'results.jsonl'))
(archive/'summary.json').write_text(json.dumps(summary))
items[0].update(input_sha256=sha(cached),forward_spec=str(upstream_spec_path),archive_sha256={n:sha(archive/n) for n in ('metadata.json','results.jsonl','summary.json')})
specpath.write_text(json.dumps(dict(baseline_root=str(frozen),forward_root=str(forward),captures=items)))
base=OUT/'baseline-valid';cand=OUT/'candidate-valid'
checks=[phase('baseline',base),phase('candidate',cand,base)]
for mode in ['settlement_before_receipt','whole_181','extra_91_inclusive','first_five_changed']:
 checks.append(phase('candidate',OUT/('guard-'+mode),base,mode))
# Malformed eligibility must fail before producing output or invoking replay.
original_spec=specpath.read_bytes();saved={p:p.read_bytes() for p in [cached,archive/'metadata.json',archive/'summary.json',archive/'results.jsonl',obs,feed,upstream_spec_path,corearchive/'metadata.json',corearchive/'summary.json',core_results]}
rejections=[]
def attempt(name,mutate,now=1792843201.):
 global calls
 calls=0;target=OUT/('rejected-'+name)
 mutate()
 # These are intentional consistent artifact edits, to reach semantic gates.
 specvalue=json.loads(original_spec);specvalue['captures'][0]['input_sha256']=sha(cached);specvalue['captures'][0]['archive_sha256']={n:sha(archive/n) for n in ('metadata.json','results.jsonl','summary.json')};specpath.write_text(json.dumps(specvalue))
 replay.__file__=str(frozen/'scripts/replay_practice_supervisor.py')
 argv=[str(path),'--phase','baseline','--spec',str(specpath),'--out',str(target),'--capture',str(CAPTURE)]
 error=None
 try:
  with patch.dict(sys.modules,mods),patch.object(driver.subprocess,'check_output',fake_git),patch.object(driver,'runtime_files',lambda root:sorted([root/'data/case.json',root/'bot/practice.py'])),patch.object(driver.sys,'argv',argv),patch.object(driver.time,'time',lambda:now),contextlib.redirect_stdout(io.StringIO()):
   try:driver.main()
   except (AssertionError,ValueError,KeyError,TypeError,OSError) as exc:error=f'{type(exc).__name__}: {exc}'
  assert error is not None and calls==0 and not target.exists(), (name,error,calls)
  rejections.append(dict(name=name,error=error,replay_calls=0,output_created=False))
 finally:
  for p,b in saved.items():p.write_bytes(b)
  specpath.write_bytes(original_spec)
def edit_receipt(change):
 data=json.loads(saved[cached]);change(data['receipt']);cached.write_text(json.dumps(data));meta=json.loads(saved[archive/'metadata.json']);meta['captures'][0]['receipt_sha256']=vh(data['receipt']);(archive/'metadata.json').write_text(json.dumps(meta))
def edit_meta(**kw):
 v=json.loads(saved[archive/'metadata.json']);v.update(kw);(archive/'metadata.json').write_text(json.dumps(v))
def edit_summary(**kw):
 v=json.loads(saved[archive/'summary.json']);v.update(kw);(archive/'summary.json').write_text(json.dumps(v))
for name,change in [
 ('running_clocks',lambda r:(r['clock'].update(state='running'),r['end_clock'].update(state='running'))),
 ('wrong_year',lambda r:r.update(year='9999')),('wrong_source',lambda r:r.update(source='not_an_observer')),
 ('wrong_cid',lambda r:r.update(competition_id='other')),('missing_symbol',lambda r:r['prices'].pop(next(iter(r['prices'])))),
 ('invalid_price',lambda r:r['prices'].update(PORT=float('nan'))),('incomplete_coverage',lambda r:r['coverage'].update(contiguous=False)),
 ('before_declaration',lambda r:r.update(at=1792837692.999)),('cutoff_equal',lambda r:r.update(at=1792843200.)),('cutoff_after',lambda r:r.update(at=1792843200.001))]:
 attempt(name,lambda change=change:edit_receipt(change))
attempt('future_receipt',lambda:None,now=1792837999.)
for field,value in [('phase','reference'),('forward',False),('source_revision','unreviewed'),('source_sha256',{}),('driver_revision','wrong'),('runtime_revision','wrong'),('runtime_sha256',{}),('fraction',1.),('loss_trigger',500.),('prior_pnl',1.),('grid',[]),('forward_plan_revision','wrong')]:attempt('metadata_'+field,lambda field=field,value=value:edit_meta(**{field:value}))
for field,value in [('runs',15),('errors',1),('mismatches',1),('changed_sources',['x']),('forbidden_attempts',['network']),('finished_at',float('nan')),('finished_at',1792838099.)]:attempt('summary_'+field,lambda field=field,value=value:edit_summary(**{field:value}))
attempt('sealed_feed_changed',lambda:feed.write_text(saved[feed].decode()+'{}\n'))
attempt('sealed_observations_changed',lambda:obs.write_text(saved[obs].decode()+'{}\n'))
attempt('cached_frames_changed',lambda:cached.write_text(json.dumps(dict(json.loads(saved[cached]),frames=[]))))
attempt('serialized_predecessor_changed',lambda:core_results.write_text(saved[core_results].decode()+'{}\n'))
def corrupt_rows():
 rows=[json.loads(x) for x in saved[archive/'results.jsonl'].splitlines()];rows[0]=copy.deepcopy(rows[1]);(archive/'results.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in rows));edit_summary(results_sha256=sha(archive/'results.jsonl'))
attempt('duplicate_upstream_row',corrupt_rows)
assert not forbidden
report=dict(head='2c441aee5b5f828bc4c4e26461159a958c102067',capture=CAPTURE,actual_main_checks=checks,eligibility_rejections=rejections,upstream_dependencies=len(set(dependencies)),source_runtime_roots='Temporary byte copies of frozen code; fake git returns those fixture blobs/heads.',synthetic_capture_source='Handwritten closed three-round feed; real official_receipt and observed_capture used.',forbidden_attempts=forbidden,actual_capture_runs=0)
(OUT/'corrected-review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(capture=CAPTURE,main_phases=len(checks),rows_per_phase=16,rejected_before_replay=len(rejections),forbidden_attempts=forbidden,actual_capture_runs=0)))
