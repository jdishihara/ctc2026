import ast,hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/Users/arjunhans/Documents/ctc2026/.worktrees/cleanup-retry-forward');OUT=Path(__file__).parent
HEAD='2c441aee5b5f828bc4c4e26461159a958c102067';OLD='27ab7c4b4784c9aabc92e791b0878d387cd4cc49'
forbidden=[]
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo','socket.bind'):forbidden.append(event);raise RuntimeError('network denied')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).absolute();q=p.resolve()
  if any(any(x in str(n).lower() for x in ('/data/history/','/recordings/','/ctc2026/out/','.botkey','/.env','credentials')) for n in (p,q)):
   forbidden.append(str(p));raise RuntimeError('actual inputs and credentials denied')
sys.addaudithook(audit)
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain')
old=git('show',OLD+':scripts/compare_cleanup_retry.py').decode();new=(ROOT/'scripts/compare_cleanup_retry_forward.py').read_text();assert new.encode()==git('show',HEAD+':scripts/compare_cleanup_retry_forward.py')
oldtree,newtree=ast.parse(old),ast.parse(new);oldmain=next(x for x in oldtree.body if isinstance(x,ast.FunctionDef) and x.name=='main');newmain=next(x for x in newtree.body if isinstance(x,ast.FunctionDef) and x.name=='main');oldcheck=next(x for x in oldmain.body if isinstance(x,ast.Assert) and 'spec[' in ast.unparse(x.test))
class Normalize(ast.NodeTransformer):
 def visit_Expr(self,n):
  if isinstance(n.value,ast.Call):
   c=n.value
   if isinstance(c.func,ast.Name) and c.func.id in ('validate_forward_receipt','verify_upstream'):return None
   if isinstance(c.func,ast.Attribute) and c.func.attr=='add_argument' and c.args and isinstance(c.args[0],ast.Constant) and c.args[0].value=='--capture':return None
  return self.generic_visit(n)
 def visit_Assign(self,n):
  if any(isinstance(t,ast.Name) and t.id in ('GRID','case_definition') for t in n.targets):return None
  return self.generic_visit(n)
 def visit_Assert(self,n):
  if 'spec[' in ast.unparse(n.test) and '[args.capture]' in ast.unparse(n.test):return oldcheck
  return self.generic_visit(n)
 def visit_List(self,n):
  n.elts=[e for e in n.elts if ast.unparse(e)!="ROOT / 'docs/cleanup-retry-forward-plan.md'"];return self.generic_visit(n)
assert ast.dump(oldmain,include_attributes=False)==ast.dump(Normalize().visit(newmain),include_attributes=False)
namespace={};exec(compile(ast.Module(body=[x for x in oldtree.body if isinstance(x,ast.FunctionDef) and x.name=='runtime_files'],type_ignores=[]),'<runtime-list>','exec'),namespace)
rows=[]
for p in namespace['runtime_files'](ROOT):
 name=p.relative_to(ROOT).as_posix();before=git('show',OLD+':'+name);after=git('show',HEAD+':'+name)
 assert before==after==p.read_bytes();rows.append(dict(path=name,sha256=hashlib.sha256(after).hexdigest()))
sourcehashes={}
for name in ['scripts/compare_cleanup_retry_forward.py','tests/test_cleanup_retry_forward.py','docs/cleanup-retry-forward-plan.md']:
 data=git('show',HEAD+':'+name);assert data==(ROOT/name).read_bytes();sourcehashes[name]=hashlib.sha256(data).hexdigest();dest=OUT/'reviewed-source'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
result=dict(head=HEAD,runtime_parent=OLD,runtime_files_identical=len(rows),runtime_blobs_verified=2*len(rows),runtime_file_sha256=rows,original_main_body_exact_after_declared_input_gate_additions=True,current_clean=True,source_sha256=sourcehashes,forbidden_attempts=forbidden,actual_capture_runs=0,actual_inputs_read=False)

# Independently verify the real frozen provenance roots, using only source files.
import importlib.util
forward=Path('/Users/arjunhans/Documents/ctc2026/.worktrees/supervised-forward');reference=Path('/Users/arjunhans/Documents/ctc2026/.worktrees/serialized-forward')
def frozen_git(root,*args):return subprocess.check_output(['git',*args],cwd=root)
c5='c5c35a30e0c5f521f12324eec854f405b681b8c0';ref='505a5ad2d5a6f81e7c711cb550871ce7aa7f3734'
assert frozen_git(forward,'rev-parse','HEAD').decode().strip()==c5 and not frozen_git(forward,'status','--porcelain')
assert frozen_git(reference,'rev-parse','HEAD').decode().strip()==ref and not frozen_git(reference,'status','--porcelain')
driver=forward/'scripts/compare_practice_supervisor.py';assert driver.read_bytes()==frozen_git(forward,'show',c5+':scripts/compare_practice_supervisor.py')
sp=importlib.util.spec_from_file_location('frozen_source_review',driver);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
verified_upstream=[]
for root,revision in [(forward,c5),(reference,ref)]:
 paths=m.source_files(root)
 if root==forward:paths += [root/x for x in ['bot/practice.py','scripts/replay_practice_supervisor.py','scripts/compare_practice_supervisor.py','docs/supervised-replay-plan.md','docs/practice-round-transition-plan.md','docs/supervised-forward-plan.md']]
 for path in sorted(set(paths)):
  relative=path.relative_to(root).as_posix();data=path.read_bytes();assert data==frozen_git(root,'show',revision+':'+relative);verified_upstream.append(dict(revision=revision,path=relative,sha256=hashlib.sha256(data).hexdigest()))
verified_runtime=m.verify_forward_runtime(forward)
result.update(upstream_source_blobs_verified=len(verified_upstream),upstream_source_sha256=verified_upstream,upstream_cd3_runtime_files_verified=len(verified_runtime),upstream_frozen_roots_clean=True)

(OUT/'static-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('runtime_file_sha256','source_sha256','upstream_source_sha256')}))
