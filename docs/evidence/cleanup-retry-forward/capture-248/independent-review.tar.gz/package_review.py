"""Seal completed capture-248 independent audit; no evaluation execution."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

ROOT=Path('/Users/arjunhans/Documents/ctc2026')
OUT=Path(__file__).parent
PARENT=ROOT/'out/cleanup-retry-forward-20261024'
RUN=PARENT/'capture-248'
SOURCE=ROOT/'.worktrees/cleanup-retry-forward'
REV='2c441aee5b5f828bc4c4e26461159a958c102067'
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_bytes())
audit=load(OUT/'audit.json');reruns=load(OUT/'authorized-reruns/independent-reruns.json');trace=load(OUT/'analysis-trace-check.json')
assert audit['source_revision']==REV and audit['forbidden_attempts']==reruns['forbidden_attempts']==[]
assert reruns['authorized_settings']==reruns['successful_reproductions']==2 and reruns['successful_cases_reused_from_previous_invocation']==0
assert trace['all_32_analyzer_pair_descriptions_exact'] is True
assert subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip()==REV
assert not subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'])
for path,h in audit['source_input_sha256'].items():assert sha(Path(path).read_bytes())==h
for path,h in audit['produced_files_sha256'].items():assert sha(Path(path).read_bytes())==h

def cp(src,relative):
    dst=OUT/relative;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
    assert dst.read_bytes()==Path(src).read_bytes()

for phase in ['baseline','candidate']:
    for p in (RUN/phase).rglob('*'):
        if p.is_file():cp(p,Path('producer')/phase/p.relative_to(RUN/phase))
    for name in [phase+'.stderr.log',phase+'.stdout.log']:cp(RUN/name,Path('producer')/name)
for name in ['spec.json','analysis.json','analysis.stderr.log']:cp(RUN/name,Path('producer')/name)
for name in ['analyze.py','248-seal.stdout.json','248-seal.stderr.log','seal-input.py','preflight-final-approved.tar.gz','preflight-initial-rejected.tar.gz']:
    cp(PARENT/name,Path('producer')/name)
cp(ROOT/'out/capture-248-independent-review-20261024.tar.gz','original-capture-audit.tar.gz')
for name in ['README.md','audit.json','verification.json','artifact-hashes.json']:
    cp(ROOT/'out/capture-248-independent-review-20261024'/name,Path('original-audit-summary')/name)
for name in ['bot/practice.py','scripts/compare_cleanup_retry_forward.py','docs/cleanup-retry-window-plan.md','docs/cleanup-retry-forward-plan.md']:
    cp(SOURCE/name,Path('reviewed-source')/name)
(OUT/'capture-248-attempts.jsonl').write_text(''.join(json.dumps(e,sort_keys=True)+'\n' for e in audit['attempt_events']))
verdict={
    'verdict':'PASS_PREDECLARED_CAPTURE_248_NO_OP_CONFIRMATION_NO_LIVE_ACTIVATION',
    'source_revision':REV,'runtime_revision':'27ab7c4b4784c9aabc92e791b0878d387cd4cc49',
    'blockers':[],'settings_per_phase':16,'rows_verified':32,'original_rows_exact':16,'original_journals_byte_exact':112,
    'produced_files_verified':288,'source_input_artifacts_verified':244,'bound_baseline_artifacts':147,
    'paired_runtime_results_identical':16,'paired_standard_journals_byte_identical':112,
    'cleanup_profile_differences':'Only source stack line numbers; requests and all other profile values equal.',
    'metrics':audit['metrics'],'total_actual_mutations_per_phase':audit['total_mutations'],'maximum_rolling_mutations':25,
    'cleanup_mutations':0,'extra_pass_mutations':0,'positive':16,'negative':0,'completed':16,'settled':16,'attention':0,
    'candidate_primary_terminal_pnl':985.54,'candidate_primary_final_mark_pnl':986.42,'primary_settled_not_flat':True,
    'primary_nonzero_settled_holdings':audit['primary_settled_positions'],
    'authorized_unique_candidate_reproductions':2,'candidate_replay_executions':2,'duplicate_candidate_replay_executions':0,
    'representative_exact_files':18,'representative_cases':trace['full_trace_cases'],'new_original_engine_reproductions':0,
    'guard_counters':reruns['counters_for_this_resume'],'forbidden_attempts':[],'runtime_or_replay_failures':[],
    'retained_audit_harness_failures':[{'invocation':1,'type':'read-only provenance assertion',
        'reason':'Initially expected a direct reference-results hash on the supervised phase. The schema binds supervised to baseline and baseline to reference. Corrected the independent assertion to verify both links; failed script/log retained. No performance rerun.'}],
    'source_unchanged':True,'timing':audit['timing'],'training_overlap':audit['original_weather_overlap'],
    'original_audit_archive_sha256':audit['original_audit_archive_sha256'],'original_audit_archive_files':203,
    'approved_preflight_sha256':'e9ab0c1026422fb42155f5957476f6296a0fffc4658a6b6a1c8119e380c6c142','approved_preflight_files':359,
    'initial_rejected_preflight_sha256':'fa281c52dab08a04d6f7a90f4f1a5a996180e3612ee91dcfbc702a86c26c4948','initial_rejected_preflight_files':134,
    'analyzer_sha256':'6db56e6d7a72b0c770858c33723a1d58713dd1b17ad79bb222b6caca8f56ec75',
    'analysis_sha256':'986ed5f54fc76fb6a1632231dbc17d93de9ef28c1dadef77f58ecf28dd887868',
    'analysis_pair_descriptions_independently_checked':32,'other_reported_analyzer_synthetic_checks_not_repeated':27,
    'declined_to_judge':['Live ownership, orders, activation or actual account returns.',
        'Extra-pass effectiveness on this capture; no setting reached extra mutation processing.',
        'Unseen-weather generalization or a fully prospective capture; fitted rows 741-743 and interval predates freezes.',
        'Quote completeness, disconnect onset, live queue priority, market impact or consistent profitability.',
        'Any capture-249 or later outcome, alternative settings or new strategy parameters.'],
    'evidence_sha256':{n:sha((OUT/n).read_bytes()) for n in ['audit.json','analysis-trace-check.json','authorized-reruns/independent-reruns.json']}}
(OUT/'verdict.json').write_text(json.dumps(verdict,indent=2,sort_keys=True)+'\n')
(OUT/'README.md').write_text('''# Independent capture-248 bounded-retry result audit

## Judgment

**Pass the predeclared capture-248 no-op confirmation. No blocker to the previously approved integration was found. This is not live activation approval.** Source remains frozen at `2c441aee5b5f828bc4c4e26461159a958c102067`, with all 28 runtime files byte-identical to the already reviewed retry source `27ab7c4`.

## Complete comparison

Both phases contain the complete 16-setting grid: RTT 0/0.05/0.25/1 seconds, full/half displayed depth, baskets off/on, 10% limits, 90 strategy actions/minute, zero prior P&L and the $250 sampled loss trigger. All 32 rows and all 288 produced files/profiles verify. The baseline reproduces every original result field and all 112 original standard journals; the candidate preserves every runtime field and all 112 paired standard journals. All 16 mutation profiles are byte-identical. Cleanup profiles differ only in source stack line numbers introduced by the frozen code delta; their request contents are equal.

Both modes have 16 positive, completed, settled outcomes and zero attention cases. Mean terminal P&L is $897.993125; the range is $295.45 to $1,224.03. Primary terminal P&L is $985.54. The primary's contemporaneous final mark is $986.42 and it retains seven settled holdings, so it is not flat. No value is an actual account return.

All pre-cleanup and first-five hashes and stopping fields match. Across each complete phase, 1,376 actual POST/DELETE starts are represented, with a maximum inclusive trailing-60-second count of 25. No cleanup mutation or extra-pass mutation occurs. This capture adds a no-op compatibility check, not evidence of additional retry effectiveness.

All 32 analyzer pair descriptions, complete metrics, primary selection and no-regression decisions were independently derived from rows/profiles and match the frozen analyzer output. The supplied analyzer SHA matches; the separate reviewer's reported 27 synthetic analyzer checks were not rerun here.

## Exactly two authorized candidate reproductions

| Setting | Terminal P&L | Requests | Fills | Actual mutations | Maximum rolling mutations |
| --- | ---: | ---: | ---: | ---: | ---: |
| 0.25 s / full / baskets on | $985.54 | 4,557 | 61 | 80 | 9 |
| 1 s / half / baskets off | $295.45 | 2,204 | 59 | 67 | 7 |

Each reproduction matches every result field and all nine producer files, for 18 byte-exact files. Full request traces including GET response bodies and full fill traces are retained. Independent fill cash, ETF inventory transfers and terminal holdings reconcile the final P&L. Both runs have zero sticky guard violations. Guards check terminal-price availability, complete model/news readiness, competition identity, unchanged quote callback history, true execution-time cleanup reduction, rolling mutations and extra-pass budget admission. Across these two runs, there were 72 guarded settlement value reads and 116 history-ready strategy POST checks. There were zero cleanup POST checks or extra-budget checks because neither run used those paths.

Only these two settings were executed, once each. No new original-engine performance run occurred. The original audit's six reproductions are reused through its verified 203-file archive.

## Source, input and chronological checks

The complete 244-entry source/input manifest was independently reconstructed and hashed before/after. Current files match frozen Git blobs in the retry, original runtime, original forward driver and reference checkouts. Candidate metadata binds all 147 completed baseline artifacts. Both phases' chronology follows the fully completed original reference -> baseline -> supervised chain. The sealed observation/feed prefixes match exact byte lengths and hashes; parsing them reconstructs the identical 25,213 cached frames and official ready receipt. The complete news sequence is 0..864 with all three final reports.

- First selected frame: epoch 1792835258.5583282 (09:47:38.558 UTC).
- Retry runtime freeze: epoch 1792836560 (10:09:20 UTC).
- Follow-up declaration: epoch 1792837693 (10:28:13 UTC).
- Corrected driver freeze: epoch 1792838017 (10:33:37 UTC).
- Official closing receipt: epoch 1792838086.3271759 (10:34:46.327 UTC).
- Baseline execution: epochs 1792838454.9809642–1792838484.4532769.
- Candidate execution: epochs 1792838511.802965–1792838540.572074.

The corrected driver froze 69.327 seconds before the receipt, but the selected capture began before the runtime/declaration/driver freezes. This is not a fully prospective capture. The original independently verified weather audit finds exact 241-observation matches to fitted library rows 741, 742 and 743; it provides no unseen-weather validation. That audit is bound to the identical canonical frame and receipt hashes here, without an additional weather or original-engine performance run.

Recorded quote completeness remains unproven. The original audit records approximately 120.318 seconds from the first round-one snapshot to valid quotes, a later valid-quote gap of 52.438 seconds, and unknown disconnect count. These limitations remain relevant even though every prescribed result is positive.

## Failure retention

The initial rejected forward-driver preflight archive (134 files), corrected approved preflight archive (359 files, including the rejected archive), and their counterexamples remain retained. Their source heads and hashes verify.

This result audit's first read-only provenance pass failed because its harness initially expected the supervised metadata to include a direct reference-results hash. The actual schema binds supervised -> baseline -> reference. The corrected audit verifies both links. The first script and failure logs are retained. This caused no performance rerun and changed no production file. Both authorized candidate reruns passed on their first execution.

## Declined to judge

- Live ownership, activation, actual account returns or consistent profitability.
- Extra-pass effectiveness on this capture, because no such mutation occurred.
- Unseen-weather generalization or fully prospective validation.
- True quote completeness, disconnect onset, live priority, latency and market impact.
- Capture 249 or later outcomes, other settings, or strategy/model changes.

## Evidence

`verdict.json` is the final judgment. `audit.json` retains complete source/input/file hashes, rows, budgets, chronology, sealed-input checks and the original audit binding. `analysis-trace-check.json` checks all analyzer descriptors and both full traces. `authorized-reruns/` retains exactly two reproductions. `producer/` contains all 288 phase files, metadata/results/summaries, analysis, specification, logs and preflight archives. `original-capture-audit.tar.gz` preserves the independent original-engine/weather evidence. `artifact-manifest.json` seals this review and `archive-receipt.json` records its archive hash.
''')
for path,h in audit['source_input_sha256'].items():assert sha(Path(path).read_bytes())==h
assert subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip()==REV
assert not subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'])
exclude={'artifact-manifest.json','independent-review.tar.gz','archive-receipt.json'}
files={str(p.relative_to(OUT)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(OUT.rglob('*')) if p.is_file() and str(p.relative_to(OUT)) not in exclude}
(OUT/'artifact-manifest.json').write_text(json.dumps({'head':REV,'files':files,'payload_files':len(files),'candidate_performance_runs':2,'other_performance_runs':0},indent=2,sort_keys=True)+'\n')
archive=OUT/'independent-review.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
    for n in sorted(set(files)|{'artifact-manifest.json'}):tf.add(OUT/n,arcname=n,recursive=False)
with tarfile.open(archive) as tf:packed={m.name:tf.extractfile(m).read() for m in tf.getmembers() if m.isfile()}
assert set(packed)==set(files)|{'artifact-manifest.json'}
for n,h in files.items():assert sha(packed[n])==h['sha256'] and len(packed[n])==h['bytes']
receipt={'path':str(archive),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'regular_files':len(packed),
         'source_revision':REV,'verdict_sha256':sha((OUT/'verdict.json').read_bytes())}
(OUT/'archive-receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps(receipt,sort_keys=True))
