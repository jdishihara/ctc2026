"""Independent closed capture-248 audit; never runs a strategy or performance case."""
from pathlib import Path, PurePosixPath
from collections import Counter, deque
import hashlib
import itertools
import json
import math
import statistics
import subprocess
import sys
import tarfile

ROOT=Path('/Users/arjunhans/Documents/ctc2026')
SOURCE=ROOT/'.worktrees/cleanup-retry-forward'
BASE=ROOT/'.worktrees/practice-history'
FORWARD=ROOT/'.worktrees/supervised-forward'
REFERENCE=ROOT/'.worktrees/serialized-forward'
PARENT=ROOT/'out/cleanup-retry-forward-20261024'
RUN=PARENT/'capture-248'
OUT=Path(__file__).parent
REV='2c441aee5b5f828bc4c4e26461159a958c102067'
BASE_REV='cd3eb239bd7bad97b34f10a8f2bb0b2e1c0f5026'
FORWARD_REV='c5c35a30e0c5f521f12324eec854f405b681b8c0'
REFERENCE_REV='505a5ad2d5a6f81e7c711cb550871ce7aa7f3734'
RUNTIME_REV='27ab7c4b4784c9aabc92e791b0878d387cd4cc49'
CID='789097b1-a48b-4e68-95b4-5e15b047e149'
GRID=set(itertools.product([248],[0.,.05,.25,1.],[1.,.5],[False,True]))
JOURNALS=['observations.json','actions.jsonl','status.json','final-receipt.json','startup-feed.jsonl','result.json','run.lock']
FILES=JOURNALS+['cleanup-profile.json','mutation-profile.json']
FORBIDDEN=[]
sys.dont_write_bytecode=True

def guard(event,args):
    if event.startswith('socket.'):
        FORBIDDEN.append('network');raise RuntimeError('network forbidden')
    if event=='open' and isinstance(args[0],(str,bytes)):
        p=str(args[0]).lower()
        if any(s in p for s in ('.botkey','/.env','credentials','/data/history/','/secrets/','/249.json','/capture-249')):
            FORBIDDEN.append('restricted data');raise RuntimeError('credentials, history, later capture forbidden')
sys.addaudithook(guard)

def sha(b):return hashlib.sha256(b).hexdigest()
def digest(p):return sha(Path(p).read_bytes())
def load(p):return json.loads(Path(p).read_bytes())
def vh(x):return sha(json.dumps(x,sort_keys=True,allow_nan=False).encode())
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args])
def close(a,b):assert math.isclose(a,b,rel_tol=0,abs_tol=1e-8),(a,b)
def key(r):return tuple(r[x] for x in ['capture','rtt_seconds','displayed_depth_fraction','basket_enabled'])
def dirname(k):return f'capture-{k[0]}-{k[1]}-{k[2]}-{int(k[3])}'
def rows(p):
    b=Path(p).read_bytes();assert b.endswith(b'\n');return [json.loads(s) for s in b.splitlines()]
def finite(x):
    if isinstance(x,float):assert math.isfinite(x)
    elif isinstance(x,dict):
        for v in x.values():finite(v)
    elif isinstance(x,list):
        for v in x:finite(v)
def verify_tar(path,expected_count,expected_hash):
    assert digest(path)==expected_hash
    with tarfile.open(path) as tf:
        ms=tf.getmembers();assert len(ms)==len({m.name for m in ms})
        for m in ms:
            assert m.isfile() or m.isdir()
            n=PurePosixPath(m.name);assert not n.is_absolute() and '..' not in n.parts
        packed={m.name:tf.extractfile(m).read() for m in ms if m.isfile()}
    assert len(packed)==expected_count
    manifest_name='artifact-manifest.json' if 'artifact-manifest.json' in packed else 'artifact-hashes.json'
    manifest=json.loads(packed[manifest_name]);entries=manifest.get('files',manifest)
    assert set(entries)==set(packed)-{manifest_name}
    for n,x in entries.items():
        assert sha(packed[n])==(x['sha256'] if isinstance(x,dict) else x)
        if isinstance(x,dict) and 'bytes' in x:assert len(packed[n])==x['bytes']
    return packed

def main():
    assert __debug__
    for root,rev in [(SOURCE,REV),(BASE,BASE_REV),(FORWARD,FORWARD_REV),(REFERENCE,REFERENCE_REV)]:
        assert git(root,'rev-parse','HEAD').decode().strip()==rev
        assert not git(root,'status','--porcelain','--untracked-files=no')
    assert digest(RUN/'spec.json')=='208fbe3d11c589cc2aedced9fe390609c0020e2f5eb3288eec51b94c277a88b6'
    assert digest(PARENT/'analyze.py')=='6db56e6d7a72b0c770858c33723a1d58713dd1b17ad79bb222b6caca8f56ec75'
    assert digest(RUN/'analysis.json')=='986ed5f54fc76fb6a1632231dbc17d93de9ef28c1dadef77f58ecf28dd887868'
    spec=load(RUN/'spec.json');assert [x['capture'] for x in spec['captures']]==[248]
    assert spec['baseline_root']==str(BASE) and spec['forward_root']==str(FORWARD)
    entry=spec['captures'][0];original=Path(entry['archive']);upstream_spec=load(entry['forward_spec'])
    item=upstream_spec['captures'][0];assert len(upstream_spec['captures'])==1 and item['capture']==248 and item['competition_id']==CID
    assert upstream_spec['reference_root']==str(REFERENCE) and upstream_spec['reference_revision']==REFERENCE_REV
    assert digest(entry['input'])==entry['input_sha256']
    data=load(entry['input']);receipt=data['receipt'];frames=data['frames']
    assert receipt['competition_id']==CID and receipt['year']=='1779' and receipt['kind']=='settlement'
    assert receipt['source']=='read_only_market_observer' and 1792837693<=receipt['at']<1792843200
    case=load(SOURCE/'data/case.json')
    assert set(receipt['prices'])==set(case['limits']) and all(type(p) in (int,float) and math.isfinite(p) and p>0 for p in receipt['prices'].values())
    for c in ['clock','end_clock']:
        assert receipt[c]['competition_id']==CID and receipt[c]['state']=='ready' and receipt[c]['fictional_time'].startswith('1779-')
    coverage=receipt['coverage'];assert coverage['contiguous'] is True and coverage['conflicting_sequences'] is False
    assert coverage['seq_count']==coverage['last_seq']+1==coverage['advertised_last_seq']+1==865
    assert coverage['final_rounds']==[1,2,3]
    assert frames[0]['received_at']==coverage['first_at'] and frames[-1]['received_at']==coverage['last_at']<=receipt['at']
    assert vh(frames)=='444689d84a43c4a3bb8f41ebed810599bc236ae345699930cdc950516c919475'
    assert vh(receipt)=='7b91d8fdaae8b25a125e9285cc8fb8a5a5d4cf60c69499f383965c6cc3480280'
    sealed={}
    for field in ('observations','feed'):
        p=Path(item[field]);raw=p.read_bytes()
        assert raw.endswith(b'\n') and len(raw)==item[field+'_bytes'] and sha(raw)==item[field+'_sha256']
        sealed[field]={'path':str(p),'bytes':len(raw),'sha256':sha(raw)}
    metas={phase:load(RUN/phase/'metadata.json') for phase in ('baseline','candidate')}
    summaries={phase:load(RUN/phase/'summary.json') for phase in ('baseline','candidate')}
    source_map=metas['baseline']['source_sha256']
    assert len(source_map)==244 and source_map==metas['candidate']['source_sha256']
    before={p:digest(p) for p in source_map};assert before==source_map
    runtime_names=['data/case.json','bot/live.py','bot/http_transport.py','bot/control.py','bot/practice.py',
        'scripts/replay_practice_supervisor.py','scripts/replay_serialized_client.py','scripts/replay_captured_market.py',
        'scripts/evaluate_observed_season.py','scripts/observe_market_seasons.py','scripts/experiment_execution_costs.py']
    runtime_names += [str(p.relative_to(BASE)) for ext in ['*.py','*.json','*.npz'] for p in (BASE/'ctc').glob(ext)]
    assert len(set(runtime_names))==len(runtime_names)==28
    core_names=set(runtime_names)-{'bot/practice.py','scripts/replay_practice_supervisor.py'}|{'docs/serialized-replay-plan.md','docs/serialized-forward-plan.md'}
    forward_names=core_names|{'bot/practice.py','scripts/replay_practice_supervisor.py','scripts/compare_practice_supervisor.py','docs/supervised-replay-plan.md','docs/practice-round-transition-plan.md','docs/supervised-forward-plan.md'}
    candidate_names=set(runtime_names)|{'scripts/compare_cleanup_retry_forward.py','docs/cleanup-retry-window-plan.md','docs/cleanup-retry-forward-plan.md'}
    expected_sources=set();blobs={};runtime_changes=[]
    for root,rev,names in [(SOURCE,REV,candidate_names),(BASE,BASE_REV,runtime_names),(REFERENCE,REFERENCE_REV,core_names),(FORWARD,FORWARD_REV,forward_names)]:
        for n in names:
            p=root/n;b=git(root,'show',rev+':'+n);assert p.read_bytes()==b
            expected_sources.add(str(p));blobs[rev+':'+n]=sha(b)
    for n in runtime_names:
        assert (SOURCE/n).read_bytes()==git(SOURCE,'show',RUNTIME_REV+':'+n)
        assert (FORWARD/n).read_bytes()==git(FORWARD,'show',BASE_REV+':'+n)
        if (SOURCE/n).read_bytes()!=(BASE/n).read_bytes():runtime_changes.append(n)
    assert runtime_changes==['bot/practice.py']
    expected_sources.update(str(p) for p in [RUN/'spec.json',Path(entry['input']),Path(entry['forward_spec']),Path(item['observations']),Path(item['feed'])])
    for name,h in entry['archive_sha256'].items():assert digest(original/name)==h;expected_sources.add(str(original/name))
    core=Path(item['archive_results']).parent
    for name in ['results','metadata','summary']:
        p=core/('results.jsonl' if name=='results' else name+'.json')
        assert digest(p)==item['archive_'+name+'_sha256'];expected_sources.add(str(p))
    original_rows=rows(original/'results.jsonl');original_index={key(r):r for r in original_rows}
    assert len(original_rows)==len(original_index)==16 and set(original_index)==GRID
    original_meta=load(original/'metadata.json');original_summary=load(original/'summary.json')
    assert original_meta['spec']==upstream_spec and original_meta['phase']=='supervised'
    assert original_meta['source_revision']==original_meta['driver_revision']==FORWARD_REV
    assert original_meta['runtime_revision']==BASE_REV
    assert original_meta['fraction']==.1 and original_meta['loss_trigger']==250 and original_meta['prior_pnl']==0
    assert original_summary['runs']==16 and original_summary['errors']==original_summary['mismatches']==0 and original_summary['changed_sources']==[]
    assert original_summary['results_sha256']==digest(original/'results.jsonl')
    assert original_meta['captures'][0]['frames_sha256']==vh(frames) and original_meta['captures'][0]['receipt_sha256']==vh(receipt)
    assert all(r['status']=='ok' and r['errors']==[] and r['comparison_status']=='supervised_after_verified_baseline' for r in original_rows)
    for k in original_index:expected_sources.update(str(original/dirname(k)/f) for f in JOURNALS)
    assert expected_sources==set(source_map),(sorted(expected_sources-set(source_map)), sorted(set(source_map)-expected_sources))
    # Independently re-extract the same closed sealed frames; this is parsing, not a strategy replay.
    sys.path.insert(0,str(SOURCE))
    from scripts.evaluate_observed_season import observed_capture
    extracted_receipt,extracted_frames,extracted_coverage=observed_capture(item['observations'],item['feed'],CID,case['limits'])
    assert extracted_receipt==receipt and extracted_frames==frames
    assert extracted_coverage==original_meta['captures'][0]['coverage']
    # Confirm reference -> baseline -> supervised artifacts exist and their completion precedes this comparison.
    upstream_phases={};previous=receipt['at']
    for phase in ['reference','baseline','supervised']:
        p=original.parent/phase;m=load(p/'metadata.json');s=load(p/'summary.json');rr=rows(p/'results.jsonl')
        assert s['runs']==16 and s['errors']==s['mismatches']==0 and s['changed_sources']==[]
        assert s['results_sha256']==digest(p/'results.jsonl')
        assert previous<=m['started_at']<=s['finished_at']<metas['baseline']['started_at']
        previous=s['finished_at'];upstream_phases[phase]={'started_at':m['started_at'],**s}
    assert load(original.parent/'baseline/metadata.json')['reference_results_sha256']==upstream_phases['reference']['results_sha256']
    assert original_meta['reference_results_sha256'] is None
    assert original_meta['baseline_results_sha256']==upstream_phases['baseline']['results_sha256']
    # Approved preflight and the retained earlier rejected counterexamples are both bound.
    packed=verify_tar(PARENT/'preflight-final-approved.tar.gz',359,'e9ab0c1026422fb42155f5957476f6296a0fffc4658a6b6a1c8119e380c6c142')
    preflight=json.loads(packed['verdict.json']);assert preflight['head']==REV and preflight['blockers']==[]
    assert preflight['verdict']=='APPROVE_FIXED_OFFLINE_FORWARD_COMPARISON'
    rejected=verify_tar(PARENT/'preflight-initial-rejected.tar.gz',134,'fa281c52dab08a04d6f7a90f4f1a5a996180e3612ee91dcfbc702a86c26c4948')
    assert packed['initial-blocked-review.tar.gz']==(PARENT/'preflight-initial-rejected.tar.gz').read_bytes()
    # Bind the original-engine causal audit and exact weather-overlap evidence without new original-engine runs.
    original_audit_dir=ROOT/'out/capture-248-independent-review-20261024'
    original_audit_pack=verify_tar(ROOT/'out/capture-248-independent-review-20261024.tar.gz',203,'e8105c703cb088aff4d7bbc29e7c7fa2d2a4ed828be14193cf2f4fd38ff6efbd')
    for n,b in original_audit_pack.items():assert (original_audit_dir/n).read_bytes()==b
    original_audit=load(original_audit_dir/'audit.json');original_verification=load(original_audit_dir/'verification.json')
    cached_original=load(original_audit_dir/'248.json');assert cached_original['frames']==frames and cached_original['receipt']==receipt
    assert [r['exact_library_rows_zero_based'] for r in original_audit['overlap']]==[[741],[742],[743]]
    assert all(r['observations']==241 and r['closest_rmse']==0 for r in original_audit['overlap'])
    assert original_audit['npz_sha256']==digest(SOURCE/'ctc/analog_library.npz')
    analysis=load(RUN/'analysis.json');indexed={};file_hashes={};metrics={};checks=[]
    total_mutations={};original_exact=0
    for phase in ['baseline','candidate']:
        rr=rows(RUN/phase/'results.jsonl');indexed[phase]={key(r):r for r in rr};m=metas[phase];s=summaries[phase]
        assert len(rr)==len(indexed[phase])==16 and set(indexed[phase])==GRID
        assert len(m['grid'])==16 and set(map(tuple,m['grid']))==GRID
        assert m['candidate_revision']==REV and m['baseline_revision']==BASE_REV and m['runtime_changes']==['bot/practice.py']
        assert m['phase']==phase and m['spec']==spec
        assert s['runs']==16 and s['errors']==0 and s['changed_sources']==s['forbidden_attempts']==[]
        assert s['results_sha256']==digest(RUN/phase/'results.jsonl')
        assert previous<=m['started_at']<=s['finished_at'];previous=s['finished_at']
        pnl=[r['terminal_settlement_pnl'] for r in rr]
        metrics[phase]=dict(positive=sum(x>0 for x in pnl),negative=sum(x<0 for x in pnl),mean=statistics.mean(pnl),minimum=min(pnl),maximum=max(pnl),
          cleanup=dict(Counter(r['cleanup']['state'] for r in rr)),trial=dict(Counter(r['trial_state'] for r in rr)),loss_stops=0,loss_cleanup_mean=None,
          results_sha256=s['results_sha256'],finished_at=s['finished_at'],lowest_marked_pnl=min(r['lowest_marked_pnl'] for r in rr),
          maximum_marked_drawdown=max(r['maximum_marked_drawdown'] for r in rr),maximum_rolling_mutations=max(r['maximum_rolling_mutations'] for r in rr),
          extra_pass_mutations=sum(r['extra_pass_mutations'] for r in rr))
        assert metrics[phase]==analysis['summaries'][phase]
        total_mutations[phase]=0
        for k,r in indexed[phase].items():
            finite(r);assert r['status']=='ok' and r['errors']==[] and r['trial_state']=='completed' and r['cleanup']['state']=='settled'
            assert r['stop_reason']=='requested complete practice seasons recorded' and r['terminal_closed'] is True
            assert r['history_block_reason'] is None and r['final_report_rounds']==[1,2,3]
            assert r['request_count']==sum(r['request_counts'].values()) and r['extra_pass_mutations']==0
            assert r['fills_after_final_receipt_requests']==0
            if phase=='baseline':
                assert r['comparison_status']=='exact_archive'
                for f,v in original_index[k].items():
                    if f!='comparison_status':assert r[f]==v,(k,f)
            else:
                assert r['comparison_status']=='identical_before_cleanup'
                for f,v in indexed['baseline'][k].items():
                    if f not in ['comparison_status','journal_sha256']:assert r[f]==v,(k,f)
            d=RUN/phase/dirname(k);assert {p.name for p in d.iterdir() if p.is_file()}==set(FILES)
            assert set(r['journal_sha256'])==set(FILES)
            for f,h in r['journal_sha256'].items():
                assert digest(d/f)==h;file_hashes[str(d/f)]=h
                if f in JOURNALS:
                    assert (d/f).read_bytes()==(original/dirname(k)/f).read_bytes()
                    if phase=='baseline':original_exact+=1
            status=load(d/'status.json');assert status['fraction']==.1 and status['loss_trigger']==250 and status['target_seasons']==1
            profile=load(d/'cleanup-profile.json');mut=load(d/'mutation-profile.json')
            first5=[p['request'] for p in profile if p['cleanup_attempt'] is not None and p['cleanup_attempt']<5]
            assert vh(first5)==r['first_five_requests_sha256']
            assert all(p['cleanup_attempt'] is None or 0<=p['cleanup_attempt']<5 for p in profile)
            assert all(p['request']['method']=='GET' for p in profile)
            window=deque();maximum=0;lastindex=-1;lasttime=-math.inf
            assert len(mut)==sum(v for endpoint,v in r['request_counts'].items() if endpoint.startswith(('POST ','DELETE ')))
            for event in mut:
                assert event['method'] in ('POST','DELETE') and lastindex<event['request_index']<r['request_count'] and lasttime<=event['started_at']
                lastindex,lasttime=event['request_index'],event['started_at']
                while window and window[0]<lasttime-60:window.popleft()
                window.append(lasttime);assert len(window)==event['rolling_60s']<=180
                maximum=max(maximum,len(window));assert event['cleanup_attempt'] is None or event['cleanup_attempt']<5
            assert maximum==r['maximum_rolling_mutations'];total_mutations[phase]+=len(mut)
            if phase=='candidate':
                bprofile=load(RUN/'baseline'/dirname(k)/'cleanup-profile.json')
                normalized=lambda pp:[{**p,'stack':[{f:v for f,v in s.items() if f!='line'} for s in p['stack']]} for p in pp]
                assert normalized(profile)==normalized(bprofile)
                assert (d/'mutation-profile.json').read_bytes()==(RUN/'baseline'/dirname(k)/'mutation-profile.json').read_bytes()
            checks.append(dict(phase=phase,setting=k,pnl=r['terminal_settlement_pnl'],cleanup='settled',profile_requests=len(profile),
                               mutations=len(mut),maximum_rolling_mutations=maximum,nonzero_settled_positions={s:v for s,v in r['server_positions_after_final_receipt'].items() if v}))
    assert original_exact==112 and len(file_hashes)==288
    assert len(metas['candidate']['baseline_artifact_sha256'])==147
    expected_baseline_artifacts={str(RUN/'baseline'/f) for f in ['metadata.json','results.jsonl','summary.json']}
    expected_baseline_artifacts.update(p for p in file_hashes if '/baseline/' in p)
    assert set(metas['candidate']['baseline_artifact_sha256'])==expected_baseline_artifacts
    assert {p:digest(p) for p in expected_baseline_artifacts}==metas['candidate']['baseline_artifact_sha256']
    assert analysis['failed_rules']==analysis['residual_increases']==analysis['residual_reductions']==[]
    assert analysis['pre_cleanup_pairs_equal']==analysis['first_five_passes_equal']==analysis['unchanged_pnl']==16
    assert analysis['improved_pnl']==analysis['worsened_pnl']==0
    assert metrics['candidate']['positive']==16 and metrics['candidate']['negative']==0 and metrics['candidate']['maximum_rolling_mutations']==25
    primary=indexed['candidate'][(248,.25,1.,True)];close(primary['terminal_settlement_pnl'],985.54)
    close(primary['final_receipt']['pnl'],986.42)
    assert len([q for q in primary['server_positions_after_final_receipt'].values() if q])==7 and primary['final_receipt']['flat'] is False
    # Retain only this capture's already completed attempt entries, not other capture records.
    events=[]
    for line in (PARENT/'attempts.jsonl').open():
        if '248' not in line:continue
        event=json.loads(line)
        if event.get('capture')==248:events.append(event)
    for phase in ['baseline','candidate']:
        completed=[e for e in events if e['kind']=='phase_completed' and e['phase']==phase]
        assert len(completed)==1 and completed[0]['exit_status']==0 and completed[0]['summary']==summaries[phase]
        for f,h in completed[0]['artifact_sha256'].items():assert digest(RUN/phase/f)==h
    commit_times={rev:int(git(SOURCE,'show','-s','--format=%ct',rev)) for rev in ['fd35a1e',RUNTIME_REV,REV]}
    assert frames[0]['received_at']<commit_times[RUNTIME_REV]<commit_times['fd35a1e']<commit_times[REV]<receipt['at']<metas['baseline']['started_at']
    assert before=={p:digest(p) for p in source_map} and FORBIDDEN==[]
    for root in (SOURCE,BASE,FORWARD,REFERENCE):assert not git(root,'status','--porcelain','--untracked-files=no')
    result=dict(verdict='ALL_CAPTURE_248_OFFLINE_NO_OP_GATES_VERIFIED_PENDING_RERUN_PACKAGE',source_revision=REV,runtime_revision=RUNTIME_REV,
        source_input_artifacts_verified=244,source_input_sha256=before,source_manifest_complete=True,runtime_files_identical_to_27ab7c4=28,
        frozen_git_blobs_verified=blobs,source_changes=[],forbidden_attempts=FORBIDDEN,original_rows_exact=16,original_journals_byte_exact=112,
        produced_files_sha256=file_hashes,produced_files_verified=288,paired_runtime_rows_identical=16,paired_standard_files_byte_identical=112,
        paired_mutation_profiles_byte_identical=16,paired_cleanup_profiles_equal_except_source_line_numbers=16,bound_baseline_artifacts=147,
        metrics=metrics,checks=checks,total_mutations=total_mutations,extra_mutations=0,cleanup_mutations=0,
        timing=dict(first_frame_at=frames[0]['received_at'],last_frame_at=frames[-1]['received_at'],receipt_at=receipt['at'],commit_times=commit_times,
                    baseline_started=metas['baseline']['started_at'],baseline_finished=summaries['baseline']['finished_at'],
                    candidate_started=metas['candidate']['started_at'],candidate_finished=summaries['candidate']['finished_at'],
                    runtime_and_declaration_after_capture_started=True,corrected_driver_frozen_before_receipt=True,fully_prospective_capture=False),
        sealed_inputs=sealed,frame_count=len(frames),frames_sha256=vh(frames),receipt_sha256=vh(receipt),coverage=extracted_coverage,
        upstream_phase_checks=upstream_phases,original_audit_archive_sha256='e8105c703cb088aff4d7bbc29e7c7fa2d2a4ed828be14193cf2f4fd38ff6efbd',
        original_audit_members_verified=203,original_audit_verification_sha256=digest(original_audit_dir/'verification.json'),
        original_weather_overlap=original_audit['overlap'],original_audit_performance_reruns_reused=6,new_original_engine_runs=0,
        preflight_members_verified=359,rejected_preflight_members_verified=134,preflight=preflight,attempt_events=events,
        primary_terminal_pnl=primary['terminal_settlement_pnl'],primary_final_mark=primary['final_receipt']['pnl'],
        primary_settled_positions={s:v for s,v in primary['server_positions_after_final_receipt'].items() if v},
        limitations=['All pairs settle before extra retries; no incremental evidence of extra-pass effectiveness.',
          'Capture started before retry runtime, declaration and driver freezes; no fully prospective capture claim.',
          'Weather matches fitted rows 741-743; not unseen-weather validation.',
          'Recorded quote completeness and disconnect count remain unknown; settled holdings are not flat; replay is not account profit.'])
    (OUT/'audit.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'verdict':result['verdict'],'source_inputs':244,'rows':32,'files':288,'original_journals':112,
      'no_op_pairs':16,'total_mutations_per_phase':total_mutations,'max_rolling':25,'extra_mutations':0,'primary':primary['terminal_settlement_pnl'],
      'mean':metrics['candidate']['mean'],'worst':metrics['candidate']['minimum'],'forbidden_attempts':FORBIDDEN},sort_keys=True))

if __name__=='__main__':main()
