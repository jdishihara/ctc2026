# Independent capture-248 bounded-retry result audit

## Judgment

**Pass the predeclared capture-248 no-op confirmation. No blocker to the previously approved integration was found. This is not live activation approval.** Source remains frozen at `2c441aee5b5f828bc4c4e26461159a958c102067`, with all 28 runtime files byte-identical to the already reviewed retry source `27ab7c4`.

## Complete comparison

Both phases contain the complete 16-setting grid: RTT 0/0.05/0.25/1 seconds, full/half displayed depth, baskets off/on, 10% limits, 90 strategy actions/minute, zero prior P&L and the $250 sampled loss trigger. All 32 rows and all 288 produced files/profiles verify. The baseline reproduces every original result field and all 112 original standard journals; the candidate preserves every runtime field and all 112 paired standard journals. All 16 mutation profiles are byte-identical. Cleanup profiles differ only in source stack line numbers introduced by the frozen code delta; their request contents are equal.

Both modes have 16 positive, completed, settled outcomes and zero attention cases. Mean terminal P&L is $897.993125; the range is $295.45 to $1,224.03. Primary terminal P&L is $985.54. The primary's contemporaneous final mark is $986.42 and it retains seven settled holdings, so it is not flat. No value is an actual account return.

All pre-cleanup and first-five hashes and stopping fields match. Across each complete phase, 1,376 actual POST/DELETE starts are represented, with a maximum inclusive trailing-60-second count of 25. No cleanup mutation or extra-pass mutation occurs. This capture adds a no-op compatibility check, not evidence of additional retry effectiveness.

All 32 analyzer pair descriptions, complete metrics, primary selection and no-regression decisions were independently derived from rows/profiles and match the frozen analyzer output. The supplied analyzer SHA matches; the separate reviewer's reported 27 synthetic analyzer checks were not rerun here.

## Exactly two authorized candidate reproductions

| Setting | Terminal P&L | Requests | Fills | Actual mutations | Maximum rolling mutations |
| --- | ---: | ---: | ---: | ---: | ---: |
| 0.25 s / full / baskets on | $985.54 | 4,557 | 61 | 80 | 9 |
| 1 s / half / baskets off | $295.45 | 2,204 | 59 | 67 | 7 |

Each reproduction matches every result field and all nine producer files, for 18 byte-exact files. Full request traces including GET response bodies and full fill traces are retained. Independent fill cash, ETF inventory transfers and terminal holdings reconcile the final P&L. Both runs have zero sticky guard violations. Guards check terminal-price availability, complete model/news readiness, competition identity, unchanged quote callback history, true execution-time cleanup reduction, rolling mutations and extra-pass budget admission. Across these two runs, there were 72 guarded settlement value reads and 116 history-ready strategy POST checks. There were zero cleanup POST checks or extra-budget checks because neither run used those paths.

Only these two settings were executed, once each. No new original-engine performance run occurred. The original audit's six reproductions are reused through its verified 203-file archive.

## Source, input and chronological checks

The complete 244-entry source/input manifest was independently reconstructed and hashed before/after. Current files match frozen Git blobs in the retry, original runtime, original forward driver and reference checkouts. Candidate metadata binds all 147 completed baseline artifacts. Both phases' chronology follows the fully completed original reference -> baseline -> supervised chain. The sealed observation/feed prefixes match exact byte lengths and hashes; parsing them reconstructs the identical 25,213 cached frames and official ready receipt. The complete news sequence is 0..864 with all three final reports.

- First selected frame: epoch 1792835258.5583282 (09:47:38.558 UTC).
- Retry runtime freeze: epoch 1792836560 (10:09:20 UTC).
- Follow-up declaration: epoch 1792837693 (10:28:13 UTC).
- Corrected driver freeze: epoch 1792838017 (10:33:37 UTC).
- Official closing receipt: epoch 1792838086.3271759 (10:34:46.327 UTC).
- Baseline execution: epochs 1792838454.9809642–1792838484.4532769.
- Candidate execution: epochs 1792838511.802965–1792838540.572074.

The corrected driver froze 69.327 seconds before the receipt, but the selected capture began before the runtime/declaration/driver freezes. This is not a fully prospective capture. The original independently verified weather audit finds exact 241-observation matches to fitted library rows 741, 742 and 743; it provides no unseen-weather validation. That audit is bound to the identical canonical frame and receipt hashes here, without an additional weather or original-engine performance run.

Recorded quote completeness remains unproven. The original audit records approximately 120.318 seconds from the first round-one snapshot to valid quotes, a later valid-quote gap of 52.438 seconds, and unknown disconnect count. These limitations remain relevant even though every prescribed result is positive.

## Failure retention

The initial rejected forward-driver preflight archive (134 files), corrected approved preflight archive (359 files, including the rejected archive), and their counterexamples remain retained. Their source heads and hashes verify.

This result audit's first read-only provenance pass failed because its harness initially expected the supervised metadata to include a direct reference-results hash. The actual schema binds supervised -> baseline -> reference. The corrected audit verifies both links. The first script and failure logs are retained. This caused no performance rerun and changed no production file. Both authorized candidate reruns passed on their first execution.

## Declined to judge

- Live ownership, activation, actual account returns or consistent profitability.
- Extra-pass effectiveness on this capture, because no such mutation occurred.
- Unseen-weather generalization or fully prospective validation.
- True quote completeness, disconnect onset, live priority, latency and market impact.
- Capture 249 or later outcomes, other settings, or strategy/model changes.

## Evidence

`verdict.json` is the final judgment. `audit.json` retains complete source/input/file hashes, rows, budgets, chronology, sealed-input checks and the original audit binding. `analysis-trace-check.json` checks all analyzer descriptors and both full traces. `authorized-reruns/` retains exactly two reproductions. `producer/` contains all 288 phase files, metadata/results/summaries, analysis, specification, logs and preflight archives. `original-capture-audit.tar.gz` preserves the independent original-engine/weather evidence. `artifact-manifest.json` seals this review and `archive-receipt.json` records its archive hash.
