# Independent original capture 248 audit

## Verdict

All requested original evidence checks and **exactly six authorized reproductions passed**. No blocker was found in the reported original results. This is virtual performance on one captured market path, with exact fitted-weather overlap and incomplete quote coverage; it is not live account attribution or unseen-weather validation.

CID: `789097b1-a48b-4e68-95b4-5e15b047e149`; fictional year 1779.

## Closure, timing and source gates

- Official receipt: **2026-10-24T10:34:46.327176+00:00**, epoch 1792838086.3271759. Both clocks are ready and identify the same CID/year; all 12 finite positive settlement prices and three final reports are present.
- Selected interval: **2026-10-24T09:47:38.558328+00:00** through **2026-10-24T10:34:42.529236+00:00**. All 25,213 selected frames precede the receipt.
- Original runtime freeze 1792828815 and supervisor-driver freeze 1792829252 both precede the selected interval. Serialized reference is `505a5ad2`; supervisor driver `c5c35a30`; runtime `cd3eb239`; fixed worker `49a690ef`. Frozen source hashes remain unchanged.
- Sealed observation/feed byte counts and hashes match the immutable spec. The sealed observation prefix also matches exactly that many bytes from the observer ledger; no later appended observations were read.
- All three phase artifacts match the supplied result hashes, report 16 rows/zero errors/zero mismatches/no source changes, and their completion events have exit 0. Prerequisite result hashes and phase timing are consistent.
- Closure was established before loading the approved selector or fitted NPZ. Guards denied network, credentials, downloaded history and manifests. No active 249 outcome was read.

## Original results

**88 original rows** were checked: 24 fixed-worker + 16 serialized + 48 reference/baseline/supervised comparison rows. The comparison rows repeat configurations; they are not 88 independent trials. Reference and baseline fields match the original serialized rows.

| Evaluation | Rows | Positive | Mean virtual P&L | Worst | Best |
|---|---:|---:|---:|---:|---:|
| Original fixed worker | 24 | 24 | 965.536250 | 919.12 | 1050.83 |
| Serialized client | 16 | 16 | 964.047500 | 493.54 | 1224.03 |
| Supervised client | 16 | 16 | 897.993125 | 295.45 | 1224.03 |

All 16 supervised trials are **completed and settled**, with no attention cases. Every one of the 16 settings has all seven standard journals, totaling **112 files**; results, status, observations, actions, startup feeds, final receipts and run locks reconcile. Ownership is clear, caps are respected and no fills occur after final receipt requests.

Primary `.25/full/on` terminal settlement P&L is **+$985.54**. Its final receipt's contemporaneous mark is **+$986.42**; these are different valuation bases. The primary is settled with seven nonzero symbol holdings and zero open orders, **not flat**. Settlement success must not be described as completed liquidation.

## Exactly six authorized reruns

| Evaluator | RTT / depth / baskets | Virtual P&L | Original fields |
|---|---|---:|---|
| serialized | 0.25 / 1.0 / on | 997.15 | exact |
| serialized | 1.0 / 0.5 / off | 493.54 | exact |
| supervised | 0.25 / 1.0 / on | 985.54 | exact |
| supervised | 1.0 / 0.5 / off | 295.45 | exact |
| supervised | 0.0 / 1.0 / off | 1194.09 | exact |
| worker | 0.25 / 1.0 / on | 1039.24 | exact |

All five serialized/supervised request and fill hashes match their original rows. The three supervised reruns additionally reproduce all seven journal files byte for byte: **21 identical files**. Cash plus holdings reconciles to terminal settlement in every rerun. The fixed-worker run uses current snapshot behavior (`reset_warmup_each_snapshot=False`); it has no HTTP requests, and its full virtual action/fill traces are retained. There were zero rerun failures and zero candidate-policy runs.

Each rerun retains its full request/fill traces, result, field comparison, source checks and guarded settlement-access timing. Serialized/worker settlement reads are confined to terminal scoring after market close; supervised reads additionally wait until receipt availability.

## Coverage and fitted-weather overlap

- News sequences 0–864 are contiguous, unique and complete: 865 messages. Final reports are at sequence 288/575/864 for rounds 1/2/3.
- 25,213 selected frames include 24,253 quote frames, 41 unusable quotes, and one subscription acknowledgement in round 3. Zero explicit disconnect frames were recorded; the acknowledgement may indicate a reconnect but cannot establish disconnect onset or reconstruct missed quotes.
- Initial round 1 snapshot-to-first-valid-quote delay is approximately 120.318 seconds. The largest later within-round valid-quote interval is **52.438055 seconds, RECON round 3**. Receive-time gaps do not prove missing server events, and quote-path completeness remains unproven.
- Every storm has all 241 observations at ages 0–480 by 2 seconds. Comparing all four channels `(x,y,radius,intensity)` after closure gives exact fitted NPZ matches at zero-based rows **741,742,743**, respectively; each closest RMSE is 0. No downloaded history or library-build manifest was opened.

Chronological evaluator freezes do not remove this training overlap. All scenario outcomes share one recorded path and should not be reported as an independent-trial success rate.

## Durable artifacts

- `audit.json`: original 88-row/112-file audit, full coverage, source hashes, phase events, receipt and track overlap.
- `verification.json`: independent news/gap recomputation and exact six-run reconciliation.
- `248.json`: reconstructed closed cache, exactly `{frames,receipt}`.
- `original/`: copied original result artifacts, sealed spec/observations, phase logs and 112 supervised journal files.
- `rerun-reference/`, `rerun-supervised/`, `rerun-worker/`: all six retained runs and complete traces. The `reference` directory denotes runs of the frozen serialized evaluator.
- `artifact-hashes.json`: every archived file hash; original source and input feed files are preserved at their existing paths and identified by hash.

| Object | SHA256 |
|---|---|
| Spec | `28a7f299a513ee14232861516dbbb08bb57c4657b15069c8fbc9daf1afa71301` |
| Sealed observations | `0daa9141a10ba4b23df7e5f1d90995ede71f6e62f43577a63b4e7cfea177e0dc` |
| Sealed feed | `734690b1b1e868113faf5af30caae0ae6d442408e1e7710a3b43f34a56ff1cd8` |
| Frames canonical value | `444689d84a43c4a3bb8f41ebed810599bc236ae345699930cdc950516c919475` |
| Receipt canonical value | `7b91d8fdaae8b25a125e9285cc8fb8a5a5d4cf60c69499f383965c6cc3480280` |
| Independently serialized cache file | `5614d61cc76b1fdb74192b1deab3a210eda938820c002a5945e9be8486e69759` |
| Fitted NPZ | `22694387c3b612f5c20853feb9143e1bf8b8f5722a845da8ed584ab1b30bdf09` |

Canonical value hashes match the original supervised metadata. A different JSON whitespace serialization can have a different raw cache hash while retaining these canonical values. This independent cache was preserved unchanged.

## Declined to judge

Actual account P&L, unobserved quote updates or liquidity, market impact and competing traders; generalization to unseen weather; retry-candidate performance; outcomes of active capture 249 or later. No live activation is implied by this audit.
