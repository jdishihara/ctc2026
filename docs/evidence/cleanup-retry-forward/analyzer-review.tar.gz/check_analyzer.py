"""Independent synthetic-only gates for the fixed forward analyzer; no replay."""
import collections
import contextlib
import copy
import difflib
import hashlib
import io
import itertools
import json
import math
from pathlib import Path
import runpy
import sys

OUT = Path(__file__).resolve().parent
BASE = OUT.parents[1]
ANALYZER = BASE/'out/cleanup-retry-forward-20261024/analyze.py'
PREVIOUS = BASE/'out/cleanup-retry-window-20261024/analyze.py'
EXPECTED = '6db56e6d7a72b0c770858c33723a1d58713dd1b17ad79bb222b6caca8f56ec75'
OLD_EXPECTED = '7abc2a98b45769399ce14e5622e8dabc8fcc236c8b499d71977c9b9a1e071010'
forbidden, opened = [], set()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def dump(path, obj):
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, allow_nan=False)+'\n')

new, old = ANALYZER.read_bytes(), PREVIOUS.read_bytes()
assert digest(new)==EXPECTED and digest(old)==OLD_EXPECTED
expected = old.decode().replace("args = parser.parse_args()", "parser.add_argument('--capture', type=int, choices=[248, 249], required=True)\nargs = parser.parse_args()")
expected = expected.replace('range(241, 248)', '[args.capture]').replace('== 112', '== 16')
expected = expected.replace("loss_cleanup_mean=statistics.mean(row['cleanup_completed_at'] - row['cleanup_started_at'] for row in loss),",
                            "loss_cleanup_mean=statistics.mean(row['cleanup_completed_at'] - row['cleanup_started_at'] for row in loss) if loss else None,")
expected = expected.replace("if not reductions:\n    failures.append('no improvement to residual holdings in attention outcomes')\n", '')
assert new.decode()==expected, 'Unexpected analyzer change'
(OUT/'forward-analyzer.py').write_bytes(new)
(OUT/'previous-analyzer.py').write_bytes(old)
(OUT/'analyzer.diff').write_text(''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='previous',tofile='forward')))

def guard(event,args):
    if event.startswith('socket.') or event=='subprocess.Popen':
        forbidden.append(event); raise RuntimeError('Network and subprocess forbidden')
    if event=='open' and isinstance(args[0],(str,bytes)):
        path=Path(args[0].decode() if isinstance(args[0],bytes) else args[0]).absolute()
        low=str(path).lower()
        if any(token in low for token in ('.botkey','/.env','credentials','/data/history/','/recordings/','manifest')):
            forbidden.append(str(path));raise RuntimeError('Forbidden data input')
        if path.is_relative_to(BASE):
            if not (path.is_relative_to(OUT) or path==ANALYZER):
                forbidden.append(str(path));raise RuntimeError('Only synthetic fixture files and exact analyzer may be read')
            opened.add(str(path))
sys.addaudithook(guard)

def grid(capture):
    return list(itertools.product([capture],[0.,.05,.25,1.],[1.,.5],[False,True]))

def base_rows(capture):
    rows=[]
    for c,r,d,b in grid(capture):
        rows.append(dict(capture=c,rtt_seconds=r,displayed_depth_fraction=d,basket_enabled=b,
            status='ok',errors=[],terminal_settlement_pnl=100.,cleanup={'state':'settled'},trial_state='completed',
            stop_reason='complete',cleanup_started_at=10.,cleanup_completed_at=20.,
            server_positions_after_final_receipt={},server_orders_after_final_receipt=[],
            lowest_marked_pnl=0.,maximum_marked_drawdown=10.,maximum_rolling_mutations=10,
            extra_pass_mutations=0,pre_cleanup_trace={'requests_sha256':'r','fills_sha256':'f'},
            first_five_requests_sha256='unchanged'))
    rows[0].update(cleanup={'state':'attention'},trial_state='incomplete_trial',stop_reason='loss trigger',
        server_positions_after_final_receipt={'REIN':-6})
    return rows

def write_phase(directory,rows,profiles,summary_change=None):
    directory.mkdir(parents=True,exist_ok=False)
    for row in rows:
        setting=tuple(row[n] for n in ['capture','rtt_seconds','displayed_depth_fraction','basket_enabled'])
        c,r,d,b=setting
        p=directory/f'capture-{c}-{r}-{d}-{int(b)}'
        p.mkdir(exist_ok=True)
        dump(p/'cleanup-profile.json',profiles.get(setting,[]))
    data=b''.join((json.dumps(row,sort_keys=True,allow_nan=False)+'\n').encode() for row in rows)
    (directory/'results.jsonl').write_bytes(data)
    summary=dict(runs=16,errors=0,changed_sources=[],forbidden_attempts=[],results_sha256=digest(data),finished_at=1.)
    if summary_change:summary.update(summary_change)
    dump(directory/'summary.json',summary)

tests=[
    ('residual_reduction',[],False),
    ('no_op_confirmation',[],False),
    ('no_loss_stops',[],False),
    ('no_op_capture249',[],False),
    ('worse_worst',['worse worst terminal P&L'],False),
    ('negative_increase',['worse worst terminal P&L','more negative settings','new negative setting'],False),
    ('zero_to_negative',['worse worst terminal P&L','more negative settings','new negative setting'],False),
    ('new_negative_same_total',['new negative setting'],False),
    ('new_attention',['new attention setting'],False),
    ('residual_increase',['increased absolute residual exposure'],False),
    ('primary_regression_retained',[],False),
    ('profile_metrics',[],False),
    ('mutation_boundary180',[],False),
    ('pre_cleanup_changed',None,True),
    ('first_five_changed',None,True),
    ('mutation_ceiling181',None,True),
    ('source_change',None,True),
    ('forbidden_access_summary',None,True),
    ('error_summary',None,True),
    ('duplicate_grid',None,True),
    ('missing_grid_row',None,True),
    ('wrong_capture',None,True),
    ('wrong_rtt',None,True),
    ('error_row',None,True),
    ('results_hash_mismatch',None,True),
]
results=[]
for name,failures,rejects in tests:
    capture=249 if name=='no_op_capture249' else 248
    baseline=base_rows(capture);candidate=copy.deepcopy(baseline)
    candidate[0].update(cleanup={'state':'flat'},server_positions_after_final_receipt={})
    changes,profiles={},{}
    if name in ('no_op_confirmation','no_op_capture249'):candidate=copy.deepcopy(baseline)
    elif name=='no_loss_stops':
        for phase in (baseline,candidate):
            phase[0].update(cleanup={'state':'settled'},trial_state='completed',stop_reason='complete',server_positions_after_final_receipt={})
    elif name=='worse_worst':candidate[1]['terminal_settlement_pnl']=99.
    elif name=='negative_increase':candidate[1]['terminal_settlement_pnl']=-1.
    elif name=='zero_to_negative':
        baseline[1]['terminal_settlement_pnl']=0.;candidate[1]['terminal_settlement_pnl']=-1.
    elif name=='new_negative_same_total':
        baseline[1]['terminal_settlement_pnl']=-10.;candidate[2]['terminal_settlement_pnl']=-1.
    elif name=='new_attention':candidate[1].update(cleanup={'state':'attention'},server_orders_after_final_receipt=[{'id':'unconfirmed'}])
    elif name=='residual_increase':candidate[1]['server_positions_after_final_receipt']={'REIN':1}
    elif name=='primary_regression_retained':
        baseline[9]['terminal_settlement_pnl']=200.;candidate[9]['terminal_settlement_pnl']=150.
    elif name=='mutation_boundary180':candidate[0]['maximum_rolling_mutations']=180
    elif name=='pre_cleanup_changed':candidate[0]['pre_cleanup_trace']['fills_sha256']='changed'
    elif name=='first_five_changed':candidate[0]['first_five_requests_sha256']='changed'
    elif name=='mutation_ceiling181':candidate[0]['maximum_rolling_mutations']=181
    elif name=='source_change':changes['changed_sources']=['synthetic-source.py']
    elif name=='forbidden_access_summary':changes['forbidden_attempts']=['synthetic forbidden event']
    elif name=='error_summary':changes['errors']=1
    elif name=='duplicate_grid':candidate[-1]=copy.deepcopy(candidate[0])
    elif name=='missing_grid_row':candidate.pop()
    elif name=='wrong_capture':
        for row in candidate:row['capture']=249
    elif name=='wrong_rtt':candidate[0]['rtt_seconds']=3.
    elif name=='error_row':candidate[0]['status']='error'
    elif name=='results_hash_mismatch':changes['results_sha256']='bad'
    elif name=='profile_metrics':
        def request(method,path,start,body=None,response=None):
            return {'request':dict(method=method,path=path,started_at=start,executed_at=start+.1,
                completed_at=start+.2,body=body,response=response)}
        old=dict(trade_id='old',executed_at='9.0');first=dict(trade_id='first',executed_at='10.95');second=dict(trade_id='second',executed_at='11.5')
        profiles[grid(capture)[0]]=[request('GET','/orderbook/REIN?depth=1',10.),
            request('POST','/orders',10.8,{'symbol':'REIN'}),
            request('GET','/trades',11.,response={'trades':[old,first]}),
            request('GET','/trades',12.,response={'trades':[first,second]})]
    root=OUT/'synthetic'/name
    write_phase(root/'baseline',baseline,profiles)
    write_phase(root/'candidate',candidate,profiles,changes)
    argv=sys.argv;text=io.StringIO();error=None
    try:
        sys.argv=[str(ANALYZER),str(root),'--capture',str(capture)]
        with contextlib.redirect_stdout(text):runpy.run_path(str(ANALYZER),run_name='__main__')
    except AssertionError as exc:error=type(exc).__name__
    finally:sys.argv=argv
    assert bool(error)==rejects,(name,error)
    if error:
        (root/'expected-error.txt').write_text(error+'\n')
    else:
        report=json.loads(text.getvalue())
        assert report['failed_rules']==failures,(name,report['failed_rules'])
        assert report['decision']==('reject' if failures else 'passes_declared_gates_pending_independent_review')
        assert report['pre_cleanup_pairs_equal']==report['first_five_passes_equal']==16
        assert len(report['pairs'])==16 and len(report['primary'])==1
        assert report['primary'][0]['setting']==[capture,.25,1.,True]
        if name in ('no_op_confirmation','no_op_capture249'):
            assert report['unchanged_pnl']==16 and not report['residual_reductions']
        if name=='no_loss_stops':
            assert all(s['loss_stops']==0 and s['loss_cleanup_mean'] is None for s in report['summaries'].values())
        if name=='primary_regression_retained':
            assert report['worsened_pnl']==1 and report['primary'][0]['pnl_delta']==-50.
        if name=='profile_metrics':
            p=report['pairs'][0]['candidate']
            assert p['requests']==4 and p['closing_orders']==1 and p['observed_cleanup_fills']==2
            for field,value in [('request_seconds',.8),('min_book_age',.8),('max_book_age',.8),('first_closing_order_after',.9),('last_observed_cleanup_fill_after',1.5)]:
                assert math.isclose(p[field],value,abs_tol=1e-8),(field,p[field])
        dump(root/'analysis.json',report)
    results.append(dict(case=name,expected_assertion=rejects,actual_exception=error,expected_failed_rules=failures,passed=True))

for name,cli in [('missing_capture',[]),('invalid_capture',['--capture','247'])]:
    argv=sys.argv;stderr=io.StringIO();exit_code=None
    try:
        sys.argv=[str(ANALYZER),str(OUT/'not-read')]+cli
        with contextlib.redirect_stderr(stderr):runpy.run_path(str(ANALYZER),run_name='__main__')
    except SystemExit as exc:exit_code=exc.code
    finally:sys.argv=argv
    assert exit_code==2
    (OUT/(name+'.stderr.log')).write_text(stderr.getvalue())
    results.append(dict(case=name,expected_exit=2,actual_exit=exit_code,passed=True))
assert digest(ANALYZER.read_bytes())==EXPECTED and not forbidden
report=dict(analyzer_sha256=EXPECTED,previous_analyzer_sha256=OLD_EXPECTED,
    exact_diff_matches_declared_changes=True,synthetic_cases=len(results),cases=results,
    performance_runs=0,actual_capture_results_read=False,forbidden_attempts=forbidden,
    limits=['Analyzer trusts producer hashes and maxima; independent result audit must recompute them from profiles.',
            'The frozen comparison driver enforces stopping/prefix identity, extra-pass90 budget and provenance; this is not a replacement for that audit.',
            'Worst/paired P&L tolerance remains1e-7; new-negative transitions use exact zero.',
            'Run with assertions enabled; malformed/untrusted schema validation is not newly added by this diff.'],
    repository_files_opened=sorted(opened))
dump(OUT/'review.json',report)
receipt={str(p.relative_to(OUT)):dict(bytes=p.stat().st_size,sha256=digest(p.read_bytes()))
    for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='hash-receipt.json'}
dump(OUT/'hash-receipt.json',dict(files=receipt,analyzer_sha256=EXPECTED,performance_runs=0,all_synthetic_checks_passed=True))
print(json.dumps(dict(synthetic_cases=len(results),all_passed=True,exact_diff_matches=True,performance_runs=0,
    forbidden_attempts=forbidden,receipt_sha256=digest((OUT/'hash-receipt.json').read_bytes())),indent=2))
